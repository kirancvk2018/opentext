# Quick Start Guide

## 1-Minute Setup

```bash
# Clone/extract project
cd Module4_Enterprise_Python_Demos

# Create virtual environment
python -m venv venv
source venv/Scripts/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env

# Done! Start learning
```

## Run Each Demo (5 minutes each)

### Demo 1: Network Programming

**Terminal 1:**
```bash
python src/demo1_network/network_server.py
```

**Terminal 2:**
```bash
python src/demo1_network/network_client.py
```

**Type:** `ping`, `time`, `info`, or `ECHO:message`

### Demo 2: XML Processing

```bash
python src/demo2_xml/xml_reader.py
python src/demo2_xml/xml_writer.py
python src/demo2_xml/xml_to_json.py
```

### Demo 3: GUI Employee App

```bash
python src/demo3_gui/employee_gui.py
```

Click buttons to Add/Edit/Delete employees

### Demo 4: Send Email

```bash
# First: Configure .env with Gmail credentials
python src/demo4_smtp/send_mail.py
```

### Demo 5: Language Integration

```bash
python src/demo5_integration/call_c.py
python src/demo5_integration/call_subprocess.py
```

## Open Jupyter Notebooks

```bash
jupyter notebook notebooks/
```

Open any `.ipynb` file to see complete lessons with:
- Learning objectives
- Theory with diagrams
- Code examples
- Exercises
- Solutions
- Interview questions

## Verify Installation

```bash
# Check Python
python --version  # Should be 3.12+

# Check imports
python -c "import tkinter; import socket; print('All good!')"

# Run a simple demo
python src/demo2_xml/xml_reader.py
```

## Common Issues

| Issue | Solution |
|-------|----------|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` |
| Port already in use | Change `SERVER_PORT` in `.env` |
| Tkinter error | Ubuntu: `sudo apt-get install python3-tk` |
| SMTP auth failed | Check Gmail app password in `.env` |

## Next Steps

1. ✅ Complete installation
2. 📚 Read `README.md` for overview
3. 🎓 Start with `01_NetworkProgramming.ipynb`
4. 🎯 Run each demo sequentially
5. 💡 Complete exercises
6. 🚀 Build your own project

## Documentation Files

- `README.md` - Full project documentation
- `INSTALLATION.md` - Detailed setup instructions
- `QUICK_START.md` - This file (30 seconds)
- `LAB_MANUAL.md` - Exercises and solutions
- `INSTRUCTOR_GUIDE.md` - Teaching notes
- `TROUBLESHOOTING.md` - Common problems
- `ARCHITECTURE.md` - System design details

## Project Structure

```
Module4_Enterprise_Python_Demos/
├── src/
│   ├── demo1_network/     ← Network programming
│   ├── demo2_xml/         ← XML processing
│   ├── demo3_gui/         ← Desktop app
│   ├── demo4_smtp/        ← Email automation
│   ├── demo5_integration/ ← C/Java/PowerShell
│   ├── config.py          ← Settings
│   └── utils.py           ← Utilities
├── notebooks/             ← Jupyter notebooks
├── docs/                  ← Documentation
├── assets/                ← Sample data
├── outputs/               ← Generated files
├── requirements.txt       ← Python packages
├── .env.example           ← Environment template
└── README.md              ← Full documentation
```

## Learning Path (4 hours)

| Time | Activity | Demo |
|------|----------|------|
| 0:00 - 0:45 | Network Programming | Demo 1 |
| 0:45 - 1:30 | XML Processing | Demo 2 |
| 1:30 - 2:20 | GUI Development | Demo 3 |
| 2:20 - 2:50 | Email Automation | Demo 4 |
| 2:50 - 3:20 | Language Integration | Demo 5 |
| 3:20 - 4:00 | Exercises & Q&A | All |

## Key Commands

```bash
# Activate environment
source venv/Scripts/activate

# Install/update packages
pip install -r requirements.txt

# Run tests
pytest src/ -v

# Format code
black src/

# Check types
mypy src/

# Run a demo
python src/demo1_network/network_server.py

# Open Jupyter
jupyter notebook

# Deactivate environment
deactivate
```

## Get Help

- 📖 **Python Docs**: https://docs.python.org/3/
- 🔍 **Stack Overflow**: Search for your error message
- 💬 **GitHub Issues**: Create an issue with details
- 📧 **Email**: Contact instructor

---

**Ready to learn? Start with Demo 1!** 🚀
