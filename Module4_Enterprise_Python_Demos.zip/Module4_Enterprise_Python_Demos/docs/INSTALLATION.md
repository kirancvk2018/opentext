# Installation Guide

## Prerequisites

- **Python 3.12+** (recommended 3.13)
- **Visual Studio Code** (or any Python IDE)
- **Git** (for version control)
- **pip** or **conda** (Python package manager)
- **Windows/macOS/Linux** (tested on all platforms)

## Setup Instructions

### 1. Clone or Extract the Project

```bash
cd Module4_Enterprise_Python_Demos
```

### 2. Create Virtual Environment

#### Using venv (Recommended)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

#### Using conda

```bash
conda create -n module4 python=3.12
conda activate module4
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Environment Variables

```bash
# Copy template
cp .env.example .env

# Edit .env with your settings (especially SMTP credentials)
# On Windows: edit .env with your text editor
# On Unix:    nano .env
```

### 5. Create Output Directory

```bash
mkdir outputs
```

### 6. Verify Installation

```bash
python -c "import sys; print(f'Python {sys.version}')"
python -c "import tkinter; print('tkinter OK')"
python -m pytest src/ -v  # Run tests
```

## Platform-Specific Setup

### Windows

**Additional requirements for C integration:**
```bash
# Install MinGW (for compiling C code)
# Download from: https://www.mingw-w64.org/
# Or use: choco install mingw
```

**PowerShell setup:**
- Ensure PowerShell execution policy allows scripts:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### macOS

**Install Xcode Command Line Tools:**
```bash
xcode-select --install
```

**Install additional packages:**
```bash
brew install gcc
```

### Linux

**Install build essentials:**

**Ubuntu/Debian:**
```bash
sudo apt-get install build-essential python3-dev
```

**Fedora/RHEL:**
```bash
sudo dnf install gcc python3-devel
```

## Gmail SMTP Configuration

### Generate App Password

1. Go to **Google Account** → **Security**
2. Enable **2-Step Verification** (if not already enabled)
3. Create **App Password**:
   - Select "Mail"
   - Select "Windows/Mac/Linux"
   - Generate 16-character password
4. Copy password to `.env`:
   ```env
   SMTP_USERNAME=your-email@gmail.com
   SMTP_PASSWORD=xxxx-xxxx-xxxx-xxxx
   ```

### Test SMTP Connection

```bash
python src/demo4_smtp/send_mail.py
```

## Verify Each Demo

### Demo 1: Network Programming

**Terminal 1 - Start server:**
```bash
python src/demo1_network/network_server.py
```

**Terminal 2 - Start client:**
```bash
python src/demo1_network/network_client.py
```

**Expected output:**
- Server: "✓ Server listening on localhost:5000"
- Client: "✓ Connected to server"

### Demo 2: XML Processing

```bash
python src/demo2_xml/xml_reader.py
python src/demo2_xml/xml_writer.py
python src/demo2_xml/xml_to_json.py
```

**Expected output:**
- Sample XML files created in `assets/data/`
- JSON conversion in `outputs/`

### Demo 3: GUI

```bash
python src/demo3_gui/employee_gui.py
```

**Expected output:**
- GUI window opens with employee list

### Demo 4: SMTP

```bash
python src/demo4_smtp/send_mail.py
```

**Expected output:**
- (If configured) Email sent successfully
- (If not configured) Configuration instructions

### Demo 5: Integration

```bash
python src/demo5_integration/call_c.py
python src/demo5_integration/call_subprocess.py
```

**Expected output:**
- C library functions called
- System commands executed

## Using Jupyter Notebooks

### Install Jupyter (if not in requirements.txt)

```bash
pip install jupyter notebook ipykernel
```

### Start Jupyter Server

```bash
jupyter notebook
```

### Open Notebooks

Navigate to `notebooks/` and open:
- `01_NetworkProgramming.ipynb`
- `02_XML_Processing.ipynb`
- `03_GUI_Tkinter.ipynb`
- `04_SMTP.ipynb`
- `05_Integration.ipynb`

## Troubleshooting

### ModuleNotFoundError

```bash
# Reinstall requirements
pip install --upgrade -r requirements.txt

# Check Python path
python -c "import sys; print(sys.path)"
```

### Port Already in Use

```bash
# Change port in .env
SERVER_PORT=5001
```

**Check Windows ports:**
```bash
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### SMTP Authentication Error

```bash
# Verify Gmail app password is 16 characters
# Ensure 2-Step Verification is enabled
# Check .env has correct credentials
```

### Tkinter Import Error

**Windows:**
```bash
# Tkinter is included with Python
# If missing, reinstall Python with "tcl/tk and IDLE" checked
```

**Linux:**
```bash
# Ubuntu/Debian
sudo apt-get install python3-tk

# Fedora
sudo dnf install python3-tkinter
```

### C Compilation Error

```bash
# Windows: Install MinGW
choco install mingw

# macOS: Install Xcode tools
xcode-select --install

# Linux: Install build tools
sudo apt-get install build-essential
```

## Virtual Environment Management

### Deactivate Environment

```bash
deactivate
```

### Delete Environment

```bash
# On Windows
rmdir /s venv

# On Unix
rm -rf venv
```

### Recreate Environment

```bash
# After deleting
python -m venv venv
source venv/Scripts/activate  # Windows
source venv/bin/activate      # Unix
pip install -r requirements.txt
```

## IDE Configuration

### Visual Studio Code

1. **Open folder:** File → Open Folder → Select `Module4_Enterprise_Python_Demos`

2. **Select Python interpreter:**
   - `Ctrl+Shift+P` → "Python: Select Interpreter"
   - Choose `./venv/Scripts/python.exe` (Windows) or `./venv/bin/python` (Unix)

3. **Install extensions:**
   - Python
   - Pylance
   - Jupyter

### PyCharm

1. **Open project:** File → Open → Select project folder

2. **Configure interpreter:**
   - Settings → Project → Python Interpreter
   - Add interpreter → Existing environment → Select `venv/bin/python`

## Development Tools

### Code Formatting

```bash
black src/
```

### Linting

```bash
flake8 src/
pylint src/
```

### Type Checking

```bash
mypy src/
```

### Testing

```bash
pytest src/ -v
pytest src/ --cov
```

## Next Steps

1. Complete installation verification
2. Open `README.md` for module overview
3. Start with `notebooks/01_NetworkProgramming.ipynb`
4. Run each demo sequentially
5. Complete exercises and challenges
6. Review best practices documentation

## Support

- **Python Docs:** https://docs.python.org/3/
- **Socket Programming:** https://docs.python.org/3/library/socket.html
- **Tkinter:** https://docs.python.org/3/library/tkinter.html
- **Email:** https://docs.python.org/3/library/smtplib.html

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Python | 3.10 | 3.13+ |
| RAM | 2 GB | 4 GB+ |
| Disk | 500 MB | 1 GB+ |
| Network | Required for SMTP | Fast for optimal experience |

---

**Installation Complete!** 🎉

Ready to start training. Begin with Demo 1: Network Programming.
