# Module 4: Enterprise Python Demos

**Advanced Python Programming for Enterprise Applications**

## Overview

A comprehensive Visual Studio Code training project demonstrating five critical enterprise-grade Python applications. This 4-hour instructor-led training covers network programming, XML processing, GUI development, email automation, and language integration.

### Key Features

✅ **5 Independent Enterprise Demos**  
✅ **Production-Grade Code Quality**  
✅ **Complete Jupyter Notebooks**  
✅ **Architecture Diagrams (Mermaid)**  
✅ **Sample Data & Outputs**  
✅ **Exercises & Solutions**  
✅ **Professional Documentation**  

## Project Structure

```
Module4_Enterprise_Python_Demos/
├── src/
│   ├── demo1_network/          # Network Programming
│   ├── demo2_xml/               # XML Processing
│   ├── demo3_gui/               # GUI with Tkinter
│   ├── demo4_smtp/              # Email Automation
│   └── demo5_integration/       # Language Integration
├── notebooks/                   # Jupyter Notebooks
├── docs/                        # Documentation
├── assets/                      # Sample data & images
├── outputs/                     # Generated outputs
├── requirements.txt             # Dependencies
├── .env.example                 # Environment template
├── .gitignore                   # Git ignore rules
└── README.md                    # This file
```

## Target Audience

- Software Engineers
- Python Developers
- System Engineers
- Automation Engineers
- Intermediate Python Developers

## Training Objectives

After completing this module, participants will:

1. **Network Programming**: Build scalable socket-based applications with multi-threading
2. **XML Processing**: Parse, validate, and transform XML documents
3. **GUI Development**: Create professional desktop applications with Tkinter
4. **Email Automation**: Implement secure SMTP-based notification systems
5. **Language Integration**: Integrate Python with C, Java, PowerShell, and Bash

## Module Contents

### Demo 1: Network Programming
**Business Scenario**: Enterprise wants a lightweight network monitoring utility

- TCP/UDP servers and clients
- Multi-client chat application
- Network scanner
- File transfer over sockets
- Socket timeouts and threading

**Key Concepts**: `socket`, `threading`, `json`, `logging`

**Duration**: 45 minutes

### Demo 2: XML Processing
**Business Scenario**: Financial institution exchanges XML reports with external systems

- XML parsing and manipulation
- XML validation with XSD
- Convert XML to JSON/DataFrame
- Beautiful XML formatting
- XPath queries

**Key Concepts**: `xml.etree.ElementTree`, `xml.dom.minidom`, XPath

**Duration**: 45 minutes

### Demo 3: GUI Development
**Business Scenario**: Desktop Employee Management application

- Login authentication
- Employee CRUD operations
- Search and filtering
- CSV export
- Professional UI with themes

**Key Concepts**: `tkinter`, widgets, dialogs, event handling

**Duration**: 50 minutes

### Demo 4: SMTP Email
**Business Scenario**: Automated email notification system

- SMTP authentication
- HTML and plain text emails
- Multiple recipients, CC/BCC
- File attachments
- Email templates

**Key Concepts**: `smtplib`, `email`, authentication, templates

**Duration**: 30 minutes

### Demo 5: Language Integration
**Business Scenario**: Integrate Python with legacy enterprise applications

- Call C functions via ctypes
- Execute Java JAR files
- Invoke PowerShell scripts
- Run Bash commands
- Subprocess management

**Key Concepts**: `ctypes`, `subprocess`, inter-process communication

**Duration**: 30 minutes

## Quick Start

### Prerequisites

- Python 3.12+
- Visual Studio Code
- pip or conda
- Git

### Installation

1. **Clone or extract the project**
   ```bash
   cd Module4_Enterprise_Python_Demos
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/Scripts/activate  # Windows
   # or
   source venv/bin/activate      # macOS/Linux
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env with your settings (especially SMTP credentials)
   ```

5. **Open in VS Code**
   ```bash
   code .
   ```

## Running the Demos

### Demo 1: Network Programming
```bash
# Terminal 1: Start server
python src/demo1_network/network_server.py

# Terminal 2: Start client
python src/demo1_network/network_client.py

# Or run multi-client chat
# Terminal 1: Server
python src/demo1_network/chat_server.py

# Terminal 2+: Multiple clients
python src/demo1_network/chat_client.py
```

### Demo 2: XML Processing
```bash
python src/demo2_xml/xml_reader.py
python src/demo2_xml/xml_writer.py
python src/demo2_xml/xml_validator.py
```

### Demo 3: GUI Application
```bash
python src/demo3_gui/employee_gui.py
```

### Demo 4: Email Automation
```bash
# Configure SMTP credentials in .env first
python src/demo4_smtp/send_mail.py
```

### Demo 5: Language Integration
```bash
python src/demo5_integration/call_c.py
python src/demo5_integration/call_java.py
python src/demo5_integration/powershell_demo.py
```

## Jupyter Notebooks

Open in Jupyter Lab/Notebook:

```bash
jupyter notebook notebooks/01_NetworkProgramming.ipynb
jupyter notebook notebooks/02_XML_Processing.ipynb
jupyter notebook notebooks/03_GUI_Tkinter.ipynb
jupyter notebook notebooks/04_SMTP.ipynb
jupyter notebook notebooks/05_Integration.ipynb
```

## Documentation

- **Installation Guide**: `docs/INSTALLATION.md`
- **Lab Manual**: `docs/LAB_MANUAL.md`
- **Instructor Guide**: `docs/INSTRUCTOR_GUIDE.md`
- **Troubleshooting**: `docs/TROUBLESHOOTING.md`
- **Architecture**: `docs/ARCHITECTURE.md`

## Code Quality Standards

✅ **PEP-8 Compliant**  
✅ **Type Hints**  
✅ **Comprehensive Logging**  
✅ **Error Handling**  
✅ **Docstrings**  
✅ **Unit Tests**  

## Requirements

See `requirements.txt` for all dependencies:

- Core Libraries: socket, threading, xml, smtplib, ctypes, subprocess
- Data Processing: pandas, numpy
- Network: requests
- GUI: tkinter (built-in)
- Email: email-validator
- Testing: pytest
- Documentation: jupyter, ipykernel

## Environment Variables

Create `.env` file from `.env.example`:

```env
# SMTP Configuration
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM=your-email@gmail.com

# Email Recipients
EMAIL_TO=recipient@example.com
EMAIL_CC=cc@example.com
EMAIL_BCC=bcc@example.com

# Network Configuration
SERVER_HOST=localhost
SERVER_PORT=5000
TIMEOUT=30

# Logging
LOG_LEVEL=INFO
LOG_FILE=outputs/app.log
```

## Training Duration

- **Total**: 4 hours (instructor-led)
- Demo 1: 45 minutes
- Demo 2: 45 minutes
- Demo 3: 50 minutes
- Demo 4: 30 minutes
- Demo 5: 30 minutes
- Q&A & Wrap-up: 40 minutes

## Key Learning Outcomes

### Network Programming
- ✅ Design scalable socket-based architecture
- ✅ Implement multi-threaded servers
- ✅ Handle concurrent client connections
- ✅ Debug network communication issues

### XML Processing
- ✅ Parse and validate XML documents
- ✅ Transform XML to JSON/CSV/DataFrame
- ✅ Implement XPath queries
- ✅ Handle XML namespaces

### GUI Development
- ✅ Build professional desktop applications
- ✅ Implement MVC patterns
- ✅ Handle user authentication
- ✅ Create responsive UI layouts

### Email Automation
- ✅ Configure secure SMTP authentication
- ✅ Generate HTML email content
- ✅ Manage attachments
- ✅ Implement retry logic

### Language Integration
- ✅ Call C/C++ libraries from Python
- ✅ Execute Java applications
- ✅ Automate system administration tasks
- ✅ Manage inter-process communication

## Best Practices Demonstrated

✅ **Security**
- SMTP authentication with environment variables
- Input validation
- Error handling
- Secure subprocess execution

✅ **Reliability**
- Logging and monitoring
- Retry logic
- Timeout handling
- Exception handling

✅ **Maintainability**
- Type hints
- Docstrings
- Code comments
- Modular design

✅ **Performance**
- Connection pooling
- Threading and async patterns
- Resource management
- Efficient data structures

## Troubleshooting

### Common Issues

1. **ModuleNotFoundError**: Run `pip install -r requirements.txt`
2. **Port already in use**: Change `SERVER_PORT` in `.env`
3. **SMTP authentication failed**: Verify credentials in `.env`
4. **GUI won't open**: Check tkinter installation
5. **C compilation errors**: Install MinGW (Windows) or gcc (Linux/macOS)

See `docs/TROUBLESHOOTING.md` for detailed solutions.

## Interview Questions

### Network Programming
1. What's the difference between TCP and UDP?
2. How do you handle multiple clients in a server?
3. What is a socket timeout and why is it important?
4. How do you gracefully close a socket connection?

### XML Processing
1. What are the differences between DOM and SAX parsing?
2. How do you validate XML against a schema?
3. What are XML namespaces and why are they used?
4. How do you convert XML to JSON safely?

### GUI Development
1. What is the MVC pattern and how does it apply to GUIs?
2. How do you handle user input validation?
3. What are the best practices for responsive UI design?
4. How do you implement threading in GUI applications?

### Email Automation
1. How do you securely store SMTP credentials?
2. What's the difference between SMTP and IMAP?
3. How do you handle email delivery failures?
4. How do you create email templates?

### Language Integration
1. What are the pros and cons of ctypes vs. direct C binding?
2. How do you handle subprocess exit codes?
3. What security considerations exist when calling external commands?
4. How do you pass complex data structures between languages?

## Support & Resources

- **Python Documentation**: https://docs.python.org/3/
- **Socket Programming**: https://docs.python.org/3/library/socket.html
- **XML in Python**: https://docs.python.org/3/library/xml.html
- **Tkinter**: https://docs.python.org/3/library/tkinter.html
- **SMTP**: https://docs.python.org/3/library/smtplib.html

## License

Open Source - Educational Use

## Author

Enterprise Python Training Program

## Version

1.0.0 (2026)

---

**Happy Learning! 🚀**
