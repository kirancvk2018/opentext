# Getting Started with Module 4: Enterprise Python Demos

## Welcome! 👋

This is a complete Python training course covering five critical enterprise topics. This file will get you up and running in 5 minutes.

## What's Inside?

### 5 Complete Demos

1. **Network Programming** (45 min)
   - TCP/UDP client-server
   - Multi-threaded servers
   - Chat application
   - File transfer

2. **XML Processing** (45 min)
   - Parse and create XML
   - XPath queries
   - XML to JSON conversion
   - Data validation

3. **GUI Development** (50 min)
   - Employee management app
   - CRUD operations
   - Data validation
   - CSV export

4. **Email Automation** (30 min)
   - SMTP authentication
   - HTML emails
   - Attachments
   - Email templates

5. **Language Integration** (30 min)
   - Call C from Python
   - Execute Java apps
   - PowerShell/Bash scripts
   - System commands

### Complete Learning Materials

- 📚 5 Jupyter Notebooks with theory and examples
- 📖 Complete documentation with architecture diagrams
- 💻 Fully executable source code for each demo
- ✏️ Exercises and solutions
- 🧪 Error handling and best practices
- 🎓 Interview questions and quizzes

## Quick Start (5 Minutes)

### Step 1: Setup Environment

**Windows (PowerShell):**
```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

**macOS/Linux (Bash):**
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Step 2: Configure Settings

```bash
# Copy environment template
cp .env.example .env

# Edit if needed (for SMTP):
# Open .env and add Gmail credentials
```

### Step 3: Run Your First Demo

```bash
# Terminal 1: Start server
python src/demo1_network/network_server.py

# Terminal 2: Start client (in another terminal)
python src/demo1_network/network_client.py

# Type: ping, time, info, or ECHO:message
```

**That's it!** You now have a working network server and client.

## Run All Demos (5 Minutes Each)

```bash
# Demo 1: Network
python src/demo1_network/network_server.py  # Terminal 1
python src/demo1_network/network_client.py  # Terminal 2

# Demo 2: XML
python src/demo2_xml/xml_reader.py
python src/demo2_xml/xml_writer.py
python src/demo2_xml/xml_to_json.py

# Demo 3: GUI
python src/demo3_gui/employee_gui.py

# Demo 4: Email
python src/demo4_smtp/send_mail.py

# Demo 5: Integration
python src/demo5_integration/call_c.py
python src/demo5_integration/call_subprocess.py
```

## Open Jupyter Notebooks

```bash
# Start Jupyter
jupyter notebook

# Navigate to: notebooks/
# Open any .ipynb file to read lessons with:
# - Theory and architecture diagrams
# - Code examples
# - Exercises
# - Interview questions
```

## Project Structure

```
📁 Module4_Enterprise_Python_Demos/
├── 📁 src/                          # All source code
│   ├── 📁 demo1_network/           # Sockets, threading
│   ├── 📁 demo2_xml/                # XML parsing
│   ├── 📁 demo3_gui/                # Tkinter desktop app
│   ├── 📁 demo4_smtp/               # Email automation
│   ├── 📁 demo5_integration/        # Language integration
│   ├── config.py                    # Configuration
│   └── utils.py                     # Shared utilities
│
├── 📁 notebooks/                    # Jupyter notebooks
│   ├── 01_NetworkProgramming.ipynb
│   ├── 02_XML_Processing.ipynb
│   ├── 03_GUI_Tkinter.ipynb
│   ├── 04_SMTP.ipynb
│   └── 05_Integration.ipynb
│
├── 📁 docs/                         # Documentation
│   ├── INSTALLATION.md              # Detailed setup
│   ├── QUICK_START.md               # 1-minute start
│   └── (more docs...)
│
├── 📁 assets/data/                  # Sample data files
├── 📁 outputs/                      # Generated files
│
├── README.md                        # Full documentation
├── GETTING_STARTED.md               # This file
├── requirements.txt                 # Dependencies
├── .env.example                     # Configuration template
└── .gitignore                       # Git settings
```

## Common Commands

```bash
# Virtual environment
python -m venv venv              # Create
source venv/bin/activate         # Activate (Unix)
venv\Scripts\activate            # Activate (Windows)
deactivate                       # Deactivate

# Dependencies
pip install -r requirements.txt  # Install
pip install --upgrade package    # Update
pip list                         # List installed

# Running demos
python src/demo1_network/network_server.py
python src/demo2_xml/xml_reader.py
python src/demo3_gui/employee_gui.py
# ... etc

# Jupyter
jupyter notebook                 # Start server
jupyter notebook --ip=0.0.0.0   # Listen on all interfaces

# Code quality
black src/                       # Format code
flake8 src/                      # Lint
mypy src/                        # Type check
pytest src/                      # Run tests
```

## Prerequisites Checklist

- ✅ Python 3.12+ installed
- ✅ pip package manager
- ✅ Text editor or IDE (VS Code recommended)
- ✅ Command line/terminal
- ✅ Network connection (for SMTP demo)

## Troubleshooting

### "ModuleNotFoundError"
```bash
pip install -r requirements.txt
```

### Port already in use
Edit `.env`:
```env
SERVER_PORT=5001  # Change from 5000
```

### Tkinter not found (Linux)
```bash
sudo apt-get install python3-tk
```

### SMTP authentication failed
1. Ensure 2-Step Verification is enabled on Gmail
2. Generate app-specific password
3. Copy password to `.env` file
4. No spaces or special formatting

### "Address already in use"
```bash
# Windows - find and kill process
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/macOS
lsof -ti:5000 | xargs kill -9
```

## Learning Path

### Recommended Order
1. **First**: Read README.md (10 min overview)
2. **Then**: Open 01_NetworkProgramming.ipynb (20 min theory)
3. **Next**: Run network_server.py and network_client.py (10 min hands-on)
4. **Then**: Complete exercises (20 min)
5. **Repeat**: For each demo (4-5 hours total)

### By Experience Level

**Beginners:**
- Start with notebooks (theory first)
- Run demos as shown
- Complete basic exercises
- Focus on understanding concepts

**Intermediate:**
- Skim notebooks for new concepts
- Modify demos to understand behavior
- Solve all exercises
- Attempt challenges

**Advanced:**
- Focus on architecture and best practices
- Modify demos significantly
- Solve challenges immediately
- Consider building own projects

## IDE Setup (VS Code)

1. **Install extensions:**
   - Python (Microsoft)
   - Pylance (Microsoft)
   - Jupyter (Microsoft)

2. **Select Python interpreter:**
   - Ctrl+Shift+P → "Python: Select Interpreter"
   - Choose `./venv/bin/python`

3. **Configure debugging:**
   - Click "Run and Debug"
   - Select from pre-configured launchers
   - Available for each demo

4. **Use integrated terminal:**
   - Ctrl+` to open
   - Terminal already uses selected Python

## Key Features

✨ **Production-Quality Code**
- Type hints throughout
- Comprehensive logging
- Error handling
- PEP-8 compliant

📚 **Complete Documentation**
- Architecture diagrams (Mermaid)
- Code comments
- Usage examples
- Troubleshooting guides

🧪 **Real-World Scenarios**
- Network monitoring
- Financial XML reports
- Employee management
- Email notifications
- Language integration

🎓 **Educational**
- Learning objectives
- Step-by-step explanations
- Best practices
- Interview questions
- Quiz sections

## Time Commitment

- **Minimum**: 30 minutes (run one demo)
- **Quick**: 2 hours (all demos)
- **Complete**: 4 hours (demos + notebooks)
- **Thorough**: 8 hours (everything + exercises)

## Next Steps

1. ✅ Complete this setup
2. 📖 Read README.md
3. 💻 Run demo 1
4. 📚 Open 01_NetworkProgramming.ipynb
5. ✏️ Complete exercises
6. 🔄 Repeat for each demo
7. 🏆 Build something awesome!

## Need Help?

**Documentation:**
- README.md - Full overview
- INSTALLATION.md - Detailed setup
- QUICK_START.md - Super quick start
- docs/*.md - Specific topics

**Common Issues:**
- See docs/TROUBLESHOOTING.md
- Check .env configuration
- Verify Python version (3.12+)
- Ensure all dependencies installed

**Resources:**
- Python docs: https://docs.python.org/3/
- Real Python: https://realpython.com/
- Stack Overflow: Tag with `python`

## Let's Get Started! 🚀

You have everything you need. Pick a demo and run it!

```bash
# First-time users: Start here
python src/demo1_network/network_server.py
```

**Happy learning!**

---

**Module 4: Enterprise Python Demos**  
*Professional Python Training for Enterprise Applications*  
v1.0.0 - 2026
