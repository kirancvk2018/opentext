"""
Demo 5: Language Integration - Subprocess & System Commands

Demonstrates running external processes, capturing output, and handling errors.
Works with PowerShell, Bash, Java, and system commands.
"""

import subprocess
import sys
import platform
from pathlib import Path
from typing import Tuple, Optional

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import setup_logging, OUTPUT_DIR

LOG = setup_logging(__name__)


class SubprocessRunner:
    """Execute external processes."""

    @staticmethod
    def run_command(
        command: str, shell: bool = False, capture_output: bool = True
    ) -> Tuple[int, str, str]:
        """
        Run external command.

        Args:
            command: Command to run
            shell: Whether to run with shell
            capture_output: Whether to capture output

        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        try:
            result = subprocess.run(
                command,
                shell=shell,
                capture_output=capture_output,
                text=True,
                timeout=30,
            )

            LOG.info(f"Command executed: {command} (exit code: {result.returncode})")
            return result.returncode, result.stdout, result.stderr

        except subprocess.TimeoutExpired:
            LOG.error(f"Command timeout: {command}")
            return -1, "", "Command timeout"
        except Exception as e:
            LOG.error(f"Command error: {e}")
            return -1, "", str(e)

    @staticmethod
    def run_powershell(script: str) -> Tuple[int, str, str]:
        """
        Run PowerShell script.

        Args:
            script: PowerShell script code

        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        if platform.system() != "Windows":
            return -1, "", "PowerShell only available on Windows"

        command = ["powershell", "-Command", script]

        try:
            result = subprocess.run(
                command, capture_output=True, text=True, timeout=30
            )
            LOG.info(f"PowerShell executed (exit code: {result.returncode})")
            return result.returncode, result.stdout, result.stderr

        except Exception as e:
            LOG.error(f"PowerShell error: {e}")
            return -1, "", str(e)

    @staticmethod
    def run_bash(script: str) -> Tuple[int, str, str]:
        """
        Run Bash script.

        Args:
            script: Bash script code

        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        if platform.system() == "Windows":
            return -1, "", "Bash not available on Windows"

        command = ["bash", "-c", script]

        try:
            result = subprocess.run(
                command, capture_output=True, text=True, timeout=30
            )
            LOG.info(f"Bash executed (exit code: {result.returncode})")
            return result.returncode, result.stdout, result.stderr

        except Exception as e:
            LOG.error(f"Bash error: {e}")
            return -1, "", str(e)

    @staticmethod
    def run_python(code: str) -> Tuple[int, str, str]:
        """
        Run Python code in subprocess.

        Args:
            code: Python code

        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        command = [sys.executable, "-c", code]

        try:
            result = subprocess.run(
                command, capture_output=True, text=True, timeout=30
            )
            LOG.info(f"Python executed (exit code: {result.returncode})")
            return result.returncode, result.stdout, result.stderr

        except Exception as e:
            LOG.error(f"Python error: {e}")
            return -1, "", str(e)

    @staticmethod
    def run_java_jar(jar_file: Path, *args) -> Tuple[int, str, str]:
        """
        Run Java JAR file.

        Args:
            jar_file: Path to JAR file
            *args: Arguments to pass

        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        if not jar_file.exists():
            LOG.error(f"JAR file not found: {jar_file}")
            return -1, "", "JAR file not found"

        command = ["java", "-jar", str(jar_file)] + list(args)

        try:
            result = subprocess.run(
                command, capture_output=True, text=True, timeout=30
            )
            LOG.info(f"Java JAR executed (exit code: {result.returncode})")
            return result.returncode, result.stdout, result.stderr

        except Exception as e:
            LOG.error(f"Java error: {e}")
            return -1, "", str(e)


def demonstrate_subprocess():
    """Demonstrate subprocess functionality."""
    print("\n" + "=" * 70)
    print("MODULE 4 - DEMO 5: LANGUAGE INTEGRATION")
    print("Subprocess Execution")
    print("=" * 70 + "\n")

    runner = SubprocessRunner()

    # Example 1: System commands
    print("📚 Example 1: System Commands")
    print("-" * 70)

    if platform.system() == "Windows":
        exit_code, stdout, stderr = runner.run_command("echo Hello from system")
        print(f"  Command: echo Hello from system")
        print(f"  Exit Code: {exit_code}")
        print(f"  Output: {stdout.strip()}\n")

        exit_code, stdout, stderr = runner.run_command("dir", shell=True)
        print(f"  Command: dir")
        print(f"  Exit Code: {exit_code}")
        print(f"  Output lines: {len(stdout.splitlines())}\n")

    else:
        exit_code, stdout, stderr = runner.run_command("echo Hello from system")
        print(f"  Command: echo Hello from system")
        print(f"  Exit Code: {exit_code}")
        print(f"  Output: {stdout.strip()}\n")

        exit_code, stdout, stderr = runner.run_command("ls -la", shell=True)
        print(f"  Command: ls -la")
        print(f"  Exit Code: {exit_code}")
        print(f"  Output lines: {len(stdout.splitlines())}\n")

    # Example 2: Python execution
    print("📚 Example 2: Execute Python Code")
    print("-" * 70)

    code = 'print("Hello from subprocess Python"); print(2 + 2)'
    exit_code, stdout, stderr = runner.run_python(code)
    print(f"  Code: {code}")
    print(f"  Exit Code: {exit_code}")
    print(f"  Output:\n{stdout}\n")

    # Example 3: PowerShell (Windows only)
    if platform.system() == "Windows":
        print("📚 Example 3: PowerShell")
        print("-" * 70)

        ps_script = 'Write-Host "PowerShell Version:"; $PSVersionTable.PSVersion'
        exit_code, stdout, stderr = runner.run_powershell(ps_script)
        print(f"  Script: {ps_script}")
        print(f"  Exit Code: {exit_code}")
        print(f"  Output:\n{stdout}\n")

    # Example 4: Bash (Unix-like only)
    if platform.system() != "Windows":
        print("📚 Example 4: Bash")
        print("-" * 70)

        bash_script = 'echo "Current user: $(whoami)"; echo "Current directory: $(pwd)"'
        exit_code, stdout, stderr = runner.run_bash(bash_script)
        print(f"  Script: {bash_script}")
        print(f"  Exit Code: {exit_code}")
        print(f"  Output:\n{stdout}\n")

    # Example 5: Error handling
    print("📚 Example 5: Error Handling")
    print("-" * 70)

    exit_code, stdout, stderr = runner.run_command("invalid_command_xyz")
    print(f"  Command: invalid_command_xyz")
    print(f"  Exit Code: {exit_code}")
    if stderr:
        print(f"  Error: {stderr.strip()[:100]}...\n")
    else:
        print(f"  (Error captured)\n")

    print("=" * 70)
    print("✓ Subprocess Demo Complete")
    print("=" * 70 + "\n")


def main():
    """Main entry point."""
    demonstrate_subprocess()


if __name__ == "__main__":
    main()
