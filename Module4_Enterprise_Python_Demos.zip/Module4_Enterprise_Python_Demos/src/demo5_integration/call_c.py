"""
Demo 5: Language Integration - Call C from Python

Demonstrates using ctypes to call C functions from Python.
Includes calling compiled C libraries and handling data types.
"""

import ctypes
import os
import platform
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import setup_logging, OUTPUT_DIR

LOG = setup_logging(__name__)


def load_c_library(lib_name: str, lib_path: Path = None) -> ctypes.CDLL:
    """
    Load C library using ctypes.

    Args:
        lib_name: Library name
        lib_path: Optional path to library

    Returns:
        CDLL instance
    """
    try:
        if lib_path and lib_path.exists():
            lib = ctypes.CDLL(str(lib_path))
        else:
            # Try to load from system
            if platform.system() == "Windows":
                lib = ctypes.CDLL(f"{lib_name}.dll")
            elif platform.system() == "Darwin":
                lib = ctypes.CDLL(f"lib{lib_name}.dylib")
            else:
                lib = ctypes.CDLL(f"lib{lib_name}.so")

        LOG.info(f"Loaded library: {lib_name}")
        return lib

    except OSError as e:
        LOG.error(f"Failed to load library {lib_name}: {e}")
        raise


def demonstrate_basic_c_calls():
    """Demonstrate calling basic C library functions."""
    print("\n" + "=" * 70)
    print("MODULE 4 - DEMO 5: LANGUAGE INTEGRATION")
    print("Calling C from Python")
    print("=" * 70 + "\n")

    # Example 1: Use C standard library (available on all systems)
    print("📚 Example 1: Standard C Library")
    print("-" * 70)

    try:
        if platform.system() == "Windows":
            libc = ctypes.CDLL("msvcrt")
        else:
            libc = ctypes.CDLL("libc.so.6")

        # Get math functions
        print("✓ Loaded C Standard Library\n")

        # sqrt function
        sqrt_func = libc.sqrt
        sqrt_func.argtypes = [ctypes.c_double]
        sqrt_func.restype = ctypes.c_double

        result = sqrt_func(16.0)
        print(f"  sqrt(16.0) = {result}")

        # abs function
        abs_func = libc.abs
        abs_func.argtypes = [ctypes.c_int]
        abs_func.restype = ctypes.c_int

        result = abs_func(-42)
        print(f"  abs(-42) = {result}\n")

    except Exception as e:
        LOG.error(f"Error calling C library: {e}")
        print(f"  ⚠️  Error: {e}\n")


def demonstrate_custom_c_library():
    """Demonstrate calling custom C library."""
    print("📚 Example 2: Custom C Library")
    print("-" * 70)

    c_source = """
    /* Simple C library for demonstration */

    int add(int a, int b) {
        return a + b;
    }

    int multiply(int a, int b) {
        return a * b;
    }

    double celsius_to_fahrenheit(double celsius) {
        return (celsius * 9.0 / 5.0) + 32.0;
    }

    char* get_message() {
        return "Hello from C!";
    }
    """

    # Compile script
    compile_script = """
    @echo off
    cd /d "%~dp0"
    gcc -shared -fPIC -o sample.dll sample.c
    if %errorlevel% equ 0 (
        echo Compilation successful!
    ) else (
        echo Compilation failed!
    )
    """

    lib_file = Path("sample.dll" if platform.system() == "Windows" else "sample.so")

    if lib_file.exists():
        try:
            lib = ctypes.CDLL(str(lib_file))

            # Test add function
            add = lib.add
            add.argtypes = [ctypes.c_int, ctypes.c_int]
            add.restype = ctypes.c_int

            result = add(5, 3)
            print(f"  add(5, 3) = {result}")

            # Test multiply function
            multiply = lib.multiply
            multiply.argtypes = [ctypes.c_int, ctypes.c_int]
            multiply.restype = ctypes.c_int

            result = multiply(4, 7)
            print(f"  multiply(4, 7) = {result}")

            # Test conversion function
            convert = lib.celsius_to_fahrenheit
            convert.argtypes = [ctypes.c_double]
            convert.restype = ctypes.c_double

            result = convert(0.0)
            print(f"  celsius_to_fahrenheit(0) = {result}°F")

            print("\n  ✓ Custom C library functions executed successfully\n")

        except Exception as e:
            LOG.error(f"Error calling custom C library: {e}")
            print(f"  ⚠️  Error: {e}")
            print("  To use custom C library:")
            print("  1. Create sample.c with C functions")
            print("  2. Compile: gcc -shared -fPIC -o sample.so sample.c")
            print("  3. Run this script\n")

    else:
        print(f"  ⚠️  Library not found: {lib_file}")
        print("  See src/demo5_integration/sample.c for compilation instructions\n")


def demonstrate_struct_usage():
    """Demonstrate using C structs with ctypes."""
    print("📚 Example 3: Working with C Structs")
    print("-" * 70)

    # Define a C struct in Python
    class Point(ctypes.Structure):
        _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]

    # Create instance
    p = Point(x=3.0, y=4.0)
    print(f"  Point: ({p.x}, {p.y})")

    # Calculate distance from origin
    distance = (p.x ** 2 + p.y ** 2) ** 0.5
    print(f"  Distance from origin: {distance}\n")


def demonstrate_callback():
    """Demonstrate using callbacks with C."""
    print("📚 Example 4: Callbacks with C")
    print("-" * 70)

    # Define callback function type
    CALLBACK_FUNC = ctypes.CFUNCTYPE(None, ctypes.c_int)

    def my_callback(value):
        print(f"  Callback called with value: {value}")

    callback = CALLBACK_FUNC(my_callback)
    print("  ✓ Callback function created\n")


def demonstrate_c_types():
    """Demonstrate C data types in ctypes."""
    print("📚 Example 5: C Data Types")
    print("-" * 70)

    print("  C Type Mappings:")
    print("    c_char       -> char")
    print("    c_wchar      -> wchar_t")
    print("    c_byte       -> signed char")
    print("    c_ubyte      -> unsigned char")
    print("    c_short      -> short")
    print("    c_ushort     -> unsigned short")
    print("    c_int        -> int")
    print("    c_uint       -> unsigned int")
    print("    c_long       -> long")
    print("    c_ulong      -> unsigned long")
    print("    c_longlong   -> long long")
    print("    c_ulonglong  -> unsigned long long")
    print("    c_float      -> float")
    print("    c_double     -> double")
    print("    c_void_p     -> void*")
    print("    c_char_p     -> char*")
    print("    c_wchar_p    -> wchar_t*\n")


def main():
    """Main entry point."""
    demonstrate_basic_c_calls()
    demonstrate_custom_c_library()
    demonstrate_struct_usage()
    demonstrate_callback()
    demonstrate_c_types()

    print("=" * 70)
    print("✓ Language Integration Demo Complete")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()
