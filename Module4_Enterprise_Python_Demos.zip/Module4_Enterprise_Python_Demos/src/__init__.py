"""Module 4: Enterprise Python Demos Package."""

__version__ = "1.0.0"
__author__ = "Enterprise Python Training"
__description__ = "Advanced Python training module covering network, XML, GUI, SMTP, and integration"

from src.config import Config, setup_logging
from src import utils

__all__ = ["Config", "setup_logging", "utils"]
