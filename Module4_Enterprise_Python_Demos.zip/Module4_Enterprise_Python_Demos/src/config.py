"""
Module 4: Configuration Management

Centralized configuration management for all demos.
"""

import os
import logging
from pathlib import Path
from dotenv import load_dotenv
from typing import Optional

# Load environment variables
load_dotenv()

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
SRC_DIR = PROJECT_ROOT / "src"
DATA_DIR = PROJECT_ROOT / "assets" / "data"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
TEMPLATES_DIR = SRC_DIR / "demo4_smtp" / "templates"

# Ensure directories exist
for directory in [DATA_DIR, OUTPUT_DIR, TEMPLATES_DIR]:
    directory.mkdir(parents=True, exist_ok=True)


class Config:
    """Application configuration."""

    # Network settings
    SERVER_HOST: str = os.getenv("SERVER_HOST", "localhost")
    SERVER_PORT: int = int(os.getenv("SERVER_PORT", 5000))
    BUFFER_SIZE: int = int(os.getenv("BUFFER_SIZE", 4096))
    SOCKET_TIMEOUT: int = int(os.getenv("SOCKET_TIMEOUT", 30))
    MAX_CLIENTS: int = int(os.getenv("MAX_CLIENTS", 5))

    # SMTP settings
    SMTP_SERVER: str = os.getenv("SMTP_SERVER", "smtp.gmail.com")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", 587))
    SMTP_USE_TLS: bool = os.getenv("SMTP_USE_TLS", "True").lower() == "true"
    SMTP_USERNAME: str = os.getenv("SMTP_USERNAME", "")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "")

    # Email settings
    EMAIL_FROM: str = os.getenv("EMAIL_FROM", "")
    EMAIL_TO: str = os.getenv("EMAIL_TO", "")
    EMAIL_CC: str = os.getenv("EMAIL_CC", "")
    EMAIL_BCC: str = os.getenv("EMAIL_BCC", "")
    EMAIL_SUBJECT: str = os.getenv("EMAIL_SUBJECT", "Enterprise Python Demo")

    # Logging settings
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = os.getenv("LOG_FILE", str(OUTPUT_DIR / "app.log"))
    DEBUG: bool = os.getenv("DEBUG", "False").lower() == "true"

    # Application settings
    APP_ENV: str = os.getenv("APP_ENV", "development")
    APP_NAME: str = os.getenv("APP_NAME", "Enterprise Python Demos")
    APP_VERSION: str = os.getenv("APP_VERSION", "1.0.0")

    # Paths
    DATA_DIR_PATH: Path = DATA_DIR
    OUTPUT_DIR_PATH: Path = OUTPUT_DIR
    TEMPLATES_DIR_PATH: Path = TEMPLATES_DIR


def setup_logging(
    name: str,
    level: Optional[str] = None,
    log_file: Optional[str] = None,
) -> logging.Logger:
    """
    Configure logging for a module.

    Args:
        name: Logger name (usually __name__)
        level: Logging level (defaults to config.LOG_LEVEL)
        log_file: Log file path (defaults to config.LOG_FILE)

    Returns:
        Configured logger instance
    """
    level = level or Config.LOG_LEVEL
    log_file = log_file or Config.LOG_FILE

    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper()))

    # Ensure log directory exists
    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, level.upper()))
    console_format = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    console_handler.setFormatter(console_format)

    # File handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(getattr(logging, level.upper()))
    file_handler.setFormatter(console_format)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger


# Global logger
logger = setup_logging(__name__)
