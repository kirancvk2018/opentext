"""
Demo 4: SMTP Email - Send Email via SMTP

Demonstrates sending emails with attachments, HTML content, and multiple recipients.
Uses Gmail SMTP with app-specific passwords for authentication.
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email import encoders
from pathlib import Path
from typing import List, Optional
import sys
import os

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import Config, setup_logging
from src.utils import validate_email, EmailUtils

LOG = setup_logging(__name__)


class SMTPMailer:
    """Send emails via SMTP."""

    def __init__(
        self,
        smtp_server: str = Config.SMTP_SERVER,
        smtp_port: int = Config.SMTP_PORT,
        username: str = Config.SMTP_USERNAME,
        password: str = Config.SMTP_PASSWORD,
        use_tls: bool = Config.SMTP_USE_TLS,
    ):
        """
        Initialize SMTP mailer.

        Args:
            smtp_server: SMTP server address
            smtp_port: SMTP server port
            username: SMTP username
            password: SMTP password
            use_tls: Whether to use TLS
        """
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.use_tls = use_tls

        if not self.username or not self.password:
            raise ValueError("SMTP credentials not configured in .env")

        LOG.info(f"SMTP Mailer initialized: {smtp_server}:{smtp_port}")

    def send_plain_text(
        self,
        subject: str,
        body: str,
        to_addresses: List[str],
        from_address: Optional[str] = None,
        cc_addresses: Optional[List[str]] = None,
        bcc_addresses: Optional[List[str]] = None,
    ) -> bool:
        """
        Send plain text email.

        Args:
            subject: Email subject
            body: Email body (plain text)
            to_addresses: List of recipient addresses
            from_address: Sender address
            cc_addresses: CC recipients
            bcc_addresses: BCC recipients

        Returns:
            True if successful, False otherwise
        """
        from_address = from_address or self.username
        cc_addresses = cc_addresses or []
        bcc_addresses = bcc_addresses or []

        # Validate emails
        to_addresses = EmailUtils.validate_recipients(",".join(to_addresses))
        cc_addresses = EmailUtils.validate_recipients(",".join(cc_addresses))
        bcc_addresses = EmailUtils.validate_recipients(",".join(bcc_addresses))

        if not to_addresses:
            LOG.error("No valid recipient addresses")
            return False

        try:
            msg = MIMEText(body)
            msg["Subject"] = subject
            msg["From"] = from_address
            msg["To"] = ", ".join(to_addresses)

            if cc_addresses:
                msg["Cc"] = ", ".join(cc_addresses)

            all_recipients = to_addresses + cc_addresses + bcc_addresses

            self._send_message(msg, from_address, all_recipients)
            LOG.info(f"Email sent: {subject}")
            return True

        except Exception as e:
            LOG.error(f"Send error: {e}")
            return False

    def send_html(
        self,
        subject: str,
        html_body: str,
        text_body: str = "",
        to_addresses: List[str] = None,
        from_address: Optional[str] = None,
        cc_addresses: Optional[List[str]] = None,
        bcc_addresses: Optional[List[str]] = None,
    ) -> bool:
        """
        Send HTML email with plain text fallback.

        Args:
            subject: Email subject
            html_body: HTML email body
            text_body: Plain text fallback
            to_addresses: List of recipient addresses
            from_address: Sender address
            cc_addresses: CC recipients
            bcc_addresses: BCC recipients

        Returns:
            True if successful, False otherwise
        """
        to_addresses = to_addresses or []
        from_address = from_address or self.username
        cc_addresses = cc_addresses or []
        bcc_addresses = bcc_addresses or []

        to_addresses = EmailUtils.validate_recipients(",".join(to_addresses))

        if not to_addresses:
            LOG.error("No valid recipient addresses")
            return False

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = from_address
            msg["To"] = ", ".join(to_addresses)

            if cc_addresses:
                msg["Cc"] = ", ".join(cc_addresses)

            # Attach plain text and HTML versions
            if text_body:
                msg.attach(MIMEText(text_body, "plain"))
            msg.attach(MIMEText(html_body, "html"))

            all_recipients = to_addresses + cc_addresses + bcc_addresses

            self._send_message(msg, from_address, all_recipients)
            LOG.info(f"HTML email sent: {subject}")
            return True

        except Exception as e:
            LOG.error(f"Send error: {e}")
            return False

    def send_with_attachment(
        self,
        subject: str,
        body: str,
        to_addresses: List[str],
        attachments: List[Path],
        from_address: Optional[str] = None,
        is_html: bool = False,
    ) -> bool:
        """
        Send email with attachments.

        Args:
            subject: Email subject
            body: Email body
            to_addresses: List of recipient addresses
            attachments: List of file paths to attach
            from_address: Sender address
            is_html: Whether body is HTML

        Returns:
            True if successful, False otherwise
        """
        from_address = from_address or self.username

        to_addresses = EmailUtils.validate_recipients(",".join(to_addresses))

        if not to_addresses:
            LOG.error("No valid recipient addresses")
            return False

        try:
            msg = MIMEMultipart()
            msg["Subject"] = subject
            msg["From"] = from_address
            msg["To"] = ", ".join(to_addresses)

            # Attach body
            msg.attach(MIMEText(body, "html" if is_html else "plain"))

            # Attach files
            for filepath in attachments:
                if not filepath.exists():
                    LOG.warning(f"Attachment not found: {filepath}")
                    continue

                try:
                    with open(filepath, "rb") as attachment:
                        part = MIMEBase("application", "octet-stream")
                        part.set_payload(attachment.read())

                    encoders.encode_base64(part)
                    part.add_header(
                        "Content-Disposition",
                        f"attachment; filename= {filepath.name}",
                    )
                    msg.attach(part)
                    LOG.debug(f"Attached: {filepath.name}")

                except Exception as e:
                    LOG.error(f"Error attaching {filepath}: {e}")

            self._send_message(msg, from_address, to_addresses)
            LOG.info(f"Email with attachments sent: {subject}")
            return True

        except Exception as e:
            LOG.error(f"Send error: {e}")
            return False

    def _send_message(
        self, message: MIMEMultipart, from_addr: str, to_addrs: List[str]
    ) -> None:
        """
        Send message via SMTP.

        Args:
            message: MIME message
            from_addr: Sender address
            to_addrs: List of recipient addresses
        """
        try:
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                if self.use_tls:
                    server.starttls()

                server.login(self.username, self.password)
                server.sendmail(from_addr, to_addrs, message.as_string())
                LOG.debug(f"SMTP session successful")

        except smtplib.SMTPAuthenticationError:
            LOG.error("SMTP authentication failed")
            raise
        except smtplib.SMTPException as e:
            LOG.error(f"SMTP error: {e}")
            raise


def demonstrate_email_sending():
    """Demonstrate email sending functionality."""
    print("\n" + "=" * 70)
    print("MODULE 4 - DEMO 4: SMTP EMAIL")
    print("Email Sending Demonstration")
    print("=" * 70 + "\n")

    # Check credentials
    if not Config.SMTP_USERNAME or not Config.SMTP_PASSWORD:
        print("⚠️  SMTP credentials not configured in .env file")
        print("\nSetup instructions:")
        print("1. Create .env from .env.example")
        print("2. Configure SMTP credentials:")
        print("   SMTP_SERVER=smtp.gmail.com")
        print("   SMTP_PORT=587")
        print("   SMTP_USERNAME=your-email@gmail.com")
        print("   SMTP_PASSWORD=your-app-password")
        print("\n📖 Gmail App Password setup:")
        print("   https://support.google.com/accounts/answer/185833")
        return

    try:
        mailer = SMTPMailer()
        print("✓ SMTP Mailer initialized\n")

        # Example: Send plain text
        print("📧 Sending test email...")

        subject = "Module 4 Enterprise Python - Test Email"
        body = "This is a test email from Enterprise Python training."
        to_addresses = [Config.EMAIL_TO] if Config.EMAIL_TO else []

        if not to_addresses:
            print("⚠️  No recipient email configured in .env (EMAIL_TO)")
            print("   Email will not be sent")
        else:
            if mailer.send_plain_text(subject, body, to_addresses):
                print("✓ Email sent successfully!")
            else:
                print("✗ Failed to send email")

    except ValueError as e:
        print(f"✗ Configuration error: {e}")
    except Exception as e:
        LOG.error(f"Error: {e}")
        print(f"✗ Error: {e}")


def create_html_template():
    """Create sample HTML email template."""
    html_template = """
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; }
            .header { background-color: #0066cc; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; }
            .footer { background-color: #f0f0f0; padding: 10px; text-align: center; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Enterprise Python Training</h1>
            <p>Module 4: Advanced Topics</p>
        </div>
        <div class="content">
            <h2>Welcome!</h2>
            <p>Thank you for participating in our training program.</p>
            <p>Today we covered:</p>
            <ul>
                <li>Network Programming with Sockets</li>
                <li>XML Processing and Transformation</li>
                <li>Desktop GUI Development</li>
                <li>Email Automation</li>
                <li>Language Integration</li>
            </ul>
        </div>
        <div class="footer">
            <p>&copy; 2026 Enterprise Python Training. All rights reserved.</p>
        </div>
    </body>
    </html>
    """
    return html_template


def main():
    """Main entry point."""
    demonstrate_email_sending()


if __name__ == "__main__":
    main()
