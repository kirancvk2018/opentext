"""
Module 4: Utility Functions

Common utilities and helpers used across all demos.
"""

import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional
from src.config import logger, OUTPUT_DIR


def save_json(data: Dict[str, Any], filename: str) -> Path:
    """
    Save dictionary to JSON file.

    Args:
        data: Dictionary to save
        filename: Output filename

    Returns:
        Path to saved file
    """
    output_path = OUTPUT_DIR / filename
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    logger.info(f"Saved JSON to {output_path}")
    return output_path


def load_json(filepath: Path) -> Dict[str, Any]:
    """
    Load JSON file.

    Args:
        filepath: Path to JSON file

    Returns:
        Loaded dictionary
    """
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    logger.info(f"Loaded JSON from {filepath}")
    return data


def save_xml(element: ET.Element, filename: str, pretty_print: bool = True) -> Path:
    """
    Save XML element to file.

    Args:
        element: XML Element to save
        filename: Output filename
        pretty_print: Whether to format the XML

    Returns:
        Path to saved file
    """
    output_path = OUTPUT_DIR / filename
    output_path.parent.mkdir(parents=True, exist_ok=True)

    tree = ET.ElementTree(element)
    ET.indent(element, space="  ")  # Python 3.9+
    tree.write(output_path, encoding="utf-8", xml_declaration=True)

    logger.info(f"Saved XML to {output_path}")
    return output_path


def load_xml(filepath: Path) -> ET.Element:
    """
    Load XML file.

    Args:
        filepath: Path to XML file

    Returns:
        Root element
    """
    tree = ET.parse(filepath)
    root = tree.getroot()
    logger.info(f"Loaded XML from {filepath}")
    return root


def format_bytes(bytes_size: int) -> str:
    """
    Format bytes to human-readable format.

    Args:
        bytes_size: Size in bytes

    Returns:
        Formatted string (e.g., "1.5 MB")
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.2f} PB"


def validate_email(email: str) -> bool:
    """
    Basic email validation.

    Args:
        email: Email address to validate

    Returns:
        True if valid format, False otherwise
    """
    import re

    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(pattern, email) is not None


def parse_host_port(address: str, default_port: int = 5000) -> tuple[str, int]:
    """
    Parse host:port string.

    Args:
        address: Address in format "host:port" or just "host"
        default_port: Port to use if not specified

    Returns:
        Tuple of (host, port)
    """
    parts = address.rsplit(":", 1)
    host = parts[0]

    try:
        port = int(parts[1]) if len(parts) > 1 else default_port
    except ValueError:
        port = default_port

    return host, port


def create_file_if_not_exists(filepath: Path, content: str = "") -> Path:
    """
    Create file if it doesn't exist.

    Args:
        filepath: Path to file
        content: Initial content

    Returns:
        Path to file
    """
    if not filepath.exists():
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content, encoding="utf-8")
        logger.info(f"Created file: {filepath}")
    return filepath


def read_file(filepath: Path) -> str:
    """
    Read file contents.

    Args:
        filepath: Path to file

    Returns:
        File contents
    """
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def write_file(filepath: Path, content: str) -> Path:
    """
    Write content to file.

    Args:
        filepath: Path to file
        content: Content to write

    Returns:
        Path to file
    """
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    logger.info(f"Wrote to file: {filepath}")
    return filepath


class NetworkUtils:
    """Network utility functions."""

    @staticmethod
    def validate_port(port: int) -> bool:
        """Validate port number (1-65535)."""
        return 1 <= port <= 65535

    @staticmethod
    def is_port_available(host: str, port: int) -> bool:
        """Check if port is available."""
        import socket

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex((host, port))
        sock.close()
        return result != 0

    @staticmethod
    def format_address(host: str, port: int) -> str:
        """Format address as host:port."""
        return f"{host}:{port}"


class XMLUtils:
    """XML utility functions."""

    @staticmethod
    def prettify_xml(elem: ET.Element) -> str:
        """Return a pretty-printed XML string."""
        from xml.dom import minidom

        rough_string = ET.tostring(elem, encoding="unicode")
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")

    @staticmethod
    def find_elements_by_tag(
        root: ET.Element, tag: str, namespace: Optional[str] = None
    ) -> List[ET.Element]:
        """Find all elements with given tag."""
        if namespace:
            tag = f"{{{namespace}}}{tag}"
        return root.findall(f".//{tag}")

    @staticmethod
    def get_element_text(element: ET.Element, default: str = "") -> str:
        """Safely get element text."""
        return element.text if element.text else default


class EmailUtils:
    """Email utility functions."""

    @staticmethod
    def validate_recipients(email_list: str) -> List[str]:
        """Parse and validate email recipient list."""
        emails = [e.strip() for e in email_list.split(",") if e.strip()]
        valid_emails = [e for e in emails if validate_email(e)]
        return valid_emails

    @staticmethod
    def format_email_message(
        subject: str,
        body: str,
        sender: str,
        recipients: List[str],
        html: bool = False,
    ) -> Dict[str, str]:
        """Format email message."""
        return {
            "subject": subject,
            "body": body,
            "sender": sender,
            "recipients": recipients,
            "format": "html" if html else "plain",
        }


if __name__ == "__main__":
    print("Module 4 Utilities Loaded")
