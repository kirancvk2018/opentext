"""
Demo 3: GUI Development - Employee Management Application

Desktop application using Tkinter for CRUD operations on employee records.
Demonstrates widgets, dialogs, event handling, and data validation.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import csv
from pathlib import Path
from dataclasses import dataclass
from typing import List, Optional
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import setup_logging, OUTPUT_DIR

LOG = setup_logging(__name__)


@dataclass
class Employee:
    """Employee data class."""

    emp_id: str
    name: str
    department: str
    position: str
    salary: float

    def to_tuple(self) -> tuple:
        """Convert to tuple for display."""
        return (self.emp_id, self.name, self.department, self.position, f"${self.salary:,.2f}")


class EmployeeManager:
    """Manage employee data in memory."""

    def __init__(self):
        """Initialize employee manager."""
        self.employees: List[Employee] = [
            Employee("E001", "John Smith", "Engineering", "Senior Developer", 120000),
            Employee("E002", "Sarah Johnson", "Engineering", "DevOps Engineer", 115000),
            Employee("E003", "Michael Brown", "Sales", "Sales Manager", 95000),
        ]
        self.next_id = 1004

    def add_employee(self, employee: Employee) -> bool:
        """Add employee."""
        if any(e.emp_id == employee.emp_id for e in self.employees):
            return False
        self.employees.append(employee)
        return True

    def update_employee(self, emp_id: str, employee: Employee) -> bool:
        """Update employee."""
        for i, emp in enumerate(self.employees):
            if emp.emp_id == emp_id:
                self.employees[i] = employee
                return True
        return False

    def delete_employee(self, emp_id: str) -> bool:
        """Delete employee."""
        self.employees = [e for e in self.employees if e.emp_id != emp_id]
        return True

    def get_employee(self, emp_id: str) -> Optional[Employee]:
        """Get employee by ID."""
        for emp in self.employees:
            if emp.emp_id == emp_id:
                return emp
        return None

    def search_employees(self, query: str) -> List[Employee]:
        """Search employees by name or ID."""
        query = query.lower()
        return [
            e for e in self.employees
            if query in e.name.lower() or query in e.emp_id.lower()
        ]

    def get_all_employees(self) -> List[Employee]:
        """Get all employees."""
        return self.employees

    def export_to_csv(self, filepath: Path) -> bool:
        """Export employees to CSV."""
        try:
            with open(filepath, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["ID", "Name", "Department", "Position", "Salary"])
                for emp in self.employees:
                    writer.writerow([emp.emp_id, emp.name, emp.department, emp.position, emp.salary])
            return True
        except Exception as e:
            LOG.error(f"Export error: {e}")
            return False


class EmployeeGUI:
    """Employee Management GUI Application."""

    def __init__(self, root: tk.Tk):
        """Initialize GUI."""
        self.root = root
        self.root.title("Employee Management System")
        self.root.geometry("900x600")

        self.manager = EmployeeManager()
        self.selected_employee: Optional[str] = None

        self._setup_ui()
        self._load_employees()

        LOG.info("GUI Application started")

    def _setup_ui(self) -> None:
        """Setup user interface."""
        # Menu bar
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Export to CSV", command=self._export_csv)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)

        # Search frame
        search_frame = ttk.Frame(self.root)
        search_frame.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *args: self._on_search_change())

        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=40)
        search_entry.pack(side=tk.LEFT, padx=5)

        # Treeview for displaying employees
        tree_frame = ttk.Frame(self.root)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree = ttk.Treeview(
            tree_frame,
            columns=("ID", "Name", "Department", "Position", "Salary"),
            height=15,
            yscrollcommand=scrollbar.set,
        )
        scrollbar.config(command=self.tree.yview)

        self.tree.heading("#0", text="")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Name", text="Name")
        self.tree.heading("Department", text="Department")
        self.tree.heading("Position", text="Position")
        self.tree.heading("Salary", text="Salary")

        self.tree.column("#0", width=0, stretch=tk.NO)
        self.tree.column("ID", anchor=tk.W, width=80)
        self.tree.column("Name", anchor=tk.W, width=150)
        self.tree.column("Department", anchor=tk.W, width=120)
        self.tree.column("Position", anchor=tk.W, width=150)
        self.tree.column("Salary", anchor=tk.E, width=100)

        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_employee_select)

        # Button frame
        button_frame = ttk.Frame(self.root)
        button_frame.pack(fill=tk.X, padx=10, pady=10)

        ttk.Button(button_frame, text="Add", command=self._add_employee).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Edit", command=self._edit_employee).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete", command=self._delete_employee).pack(side=tk.LEFT, padx=5)

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.pack(fill=tk.X, side=tk.BOTTOM)

    def _load_employees(self) -> None:
        """Load employees into treeview."""
        self.tree.delete(*self.tree.get_children())
        employees = self.manager.get_all_employees()

        for emp in employees:
            self.tree.insert("", tk.END, values=emp.to_tuple())

        self._update_status(f"Loaded {len(employees)} employees")

    def _on_search_change(self) -> None:
        """Handle search text change."""
        query = self.search_var.get()

        if not query:
            self._load_employees()
            return

        self.tree.delete(*self.tree.get_children())
        results = self.manager.search_employees(query)

        for emp in results:
            self.tree.insert("", tk.END, values=emp.to_tuple())

        self._update_status(f"Found {len(results)} results")

    def _on_employee_select(self, event) -> None:
        """Handle employee selection."""
        selection = self.tree.selection()
        if selection:
            item = selection[0]
            values = self.tree.item(item, "values")
            self.selected_employee = values[0]  # emp_id

    def _add_employee(self) -> None:
        """Show add employee dialog."""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Employee")
        dialog.geometry("400x300")

        ttk.Label(dialog, text="Name:").pack(anchor=tk.W, padx=10, pady=5)
        name_entry = ttk.Entry(dialog, width=40)
        name_entry.pack(anchor=tk.W, padx=10)

        ttk.Label(dialog, text="Department:").pack(anchor=tk.W, padx=10, pady=5)
        dept_entry = ttk.Entry(dialog, width=40)
        dept_entry.pack(anchor=tk.W, padx=10)

        ttk.Label(dialog, text="Position:").pack(anchor=tk.W, padx=10, pady=5)
        pos_entry = ttk.Entry(dialog, width=40)
        pos_entry.pack(anchor=tk.W, padx=10)

        ttk.Label(dialog, text="Salary:").pack(anchor=tk.W, padx=10, pady=5)
        sal_entry = ttk.Entry(dialog, width=40)
        sal_entry.pack(anchor=tk.W, padx=10)

        def save():
            name = name_entry.get().strip()
            dept = dept_entry.get().strip()
            pos = pos_entry.get().strip()

            if not (name and dept and pos):
                messagebox.showerror("Error", "All fields are required")
                return

            try:
                salary = float(sal_entry.get())
            except ValueError:
                messagebox.showerror("Error", "Invalid salary amount")
                return

            emp_id = f"E{self.manager.next_id:03d}"
            self.manager.next_id += 1

            emp = Employee(emp_id, name, dept, pos, salary)
            if self.manager.add_employee(emp):
                self._load_employees()
                dialog.destroy()
                messagebox.showinfo("Success", f"Employee {emp_id} added")
            else:
                messagebox.showerror("Error", "Failed to add employee")

        ttk.Button(dialog, text="Save", command=save).pack(pady=10)

    def _edit_employee(self) -> None:
        """Edit selected employee."""
        if not self.selected_employee:
            messagebox.showwarning("Warning", "Select an employee first")
            return

        emp = self.manager.get_employee(self.selected_employee)
        if not emp:
            messagebox.showerror("Error", "Employee not found")
            return

        dialog = tk.Toplevel(self.root)
        dialog.title("Edit Employee")
        dialog.geometry("400x300")

        ttk.Label(dialog, text="Name:").pack(anchor=tk.W, padx=10, pady=5)
        name_entry = ttk.Entry(dialog, width=40)
        name_entry.insert(0, emp.name)
        name_entry.pack(anchor=tk.W, padx=10)

        ttk.Label(dialog, text="Department:").pack(anchor=tk.W, padx=10, pady=5)
        dept_entry = ttk.Entry(dialog, width=40)
        dept_entry.insert(0, emp.department)
        dept_entry.pack(anchor=tk.W, padx=10)

        ttk.Label(dialog, text="Position:").pack(anchor=tk.W, padx=10, pady=5)
        pos_entry = ttk.Entry(dialog, width=40)
        pos_entry.insert(0, emp.position)
        pos_entry.pack(anchor=tk.W, padx=10)

        ttk.Label(dialog, text="Salary:").pack(anchor=tk.W, padx=10, pady=5)
        sal_entry = ttk.Entry(dialog, width=40)
        sal_entry.insert(0, str(emp.salary))
        sal_entry.pack(anchor=tk.W, padx=10)

        def save():
            name = name_entry.get().strip()
            dept = dept_entry.get().strip()
            pos = pos_entry.get().strip()

            if not (name and dept and pos):
                messagebox.showerror("Error", "All fields are required")
                return

            try:
                salary = float(sal_entry.get())
            except ValueError:
                messagebox.showerror("Error", "Invalid salary amount")
                return

            updated_emp = Employee(emp.emp_id, name, dept, pos, salary)
            if self.manager.update_employee(emp.emp_id, updated_emp):
                self._load_employees()
                dialog.destroy()
                messagebox.showinfo("Success", "Employee updated")
            else:
                messagebox.showerror("Error", "Failed to update employee")

        ttk.Button(dialog, text="Save", command=save).pack(pady=10)

    def _delete_employee(self) -> None:
        """Delete selected employee."""
        if not self.selected_employee:
            messagebox.showwarning("Warning", "Select an employee first")
            return

        if messagebox.askyesno("Confirm", "Delete this employee?"):
            self.manager.delete_employee(self.selected_employee)
            self._load_employees()
            messagebox.showinfo("Success", "Employee deleted")

    def _export_csv(self) -> None:
        """Export employees to CSV."""
        filepath = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialdir=OUTPUT_DIR,
        )

        if filepath:
            if self.manager.export_to_csv(Path(filepath)):
                messagebox.showinfo("Success", f"Exported to {filepath}")
                LOG.info(f"Exported employees to {filepath}")
            else:
                messagebox.showerror("Error", "Export failed")

    def _update_status(self, message: str) -> None:
        """Update status bar."""
        self.status_var.set(message)


def main():
    """Main entry point."""
    print("\n" + "=" * 70)
    print("MODULE 4 - DEMO 3: GUI DEVELOPMENT")
    print("Employee Management Application")
    print("=" * 70 + "\n")

    root = tk.Tk()
    app = EmployeeGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
