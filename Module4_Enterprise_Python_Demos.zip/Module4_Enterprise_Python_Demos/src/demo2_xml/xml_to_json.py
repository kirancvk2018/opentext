"""
Demo 2: XML Processing - XML to JSON Conversion

Convert XML documents to JSON format for API responses and data interchange.
"""

import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Any, List
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import setup_logging, DATA_DIR, OUTPUT_DIR
from src.utils import save_json

LOG = setup_logging(__name__)


def xml_to_dict(element: ET.Element) -> Dict[str, Any]:
    """
    Convert XML element to dictionary recursively.

    Args:
        element: XML element

    Returns:
        Dictionary representation
    """
    result = {}

    # Add attributes
    if element.attrib:
        result["@attributes"] = dict(element.attrib)

    # Add text content
    if element.text and element.text.strip():
        result["#text"] = element.text.strip()

    # Add child elements
    children_dict: Dict[str, Any] = {}

    for child in element:
        child_dict = xml_to_dict(child)
        tag = child.tag

        if tag in children_dict:
            # Handle multiple elements with same tag
            if not isinstance(children_dict[tag], list):
                children_dict[tag] = [children_dict[tag]]
            children_dict[tag].append(child_dict)
        else:
            children_dict[tag] = child_dict

    if children_dict:
        if result:
            result["children"] = children_dict
        else:
            result = children_dict

    return result if result else None


def xml_to_json_string(element: ET.Element, indent: int = 2) -> str:
    """
    Convert XML element to JSON string.

    Args:
        element: XML element
        indent: JSON indentation

    Returns:
        JSON string
    """
    data = {element.tag: xml_to_dict(element)}
    return json.dumps(data, indent=indent, ensure_ascii=False)


def convert_xml_file(xml_path: Path, json_filename: str) -> Path:
    """
    Convert XML file to JSON.

    Args:
        xml_path: Path to XML file
        json_filename: Output JSON filename

    Returns:
        Path to created JSON file
    """
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()

        json_str = xml_to_json_string(root)

        output_path = OUTPUT_DIR / json_filename
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(json_str)

        LOG.info(f"Converted {xml_path} to {output_path}")
        return output_path

    except Exception as e:
        LOG.error(f"Conversion error: {e}")
        raise


def simple_xml_to_dict(element: ET.Element) -> Dict[str, Any]:
    """
    Simpler conversion - converts XML to flattened dictionary.

    Useful when XML structure is simple and you want a flat JSON.

    Args:
        element: XML element

    Returns:
        Dictionary representation
    """
    result = {element.tag: {}}

    # Add attributes
    result[element.tag].update(element.attrib)

    # Add text
    if element.text and element.text.strip():
        result[element.tag]["value"] = element.text.strip()

    # Add children
    for child in element:
        child_data = simple_xml_to_dict(child)
        child_tag = list(child_data.keys())[0]
        child_content = child_data[child_tag]

        if child_tag in result[element.tag]:
            # Convert to list for duplicate tags
            if not isinstance(result[element.tag][child_tag], list):
                result[element.tag][child_tag] = [result[element.tag][child_tag]]
            result[element.tag][child_tag].append(child_content)
        else:
            result[element.tag][child_tag] = child_content

    return result


def demonstrate_conversion():
    """Demonstrate XML to JSON conversion."""
    print("\n" + "=" * 70)
    print("MODULE 4 - DEMO 2: XML PROCESSING")
    print("XML to JSON Conversion")
    print("=" * 70 + "\n")

    # Create sample XML if needed
    sample_file = DATA_DIR / "employees.xml"

    if not sample_file.exists():
        from src.demo2_xml.xml_reader import create_sample_xml
        create_sample_xml(sample_file)

    # Convert
    try:
        print(f"📄 Source XML: {sample_file}\n")

        output_file = convert_xml_file(sample_file, "employees.json")

        print(f"✓ JSON created: {output_file}\n")

        # Read and display
        with open(output_file, "r", encoding="utf-8") as f:
            json_data = json.load(f)

        print("📊 JSON Output:")
        print(json.dumps(json_data, indent=2, ensure_ascii=False)[:500] + "...\n")

    except Exception as e:
        LOG.error(f"Error: {e}")
        print(f"✗ Error: {e}")


def main():
    """Main entry point."""
    demonstrate_conversion()


if __name__ == "__main__":
    main()
