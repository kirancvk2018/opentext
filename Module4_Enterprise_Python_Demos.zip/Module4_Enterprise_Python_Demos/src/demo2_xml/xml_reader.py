"""
Demo 2: XML Processing - XML Reader

Demonstrates parsing, querying, and extracting data from XML documents.
Supports ElementTree and XPath.
"""

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List, Dict, Optional
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import setup_logging, DATA_DIR
from src.utils import XMLUtils

LOG = setup_logging(__name__)


class XMLReader:
    """Read and parse XML documents."""

    def __init__(self, filepath: Path):
        """
        Initialize XML reader.

        Args:
            filepath: Path to XML file
        """
        self.filepath = filepath
        self.tree = None
        self.root = None

        if not filepath.exists():
            raise FileNotFoundError(f"XML file not found: {filepath}")

        self._load_xml()

    def _load_xml(self) -> None:
        """Load XML file."""
        try:
            self.tree = ET.parse(self.filepath)
            self.root = self.tree.getroot()
            LOG.info(f"Loaded XML: {self.filepath}")
        except ET.ParseError as e:
            LOG.error(f"XML parse error: {e}")
            raise

    def get_root_tag(self) -> str:
        """Get root element tag name."""
        return self.root.tag if self.root is not None else ""

    def get_root_attribs(self) -> Dict[str, str]:
        """Get root element attributes."""
        return dict(self.root.attrib) if self.root is not None else {}

    def find_elements(self, tag: str) -> List[ET.Element]:
        """
        Find all elements with given tag.

        Args:
            tag: Element tag name

        Returns:
            List of matching elements
        """
        if self.root is None:
            return []
        return self.root.findall(f".//{tag}")

    def find_direct_children(self, tag: str) -> List[ET.Element]:
        """
        Find direct children with given tag.

        Args:
            tag: Element tag name

        Returns:
            List of matching children
        """
        if self.root is None:
            return []
        return self.root.findall(tag)

    def xpath_query(self, xpath: str) -> List[ET.Element]:
        """
        Query elements using XPath.

        Args:
            xpath: XPath expression

        Returns:
            List of matching elements
        """
        try:
            return self.root.findall(xpath)
        except Exception as e:
            LOG.error(f"XPath error: {e}")
            return []

    def get_element_text(
        self, element: ET.Element, default: str = ""
    ) -> str:
        """Get element text content."""
        return element.text if element.text else default

    def get_element_attrib(
        self, element: ET.Element, attrib: str, default: str = ""
    ) -> str:
        """Get element attribute value."""
        return element.get(attrib, default)

    def extract_to_dict(self, tag: str) -> List[Dict]:
        """
        Extract elements as list of dictionaries.

        Args:
            tag: Element tag to extract

        Returns:
            List of dictionaries
        """
        elements = self.find_elements(tag)
        result = []

        for elem in elements:
            item = {}

            # Add attributes
            item.update(elem.attrib)

            # Add child text values
            for child in elem:
                key = child.tag
                value = self.get_element_text(child)

                if key in item:
                    # Convert to list if duplicate key
                    if not isinstance(item[key], list):
                        item[key] = [item[key]]
                    item[key].append(value)
                else:
                    item[key] = value

            result.append(item)

        return result

    def print_tree(self, element: Optional[ET.Element] = None, level: int = 0):
        """Print XML tree structure."""
        if element is None:
            element = self.root

        indent = "  " * level
        attribs = " ".join(f'{k}="{v}"' for k, v in element.attrib.items())
        text = (element.text or "").strip()

        print(f"{indent}<{element.tag} {attribs}>")
        if text:
            print(f"{indent}  {text}")

        for child in element:
            self.print_tree(child, level + 1)


def demonstrate_xml_reading():
    """Demonstrate XML reading functionality."""
    print("\n" + "=" * 70)
    print("MODULE 4 - DEMO 2: XML PROCESSING")
    print("XML Reader Demonstration")
    print("=" * 70 + "\n")

    # Create sample XML if needed
    sample_file = DATA_DIR / "employees.xml"

    if not sample_file.exists():
        create_sample_xml(sample_file)

    # Read and display
    try:
        reader = XMLReader(sample_file)

        print(f"📄 File: {sample_file}")
        print(f"📌 Root tag: {reader.get_root_tag()}")
        print(f"📋 Root attributes: {reader.get_root_attribs()}\n")

        # Find employees
        employees = reader.find_elements("Employee")
        print(f"👥 Found {len(employees)} employees:\n")

        for i, emp in enumerate(employees, 1):
            emp_id = reader.get_element_attrib(emp, "id")
            name = reader.find_elements("Name") if emp == employees[0] else []

            print(f"  {i}. Employee ID: {emp_id}")

            for child in emp:
                value = reader.get_element_text(child)
                print(f"     {child.tag}: {value}")
            print()

        # Extract as dictionaries
        print("📊 Extracted as dictionaries:")
        emp_dicts = reader.extract_to_dict("Employee")
        for emp_dict in emp_dicts:
            print(f"  {emp_dict}\n")

        # Print tree
        print("\n🌳 XML Tree Structure:")
        reader.print_tree()

    except Exception as e:
        LOG.error(f"Error: {e}")
        print(f"✗ Error: {e}")


def create_sample_xml(filepath: Path):
    """Create sample employees.xml for demonstration."""
    xml_content = """<?xml version="1.0" encoding="UTF-8"?>
<Company name="TechCorp" industry="Software">
    <Employees>
        <Employee id="E001">
            <Name>John Smith</Name>
            <Department>Engineering</Department>
            <Position>Senior Developer</Position>
            <Salary currency="USD">120000</Salary>
            <StartDate>2020-01-15</StartDate>
        </Employee>
        <Employee id="E002">
            <Name>Sarah Johnson</Name>
            <Department>Engineering</Department>
            <Position>DevOps Engineer</Position>
            <Salary currency="USD">115000</Salary>
            <StartDate>2021-03-20</StartDate>
        </Employee>
        <Employee id="E003">
            <Name>Michael Brown</Name>
            <Department>Sales</Department>
            <Position>Sales Manager</Position>
            <Salary currency="USD">95000</Salary>
            <StartDate>2019-06-01</StartDate>
        </Employee>
        <Employee id="E004">
            <Name>Emily Davis</Name>
            <Department>HR</Department>
            <Position>HR Specialist</Position>
            <Salary currency="USD">75000</Salary>
            <StartDate>2022-02-14</StartDate>
        </Employee>
    </Employees>
</Company>
"""

    filepath.parent.mkdir(parents=True, exist_ok=True)
    filepath.write_text(xml_content, encoding="utf-8")
    LOG.info(f"Created sample XML: {filepath}")


def main():
    """Main entry point."""
    demonstrate_xml_reading()


if __name__ == "__main__":
    main()
