"""
Demo 2: XML Processing - XML Writer

Demonstrates creating and modifying XML documents.
"""

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Any
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import setup_logging, OUTPUT_DIR
from src.utils import save_xml

LOG = setup_logging(__name__)


class XMLWriter:
    """Create and modify XML documents."""

    def __init__(self, root_tag: str, attribs: Dict[str, str] = None):
        """
        Initialize XML writer.

        Args:
            root_tag: Root element tag name
            attribs: Root element attributes
        """
        attribs = attribs or {}
        self.root = ET.Element(root_tag, attribs)
        LOG.info(f"Created XML document with root: {root_tag}")

    def add_element(
        self, parent: ET.Element, tag: str, text: str = "", attribs: Dict[str, str] = None
    ) -> ET.Element:
        """
        Add element to parent.

        Args:
            parent: Parent element
            tag: Element tag name
            text: Element text content
            attribs: Element attributes

        Returns:
            Created element
        """
        attribs = attribs or {}
        elem = ET.SubElement(parent, tag, attribs)

        if text:
            elem.text = str(text)

        return elem

    def add_elements_from_list(
        self, parent: ET.Element, items: List[Dict[str, Any]], item_tag: str = "Item"
    ):
        """
        Add multiple elements from list of dictionaries.

        Args:
            parent: Parent element
            items: List of dictionaries
            item_tag: Tag name for each item
        """
        for item_dict in items:
            item_elem = ET.SubElement(parent, item_tag)

            for key, value in item_dict.items():
                if isinstance(value, (list, dict)):
                    continue
                self.add_element(item_elem, key, str(value))

    def save(self, filename: str, pretty_print: bool = True) -> Path:
        """
        Save XML to file.

        Args:
            filename: Output filename
            pretty_print: Whether to format the output

        Returns:
            Path to saved file
        """
        if pretty_print:
            ET.indent(self.root, space="  ")

        tree = ET.ElementTree(self.root)
        filepath = OUTPUT_DIR / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)

        tree.write(
            filepath, encoding="utf-8", xml_declaration=True
        )

        LOG.info(f"Saved XML to {filepath}")
        return filepath

    def get_root(self) -> ET.Element:
        """Get root element."""
        return self.root

    def to_string(self) -> str:
        """Convert to formatted string."""
        ET.indent(self.root, space="  ")
        return ET.tostring(self.root, encoding="unicode")


def create_orders_xml():
    """Create sample orders XML."""
    print("\n📝 Creating Orders XML...\n")

    writer = XMLWriter("Orders", {"version": "1.0", "company": "TechCorp"})
    orders_elem = writer.get_root()

    # Add orders
    orders_data = [
        {
            "OrderID": "ORD001",
            "CustomerName": "John Smith",
            "OrderDate": "2026-01-15",
            "Amount": "5000",
            "Status": "Completed",
        },
        {
            "OrderID": "ORD002",
            "CustomerName": "Sarah Johnson",
            "OrderDate": "2026-01-20",
            "Amount": "7500",
            "Status": "Processing",
        },
        {
            "OrderID": "ORD003",
            "CustomerName": "Michael Brown",
            "OrderDate": "2026-01-25",
            "Amount": "3200",
            "Status": "Pending",
        },
    ]

    writer.add_elements_from_list(orders_elem, orders_data, "Order")

    filepath = writer.save("orders.xml")
    print(f"✓ Created: {filepath}\n")
    print(writer.to_string())

    return filepath


def create_inventory_xml():
    """Create sample inventory XML."""
    print("\n📝 Creating Inventory XML...\n")

    writer = XMLWriter("Inventory", {"warehouse": "Main", "location": "USA"})
    inventory_elem = writer.get_root()

    # Add products
    products_data = [
        {
            "ProductID": "P001",
            "ProductName": "Laptop",
            "Quantity": "150",
            "Price": "1200",
            "Category": "Electronics",
        },
        {
            "ProductID": "P002",
            "ProductName": "Mouse",
            "Quantity": "500",
            "Price": "25",
            "Category": "Accessories",
        },
        {
            "ProductID": "P003",
            "ProductName": "Keyboard",
            "Quantity": "300",
            "Price": "80",
            "Category": "Accessories",
        },
    ]

    writer.add_elements_from_list(inventory_elem, products_data, "Product")

    filepath = writer.save("inventory.xml")
    print(f"✓ Created: {filepath}\n")
    print(writer.to_string())

    return filepath


def demonstrate_xml_modification():
    """Demonstrate XML modification."""
    print("\n" + "=" * 70)
    print("MODULE 4 - DEMO 2: XML PROCESSING")
    print("XML Writer & Modification Demonstration")
    print("=" * 70)

    create_orders_xml()
    create_inventory_xml()


def main():
    """Main entry point."""
    demonstrate_xml_modification()


if __name__ == "__main__":
    main()
