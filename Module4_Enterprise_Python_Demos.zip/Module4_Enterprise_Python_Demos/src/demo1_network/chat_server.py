"""
Demo 1: Network Programming - Multi-Client Chat Server

A chat server that broadcasts messages to all connected clients.
Demonstrates multi-threading, synchronization, and message broadcasting.
"""

import socket
import threading
import json
import time
from datetime import datetime
from typing import Dict, Set
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import Config, setup_logging

LOG = setup_logging(__name__)


class ChatServer:
    """Multi-client chat server with message broadcasting."""

    def __init__(self, host: str = Config.SERVER_HOST, port: int = Config.SERVER_PORT):
        """Initialize chat server."""
        self.host = host
        self.port = port
        self.socket: socket.socket | None = None
        self.running = False
        self.clients: Dict[int, socket.socket] = {}
        self.usernames: Dict[int, str] = {}
        self.client_lock = threading.Lock()
        self.client_counter = 0
        LOG.info(f"Chat server initialized on {self.host}:{self.port}")

    def start(self) -> None:
        """Start chat server."""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.socket.bind((self.host, self.port))
            self.socket.listen(Config.MAX_CLIENTS)

            self.running = True
            LOG.info(f"Chat server started on {self.host}:{self.port}")
            print(f"✓ Chat server listening on {self.host}:{self.port}")
            print("  Waiting for connections...")

            while self.running:
                try:
                    self.socket.settimeout(1.0)
                    client_sock, addr = self.socket.accept()

                    with self.client_lock:
                        self.client_counter += 1
                        client_id = self.client_counter

                    LOG.info(f"New connection from {addr}")

                    thread = threading.Thread(
                        target=self._handle_client,
                        args=(client_id, client_sock),
                        daemon=True,
                    )
                    thread.start()

                except socket.timeout:
                    continue

        except KeyboardInterrupt:
            LOG.info("Server interrupted")
        except Exception as e:
            LOG.error(f"Server error: {e}")
        finally:
            self.stop()

    def _handle_client(self, client_id: int, client_sock: socket.socket) -> None:
        """Handle individual client."""
        try:
            client_sock.settimeout(Config.SOCKET_TIMEOUT)

            # Request username
            client_sock.sendall(b"USERNAME: ")
            username_data = client_sock.recv(256)
            username = username_data.decode("utf-8").strip()

            if not username:
                username = f"User{client_id}"

            with self.client_lock:
                self.clients[client_id] = client_sock
                self.usernames[client_id] = username

            LOG.info(f"Client {client_id} joined as '{username}'")
            self._broadcast(f"[SERVER] {username} joined the chat", client_id)
            client_sock.sendall(b"OK\n")

            while self.running:
                data = client_sock.recv(Config.BUFFER_SIZE)
                if not data:
                    break

                message = data.decode("utf-8").strip()
                if message:
                    LOG.debug(f"{username}: {message}")
                    self._broadcast(f"{username}: {message}", client_id)

        except socket.timeout:
            LOG.warning(f"Client {client_id}: timeout")
        except Exception as e:
            LOG.error(f"Client {client_id} error: {e}")
        finally:
            with self.client_lock:
                if client_id in self.clients:
                    del self.clients[client_id]
                username = self.usernames.pop(client_id, "Unknown")

            client_sock.close()
            LOG.info(f"Client {client_id} disconnected")
            self._broadcast(f"[SERVER] {username} left the chat", client_id)

    def _broadcast(self, message: str, sender_id: int = -1) -> None:
        """Send message to all connected clients."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted = f"[{timestamp}] {message}"

        with self.client_lock:
            for client_id, client_sock in list(self.clients.items()):
                try:
                    client_sock.sendall((formatted + "\n").encode("utf-8"))
                except Exception as e:
                    LOG.error(f"Broadcast error for client {client_id}: {e}")

    def stop(self) -> None:
        """Stop server."""
        self.running = False
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
        LOG.info("Chat server stopped")
        print("✓ Server stopped")


def main():
    """Main entry point."""
    print("\n" + "=" * 60)
    print("MODULE 4 - DEMO 1: NETWORK PROGRAMMING")
    print("Multi-Client Chat Server")
    print("=" * 60 + "\n")

    server = ChatServer()
    server.start()


if __name__ == "__main__":
    main()
