"""
Demo 1: Network Programming - TCP Client

A TCP client that connects to a server and sends/receives messages.
Demonstrates client-side socket programming and protocol handling.
"""

import socket
import sys
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import Config, setup_logging
from src.utils import parse_host_port

LOG = setup_logging(__name__)


class TCPClient:
    """TCP client for communicating with server."""

    def __init__(self, host: str = Config.SERVER_HOST, port: int = Config.SERVER_PORT):
        """
        Initialize TCP client.

        Args:
            host: Server hostname/IP
            port: Server port number
        """
        self.host = host
        self.port = port
        self.socket: Optional[socket.socket] = None
        LOG.info(f"TCP Client initialized for {self.host}:{self.port}")

    def connect(self) -> bool:
        """
        Connect to server.

        Returns:
            True if successful, False otherwise
        """
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(Config.SOCKET_TIMEOUT)
            self.socket.connect((self.host, self.port))
            LOG.info(f"Connected to {self.host}:{self.port}")
            return True
        except socket.timeout:
            LOG.error("Connection timeout")
            return False
        except ConnectionRefusedError:
            LOG.error(f"Connection refused by {self.host}:{self.port}")
            return False
        except Exception as e:
            LOG.error(f"Connection error: {e}")
            return False

    def send(self, message: str) -> bool:
        """
        Send message to server.

        Args:
            message: Message to send

        Returns:
            True if successful, False otherwise
        """
        if not self.socket:
            LOG.error("Not connected")
            return False

        try:
            self.socket.sendall(message.encode("utf-8"))
            LOG.debug(f"Sent: {message}")
            return True
        except Exception as e:
            LOG.error(f"Send error: {e}")
            return False

    def receive(self) -> Optional[str]:
        """
        Receive message from server.

        Returns:
            Message or None if error
        """
        if not self.socket:
            LOG.error("Not connected")
            return None

        try:
            data = self.socket.recv(Config.BUFFER_SIZE)
            if not data:
                return None
            message = data.decode("utf-8")
            LOG.debug(f"Received: {message}")
            return message
        except socket.timeout:
            LOG.warning("Receive timeout")
            return None
        except Exception as e:
            LOG.error(f"Receive error: {e}")
            return None

    def interactive(self) -> None:
        """Run interactive client session."""
        print("\n" + "=" * 60)
        print("TCP CLIENT - Interactive Mode")
        print("=" * 60)
        print("Commands:")
        print("  ping       - Send ping to server")
        print("  time       - Get server time")
        print("  info       - Get client info")
        print("  ECHO:text  - Echo text back")
        print("  quit       - Exit")
        print("=" * 60 + "\n")

        while True:
            try:
                message = input(">>> ").strip()

                if not message:
                    continue

                if message.lower() == "quit":
                    break

                if not self.send(message):
                    break

                response = self.receive()
                if response:
                    print(f"<<< {response}\n")
                else:
                    break

            except KeyboardInterrupt:
                print("\nDisconnected")
                break
            except Exception as e:
                LOG.error(f"Error: {e}")
                break

    def close(self) -> None:
        """Close connection."""
        if self.socket:
            try:
                self.socket.close()
                LOG.info("Connection closed")
            except Exception as e:
                LOG.error(f"Close error: {e}")


def send_message(
    host: str, port: int, message: str, timeout: int = 5
) -> Optional[str]:
    """
    Send a single message and receive response (utility function).

    Args:
        host: Server host
        port: Server port
        message: Message to send
        timeout: Timeout in seconds

    Returns:
        Response message or None
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))

        sock.sendall(message.encode("utf-8"))
        response = sock.recv(Config.BUFFER_SIZE).decode("utf-8")

        sock.close()
        return response

    except Exception as e:
        LOG.error(f"Error: {e}")
        return None


def main():
    """Main entry point."""
    print("\n" + "=" * 60)
    print("MODULE 4 - DEMO 1: NETWORK PROGRAMMING")
    print("TCP Client Implementation")
    print("=" * 60 + "\n")

    # Parse command line arguments
    if len(sys.argv) > 1:
        server_addr = sys.argv[1]
        host, port = parse_host_port(server_addr, Config.SERVER_PORT)
    else:
        host = Config.SERVER_HOST
        port = Config.SERVER_PORT

    print(f"Connecting to {host}:{port}...")

    client = TCPClient(host, port)

    if client.connect():
        print("✓ Connected to server\n")
        client.interactive()
    else:
        print("✗ Failed to connect to server")
        sys.exit(1)

    client.close()


if __name__ == "__main__":
    main()
