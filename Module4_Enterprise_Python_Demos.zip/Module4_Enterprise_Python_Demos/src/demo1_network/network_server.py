"""
Demo 1: Network Programming - TCP Server

A multi-threaded TCP server that handles multiple client connections.
Demonstrates socket programming, threading, and protocol design.

Business Scenario:
An enterprise monitoring system needs to collect metrics from multiple agents.
"""

import socket
import threading
import json
import time
from typing import Dict, Optional
from pathlib import Path
import sys

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import Config, setup_logging, logger
from src.utils import NetworkUtils, save_json

LOG = setup_logging(__name__)


class TCPServer:
    """
    Multi-threaded TCP server implementation.

    Handles multiple concurrent client connections using threads.
    """

    def __init__(self, host: str = Config.SERVER_HOST, port: int = Config.SERVER_PORT):
        """
        Initialize TCP server.

        Args:
            host: Server hostname/IP
            port: Server port number
        """
        self.host = host
        self.port = port
        self.socket: Optional[socket.socket] = None
        self.running = False
        self.client_count = 0
        self.clients: Dict[int, socket.socket] = {}
        self.lock = threading.Lock()

        if not NetworkUtils.validate_port(port):
            raise ValueError(f"Invalid port number: {port}")

        LOG.info(f"TCP Server initialized on {self.host}:{self.port}")

    def start(self) -> None:
        """Start the server and listen for connections."""
        try:
            # Create socket
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            # Bind to address
            self.socket.bind((self.host, self.port))
            self.socket.listen(Config.MAX_CLIENTS)

            self.running = True
            LOG.info(f"Server started on {self.host}:{self.port}")
            print(f"✓ Server listening on {self.host}:{self.port}")
            print("  Press Ctrl+C to stop")

            # Accept connections
            while self.running:
                try:
                    self.socket.settimeout(1.0)
                    client_socket, client_address = self.socket.accept()

                    with self.lock:
                        self.client_count += 1
                        client_id = self.client_count

                    LOG.info(f"Client {client_id} connected from {client_address}")

                    # Handle client in separate thread
                    client_thread = threading.Thread(
                        target=self._handle_client,
                        args=(client_id, client_socket, client_address),
                        daemon=True,
                    )
                    client_thread.start()

                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        LOG.error(f"Error accepting connection: {e}")

        except OSError as e:
            LOG.error(f"Server error: {e}")
            if "Address already in use" in str(e):
                print(f"✗ Port {self.port} is already in use")
                print(f"  Try: netstat -ano | findstr :{self.port}")
        except KeyboardInterrupt:
            LOG.info("Server interrupt requested")
        finally:
            self.stop()

    def _handle_client(
        self, client_id: int, client_socket: socket.socket, client_address: tuple
    ) -> None:
        """
        Handle individual client connection.

        Args:
            client_id: Unique client identifier
            client_socket: Client socket object
            client_address: Client address tuple
        """
        try:
            client_socket.settimeout(Config.SOCKET_TIMEOUT)

            while self.running:
                # Receive data
                data = client_socket.recv(Config.BUFFER_SIZE)

                if not data:
                    break

                message = data.decode("utf-8").strip()
                LOG.info(f"Client {client_id}: {message}")

                # Process message
                response = self._process_message(message, client_id)

                # Send response
                client_socket.sendall(response.encode("utf-8"))

        except socket.timeout:
            LOG.warning(f"Client {client_id}: timeout")
        except Exception as e:
            LOG.error(f"Client {client_id} error: {e}")
        finally:
            client_socket.close()
            LOG.info(f"Client {client_id} disconnected")

    def _process_message(self, message: str, client_id: int) -> str:
        """
        Process client message and return response.

        Args:
            message: Message from client
            client_id: Client identifier

        Returns:
            Response message
        """
        if message.lower() == "ping":
            return "PONG"
        elif message.lower() == "time":
            return f"Server time: {time.strftime('%Y-%m-%d %H:%M:%S')}"
        elif message.lower() == "info":
            return f"Client ID: {client_id}"
        elif message.startswith("ECHO:"):
            return message[5:]
        else:
            return "Unknown command. Try: ping, time, info, ECHO:message"

    def stop(self) -> None:
        """Stop the server gracefully."""
        self.running = False
        if self.socket:
            try:
                self.socket.close()
            except Exception as e:
                LOG.error(f"Error closing socket: {e}")
        LOG.info("Server stopped")
        print("✓ Server stopped")


class EchoServer:
    """
    Simple echo server for basic testing.

    Echoes back any message received from clients.
    """

    def __init__(self, host: str = Config.SERVER_HOST, port: int = Config.SERVER_PORT):
        """Initialize echo server."""
        self.host = host
        self.port = port
        self.running = False
        LOG.info(f"Echo server initialized on {self.host}:{self.port}")

    def start(self) -> None:
        """Start echo server."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        try:
            sock.bind((self.host, self.port))
            sock.listen(Config.MAX_CLIENTS)
            self.running = True

            LOG.info(f"Echo server listening on {self.host}:{self.port}")
            print(f"✓ Echo server running on {self.host}:{self.port}")
            print("  Press Ctrl+C to stop")

            while self.running:
                try:
                    sock.settimeout(1.0)
                    client_sock, addr = sock.accept()

                    LOG.info(f"Echo client connected: {addr}")

                    threading.Thread(
                        target=self._echo_handler,
                        args=(client_sock, addr),
                        daemon=True,
                    ).start()

                except socket.timeout:
                    continue

        except KeyboardInterrupt:
            LOG.info("Echo server interrupted")
        finally:
            sock.close()
            self.running = False
            LOG.info("Echo server stopped")

    def _echo_handler(self, client_sock: socket.socket, addr: tuple) -> None:
        """Echo data back to client."""
        try:
            client_sock.settimeout(Config.SOCKET_TIMEOUT)
            while True:
                data = client_sock.recv(Config.BUFFER_SIZE)
                if not data:
                    break
                LOG.debug(f"Echo from {addr}: {data.decode()}")
                client_sock.sendall(data)
        except Exception as e:
            LOG.error(f"Echo handler error: {e}")
        finally:
            client_sock.close()


def main():
    """Main entry point."""
    print("\n" + "=" * 60)
    print("MODULE 4 - DEMO 1: NETWORK PROGRAMMING")
    print("TCP Server Implementation")
    print("=" * 60 + "\n")

    try:
        server = TCPServer()
        server.start()
    except Exception as e:
        LOG.error(f"Fatal error: {e}")
        print(f"✗ Error: {e}")


if __name__ == "__main__":
    main()
