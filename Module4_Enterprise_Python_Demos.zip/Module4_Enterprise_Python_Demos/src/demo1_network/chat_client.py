"""
Demo 1: Network Programming - Chat Client

Client for multi-client chat server.
Demonstrates threaded input/output handling.
"""

import socket
import threading
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.config import Config, setup_logging
from src.utils import parse_host_port

LOG = setup_logging(__name__)


class ChatClient:
    """Chat client implementation."""

    def __init__(self, host: str = Config.SERVER_HOST, port: int = Config.SERVER_PORT):
        """Initialize chat client."""
        self.host = host
        self.port = port
        self.socket = None
        self.running = False
        self.username = ""

    def connect(self) -> bool:
        """Connect to server."""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(Config.SOCKET_TIMEOUT)
            self.socket.connect((self.host, self.port))

            print(f"✓ Connected to {self.host}:{self.port}")

            # Get username
            self.username = input("Enter your name: ").strip() or f"User_{id(self)}"

            # Send username
            self.socket.sendall(self.username.encode("utf-8"))

            # Get confirmation
            response = self.socket.recv(256)
            if response == b"OK\n":
                print("✓ Welcome to chat!")
                return True
            else:
                LOG.error("Server rejected connection")
                return False

        except Exception as e:
            LOG.error(f"Connection error: {e}")
            return False

    def run(self) -> None:
        """Run chat client with separate threads for sending/receiving."""
        self.running = True

        # Start receive thread
        receive_thread = threading.Thread(target=self._receive_messages, daemon=True)
        receive_thread.start()

        # Send messages from main thread
        print("\nType messages (type 'quit' to exit):\n")

        try:
            while self.running:
                message = input()
                if message.lower() == "quit":
                    break

                if message:
                    self.socket.sendall(message.encode("utf-8"))

        except KeyboardInterrupt:
            print("\nDisconnecting...")
        except Exception as e:
            LOG.error(f"Error: {e}")

        self.close()

    def _receive_messages(self) -> None:
        """Receive messages from server."""
        try:
            while self.running:
                data = self.socket.recv(Config.BUFFER_SIZE)
                if not data:
                    break

                message = data.decode("utf-8")
                if message:
                    print(f"\r{message}", end="", flush=True)
                    print("\n>>> ", end="", flush=True)

        except socket.timeout:
            pass
        except Exception as e:
            if self.running:
                LOG.error(f"Receive error: {e}")

    def close(self) -> None:
        """Close connection."""
        self.running = False
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
        LOG.info("Client disconnected")
        print("\n✓ Disconnected")


def main():
    """Main entry point."""
    print("\n" + "=" * 60)
    print("MODULE 4 - DEMO 1: NETWORK PROGRAMMING")
    print("Chat Client")
    print("=" * 60 + "\n")

    if len(sys.argv) > 1:
        server_addr = sys.argv[1]
        host, port = parse_host_port(server_addr, Config.SERVER_PORT)
    else:
        host = Config.SERVER_HOST
        port = Config.SERVER_PORT

    client = ChatClient(host, port)

    if client.connect():
        client.run()
    else:
        print("✗ Failed to connect")
        sys.exit(1)


if __name__ == "__main__":
    main()
