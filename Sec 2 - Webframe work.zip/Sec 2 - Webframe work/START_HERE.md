# 🚀 START HERE - How to Run the Applications

## Quick Start

### Option 1: Run Bottle Application (Simple)

**Double-click**: `RUN_BOTTLE.bat`

OR type in PowerShell:
```powershell
cd "d:\Kiran\Open text\Day 3\Sec 2 - Webframe work"
python -c "from app.bottle_app.app import bottle_app; bottle_app.run(host='localhost', port=8080, debug=True)"
```

**Access**: http://localhost:8080/

---

### Option 2: Run Flask Application (with REST API)

**Double-click**: `RUN_FLASK.bat`

OR type in PowerShell:
```powershell
cd "d:\Kiran\Open text\Day 3\Sec 2 - Webframe work"
python -m flask --app app.flask_app run --debug
```

**Access**: 
- Web UI: http://localhost:5000
- REST API Docs: http://localhost:5000/api/v1/docs
- Health Check: http://localhost:5000/api/v1/health

---

### Option 3: Run Tests

```powershell
cd "d:\Kiran\Open text\Day 3\Sec 2 - Webframe work"
pytest tests/ -v
```

**Expected Result**: 44 passed ✅

---

## Application Comparison

### Bottle Application (Port 8080)

**Simple, Lightweight Framework**

What you get:
- Home page with employee list
- Add employee form
- Departments list
- Health check endpoint
- Static CSS styling

**Access**:
- http://localhost:8080/ - Home page
- http://localhost:8080/health - Health check

**Features**:
- Simple routing
- Template rendering
- Form handling
- Static files
- Error handling

---

### Flask Application (Port 5000)

**Full-Featured Framework with REST API**

What you get:
- Home page UI (like Bottle)
- **11 REST API endpoints** (JSON)
- **Swagger UI documentation**
- Complete CRUD operations
- Health check
- Error handling

**Access**:
- http://localhost:5000/ - Home page UI
- http://localhost:5000/api/v1/docs - API Documentation (Swagger)
- http://localhost:5000/api/v1/health - Health check

**REST API Endpoints**:

Employees:
```
GET    /api/v1/employees              List all
POST   /api/v1/employees              Create
GET    /api/v1/employees/{id}         Get one
PUT    /api/v1/employees/{id}         Update
DELETE /api/v1/employees/{id}         Delete
```

Departments:
```
GET    /api/v1/departments            List all
POST   /api/v1/departments            Create
GET    /api/v1/departments/{id}       Get one
```

---

## Troubleshooting

### Problem: Port 8080 Already in Use

**Solution**: Change port in code
```powershell
python -c "from app.bottle_app.app import bottle_app; bottle_app.run(host='localhost', port=9090)"
```

### Problem: Port 5000 Already in Use

**Solution**: Change port
```powershell
python -m flask --app app.flask_app run --port 5001
```

### Problem: Template Not Found Error

**Solution**: Clean database and restart
```powershell
rm app/database/*.db
# Then restart the app
```

### Problem: Module Not Found Error

**Solution**: Install dependencies
```powershell
pip install -r requirements.txt
```

---

## What Each Framework Shows

### Bottle (Lightweight)

Demonstrates:
- ✅ Simple web framework basics
- ✅ Routing and decorators
- ✅ Template rendering
- ✅ Form handling
- ✅ HTTP response handling
- ✅ Static file serving

**Best for**: Learning, prototyping, simple apps

---

### Flask (Full-Featured)

Demonstrates:
- ✅ Application factory pattern
- ✅ REST API design (Flask-RESTX)
- ✅ Modular blueprints
- ✅ OpenAPI/Swagger documentation
- ✅ Request validation
- ✅ Error handling
- ✅ Service layer architecture

**Best for**: Production, complex apps, microservices

---

## Testing the Applications

### Bottle - Manual Testing

```bash
# Home page
http://localhost:8080/

# Health check
curl http://localhost:8080/health

# Add employee via form
# (Use the browser form at http://localhost:8080/)
```

### Flask - Manual Testing

```bash
# Home page
http://localhost:5000/

# REST API - List employees
curl http://localhost:5000/api/v1/employees

# REST API - Create employee
curl -X POST http://localhost:5000/api/v1/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@example.com","department_name":"IT"}'

# REST API - Get one employee
curl http://localhost:5000/api/v1/employees/1

# REST API - Update
curl -X PUT http://localhost:5000/api/v1/employees/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane","email":"jane@example.com","department_name":"Sales"}'

# REST API - Delete
curl -X DELETE http://localhost:5000/api/v1/employees/1

# Health check
curl http://localhost:5000/api/v1/health

# Swagger UI (Open in browser)
http://localhost:5000/api/v1/docs
```

### Automated Tests

```bash
# Run all tests
pytest tests/ -v

# Run specific test
pytest tests/unit/test_services.py -v
pytest tests/api/test_api.py -v
pytest tests/integration/test_flask_app.py -v

# Run with coverage
pytest --cov=app tests/
```

---

## Understanding the Database

### Database File
```
app/database/enterprise_employee_portal.db
```

### Tables

**Employees**:
- id (auto-increment)
- name
- email (unique)
- department_name

**Departments**:
- id (auto-increment)
- name (unique)

### Reset Database

```powershell
# Delete database file
rm app/database/*.db

# Or just rename to backup
mv app/database/enterprise_employee_portal.db app/database/enterprise_employee_portal.db.backup
```

The database will be recreated automatically when you start an app.

---

## Project Structure

```
app/
├── bottle_app/
│   └── app.py              ← Bottle application (4 endpoints)
├── flask_app/
│   └── __init__.py         ← Flask application (15+ endpoints)
├── api/
│   ├── __init__.py         ← REST API setup
│   ├── employees.py        ← Employee endpoints
│   ├── departments.py      ← Department endpoints
│   └── health.py           ← Health check
├── services/
│   ├── employee_service.py
│   └── department_service.py
├── repository/
│   └── database.py         ← SQLite management
├── templates/
│   ├── index.html          ← Flask UI
│   ├── bottle_index.tpl    ← Bottle UI
│   └── error.html, error.tpl
├── static/
│   └── styles.css
└── utils/
    ├── config.py
    ├── logging_config.py
    ├── validators.py
    └── exceptions.py

tests/
├── unit/
│   └── test_services.py    (18 tests)
├── integration/
│   └── test_flask_app.py   (9 tests)
└── api/
    └── test_api.py         (17 tests)
```

---

## Documentation Files

| File | Purpose |
|------|---------|
| `START_HERE.md` | This file - quick start |
| `QUICK_REFERENCE.md` | Commands and endpoints |
| `BOTTLE_APP_EXPLAINED.md` | Bottle app detailed guide |
| `BOTTLE_APP_GUIDE.md` | Bottle vs Flask comparison |
| `REST_API_TEACHING.md` | Complete REST guide (15 sections) |
| `PHASE_5_SUMMARY.md` | REST API implementation |
| `PROJECT_STATUS.md` | Full project overview |
| `TEST_RESULTS.md` | Test verification report |
| `EXECUTION_SUMMARY.md` | What was built |

---

## Important Notes

### 1. Two Web Frameworks
This project demonstrates **both** Bottle and Flask:
- **Bottle**: Lightweight, simple (4 endpoints)
- **Flask**: Full-featured, REST API (11 endpoints)

Both are running on **different ports** (8080 and 5000), so you can run them simultaneously!

### 2. Database is Shared
Both applications use the **same SQLite database**, so:
- Create an employee in Bottle → See it in Flask
- Create an employee in Flask API → See it in Bottle UI

### 3. Tests are Independent
Tests use **temporary databases**, so:
- Running tests doesn't affect production data
- You can run tests while apps are running

### 4. Error Handling
If something goes wrong:
1. Check browser console (F12)
2. Check terminal output for error messages
3. Clean database: `rm app/database/*.db`
4. Restart the application

---

## Success Indicators

### Bottle App Working ✅
- Home page loads (http://localhost:8080/)
- Can see employees list
- Can see departments list
- Form can add employees
- Health check returns: `{"status": "ok"}`

### Flask App Working ✅
- Home page loads (http://localhost:5000/)
- REST API endpoints respond
- Swagger UI works (http://localhost:5000/api/v1/docs)
- Can create/read/update/delete employees via API
- Tests pass (44/44)

---

## Next Steps

### After running the apps:

1. **Explore Bottle** (Simple)
   - Understand routing
   - See form handling
   - Check template rendering

2. **Explore Flask** (Advanced)
   - Test REST API endpoints
   - Use Swagger UI
   - See validation in action

3. **Run Tests**
   - See full test coverage
   - Understand testing patterns

4. **Read Documentation**
   - REST_API_TEACHING.md for concepts
   - BOTTLE_APP_EXPLAINED.md for Bottle details
   - QUICK_REFERENCE.md for commands

---

## Summary

### What You Have

✅ **Two working web frameworks**
- Bottle (simple, 4 endpoints)
- Flask (full-featured, 11 REST endpoints)

✅ **Complete REST API**
- OpenAPI/Swagger documentation
- Full CRUD operations
- Input validation
- Error handling

✅ **Comprehensive Tests**
- 44 automated tests
- 100% pass rate
- Unit, integration, and API tests

✅ **Production-Ready Code**
- Clean architecture
- Enterprise patterns
- Best practices
- Extensive documentation

### Status

🟢 **PRODUCTION READY**
- All features working
- All tests passing
- Ready for demonstration
- Fully documented

---

## Commands Summary

```bash
# Start Bottle
python -c "from app.bottle_app.app import bottle_app; bottle_app.run(host='localhost', port=8080)"

# Start Flask
python -m flask --app app.flask_app run

# Run tests
pytest tests/ -v

# Install dependencies
pip install -r requirements.txt

# Clean database
rm app/database/*.db
```

---

**Enjoy exploring the Enterprise Employee Portal! 🚀**

Start with Bottle to understand basics, then explore Flask REST API for advanced features!
