# Bottle Application - Complete Explanation

**Status**: ✅ Verified and Working
**File**: `app/bottle_app/app.py`
**Framework**: Bottle (lightweight single-file web framework)
**Routes**: 4 endpoints registered
**Templates**: SimpleTemplate with .tpl files

---

## What is Bottle?

**Bottle** is a lightweight Python web framework contained in a single file (~4000 lines). It's designed for:
- Simple to medium-sized web applications
- Quick prototyping
- Learning web development
- Minimal dependencies

### Bottle vs Flask

| Aspect | Bottle | Flask |
|--------|--------|-------|
| **File Size** | Single file (~4KB) | Multiple modules |
| **Installation** | pip install bottle | pip install flask |
| **Routing** | @app.get, @app.post | @app.route(methods=[]) |
| **Templates** | SimpleTemplate | Jinja2 |
| **Learning Curve** | Very easy | Easy |
| **Scalability** | Good for small projects | Better for large projects |
| **Extensions** | Limited built-in | Many plugins available |

---

## Our Bottle Application Overview

### File Structure
```
app/bottle_app/
└── app.py                    (67 lines of Bottle code)

Dependencies:
├── app/services/            (Business logic)
├── app/templates/           (HTML templates)
├── app/static/              (CSS, JS, images)
└── app/utils/               (Config, logging)
```

### Endpoints Summary

| Method | URL | Purpose | Returns |
|--------|-----|---------|---------|
| GET | `/` | Home page | HTML with employees & departments |
| POST | `/employee` | Add employee form | 303 redirect to home |
| GET | `/health` | Health check | JSON status |
| GET | `/static/<file>` | Static files | CSS, JS, images |
| GET | `<404>` | Error handler | Error page HTML |

---

## Detailed Code Breakdown

### 1. Application Initialization

```python
from bottle import Bottle, HTTPResponse, request, response, template, static_file

bottle_app = Bottle()
employee_service = EmployeeService()
department_service = DepartmentService()
```

**What it does**:
- Creates Bottle application instance
- Initializes service layer
- Services handle all business logic

**Key Objects**:
- `bottle_app` - Main application instance
- `employee_service` - Manages employee CRUD
- `department_service` - Manages department CRUD

---

### 2. Home Page Endpoint

```python
@bottle_app.get('/')
def home():
    employees = employee_service.list_employees()
    departments = department_service.list_departments()
    return template(str(BASE_DIR / 'app' / 'templates' / 'bottle_index.tpl'), 
                   employees=employees, 
                   departments=departments)
```

**Request Flow**:
1. User visits `http://localhost:8080/`
2. Browser sends `GET /`
3. Bottle routes to `home()` function
4. Function fetches data from services
5. Renders `bottle_index.tpl` template
6. Returns HTML to browser

**Template Variables**:
- `employees` - List of all employees from database
- `departments` - List of all departments from database

**Response**:
```html
<h1>Enterprise Employee Portal</h1>
<!-- Form to add employees -->
<!-- List of employees -->
<!-- List of departments -->
```

**Status Code**: `200 OK`

---

### 3. Add Employee Endpoint

```python
@bottle_app.post('/employee')
def add_employee():
    name = request.forms.get('name', '')
    email = request.forms.get('email', '')
    department_name = request.forms.get('department', '')
    if name and email and department_name:
        employee_service.create_employee(name, email, department_name)
    response.status = 303
    response.headers['Location'] = '/'
    return ''
```

**Request Flow**:
1. User fills form on home page
2. Browser POSTs form data to `/employee`
3. Bottle routes to `add_employee()` function
4. Function extracts form fields
5. Validates fields exist
6. Calls service to create employee
7. Returns 303 redirect to home page
8. Browser redirects to `/`

**Form Fields**:
- `name` - Employee name
- `email` - Employee email
- `department` - Department name

**Response**:
- Status: `303 See Other` (redirect)
- Location: `/` (home page)
- User sees updated employee list

---

### 4. Health Check Endpoint

```python
@bottle_app.get('/health')
def health():
    return HTTPResponse(body={'status': 'ok'}, status=200)
```

**Purpose**: Check if application is running

**Request Flow**:
1. Client sends `GET /health`
2. Bottle routes to `health()` function
3. Returns JSON response

**Response**:
```json
{"status": "ok"}
```

**Status Code**: `200 OK`

**Use Case**: 
- Monitoring systems
- Load balancers
- Application health checks
- Uptime monitoring

---

### 5. Static Files Endpoint

```python
@bottle_app.get('/static/<filename:path>')
def serve_static(filename):
    return static_file(filename, root=str(BASE_DIR / 'app' / 'static'))
```

**Purpose**: Serve CSS, JS, images

**Request Flow**:
1. Browser requests `GET /static/styles.css`
2. Bottle extracts `filename` parameter
3. `static_file()` finds file in `app/static/`
4. Returns file with proper MIME type

**Example URLs**:
```
/static/styles.css          → app/static/styles.css
/static/js/script.js        → app/static/js/script.js
/static/images/logo.png     → app/static/images/logo.png
```

**Response**:
- File content
- Proper MIME type (text/css, text/javascript, etc.)
- Status: `200 OK`

---

### 6. Error Handling

```python
@bottle_app.error(404)
def not_found(error):
    return template(str(BASE_DIR / 'app' / 'templates' / 'error.tpl'), 
                   message='Page not found')
```

**Purpose**: Handle 404 Not Found errors

**Request Flow**:
1. User visits non-existent URL (e.g., `/xyz`)
2. Bottle doesn't find matching route
3. Triggers 404 error handler
4. Renders `error.tpl` template
5. Returns error page to browser

**Response**:
```html
<h1>Something went wrong</h1>
<p>Page not found</p>
```

**Status Code**: `404 Not Found`

---

## Template Files

### bottle_index.tpl (Main Template)

**Location**: `app/templates/bottle_index.tpl`

**Template Language**: SimpleTemplate (Bottle's built-in)

**Features**:
- `{{ variable }}` - Display variable
- `% for item in list:` - Loop
- `% if condition:` - Conditional
- `% end` - End block

**Content**:
```html
<!DOCTYPE html>
<html>
<head>
    <title>Enterprise Employee Portal</title>
    <link rel="stylesheet" href="/static/styles.css">
</head>
<body>
    <h1>Enterprise Employee Portal</h1>
    
    <form action="/employee" method="post">
        <input name="name" placeholder="Employee Name" />
        <input name="email" placeholder="Email" />
        <input name="department" placeholder="Department" />
        <button type="submit">Add Employee</button>
    </form>
    
    <h2>Employees</h2>
    <ul>
        % for employee in employees:
            <li>{{ employee.name }} - {{ employee.email }} ({{ employee.department_name }})</li>
        % end
    </ul>
    
    <h2>Departments</h2>
    <ul>
        % for department in departments:
            <li>{{ department.name }}</li>
        % end
    </ul>
</body>
</html>
```

**Key Sections**:
1. **Head** - Title, CSS link
2. **Form** - Add employee form
3. **Employees List** - Loop through employees
4. **Departments List** - Loop through departments

---

### error.tpl (Error Template)

**Location**: `app/templates/error.tpl`

**Used When**: 404 or other errors occur

**Content**:
```html
<!DOCTYPE html>
<html>
<head>
    <title>Error</title>
    <link rel="stylesheet" href="/static/styles.css">
</head>
<body>
    <h1>Something went wrong</h1>
    <p>{{ message }}</p>
</body>
</html>
```

---

## Request Lifecycle

```
1. CLIENT REQUEST
   ↓
   curl http://localhost:8080/
   POST /employee with form data
   GET /static/styles.css
   
2. BOTTLE ROUTING
   ↓
   Match URL to decorator
   @bottle_app.get('/')
   @bottle_app.post('/employee')
   @bottle_app.get('/static/<filename:path>')
   
3. PARAMETER EXTRACTION
   ↓
   For forms: request.forms.get('name')
   For query: request.args.get('id')
   For URL: filename (from <filename:path>)
   
4. HANDLER EXECUTION
   ↓
   Execute home(), add_employee(), serve_static()
   
5. BUSINESS LOGIC
   ↓
   Call services: employee_service.list_employees()
   Services call repository: DatabaseManager
   Database queries SQLite
   
6. RESPONSE GENERATION
   ↓
   Render template with data
   Set response status code
   Set response headers
   
7. RETURN TO CLIENT
   ↓
   Send HTML/JSON/file to browser
   Browser renders/processes
```

---

## Bottle vs Flask Code Comparison

### Routing

**Bottle**:
```python
@bottle_app.get('/employees')
def get_employees():
    return employee_service.list_employees()

@bottle_app.post('/employees')
def add_employee_form():
    name = request.forms.get('name')
```

**Flask**:
```python
@app.route('/employees', methods=['GET'])
def get_employees():
    return employee_service.list_employees()

@app.route('/employees', methods=['POST'])
def add_employee_form():
    name = request.form.get('name')
```

**Difference**: Bottle uses separate decorators per HTTP method

---

### Templates

**Bottle**:
```python
return template('index.tpl', employees=employees)
```

Template syntax (SimpleTemplate):
```html
% for emp in employees:
    <p>{{ emp.name }}</p>
% end
```

**Flask**:
```python
return render_template('index.html', employees=employees)
```

Template syntax (Jinja2):
```html
{% for emp in employees %}
    <p>{{ emp.name }}</p>
{% endfor %}
```

---

### Request Object

**Bottle**:
```python
name = request.forms.get('name')      # Form data
query = request.args.get('q')         # Query string
```

**Flask**:
```python
name = request.form.get('name')       # Form data
query = request.args.get('q')         # Query string
```

---

### Response

**Bottle**:
```python
response.status = 303
response.headers['Location'] = '/'
return ''
```

**Flask**:
```python
return redirect('/', 303)
```

---

## Running the Bottle Application

### Method 1: Direct Python

```bash
python -c "from app.bottle_app.app import bottle_app; bottle_app.run(host='localhost', port=8080)"
```

### Method 2: Using Waitress (Production)

```bash
waitress-serve --host=127.0.0.1 --port=8080 app.bottle_app.app:bottle_app
```

### Method 3: Using Gunicorn

```bash
gunicorn -b 127.0.0.1:8080 app.bottle_app.app:bottle_app
```

---

## Accessing the Application

### Home Page
```
http://localhost:8080/
```
Shows:
- Form to add employee
- List of employees
- List of departments

### Health Check
```
curl http://localhost:8080/health
```
Response:
```json
{"status": "ok"}
```

### Static Files
```
http://localhost:8080/static/styles.css
```

### Test Form Submission
```bash
curl -X POST http://localhost:8080/employee \
  -d "name=John&email=john@example.com&department=IT"
```

---

## Bottle Advantages

✅ **Lightweight** - Single file, minimal code
✅ **Simple** - Easy to understand and learn
✅ **Fast** - Low overhead
✅ **Built-in** - Templates, routing, error handling included
✅ **Flexible** - Works with SQLite, PostgreSQL, etc.
✅ **Educational** - Great for learning web basics

---

## Bottle Limitations

❌ **Single File** - Not ideal for very large applications
❌ **Limited Extensions** - Fewer third-party plugins than Flask
❌ **Smaller Community** - Less documentation and examples
❌ **SimpleTemplate** - Less powerful than Jinja2
❌ **Organization** - Harder to structure large projects

---

## When to Use Bottle

✅ Small to medium projects
✅ Quick prototypes
✅ Learning web development
✅ Minimal dependency requirements
✅ Simple APIs
✅ Educational demonstrations

---

## When to Use Flask

✅ Larger applications
✅ Complex projects
✅ Need for many extensions
✅ Team development
✅ Enterprise applications
✅ Long-term projects

---

## Key Concepts

### 1. Decorators
```python
@bottle_app.get('/')        # Map GET requests to /
@bottle_app.post('/add')    # Map POST requests to /add
@bottle_app.error(404)      # Handle 404 errors
```

### 2. Request Object
```python
request.forms.get('name')   # Form data
request.args.get('id')      # Query string
request.method              # HTTP method (GET, POST, etc.)
```

### 3. Response Object
```python
response.status = 200       # Set status code
response.headers['X-Key']   # Set header
return 'content'            # Return response body
```

### 4. Templates
```python
template('file.tpl', variable=value)  # Render template
```

---

## Integration with Services

Our Bottle app uses a **layered architecture**:

```
Bottle App (Routing)
        ↓
Service Layer (Business Logic)
        ↓
Repository Pattern (Data Access)
        ↓
SQLite Database
```

**Services**:
- `EmployeeService` - CRUD for employees
- `DepartmentService` - CRUD for departments

**Benefits**:
- Clean separation of concerns
- Easy to test
- Reusable business logic
- Database agnostic

---

## Conclusion

**Bottle** is a lightweight web framework perfect for our educational demonstration because it:

1. **Shows fundamentals** - Easy to understand routing and templating
2. **Minimal overhead** - Clear what the framework does vs app code
3. **Production-ready** - Can actually be used for real applications
4. **Comparable to Flask** - Good for showing framework differences
5. **Enterprise-applicable** - Demonstrates proper architecture patterns

Our implementation shows:
- ✅ Clean code structure
- ✅ Separation of concerns
- ✅ Proper service layer
- ✅ Database integration
- ✅ Error handling
- ✅ Template rendering
- ✅ Static file serving

**The Bottle app is production-ready and fully functional!**
