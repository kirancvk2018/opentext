@echo off
REM Start Flask Application on Port 5000

echo.
echo ====================================
echo Starting Flask Application
echo ====================================
echo.
echo Application will run at:
echo   http://localhost:5000
echo.
echo Swagger API Documentation:
echo   http://localhost:5000/api/v1/docs
echo.
echo Press Ctrl+C to stop the server
echo.

cd /d "d:\Kiran\Open text\Day 3\Sec 2 - Webframe work"

python -m flask --app app.flask_app run --debug

pause
