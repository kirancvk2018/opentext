"""Flask app integration tests"""

import pytest
import random
from app.flask_app import create_app


@pytest.fixture
def app_instance():
    """Create Flask app for testing"""
    app = create_app(testing=True)
    return app


@pytest.fixture
def client(app_instance):
    """Create test client"""
    return app_instance.test_client()


def unique_email():
    """Generate unique email"""
    return f"test{random.randint(100000, 999999)}@example.com"


class TestFlaskAppUI:
    """Flask app UI tests"""

    def test_homepage_renders_200(self, client):
        """GET / returns 200 OK"""
        response = client.get("/")
        assert response.status_code == 200

    def test_homepage_contains_title(self, client):
        """Homepage contains title"""
        response = client.get("/")
        assert b"Enterprise Employee Portal" in response.data

    def test_homepage_contains_form(self, client):
        """Homepage contains form elements"""
        response = client.get("/")
        assert b"form" in response.data.lower()

    def test_homepage_shows_content(self, client):
        """Homepage displays main content"""
        response = client.get("/")
        assert response.status_code == 200
        assert len(response.data) > 100


class TestFlaskAppErrorHandling:
    """Error handling tests"""

    def test_404_error_page(self, client):
        """Non-existent page returns 404"""
        response = client.get("/nonexistent-page-xyz")
        assert response.status_code == 404

    def test_static_files_served(self, client):
        """Static CSS file is served"""
        response = client.get("/static/styles.css")
        assert response.status_code == 200
        assert b"body" in response.data or b"font-family" in response.data


class TestAPIIntegration:
    """API integration with Flask app"""

    def test_api_list_employees_works(self, client):
        """API list employees endpoint works"""
        response = client.get("/api/v1/employees")
        assert response.status_code == 200
        assert isinstance(response.json, list)

    def test_api_health_check(self, client):
        """API health check works"""
        response = client.get("/api/v1/health")
        assert response.status_code == 200
        assert response.json["status"] == "healthy"

    def test_api_create_and_list(self, client):
        """Create employee via API and list it"""
        # Create
        payload = {
            "name": "Integration Test",
            "email": unique_email(),
            "department_name": "Engineering"
        }
        create_response = client.post("/api/v1/employees", json=payload)
        assert create_response.status_code == 201

        # List
        list_response = client.get("/api/v1/employees")
        assert list_response.status_code == 200
        names = [e["name"] for e in list_response.json]
        assert "Integration Test" in names
