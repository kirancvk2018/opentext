import pytest
import tempfile
import os

from app.services.employee_service import EmployeeService
from app.services.department_service import DepartmentService
from app.repository.database import DatabaseManager


@pytest.fixture
def test_db():
    """Create temporary test database for each test"""
    db_fd, db_path = tempfile.mkstemp(suffix=".db")
    os.close(db_fd)
    db_manager = DatabaseManager(db_path)
    yield db_manager
    os.unlink(db_path)


@pytest.fixture
def employee_service(test_db):
    return EmployeeService(test_db)


@pytest.fixture
def department_service(test_db):
    return DepartmentService(test_db)


class TestEmployeeService:
    """Unit tests for EmployeeService"""

    def test_create_employee_returns_dict_with_id(self, employee_service):
        """create_employee returns dict with id"""
        result = employee_service.create_employee(
            "Alice Johnson",
            "alice@example.com",
            "Engineering"
        )
        assert isinstance(result, dict)
        assert "id" in result
        assert result["name"] == "Alice Johnson"

    def test_create_employee_has_required_fields(self, employee_service):
        """create_employee result has all required fields"""
        result = employee_service.create_employee(
            "Bob Smith",
            "bob@example.com",
            "Sales"
        )
        assert result["name"] == "Bob Smith"
        assert result["email"] == "bob@example.com"
        assert result["department_name"] == "Sales"

    def test_list_employees_returns_list(self, employee_service):
        """list_employees returns a list"""
        result = employee_service.list_employees()
        assert isinstance(result, list)

    def test_list_employees_contains_created_employee(self, employee_service):
        """list_employees includes created employee"""
        employee_service.create_employee("Charlie Brown", "charlie@example.com", "HR")
        employees = employee_service.list_employees()
        employee_names = [e["name"] for e in employees]
        assert "Charlie Brown" in employee_names

    def test_get_employee_by_id_returns_dict(self, employee_service):
        """get_employee returns a dict"""
        created = employee_service.create_employee(
            "Diana Prince",
            "diana@example.com",
            "Legal"
        )
        result = employee_service.get_employee(created["id"])
        assert isinstance(result, dict)
        assert result["name"] == "Diana Prince"

    def test_get_employee_by_nonexistent_id_returns_none(self, employee_service):
        """get_employee for non-existent returns None"""
        result = employee_service.get_employee(99999)
        assert result is None

    def test_update_employee_returns_updated_dict(self, employee_service):
        """update_employee returns updated employee"""
        created = employee_service.create_employee(
            "Eve Adams",
            "eve@example.com",
            "Marketing"
        )
        updated = employee_service.update_employee(
            created["id"],
            "Eve Adams Updated",
            "eve.updated@example.com",
            "Sales"
        )
        assert updated is not None
        assert updated["name"] == "Eve Adams Updated"
        assert updated["email"] == "eve.updated@example.com"

    def test_update_nonexistent_employee_returns_none(self, employee_service):
        """update_employee for non-existent returns None"""
        result = employee_service.update_employee(
            99999,
            "Fake",
            "fake@example.com",
            "IT"
        )
        assert result is None

    def test_delete_employee_returns_true(self, employee_service):
        """delete_employee returns True on success"""
        created = employee_service.create_employee(
            "Frank Miller",
            "frank@example.com",
            "Engineering"
        )
        result = employee_service.delete_employee(created["id"])
        assert result is True

    def test_delete_nonexistent_employee_returns_false(self, employee_service):
        """delete_employee returns False for non-existent"""
        result = employee_service.delete_employee(99999)
        assert result is False

    def test_delete_employee_actually_removes(self, employee_service):
        """delete_employee actually removes employee from list"""
        created = employee_service.create_employee(
            "Grace Lee",
            "grace@example.com",
            "Finance"
        )
        employee_id = created["id"]
        employee_service.delete_employee(employee_id)
        result = employee_service.get_employee(employee_id)
        assert result is None

    def test_create_multiple_employees(self, employee_service):
        """Can create multiple employees"""
        employee_service.create_employee("Henry Holmes", "henry@example.com", "IT")
        employee_service.create_employee("Iris Irving", "iris@example.com", "HR")
        employees = employee_service.list_employees()
        assert len(employees) >= 2


class TestDepartmentService:
    """Unit tests for DepartmentService"""

    def test_create_department_returns_dict_with_id(self, department_service):
        """create_department returns dict with id"""
        result = department_service.create_department("Engineering")
        assert isinstance(result, dict)
        assert "id" in result
        assert result["name"] == "Engineering"

    def test_list_departments_returns_list(self, department_service):
        """list_departments returns a list"""
        result = department_service.list_departments()
        assert isinstance(result, list)

    def test_list_departments_contains_created(self, department_service):
        """list_departments includes created department"""
        department_service.create_department("Sales")
        departments = department_service.list_departments()
        department_names = [d["name"] for d in departments]
        assert "Sales" in department_names

    def test_create_multiple_departments(self, department_service):
        """Can create multiple departments"""
        department_service.create_department("Marketing")
        department_service.create_department("Finance")
        departments = department_service.list_departments()
        assert len(departments) >= 2


class TestServiceErrorHandling:
    """Tests for service error handling"""

    def test_employee_service_handles_empty_name(self, employee_service):
        """Service accepts empty name (validation at API level)"""
        # Service layer doesn't validate - that's API layer responsibility
        result = employee_service.create_employee("", "test@example.com", "IT")
        assert result is not None

    def test_get_employee_multiple_times_consistent(self, employee_service):
        """Multiple calls to get_employee return same data"""
        created = employee_service.create_employee(
            "Jack Jackson",
            "jack@example.com",
            "Operations"
        )
        first_get = employee_service.get_employee(created["id"])
        second_get = employee_service.get_employee(created["id"])
        assert first_get == second_get
