"""Pytest configuration and fixtures"""

import os
import sqlite3
import tempfile
import pytest

from app.flask_app import create_app
from app.repository.database import DatabaseManager


@pytest.fixture(scope="function", autouse=False)
def test_db():
    """Create temporary test database"""
    db_fd, db_path = tempfile.mkstemp(suffix=".db")
    os.close(db_fd)

    db_manager = DatabaseManager(db_path)
    yield db_manager

    # Cleanup
    os.unlink(db_path)


@pytest.fixture(scope="function", autouse=False)
def app(test_db):
    """Create Flask app with test database"""
    app = create_app(testing=True)

    with app.app_context():
        yield app


@pytest.fixture(scope="function", autouse=False)
def client(app):
    """Create Flask test client"""
    return app.test_client()
