"""REST API tests - Flask-RESTX endpoints"""

import pytest
import random
from app.flask_app import create_app


@pytest.fixture
def app_instance():
    """Create Flask app for testing"""
    app = create_app(testing=True)
    return app


@pytest.fixture
def client(app_instance):
    """Create test client"""
    return app_instance.test_client()


def unique_email():
    """Generate unique email for testing"""
    return f"test{random.randint(100000, 999999)}@example.com"


class TestEmployeeAPI:
    """Employee REST API tests"""

    def test_list_employees_returns_200(self, client):
        """GET /api/v1/employees returns 200 OK"""
        response = client.get("/api/v1/employees")
        assert response.status_code == 200
        assert isinstance(response.json, list)

    def test_create_employee_returns_201(self, client):
        """POST /api/v1/employees returns 201 Created"""
        payload = {
            "name": "Test Employee",
            "email": unique_email(),
            "department_name": "Engineering"
        }
        response = client.post("/api/v1/employees", json=payload, content_type="application/json")
        assert response.status_code == 201
        assert response.json["name"] == "Test Employee"

    def test_create_employee_missing_field_returns_400(self, client):
        """POST /api/v1/employees with missing field returns 400"""
        payload = {"email": unique_email()}
        response = client.post("/api/v1/employees", json=payload, content_type="application/json")
        assert response.status_code == 400

    def test_get_employee_by_id_returns_200(self, client):
        """GET /api/v1/employees/{id} returns 200 OK"""
        # Create employee
        create_payload = {
            "name": "Get Test",
            "email": unique_email(),
            "department_name": "Sales"
        }
        create_response = client.post("/api/v1/employees", json=create_payload, content_type="application/json")
        assert create_response.status_code == 201

        employee_id = create_response.json["id"]
        response = client.get(f"/api/v1/employees/{employee_id}")
        assert response.status_code == 200
        assert response.json["name"] == "Get Test"

    def test_get_nonexistent_employee_returns_404(self, client):
        """GET /api/v1/employees/{id} for non-existent returns 404"""
        response = client.get("/api/v1/employees/99999")
        assert response.status_code == 404

    def test_update_employee_returns_200(self, client):
        """PUT /api/v1/employees/{id} returns 200 OK"""
        # Create
        create_payload = {
            "name": "Update Test",
            "email": unique_email(),
            "department_name": "HR"
        }
        create_response = client.post("/api/v1/employees", json=create_payload, content_type="application/json")
        employee_id = create_response.json["id"]

        # Update
        update_payload = {
            "name": "Updated Name",
            "email": unique_email(),
            "department_name": "Finance"
        }
        response = client.put(f"/api/v1/employees/{employee_id}", json=update_payload, content_type="application/json")
        assert response.status_code == 200
        assert response.json["name"] == "Updated Name"

    def test_delete_employee_returns_204(self, client):
        """DELETE /api/v1/employees/{id} returns 204 No Content"""
        # Create
        create_payload = {
            "name": "Delete Test",
            "email": unique_email(),
            "department_name": "IT"
        }
        create_response = client.post("/api/v1/employees", json=create_payload, content_type="application/json")
        employee_id = create_response.json["id"]

        # Delete
        response = client.delete(f"/api/v1/employees/{employee_id}")
        assert response.status_code == 204

    def test_delete_nonexistent_returns_404(self, client):
        """DELETE /api/v1/employees/{id} for non-existent returns 404"""
        response = client.delete("/api/v1/employees/99999")
        assert response.status_code == 404


class TestDepartmentAPI:
    """Department REST API tests"""

    def test_list_departments_returns_200(self, client):
        """GET /api/v1/departments returns 200 OK"""
        response = client.get("/api/v1/departments")
        assert response.status_code == 200
        assert isinstance(response.json, list)

    def test_create_department_returns_201(self, client):
        """POST /api/v1/departments returns 201 Created"""
        payload = {"name": f"Dept{random.randint(1000, 9999)}"}
        response = client.post("/api/v1/departments", json=payload, content_type="application/json")
        assert response.status_code == 201
        assert "name" in response.json

    def test_create_department_missing_name_returns_400(self, client):
        """POST /api/v1/departments without name returns 400"""
        response = client.post("/api/v1/departments", json={}, content_type="application/json")
        assert response.status_code == 400

    def test_get_department_by_id_returns_200(self, client):
        """GET /api/v1/departments/{id} returns 200 OK"""
        # Create
        payload = {"name": f"TestDept{random.randint(1000, 9999)}"}
        create_response = client.post("/api/v1/departments", json=payload, content_type="application/json")
        department_id = create_response.json["id"]

        # Get
        response = client.get(f"/api/v1/departments/{department_id}")
        assert response.status_code == 200

    def test_get_nonexistent_department_returns_404(self, client):
        """GET /api/v1/departments/{id} for non-existent returns 404"""
        response = client.get("/api/v1/departments/99999")
        assert response.status_code == 404


class TestHealthCheckAPI:
    """Health check endpoint tests"""

    def test_health_check_returns_200(self, client):
        """GET /api/v1/health returns 200 OK"""
        response = client.get("/api/v1/health")
        assert response.status_code == 200
        assert response.json["status"] == "healthy"


class TestAPIErrorHandling:
    """API error handling tests"""

    def test_invalid_json_returns_error(self, client):
        """POST with invalid JSON returns error"""
        response = client.post("/api/v1/employees", data="invalid", content_type="application/json")
        assert response.status_code in [400, 422]

    def test_empty_employee_list_valid(self, client):
        """Empty employee list is valid JSON"""
        response = client.get("/api/v1/employees")
        assert response.status_code == 200
        assert isinstance(response.json, list)

    def test_list_departments_returns_list(self, client):
        """GET departments returns list"""
        response = client.get("/api/v1/departments")
        assert response.status_code == 200
        assert isinstance(response.json, list)
