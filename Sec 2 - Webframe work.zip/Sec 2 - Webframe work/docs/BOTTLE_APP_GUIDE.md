# Bottle Framework Application Guide

## What is Bottle?

**Bottle** is a lightweight, single-file Python web framework that makes it easy to build simple to medium-sized web applications.

### Key Characteristics

| Feature | Bottle | Flask |
|---------|--------|-------|
| **Size** | ~4000 lines (single file) | ~6000+ lines (multiple modules) |
| **Learning Curve** | Very easy | Easy |
| **Complexity** | Simple | Medium |
| **Built-in Features** | Basic routing, templating | Modular, extensible |
| **Performance** | Fast & lightweight | Fast & flexible |
| **Use Case** | Small to medium projects | Small to large projects |
| **Dependencies** | Minimal | More dependencies |

---

## The Bottle Application

### File Location
```
app/bottle_app/app.py
```

### Code Structure

```python
from bottle import Bottle, HTTPResponse, request, response, template, static_file

bottle_app = Bottle()
employee_service = EmployeeService()
department_service = DepartmentService()
```

### What Bottle Provides

Bottle gives you:
- **Routing** - Map URLs to functions
- **Request handling** - Access form data, JSON, headers
- **Templates** - Render HTML with SimpleTemplate
- **Static files** - Serve CSS, JS, images
- **Error handling** - Built-in error pages
- **HTTP responses** - Set status codes and headers

---

## Bottle vs Flask - Side by Side Comparison

### 1. ROUTING

**Bottle**:
```python
@bottle_app.get('/')
def home():
    return "Hello, World!"

@bottle_app.post('/employee')
def add_employee():
    name = request.forms.get('name')
    return redirect('/')
```

**Flask**:
```python
@app.route('/', methods=['GET'])
def home():
    return "Hello, World!"

@app.route('/employee', methods=['POST'])
def add_employee():
    name = request.form.get('name')
    return redirect('/')
```

**Comparison**:
- Bottle: Separate decorators for HTTP methods (`@get`, `@post`)
- Flask: Single `@route` decorator with methods parameter

### 2. TEMPLATES

**Bottle** (uses SimpleTemplate):
```python
@bottle_app.get('/')
def home():
    employees = employee_service.list_employees()
    return template('index.tpl', employees=employees)
```

**Template File** (`index.tpl`):
```html
<h1>Employees</h1>
% for employee in employees:
    <p>{{ employee.name }}</p>
% end
```

**Flask** (uses Jinja2):
```python
@app.route('/')
def home():
    employees = employee_service.list_employees()
    return render_template('index.html', employees=employees)
```

**Template File** (`index.html`):
```html
<h1>Employees</h1>
{% for employee in employees %}
    <p>{{ employee.name }}</p>
{% endfor %}
```

**Comparison**:
- Bottle: SimpleTemplate - simpler, less powerful
- Flask: Jinja2 - more powerful, more features

### 3. FORM DATA

**Bottle**:
```python
@bottle_app.post('/login')
def login():
    username = request.forms.get('username')
    password = request.forms.get('password')
```

**Flask**:
```python
@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
```

**Comparison**:
- Bottle: `request.forms` (plural)
- Flask: `request.form` (singular)

### 4. STATIC FILES

**Bottle**:
```python
@bottle_app.get('/static/<filename:path>')
def serve_static(filename):
    return static_file(filename, root='app/static')
```

**Flask**:
```python
# Automatic - no code needed
# Access via: url_for('static', filename='styles.css')
```

**Comparison**:
- Bottle: Manual routing for static files
- Flask: Automatic static file handling

### 5. ERROR HANDLING

**Bottle**:
```python
@bottle_app.error(404)
def not_found(error):
    return template('error.tpl', message='Page not found')
```

**Flask**:
```python
@app.errorhandler(404)
def not_found(error):
    return render_template('error.html', message='Page not found'), 404
```

**Comparison**:
- Bottle: Dedicated error decorators
- Flask: General error handler decorator

### 6. RESPONSE OBJECTS

**Bottle**:
```python
@bottle_app.get('/api/data')
def get_data():
    response.status = 200
    response.headers['Content-Type'] = 'application/json'
    return {'data': 'value'}
```

**Flask**:
```python
@app.route('/api/data')
def get_data():
    return jsonify({'data': 'value'}), 200
```

**Comparison**:
- Bottle: Modify global `response` object
- Flask: Return tuple of (response, status_code)

---

## Our Bottle Application Structure

### Endpoints

**1. Home Page**
```python
@bottle_app.get('/')
def home():
    employees = employee_service.list_employees()
    departments = department_service.list_departments()
    return template('bottle_index.tpl', employees=employees, departments=departments)
```

**What it does**:
- GET request to `/`
- Fetches all employees and departments
- Renders bottle_index.tpl template
- Shows employees and departments list

**URL**: http://localhost:8080/

---

**2. Add Employee (Form Submission)**
```python
@bottle_app.post('/employee')
def add_employee():
    name = request.forms.get('name', '')
    email = request.forms.get('email', '')
    department_name = request.forms.get('department', '')
    if name and email and department_name:
        employee_service.create_employee(name, email, department_name)
    response.status = 303
    response.headers['Location'] = '/'
    return ''
```

**What it does**:
- POST request to `/employee`
- Gets form data (name, email, department)
- Creates new employee via service
- Returns 303 redirect to home page
- Browser shows updated employee list

**Form submission**: From the home page form

---

**3. Health Check**
```python
@bottle_app.get('/health')
def health():
    return HTTPResponse(body={'status': 'ok'}, status=200)
```

**What it does**:
- GET request to `/health`
- Returns JSON status
- Used to check if app is running

**URL**: http://localhost:8080/health

---

**4. Static Files**
```python
@bottle_app.get('/static/<filename:path>')
def serve_static(filename):
    return static_file(filename, root=str(BASE_DIR / 'app' / 'static'))
```

**What it does**:
- Serves CSS, JS, images from `/static` folder
- Example: `<link href="/static/styles.css">`

**URL**: http://localhost:8080/static/styles.css

---

**5. Error Handling**
```python
@bottle_app.error(404)
def not_found(error):
    return template(str(BASE_DIR / 'app' / 'templates' / 'error.tpl'), message='Page not found')
```

**What it does**:
- Catches all 404 errors
- Shows error page template
- Provides user-friendly error message

**Triggered**: When visiting non-existent URL

---

## How Bottle Works - Request Lifecycle

```
1. Client Request
   ↓
   GET /employee?id=1
   ↓
2. Bottle Routing
   ↓
   Match URL to @bottle_app.get('/employee')
   ↓
3. Extract Parameters
   ↓
   id = request.args.get('id')
   ↓
4. Execute Handler
   ↓
   Call the home() function
   ↓
5. Business Logic
   ↓
   Call employee_service.get_employee(id)
   ↓
6. Database Query
   ↓
   SQLite returns employee data
   ↓
7. Template Rendering
   ↓
   template('index.tpl', employee=employee)
   ↓
8. Response
   ↓
   return HTML to client
   ↓
9. Browser Displays
   ↓
   User sees rendered page
```

---

## Bottle Template Syntax

### Simple Template (bottle_index.tpl)

```html
% # Python comment (% prefix)
% for employee in employees:
    <p>{{ employee.name }} - {{ employee.email }}</p>
% end

% if len(departments) > 0:
    <h2>Departments</h2>
    % for dept in departments:
        <li>{{ dept.name }}</li>
    % end
% end
```

### Key Features

| Feature | Syntax | Example |
|---------|--------|---------|
| **Variable** | `{{ var }}` | `{{ employee.name }}` |
| **Python Code** | `% code` | `% for x in list:` |
| **End Block** | `% end` | After loop/if |
| **Comments** | `% #` | `% # this is comment` |
| **Conditions** | `% if condition:` | `% if x > 5:` |

---

## Running the Bottle Application

### Start Bottle Server

```bash
cd "d:\Kiran\Open text\Day 3\Sec 2 - Webframe work"

# Method 1: Direct Python
python -c "from app.bottle_app.app import bottle_app; bottle_app.run(host='localhost', port=8080)"

# Method 2: Using Waitress (production server)
waitress-serve --host=127.0.0.1 --port=8080 app.bottle_app.app:bottle_app
```

### Access the Application

- **Home Page**: http://localhost:8080/
- **Health Check**: http://localhost:8080/health
- **Static Files**: http://localhost:8080/static/styles.css

---

## Bottle vs Flask - When to Use Each

### Use Bottle When

✅ You want a lightweight framework
✅ Building a small to medium project
✅ You prefer simplicity over features
✅ Single-file framework is acceptable
✅ Minimal dependencies desired
✅ Learning web development basics

**Bottle is better for**:
- Simple websites
- APIs with few endpoints
- Quick prototypes
- Educational purposes
- Embedded applications

---

### Use Flask When

✅ You need extensibility
✅ Building larger applications
✅ You want modular structure
✅ Need many third-party extensions
✅ Building microservices
✅ Enterprise applications

**Flask is better for**:
- Complex applications
- Multiple blueprints needed
- REST APIs with many endpoints
- Full-featured web applications
- Long-term projects
- Team development

---

## Architecture Comparison

### Bottle Architecture
```
Single App Instance
    ↓
@bottle_app.get('/')    ← Direct decorator
@bottle_app.post('/api')
@bottle_app.error(404)
    ↓
Request Handler Functions
    ↓
Services/Database
```

**Characteristics**:
- All routes on single app object
- Flat structure
- Quick to set up
- Less organization for large apps

---

### Flask Architecture
```
Application Factory
    ↓
Flask(__name__)
    ↓
Blueprints (modular)
    ↓
@api_bp.route('/api/employees')  ← Blueprint decorator
@auth_bp.route('/login')
    ↓
Registered Blueprints
    ↓
Request Handler Functions
    ↓
Services/Database
```

**Characteristics**:
- Modular blueprint system
- Better organization
- Scalable structure
- More complex setup

---

## Code Example: Complete Bottle Application

```python
from bottle import Bottle, request, response, template, static_file

# Create app instance
app = Bottle()

# Simple data store (normally would use database)
employees = []

# Routes

@app.get('/')
def home():
    """Home page showing all employees"""
    return template(
        '''
        <h1>Employee List</h1>
        <form action="/add" method="post">
            <input name="name" placeholder="Name" required>
            <input name="email" placeholder="Email" required>
            <button type="submit">Add Employee</button>
        </form>
        
        <h2>Employees</h2>
        <ul>
        % for emp in employees:
            <li>{{ emp['name'] }} - {{ emp['email'] }}</li>
        % end
        </ul>
        ''',
        employees=employees
    )

@app.post('/add')
def add_employee():
    """Add new employee"""
    employees.append({
        'name': request.forms.get('name'),
        'email': request.forms.get('email')
    })
    response.status = 303
    response.headers['Location'] = '/'

@app.get('/api/employees')
def get_employees_api():
    """API endpoint returning JSON"""
    return {'employees': employees}

@app.get('/health')
def health():
    """Health check"""
    return {'status': 'ok'}

@app.error(404)
def error404(err):
    """Handle 404 errors"""
    return template('<h1>Not Found</h1><p>The page does not exist</p>')

if __name__ == '__main__':
    app.run(host='localhost', port=8080)
```

---

## Bottle Advantages

✅ **Lightweight** - Single file, minimal code
✅ **Simple** - Easy to learn and use
✅ **Fast** - Minimal overhead
✅ **Flexible** - Can be used for various purposes
✅ **Built-in** - Templates, routing, error handling
✅ **Good for Learning** - Teaches web fundamentals

---

## Bottle Limitations

❌ **Single File** - Not ideal for large applications
❌ **Limited Features** - No built-in ORM, authentication
❌ **Smaller Ecosystem** - Fewer third-party extensions
❌ **Scalability** - Harder to organize large projects
❌ **Community** - Smaller community than Flask/Django

---

## Our Enterprise Implementation

Our Bottle app demonstrates:

✅ **Clean Architecture**
- Service layer for business logic
- Repository pattern for data access
- Separation of concerns

✅ **Professional Features**
- Request validation
- Error handling
- Logging configuration
- Template rendering

✅ **Best Practices**
- Configuration management
- Modular services
- Type hints
- Clean code

---

## Testing Bottle Application

```bash
# Test with curl
curl http://localhost:8080/

# Test form submission
curl -X POST http://localhost:8080/employee \
  -d "name=John&email=john@example.com&department=IT"

# Test API endpoint
curl http://localhost:8080/api/employees

# Test health check
curl http://localhost:8080/health

# Test error handling
curl http://localhost:8080/nonexistent
```

---

## Conclusion

**Bottle Framework** is a lightweight web framework perfect for:
- Learning web development
- Building small to medium projects
- Quick prototypes
- Minimal dependency projects
- Educational demonstrations

Our implementation shows how Bottle can be used professionally with:
- Clean architecture patterns
- Service layer separation
- Database integration
- Template rendering
- Error handling
- Request/response management

**Bottle vs Flask**: Bottle is simpler and lighter, Flask is more powerful and scalable. Choose based on project complexity and team preferences.
