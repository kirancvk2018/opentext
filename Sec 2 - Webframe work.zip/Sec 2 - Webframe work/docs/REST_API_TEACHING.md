# REST API Implementation: Comprehensive Teaching Guide

## Table of Contents
1. [What is REST?](#what-is-rest)
2. [Why REST Exists](#why-rest-exists)
3. [Business Problems REST Solves](#business-problems)
4. [Advantages of REST](#advantages)
5. [Limitations](#limitations)
6. [Enterprise Use Cases](#enterprise-use-cases)
7. [Implementation Guide](#implementation-guide)
8. [Code Walkthrough](#code-walkthrough)
9. [Expected Output](#expected-output)
10. [Common Errors](#common-errors)
11. [Troubleshooting](#troubleshooting)
12. [Best Practices](#best-practices)
13. [Performance Considerations](#performance-considerations)
14. [Security Recommendations](#security-recommendations)
15. [Interview Questions](#interview-questions)
16. [Hands-on Exercise](#hands-on-exercise)

## What is REST?

### Definition
**REST** = **RE**presentational **S**tate **T**ransfer

REST is an architectural style for designing networked applications using HTTP as the communication protocol. It uses standard HTTP methods to perform CRUD operations on resources identified by URLs.

### Core Principles

1. **Resources**: Everything is a resource (Employee, Department)
2. **Identifiers**: Each resource has a unique URL
3. **Representation**: Resources are represented in JSON, XML, etc.
4. **Standard Methods**: HTTP methods (GET, POST, PUT, DELETE)
5. **Stateless**: Each request is independent
6. **Uniform Interface**: Consistent API design

### Example: Resource-Oriented URLs

```
Traditional (not REST):
GET  /getEmployee?id=1
POST /createEmployee
PUT  /updateEmployee?id=1
DELETE /deleteEmployee?id=1

REST Approach:
GET    /employees        (list all)
GET    /employees/1      (get one)
POST   /employees        (create)
PUT    /employees/1      (update)
DELETE /employees/1      (delete)
```

## Why REST Exists

### Historical Context

**Before REST (2000s)**:
- SOAP (Simple Object Access Protocol) - XML-heavy, complex
- RPC (Remote Procedure Calls) - Tightly coupled clients and servers
- Custom protocols - Inconsistent API designs
- Problems:
  - No standardization across APIs
  - Difficult to test and debug
  - High complexity for simple operations
  - Poor scalability

**REST Solution (2000 - Roy Fielding's dissertation)**:
- Simplified approach using HTTP
- Self-describing URLs
- Standard methods everyone knows
- Easy to test with browser or curl
- Scalable and cache-friendly

## Business Problems REST Solves

### 1. **Integration Challenge**
**Problem**: Connecting multiple systems and services
```
Monolithic App → Microservices Migration
Desktop App    → Mobile App (needs same backend)
Internal Tools → Partner API Access
```

**REST Solution**: Single API that all clients can use
```
Mobile Client ──┐
Web Browser  ──┼→ REST API → Database
Desktop App  ──┤
Third Parties──┘
```

### 2. **Scalability**
**Problem**: Growing number of clients
**REST Solution**: Stateless design allows horizontal scaling

### 3. **Standardization**
**Problem**: Every team building APIs differently
**REST Solution**: Everyone uses GET/POST/PUT/DELETE on resources

### 4. **Developer Experience**
**Problem**: Complex protocols are hard to learn
**REST Solution**: Anyone familiar with HTTP can use REST APIs

### 5. **Testing & Debugging**
**Problem**: Need complex tools to test APIs
**REST Solution**: Use browser, curl, Postman - simple tools

## Advantages of REST

### 1. **Simplicity**
- Uses standard HTTP methods
- No additional protocol overhead
- Easy to understand and implement

### 2. **Scalability**
- Stateless design
- Easy to distribute across servers
- Caching-friendly

### 3. **Reliability**
- Uses proven HTTP protocol
- Built-in error handling with status codes
- Retryable operations (idempotent)

### 4. **Flexibility**
- Works with any client: web, mobile, desktop
- Language-agnostic
- Format-agnostic (JSON, XML, etc.)

### 5. **Developer Experience**
- Easy to test (curl, browser)
- Self-documenting URLs
- Standard error codes

### 6. **Security**
- Use HTTPS for encryption
- Standard authentication methods (JWT, OAuth)
- Easier to audit and monitor

### 7. **Performance**
- HTTP caching
- Compression
- Efficient data transfer

## Limitations

### 1. **Over-fetching**
```
GET /employees/1 returns:
{
  "id": 1,
  "name": "Alice",
  "email": "alice@example.com",
  "department_name": "Engineering",
  "phone": "555-1234",
  "address": "...",
  "hire_date": "...",
  "salary": "..."  ← Not needed on frontend
}
```
**Solution**: GraphQL (but adds complexity)

### 2. **Under-fetching**
```
Client needs: Employee + Department Details
Required: 2 API calls instead of 1
/employees/1 → /departments/1
```
**Solution**: Custom endpoints or GraphQL

### 3. **Versioning Complexity**
```
URL Versioning:
GET /api/v1/employees    (old)
GET /api/v2/employees    (new)

Header Versioning:
GET /employees
Accept: application/vnd.company.v1+json
```

### 4. **Stateless Nature**
- Client must send all context
- Can't maintain session state easily
- Solved with JWT tokens

### 5. **No Built-in Pub/Sub**
- REST is request-response only
- Real-time updates need WebSockets or polling
- Solution: WebSockets for real-time features

## Enterprise Use Cases

### 1. **Microservices Architecture**
```
User Service
│
├─→ REST API → Other Services
│
Employee Service
│
├─→ REST API → Database
```

### 2. **Multi-Platform Delivery**
```
Mobile App (iOS, Android)
Web Portal
Desktop Application
Third-party Partners
        ↓
    REST API
        ↓
    Backend Services
```

### 3. **SaaS Applications**
- Customer data isolation
- Per-tenant APIs
- Usage tracking via API calls

### 4. **Real-time Dashboards**
- API provides data
- Client polls regularly
- Or WebSocket for real-time

### 5. **Mobile-first Development**
- API-first design
- Shared API between web and mobile
- Reduced duplication

## Implementation Guide

### Step 1: Define Resources

**Question**: What are our key entities?

```
Answer:
- Employee (create, read, update, delete, list)
- Department (create, read, update, delete, list)
- Health Status (read-only)
```

### Step 2: Design URLs

```
Employees:
GET    /api/v1/employees          List all
GET    /api/v1/employees/{id}     Get one
POST   /api/v1/employees          Create
PUT    /api/v1/employees/{id}     Update
DELETE /api/v1/employees/{id}     Delete

Departments:
GET    /api/v1/departments        List all
GET    /api/v1/departments/{id}   Get one
POST   /api/v1/departments        Create

Health:
GET    /api/v1/health             Status check
```

### Step 3: Define Data Models

```python
# Request Model (Input Validation)
{
  "name": "Alice Johnson",
  "email": "alice@example.com",
  "department_name": "Engineering"
}

# Response Model (Output Formatting)
{
  "id": 1,
  "name": "Alice Johnson",
  "email": "alice@example.com",
  "department_name": "Engineering"
}
```

### Step 4: Implement Endpoints

```python
@employee_ns.route("")
class EmployeeList(Resource):
    @employee_ns.doc("list_employees")
    @employee_ns.marshal_list_with(employee_model)
    def get(self):
        """List all employees"""
        return employee_service.list_employees()

    @employee_ns.doc("create_employee")
    @employee_ns.expect(employee_input_model)
    @employee_ns.marshal_with(employee_model, code=201)
    def post(self):
        """Create a new employee"""
        data = employee_ns.payload
        return employee_service.create_employee(
            data["name"], 
            data["email"], 
            data["department_name"]
        ), 201
```

### Step 5: Add Documentation

- Flask-RESTX auto-generates Swagger docs
- Models become schema definitions
- Decorators add operation descriptions
- Response codes documented

### Step 6: Add Error Handling

```python
if not data.get("name"):
    employee_ns.abort(400, "name is required")

if not employee:
    employee_ns.abort(404, f"Employee {id} not found")
```

## Code Walkthrough

### File: app/api/__init__.py

**Purpose**: Initialize API namespaces and models

```python
from flask_restx import Api, fields
from flask import Blueprint

# Blueprint: Container for API routes
api_bp = Blueprint("api", __name__, url_prefix="/api/v1")

# Api: Flask-RESTX wrapper for Swagger generation
api = Api(
    api_bp,
    version="1.0",
    title="Enterprise Employee Portal API",
    description="Complete REST API for Employee and Department Management",
    doc="/docs"  # Swagger UI location
)

# Namespaces: Logical grouping of endpoints
employee_ns = api.namespace("employees", description="Employee operations")
department_ns = api.namespace("departments", description="Department operations")

# Models: Define request/response structure
employee_model = api.model(
    "Employee",
    {
        "id": fields.Integer(required=True),
        "name": fields.String(required=True),
        "email": fields.String(required=True),
        "department_name": fields.String(required=True),
    }
)
```

**Key Concepts**:
- `Blueprint`: Flask's way to organize routes
- `Namespace`: REST endpoint grouping
- `Api.model`: Swagger schema definition
- `fields`: Type and validation specifications

### File: app/api/employees.py

**Purpose**: Employee resource endpoints

```python
@employee_ns.route("")
class EmployeeList(Resource):
    @employee_ns.marshal_list_with(employee_model)
    def get(self):
        """List all employees"""
        return employee_service.list_employees()

    @employee_ns.expect(employee_input_model)
    @employee_ns.marshal_with(employee_model, code=201)
    def post(self):
        """Create a new employee"""
        data = employee_ns.payload  # Validated input
        return employee_service.create_employee(
            data["name"], 
            data["email"], 
            data["department_name"]
        ), 201
```

**Key Decorators**:
- `@employee_ns.route("")`: URL binding
- `@employee_ns.expect()`: Input validation
- `@employee_ns.marshal_with()`: Output formatting
- `class Resource`: Base class from Flask-RESTX

**Data Flow**:
1. Client sends JSON → Flask receives
2. `@expect()` validates against model
3. `employee_ns.payload` contains validated data
4. Service processes and returns result
5. `@marshal_with()` formats response
6. Client receives JSON

### File: app/flask_app/__init__.py

**Purpose**: Application factory creating Flask app with API integration

```python
def create_app(testing: bool = False) -> Flask:
    app = Flask(__name__, ...)
    app.config.update(
        RESTX_MASK_SWAGGER=False,
        RESTX_JSON={"sort_keys": False}
    )

    # Register API blueprint
    from app.api import api_bp
    app.register_blueprint(api_bp)

    # Import routes (triggers Flask-RESTX registration)
    from app.api import employees, departments, health

    return app
```

**Key Steps**:
1. Create Flask app instance
2. Configure Flask-RESTX settings
3. Register API blueprint
4. Import route modules (activates endpoints)
5. Return configured app

## Expected Output

### Running the Application

```bash
$ python -m flask --app app.flask_app run
 * Running on http://127.0.0.1:5000
```

### Accessing Swagger UI

Navigate to: `http://localhost:5000/api/v1/docs`

You'll see:
- All endpoints listed
- Request/response models
- Interactive "Try it out" button
- Curl examples
- Response status codes

### Example API Call

**Request**:
```bash
curl -X POST http://localhost:5000/api/v1/employees \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Alice Johnson",
    "email": "alice@example.com",
    "department_name": "Engineering"
  }'
```

**Response**: `201 Created`
```json
{
  "id": 1,
  "name": "Alice Johnson",
  "email": "alice@example.com",
  "department_name": "Engineering"
}
```

### List Employees

**Request**:
```bash
curl http://localhost:5000/api/v1/employees
```

**Response**: `200 OK`
```json
[
  {
    "id": 1,
    "name": "Alice Johnson",
    "email": "alice@example.com",
    "department_name": "Engineering"
  }
]
```

## Common Errors

### Error 1: `405 Method Not Allowed`

```
POST /api/v1/employees
Error: 405 Method Not Allowed
```

**Cause**: Resource class doesn't have `post()` method

**Fix**:
```python
@employee_ns.route("")
class EmployeeList(Resource):
    def get(self):        # Add this
        return []
    
    def post(self):       # Add this
        return {}, 201
```

### Error 2: `400 Bad Request - name is required`

```json
{
  "errors": {
    "message": "name is required"
  }
}
```

**Cause**: Missing required field in request

**Fix**: Include all required fields
```json
{
  "name": "Alice",
  "email": "alice@example.com",
  "department_name": "Engineering"
}
```

### Error 3: `500 Internal Server Error`

```
Error: 500 Internal Server Error
```

**Cause**: Unhandled exception in code

**Fix**:
1. Check application logs
2. Add try-except blocks
3. Use proper error handling with `abort()`

### Error 4: `ImportError: No module named 'flask_restx'`

```
ModuleNotFoundError: No module named 'flask_restx'
```

**Cause**: Dependency not installed

**Fix**:
```bash
pip install -r requirements.txt
# or
pip install flask-restx
```

### Error 5: `404 Not Found - Employee 999 not found`

```json
{
  "errors": {
    "message": "Employee 999 not found"
  }
}
```

**Cause**: Requesting non-existent employee

**Fix**: Use valid employee ID
```bash
curl http://localhost:5000/api/v1/employees  # Get valid IDs first
curl http://localhost:5000/api/v1/employees/1  # Use existing ID
```

## Troubleshooting

### Issue: Swagger UI not showing endpoints

**Diagnosis**:
```python
# Check if API is registered
app.url_map  # In Flask shell
```

**Solution**:
```python
# In __init__.py
from app.api import api_bp, employees, departments, health
app.register_blueprint(api_bp)  # Must come first
# Then import modules
```

### Issue: CORS errors when calling from different domain

**Symptom**: `Cross-Origin Request Blocked`

**Solution**: Install and configure Flask-CORS
```python
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
```

### Issue: Database locked error

**Symptom**: `sqlite3.OperationalError: database is locked`

**Cause**: Multiple processes accessing database simultaneously

**Solution**:
```python
# In production, use connection pooling
# For SQLite, ensure WAL (Write-Ahead Logging) is enabled
conn.execute("PRAGMA journal_mode=WAL;")
```

### Issue: JSON serialization error for datetime

**Symptom**: `TypeError: Object of type datetime.datetime is not JSON serializable`

**Solution**:
```python
# Convert to ISO string
employee["hire_date"] = employee["hire_date"].isoformat()

# Or configure Flask
app.json.sort_keys = False
```

## Best Practices

### 1. **Use Consistent Naming**
```python
# Good
GET /api/v1/employees
POST /api/v1/employees
PUT /api/v1/employees/{id}

# Bad
GET /api/v1/GetEmployee
POST /api/v1/CreateEmployee
PUT /api/v1/UpdateEmployee
```

### 2. **Use Appropriate HTTP Methods**
```
GET    - Retrieve data (safe, idempotent)
POST   - Create data (not idempotent)
PUT    - Update data (idempotent)
DELETE - Remove data (idempotent)
PATCH  - Partial update (may be idempotent)
```

### 3. **Return Correct Status Codes**
```python
200 OK              # Successful GET/PUT
201 Created         # Successful POST
204 No Content      # Successful DELETE
400 Bad Request     # Invalid input
404 Not Found       # Resource missing
500 Server Error    # Unexpected error
```

### 4. **Version Your API**
```
Current:  /api/v1/employees
Future:   /api/v2/employees
```

### 5. **Validate All Inputs**
```python
@employee_ns.expect(employee_input_model)
def post(self):
    data = employee_ns.payload  # Already validated
    # Safe to use data
```

### 6. **Use Meaningful Error Messages**
```python
# Good
abort(400, "Email must be valid format: user@domain.com")

# Bad
abort(400, "Invalid input")
```

### 7. **Document Your API**
- Use Swagger/OpenAPI
- Add description decorators
- Document status codes
- Provide examples

### 8. **Handle Exceptions Gracefully**
```python
try:
    return employee_service.create_employee(...)
except Exception as e:
    employee_ns.abort(400, f"Failed to create employee: {str(e)}")
```

## Performance Considerations

### 1. **Database Indexing**
```sql
CREATE INDEX idx_employee_email ON employees(email);
CREATE INDEX idx_employee_department ON employees(department_name);
```

### 2. **Pagination for Large Results**
```python
@employee_ns.route("/paginated")
class EmployeeListPaginated(Resource):
    @employee_ns.doc(params={'page': 'Page number', 'per_page': 'Records per page'})
    def get(self):
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        return employee_service.get_paginated(page, per_page)
```

### 3. **Caching**
```python
from flask_caching import Cache

cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@employee_ns.route("")
class EmployeeList(Resource):
    @cache.cached(timeout=300)  # Cache for 5 minutes
    def get(self):
        return employee_service.list_employees()
```

### 4. **Asynchronous Processing**
```python
from celery import Celery

celery = Celery(app.name)

@employee_ns.route("")
class EmployeeList(Resource):
    def post(self):
        # Start background job
        process_employee.delay(data)
        return {"status": "processing"}, 202
```

## Security Recommendations

### 1. **Use HTTPS in Production**
```python
# Flask automatically redirects to HTTPS if configured
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
```

### 2. **Implement Authentication**
```python
from flask_httpauth import HTTPBearerAuth

auth = HTTPBearerAuth()

@auth.verify_token
def verify_token(token):
    # Validate JWT token
    return decode_jwt(token)

@employee_ns.route("")
class EmployeeList(Resource):
    @auth.login_required
    def get(self):
        return employee_service.list_employees()
```

### 3. **Rate Limiting**
```python
from flask_limiter import Limiter

limiter = Limiter(
    app=app,
    key_func=lambda: request.remote_addr,
    default_limits=["200 per day", "50 per hour"]
)

@limiter.limit("5/minute")
def post(self):
    return {}
```

### 4. **Input Validation**
```python
def validate_email(email):
    if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
        abort(400, "Invalid email format")
```

### 5. **SQL Injection Prevention**
```python
# Already safe: using parameterized queries
cursor.execute(
    "SELECT * FROM employees WHERE id = ?",
    (employee_id,)  # Parameter binding
)
```

### 6. **CORS Configuration**
```python
from flask_cors import CORS

CORS(app, resources={
    r"/api/*": {
        "origins": ["https://example.com"],
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})
```

## Interview Questions

### Question 1: What is REST and its core principles?

**Answer**: REST is Representational State Transfer. Its core principles are:
1. **Resources**: Everything is a resource with unique identifier
2. **Standard Methods**: HTTP methods (GET, POST, PUT, DELETE)
3. **Statelessness**: Each request is independent
4. **Uniform Interface**: Consistent API design
5. **Client-Server**: Separation of concerns

### Question 2: Difference between PUT and PATCH?

**Answer**:
- **PUT**: Full replacement of resource (idempotent)
- **PATCH**: Partial update (may not be idempotent)

Example:
```
PUT /employees/1
{
  "name": "Alice",
  "email": "alice@example.com",
  "department_name": "Engineering"
}
# Entire record replaced

PATCH /employees/1
{
  "email": "alice.new@example.com"
}
# Only email updated, other fields unchanged
```

### Question 3: How do you handle errors in REST APIs?

**Answer**: Use appropriate HTTP status codes and descriptive messages:
```python
400 Bad Request  - Invalid input
401 Unauthorized - Authentication failed
403 Forbidden    - Authorization failed
404 Not Found    - Resource missing
409 Conflict     - State conflict
500 Server Error - Unexpected error

Response:
{
  "errors": {
    "message": "Email already exists"
  }
}
```

### Question 4: Why is REST stateless?

**Answer**: Stateless design provides:
1. **Scalability**: Any server can handle any request
2. **Reliability**: No session state to lose
3. **Cacheability**: Responses can be cached
4. **Simplicity**: Each request contains all context

### Question 5: What is API versioning and why is it needed?

**Answer**: Versioning allows evolving the API without breaking existing clients:
```
/api/v1/employees  - Old API
/api/v2/employees  - New API with changes

Reasons:
- Breaking changes (field removal, type changes)
- New features requiring different response format
- Gradual deprecation of old versions
```

## Hands-on Exercise

### Exercise 1: Create New Endpoint

**Objective**: Add a search endpoint for employees

**Task**:
```python
# Add to app/api/employees.py
@employee_ns.route("/search")
class EmployeeSearch(Resource):
    @employee_ns.doc(params={'name': 'Employee name to search'})
    @employee_ns.marshal_list_with(employee_model)
    def get(self):
        """Search employees by name"""
        # Implementation here
        pass
```

**Implementation**:
```python
def get(self):
    search_term = request.args.get('name', '')
    if not search_term:
        employee_ns.abort(400, "name parameter is required")
    
    employees = employee_service.list_employees()
    results = [
        e for e in employees 
        if search_term.lower() in e['name'].lower()
    ]
    return results
```

**Testing**:
```bash
curl "http://localhost:5000/api/v1/employees/search?name=Alice"
```

### Exercise 2: Add Pagination

**Objective**: Implement pagination for large result sets

**Task**:
```python
@employee_ns.route("/paginated")
class EmployeeListPaginated(Resource):
    @employee_ns.doc(params={
        'page': 'Page number (default: 1)',
        'per_page': 'Records per page (default: 10)'
    })
    def get(self):
        """Get paginated employee list"""
        # Implementation here
        pass
```

**Implementation**:
```python
def get(self):
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    all_employees = employee_service.list_employees()
    total = len(all_employees)
    
    start = (page - 1) * per_page
    end = start + per_page
    
    return {
        "data": all_employees[start:end],
        "page": page,
        "per_page": per_page,
        "total": total,
        "pages": (total + per_page - 1) // per_page
    }
```

### Exercise 3: Add Request Validation

**Objective**: Enhance employee creation with validation

**Task**: Use validators.py to validate inputs before creating employee

**Implementation**:
```python
from app.utils.validators import validate_employee_input

def post(self):
    data = employee_ns.payload
    is_valid, error_msg = validate_employee_input(
        data["name"],
        data["email"],
        data["department_name"]
    )
    
    if not is_valid:
        employee_ns.abort(400, error_msg)
    
    return employee_service.create_employee(
        data["name"],
        data["email"],
        data["department_name"]
    ), 201
```

### Exercise 4: Add Logging

**Objective**: Log all API requests

**Task**:
```python
from app.utils.logging_config import configure_logging

logger = configure_logging()

@employee_ns.route("")
class EmployeeList(Resource):
    def get(self):
        logger.info("GET /api/v1/employees")
        return employee_service.list_employees()
    
    def post(self):
        logger.info(f"POST /api/v1/employees with {employee_ns.payload}")
        # Implementation
```

## Conclusion

The REST API implementation demonstrates enterprise-grade practices:
- **Stateless** design for scalability
- **Standard** HTTP methods and status codes
- **Validated** inputs using models
- **Documented** with Swagger/OpenAPI
- **Error handling** with descriptive messages
- **Logging** for monitoring and debugging

This foundation supports scaling to hundreds of endpoints and millions of requests while maintaining code quality and developer productivity.
