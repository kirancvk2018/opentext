@echo off
REM Start Bottle Application on Port 8080

echo.
echo ====================================
echo Starting Bottle Application
echo ====================================
echo.
echo Application will run at:
echo   http://localhost:8080
echo.
echo Press Ctrl+C to stop the server
echo.

cd /d "d:\Kiran\Open text\Day 3\Sec 2 - Webframe work"

python -c "from app.bottle_app.app import bottle_app; bottle_app.run(host='localhost', port=8080, debug=True)"

pause
