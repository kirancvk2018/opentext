from flask import Flask, redirect, render_template, request

from app.services.department_service import DepartmentService
from app.services.employee_service import EmployeeService
from app.utils.config import BASE_DIR
from app.utils.logging_config import configure_logging


logger = configure_logging()


def create_app(testing: bool = False) -> Flask:
    app = Flask(__name__, template_folder=str(BASE_DIR / "app" / "templates"), static_folder=str(BASE_DIR / "app" / "static"))
    app.config.update(
        TESTING=testing,
        SECRET_KEY="demo-secret",
        RESTX_MASK_SWAGGER=False,
        RESTX_JSON={"sort_keys": False}
    )

    employee_service = EmployeeService()
    department_service = DepartmentService()

    @app.route("/")
    def home() -> str:
        logger.info("Accessed home page")
        employees = employee_service.list_employees()
        departments = department_service.list_departments()
        return render_template("index.html", employees=employees, departments=departments)

    @app.route("/employee", methods=["POST"])
    def add_employee() -> str:
        name = request.form.get("name", "")
        email = request.form.get("email", "")
        department_name = request.form.get("department", "")
        if name and email and department_name:
            employee_service.create_employee(name, email, department_name)
        return redirect("/")

    @app.errorhandler(404)
    def not_found(error):
        return render_template("error.html", message="Page not found"), 404

    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Internal server error: {error}")
        return render_template("error.html", message="Internal server error"), 500

    from app.api import api_bp
    from app.api import employees  # noqa
    from app.api import departments  # noqa
    from app.api import health  # noqa

    app.register_blueprint(api_bp)

    return app


app = create_app()
