<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Error</title>
  <link rel="stylesheet" href="/static/styles.css">
</head>
<body>
  <h1>Something went wrong</h1>
  <p>{{ message }}</p>
</body>
</html>
