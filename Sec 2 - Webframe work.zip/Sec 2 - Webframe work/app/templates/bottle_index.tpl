<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Bottle Employee Portal</title>
</head>
<body>
  <h1>Bottle Employee Portal</h1>
  <form action="/employee" method="post">
    <input name="name" placeholder="Employee Name" />
    <input name="email" placeholder="Email" />
    <input name="department" placeholder="Department" />
    <button type="submit">Add Employee</button>
  </form>
  <h2>Employees</h2>
  <ul>
    % for employee in employees:
    <li>{{employee['name']}} - {{employee['email']}} ({{employee['department_name']}})</li>
    % end
  </ul>
  <h2>Departments</h2>
  <ul>
    % for department in departments:
    <li>{{department['name']}}</li>
    % end
  </ul>
</body>
</html>
