from typing import Any

from app.repository.database import DatabaseManager


class EmployeeService:
    def __init__(self, database_manager: DatabaseManager | None = None) -> None:
        self.database_manager = database_manager or DatabaseManager()

    def create_employee(self, name: str, email: str, department_name: str) -> dict[str, Any]:
        with self.database_manager.get_connection() as conn:
            cursor = conn.execute(
                "INSERT INTO employees (name, email, department_name) VALUES (?, ?, ?)",
                (name, email, department_name),
            )
            conn.commit()
            employee_id = cursor.lastrowid
            return {"id": employee_id, "name": name, "email": email, "department_name": department_name}

    def list_employees(self) -> list[dict[str, Any]]:
        with self.database_manager.get_connection() as conn:
            rows = conn.execute("SELECT id, name, email, department_name FROM employees ORDER BY id").fetchall()
            return [dict(row) for row in rows]

    def get_employee(self, employee_id: int) -> dict[str, Any] | None:
        with self.database_manager.get_connection() as conn:
            row = conn.execute(
                "SELECT id, name, email, department_name FROM employees WHERE id = ?",
                (employee_id,),
            ).fetchone()
            return None if row is None else dict(row)

    def update_employee(self, employee_id: int, name: str, email: str, department_name: str) -> dict[str, Any] | None:
        with self.database_manager.get_connection() as conn:
            conn.execute(
                "UPDATE employees SET name = ?, email = ?, department_name = ? WHERE id = ?",
                (name, email, department_name, employee_id),
            )
            conn.commit()
            if conn.total_changes == 0:
                return None
            return self.get_employee(employee_id)

    def delete_employee(self, employee_id: int) -> bool:
        with self.database_manager.get_connection() as conn:
            cursor = conn.execute("DELETE FROM employees WHERE id = ?", (employee_id,))
            conn.commit()
            return cursor.rowcount > 0
