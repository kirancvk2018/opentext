from typing import Any

from app.repository.database import DatabaseManager


class DepartmentService:
    def __init__(self, database_manager: DatabaseManager | None = None) -> None:
        self.database_manager = database_manager or DatabaseManager()

    def create_department(self, name: str) -> dict[str, Any]:
        with self.database_manager.get_connection() as conn:
            cursor = conn.execute("INSERT INTO departments (name) VALUES (?)", (name,))
            conn.commit()
            return {"id": cursor.lastrowid, "name": name}

    def list_departments(self) -> list[dict[str, Any]]:
        with self.database_manager.get_connection() as conn:
            rows = conn.execute("SELECT id, name FROM departments ORDER BY id").fetchall()
            return [dict(row) for row in rows]
