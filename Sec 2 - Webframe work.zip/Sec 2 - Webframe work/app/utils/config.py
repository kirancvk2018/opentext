import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

BASE_DIR = Path(__file__).resolve().parents[2]
DATABASE_PATH = os.getenv("DATABASE_PATH", str(BASE_DIR / "app" / "database" / "enterprise_employee_portal.db"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
FLASK_ENV = os.getenv("FLASK_ENV", "development")
