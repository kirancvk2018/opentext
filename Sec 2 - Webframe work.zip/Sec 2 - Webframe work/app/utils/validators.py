"""Request validation utilities for enterprise API"""

import re
from typing import Tuple


def validate_email(email: str) -> Tuple[bool, str]:
    """Validate email format.

    Args:
        email: Email address to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        return False, "Invalid email format"
    return True, ""


def validate_employee_input(name: str, email: str, department_name: str) -> Tuple[bool, str]:
    """Validate employee input data.

    Args:
        name: Employee name
        email: Employee email
        department_name: Department name

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not name or not name.strip():
        return False, "Employee name cannot be empty"

    if len(name) > 100:
        return False, "Employee name must be 100 characters or less"

    if not email or not email.strip():
        return False, "Email cannot be empty"

    is_valid_email, email_error = validate_email(email)
    if not is_valid_email:
        return False, email_error

    if not department_name or not department_name.strip():
        return False, "Department name cannot be empty"

    if len(department_name) > 50:
        return False, "Department name must be 50 characters or less"

    return True, ""


def validate_department_input(name: str) -> Tuple[bool, str]:
    """Validate department input data.

    Args:
        name: Department name

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not name or not name.strip():
        return False, "Department name cannot be empty"

    if len(name) > 50:
        return False, "Department name must be 50 characters or less"

    return True, ""
