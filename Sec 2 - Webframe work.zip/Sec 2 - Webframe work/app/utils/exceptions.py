"""Custom exception classes for enterprise application"""


class PortalException(Exception):
    """Base exception for Enterprise Employee Portal"""

    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class ValidationError(PortalException):
    """Raised when input validation fails"""

    def __init__(self, message: str):
        super().__init__(message, 400)


class ResourceNotFoundError(PortalException):
    """Raised when requested resource is not found"""

    def __init__(self, resource_type: str, resource_id: int):
        message = f"{resource_type} {resource_id} not found"
        super().__init__(message, 404)


class DuplicateResourceError(PortalException):
    """Raised when attempting to create duplicate resource"""

    def __init__(self, resource_type: str, identifier: str):
        message = f"{resource_type} with {identifier} already exists"
        super().__init__(message, 409)


class DatabaseError(PortalException):
    """Raised when database operation fails"""

    def __init__(self, message: str):
        super().__init__(f"Database error: {message}", 500)
