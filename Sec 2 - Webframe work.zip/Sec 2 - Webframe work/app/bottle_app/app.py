from bottle import Bottle, request, response, static_file
import os
import json

from app.services.department_service import DepartmentService
from app.services.employee_service import EmployeeService
from app.utils.config import BASE_DIR

bottle_app = Bottle()
employee_service = EmployeeService()
department_service = DepartmentService()

# Get template directory
TEMPLATE_DIR = str(BASE_DIR / 'app' / 'templates')

# Configure template search path
bottle_app.TEMPLATE_PATH = TEMPLATE_DIR


@bottle_app.get('/')
def home():
    """Home page with employee and department lists"""
    try:
        employees = employee_service.list_employees()
        departments = department_service.list_departments()

        # Read template file directly
        template_path = os.path.join(TEMPLATE_DIR, 'bottle_index.tpl')
        with open(template_path, 'r') as f:
            template_content = f.read()

        # Simple template rendering
        html = template_content

        # Replace employee list
        employees_html = ''
        for emp in employees:
            employees_html += f'<li>{emp["name"]} - {emp["email"]} ({emp["department_name"]})</li>\n'
        html = html.replace('    % for employee in employees:\n    <li>{{employee[\'name\']}} - {{employee[\'email\']}} ({{employee[\'department_name\']}})</li>\n    % end', employees_html)

        # Replace department list
        departments_html = ''
        for dept in departments:
            departments_html += f'<li>{dept["name"]}</li>\n'
        html = html.replace('    % for department in departments:\n    <li>{{department[\'name\']}}</li>\n    % end', departments_html)

        return html
    except Exception as e:
        return f'<h1>Error</h1><p>{str(e)}</p>'


@bottle_app.post('/employee')
def add_employee():
    """Add new employee"""
    try:
        name = request.forms.get('name', '').strip()
        email = request.forms.get('email', '').strip()
        department_name = request.forms.get('department', '').strip()

        if name and email and department_name:
            employee_service.create_employee(name, email, department_name)

        response.status = 303
        response.headers['Location'] = '/'
        return ''
    except Exception as e:
        return f'<h1>Error</h1><p>{str(e)}</p>'


@bottle_app.get('/health')
def health():
    """Health check endpoint"""
    response.content_type = 'application/json'
    return json.dumps({'status': 'ok', 'message': 'Bottle app is running'})


@bottle_app.error(404)
def not_found(error):
    """Handle 404 errors"""
    return '<h1>Error 404</h1><p>Page not found</p>'


@bottle_app.get('/static/<filename:path>')
def serve_static(filename):
    """Serve static files"""
    return static_file(filename, root=str(BASE_DIR / 'app' / 'static'))
