from flask_restx import Resource

from app.api import department_ns, department_model, department_input_model
from app.services.department_service import DepartmentService


department_service = DepartmentService()


@department_ns.route("")
class DepartmentList(Resource):
    """Department collection operations"""

    @department_ns.doc("list_departments")
    @department_ns.marshal_list_with(department_model)
    def get(self):
        """List all departments"""
        return department_service.list_departments()

    @department_ns.doc("create_department")
    @department_ns.expect(department_input_model)
    @department_ns.marshal_with(department_model, code=201)
    @department_ns.response(400, "Invalid input")
    def post(self):
        """Create a new department"""
        data = department_ns.payload
        if not data.get("name"):
            department_ns.abort(400, "name is required")
        try:
            return department_service.create_department(data["name"]), 201
        except Exception as e:
            department_ns.abort(400, f"Failed to create department: {str(e)}")


@department_ns.route("/<int:department_id>")
class DepartmentItem(Resource):
    """Department item operations"""

    @department_ns.doc("get_department")
    @department_ns.marshal_with(department_model)
    @department_ns.response(404, "Department not found")
    def get(self, department_id):
        """Get department by ID"""
        departments = department_service.list_departments()
        department = next((d for d in departments if d["id"] == department_id), None)
        if not department:
            department_ns.abort(404, f"Department {department_id} not found")
        return department
