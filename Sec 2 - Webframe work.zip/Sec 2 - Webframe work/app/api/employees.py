from flask_restx import Resource
from flask import request

from app.api import employee_ns, employee_model, employee_input_model
from app.services.employee_service import EmployeeService


employee_service = EmployeeService()


@employee_ns.route("")
class EmployeeList(Resource):
    """Employee collection operations"""

    @employee_ns.doc("list_employees")
    @employee_ns.marshal_list_with(employee_model)
    def get(self):
        """List all employees"""
        return employee_service.list_employees()

    @employee_ns.doc("create_employee")
    @employee_ns.expect(employee_input_model)
    @employee_ns.marshal_with(employee_model, code=201)
    @employee_ns.response(400, "Invalid input")
    def post(self):
        """Create a new employee"""
        data = employee_ns.payload
        if not data.get("name") or not data.get("email") or not data.get("department_name"):
            employee_ns.abort(400, "name, email, and department_name are required")
        try:
            return employee_service.create_employee(
                data["name"], data["email"], data["department_name"]
            ), 201
        except Exception as e:
            employee_ns.abort(400, f"Failed to create employee: {str(e)}")


@employee_ns.route("/<int:employee_id>")
class EmployeeItem(Resource):
    """Employee item operations"""

    @employee_ns.doc("get_employee")
    @employee_ns.marshal_with(employee_model)
    @employee_ns.response(404, "Employee not found")
    def get(self, employee_id):
        """Get employee by ID"""
        employee = employee_service.get_employee(employee_id)
        if not employee:
            employee_ns.abort(404, f"Employee {employee_id} not found")
        return employee

    @employee_ns.doc("update_employee")
    @employee_ns.expect(employee_input_model)
    @employee_ns.marshal_with(employee_model)
    @employee_ns.response(404, "Employee not found")
    @employee_ns.response(400, "Invalid input")
    def put(self, employee_id):
        """Update an employee"""
        data = employee_ns.payload
        if not data.get("name") or not data.get("email") or not data.get("department_name"):
            employee_ns.abort(400, "name, email, and department_name are required")
        try:
            updated = employee_service.update_employee(
                employee_id, data["name"], data["email"], data["department_name"]
            )
            if not updated:
                employee_ns.abort(404, f"Employee {employee_id} not found")
            return updated
        except Exception as e:
            employee_ns.abort(400, f"Failed to update employee: {str(e)}")

    @employee_ns.doc("delete_employee")
    @employee_ns.response(204, "Employee deleted")
    @employee_ns.response(404, "Employee not found")
    def delete(self, employee_id):
        """Delete an employee"""
        if not employee_service.delete_employee(employee_id):
            employee_ns.abort(404, f"Employee {employee_id} not found")
        return "", 204
