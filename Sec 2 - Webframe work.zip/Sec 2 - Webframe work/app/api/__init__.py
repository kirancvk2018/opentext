from flask_restx import Api, fields
from flask import Blueprint

api_bp = Blueprint("api", __name__, url_prefix="/api/v1")
api = Api(
    api_bp,
    version="1.0",
    title="Enterprise Employee Portal API",
    description="Complete REST API for Employee and Department Management",
    doc="/docs"
)

employee_ns = api.namespace("employees", description="Employee operations")
department_ns = api.namespace("departments", description="Department operations")
health_ns = api.namespace("health", description="Health check operations")

employee_model = api.model(
    "Employee",
    {
        "id": fields.Integer(required=True, description="Employee ID"),
        "name": fields.String(required=True, description="Employee name"),
        "email": fields.String(required=True, description="Employee email"),
        "department_name": fields.String(required=True, description="Department name"),
    }
)

employee_input_model = api.model(
    "EmployeeInput",
    {
        "name": fields.String(required=True, description="Employee name"),
        "email": fields.String(required=True, description="Employee email"),
        "department_name": fields.String(required=True, description="Department name"),
    }
)

department_model = api.model(
    "Department",
    {
        "id": fields.Integer(required=True, description="Department ID"),
        "name": fields.String(required=True, description="Department name"),
    }
)

department_input_model = api.model(
    "DepartmentInput",
    {
        "name": fields.String(required=True, description="Department name"),
    }
)

health_model = api.model(
    "HealthStatus",
    {
        "status": fields.String(required=True, description="Application status"),
        "message": fields.String(description="Status message"),
    }
)
