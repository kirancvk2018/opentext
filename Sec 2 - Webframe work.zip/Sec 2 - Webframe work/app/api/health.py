from flask_restx import Resource

from app.api import health_ns, health_model


@health_ns.route("")
class HealthCheck(Resource):
    """Application health check"""

    @health_ns.doc("health_check")
    @health_ns.marshal_with(health_model)
    def get(self):
        """Check application health status"""
        return {
            "status": "healthy",
            "message": "Enterprise Employee Portal is running"
        }
