# Enterprise Employee Portal REST API

## Overview

The REST API provides complete CRUD operations for managing employees and departments in the Enterprise Employee Portal. Built with **Flask-RESTX**, the API includes **OpenAPI 3.0** documentation and **Swagger UI** integration.

## API Documentation

- **Swagger UI**: http://localhost:5000/api/v1/docs
- **ReDoc**: http://localhost:5000/api/v1/redoc
- **OpenAPI Schema**: http://localhost:5000/api/v1/swagger.json

## Architecture

### Module Structure

```
app/api/
├── __init__.py          # API initialization, namespaces, models
├── employees.py         # Employee endpoints
├── departments.py       # Department endpoints
├── health.py            # Health check endpoint
└── README.md           # This file
```

### Design Pattern

The API implements the **REST Resource Pattern**:

```
Resource Class → Service Layer → Repository Pattern → SQLite Database
```

Each endpoint:
1. **Validates** incoming data using Flask-RESTX models
2. **Processes** requests via Service layer (business logic)
3. **Returns** formatted JSON responses with appropriate HTTP status codes
4. **Handles** exceptions and returns descriptive error messages

## API Endpoints

### Base URL
```
http://localhost:5000/api/v1
```

### Employee Endpoints

#### 1. List All Employees
```http
GET /employees
```

**Response**: `200 OK`
```json
[
  {
    "id": 1,
    "name": "Alice Johnson",
    "email": "alice@example.com",
    "department_name": "Engineering"
  }
]
```

#### 2. Get Employee by ID
```http
GET /employees/{id}
```

**Response**: `200 OK`
```json
{
  "id": 1,
  "name": "Alice Johnson",
  "email": "alice@example.com",
  "department_name": "Engineering"
}
```

**Error**: `404 Not Found`

#### 3. Create Employee
```http
POST /employees
Content-Type: application/json

{
  "name": "Bob Smith",
  "email": "bob@example.com",
  "department_name": "Sales"
}
```

**Response**: `201 Created`
```json
{
  "id": 2,
  "name": "Bob Smith",
  "email": "bob@example.com",
  "department_name": "Sales"
}
```

**Errors**:
- `400 Bad Request` - Missing required fields

#### 4. Update Employee
```http
PUT /employees/{id}
Content-Type: application/json

{
  "name": "Alice Johnson",
  "email": "alice.j@example.com",
  "department_name": "Engineering"
}
```

**Response**: `200 OK`

**Errors**:
- `404 Not Found` - Employee does not exist
- `400 Bad Request` - Invalid input

#### 5. Delete Employee
```http
DELETE /employees/{id}
```

**Response**: `204 No Content`

**Error**: `404 Not Found`

### Department Endpoints

#### 1. List All Departments
```http
GET /departments
```

**Response**: `200 OK`
```json
[
  {
    "id": 1,
    "name": "Engineering"
  },
  {
    "id": 2,
    "name": "Sales"
  }
]
```

#### 2. Get Department by ID
```http
GET /departments/{id}
```

**Response**: `200 OK`

**Error**: `404 Not Found`

#### 3. Create Department
```http
POST /departments
Content-Type: application/json

{
  "name": "Marketing"
}
```

**Response**: `201 Created`

**Error**: `400 Bad Request`

### Health Check Endpoint

#### Check Application Status
```http
GET /health
```

**Response**: `200 OK`
```json
{
  "status": "healthy",
  "message": "Enterprise Employee Portal is running"
}
```

## HTTP Status Codes

| Code | Meaning | Use Case |
|------|---------|----------|
| 200 | OK | Successful GET or PUT request |
| 201 | Created | Successful POST request |
| 204 | No Content | Successful DELETE request |
| 400 | Bad Request | Invalid input or validation failure |
| 404 | Not Found | Resource not found |
| 500 | Server Error | Unexpected server error |

## Request/Response Formats

### Request Headers
```http
Content-Type: application/json
```

### Response Headers
```http
Content-Type: application/json
```

## Error Handling

All error responses follow this format:

```json
{
  "errors": {
    "message": "Description of the error"
  }
}
```

### Common Error Scenarios

1. **Missing Required Field**
   ```json
   {
     "errors": {
       "message": "name, email, and department_name are required"
     }
   }
   ```

2. **Resource Not Found**
   ```json
   {
     "errors": {
       "message": "Employee 999 not found"
     }
   }
   ```

3. **Database Error**
   ```json
   {
     "errors": {
       "message": "Failed to create employee: UNIQUE constraint failed"
     }
   }
   ```

## Implementation Details

### Flask-RESTX Features Used

#### 1. Namespaces
- Organize endpoints by resource type
- Provide logical grouping in Swagger UI

#### 2. Resource Classes
- Inherit from `Resource`
- HTTP method handlers (get, post, put, delete)
- RESTful semantics

#### 3. Models
- Define request/response schemas
- Auto-generate Swagger documentation
- Validate incoming JSON

#### 4. Marshalling
- `@marshal_list_with` - Array responses
- `@marshal_with` - Single object responses
- Consistent response formatting

#### 5. Decorators
- `@ns.expect()` - Input validation
- `@ns.marshal_with()` - Output formatting
- `@ns.response()` - Response documentation
- `@ns.abort()` - Error handling

## Testing the API

### Using cURL

```bash
# List employees
curl http://localhost:5000/api/v1/employees

# Create employee
curl -X POST http://localhost:5000/api/v1/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@example.com","department_name":"Engineering"}'

# Update employee
curl -X PUT http://localhost:5000/api/v1/employees/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice Updated","email":"alice@example.com","department_name":"Engineering"}'

# Delete employee
curl -X DELETE http://localhost:5000/api/v1/employees/1

# Health check
curl http://localhost:5000/api/v1/health
```

### Using Python Requests

```python
import requests

BASE_URL = "http://localhost:5000/api/v1"

# List employees
response = requests.get(f"{BASE_URL}/employees")
print(response.json())

# Create employee
payload = {
    "name": "Alice Johnson",
    "email": "alice@example.com",
    "department_name": "Engineering"
}
response = requests.post(f"{BASE_URL}/employees", json=payload)
print(response.status_code, response.json())
```

## Enterprise Features

### Logging
Every API request is logged with timestamp, method, path, and status code.

### Validation
All inputs are validated using Flask-RESTX models before processing.

### Error Handling
Comprehensive exception handling ensures graceful error responses.

### API Documentation
Auto-generated Swagger UI provides interactive API testing.

## Best Practices

1. **Always use Content-Type header**: `application/json`
2. **Check HTTP status codes**: Don't assume success
3. **Handle errors gracefully**: Implement proper error handling in clients
4. **Validate inputs**: Use models for request validation
5. **Log API calls**: Maintain audit trail for compliance

## Performance Considerations

- All employee lists are sorted by ID
- Database connections use context managers
- Row factories convert results to dictionaries
- Connection pooling handled by sqlite3

## Security Recommendations

1. **In Production**:
   - Use HTTPS/TLS encryption
   - Implement authentication (JWT, OAuth)
   - Add rate limiting
   - Validate all inputs on server side
   - Use environment-based secrets

2. **Current Development Setup**:
   - Basic error handling
   - Input validation via models
   - Proper HTTP status codes
   - Comprehensive logging

## Conclusion

The REST API provides a production-ready foundation for managing employee and department data with enterprise-grade architecture, documentation, and error handling.
