"""Python Threading — Daemon Threads.

A background cache cleanup service that demonstrates daemon and non-daemon
thread behavior.
"""

import threading
import time
from typing import Callable, List


def cleanup_cache(service_name: str, duration_seconds: float) -> None:
    """Simulate a cache cleanup cycle for a background service."""
    print(f"[{threading.current_thread().name}] Starting {service_name} cleanup")
    time.sleep(duration_seconds)
    print(f"[{threading.current_thread().name}] Completed {service_name} cleanup")


def create_service_threads() -> List[threading.Thread]:
    """Create daemon and non-daemon service threads."""
    services: List[tuple[str, float, bool]] = [
        ("ShortLivedCache", 0.8, False),
        ("LongRunningCache", 3.0, True),
    ]

    threads: List[threading.Thread] = []
    for service_name, duration, is_daemon in services:
        thread = threading.Thread(
            target=cleanup_cache,
            args=(service_name, duration),
            name=f"CacheService-{service_name}",
            daemon=is_daemon,
        )
        threads.append(thread)
        print(f"Configured {thread.name} daemon={thread.daemon}")
    return threads


def main() -> None:
    """Execute the daemon thread demonstration."""
    print("DAEMON THREADS: BACKGROUND CACHE CLEANUP")
    threads = create_service_threads()

    for thread in threads:
        thread.start()
        print(f"Started {thread.name}")

    non_daemon_threads = [thread for thread in threads if not thread.daemon]
    for thread in non_daemon_threads:
        thread.join()
        print(f"Joined non-daemon thread {thread.name}")

    print(
        "Main process finished. Daemon threads may still be terminated by the runtime."
    )


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Demonstrates a non-daemon cleanup thread completing.
# - A daemon thread may be terminated when the main process exits.
# - Shows the difference between daemon and non-daemon lifecycle.

# Execution Flow
# ----------------
# 1. Configure service threads with explicit daemon flags.
# 2. Start each thread.
# 3. Join only the critical non-daemon thread.
# 4. Exit the main process.

# Architecture Explanation
# ----------------
# Daemon threads are suitable for background support tasks.
# Non-daemon threads represent essential cleanup operations.

# Advantages
# ----------------
# - Background tasks can run without blocking shutdown.
# - Critical work can still be protected by non-daemon threads.

# Limitations
# ----------------
# - Daemon threads may not complete if the app exits abruptly.
# - Do not use daemon threads for essential business logic.

# Performance Considerations
# ----------------
# - Daemon threads should do lightweight background work.
# - Use thread-safe shutdown coordination for graceful exits.

# Best Practices
# ----------------
# - Only mark threads daemon when they are purely supportive.
# - Keep the main thread aware of which tasks must finish.

# Common Mistakes
# ----------------
# - Making important work run in daemon threads.
# - Assuming daemon threads will always complete.

# Debugging Tips
# ----------------
# - Log daemon flags and join behavior explicitly.
# - Use thread.is_alive() to inspect which threads remain.

# Interview Questions
# ----------------
# 1. What happens to daemon threads when the main program exits?
# 2. When should you use daemon=True?
# 3. Can daemon threads acquire locks safely?
# 4. Is it safe to join a daemon thread?
# 5. Why are daemon threads useful for background services?

# Hands-on Exercise
# ----------------
# Add a graceful shutdown event to stop the daemon thread politely.

# Challenge Exercise
# ----------------
# Build a service manager that starts and stops daemon and non-daemon tasks.
