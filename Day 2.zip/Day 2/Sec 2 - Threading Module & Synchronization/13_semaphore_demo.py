"""Python Threading — Semaphore Demo.

A database connection pool simulation that limits concurrent request threads to
three active connections.
"""

import random
import threading
import time
from typing import List


def handle_request(request_id: int, connection_pool: threading.Semaphore) -> None:
    """Acquire a database connection and process a request."""
    print(f"[Request-{request_id}] Waiting for available connection")
    with connection_pool:
        print(f"[Request-{request_id}] Acquired connection")
        processing_time = random.uniform(0.7, 1.2)
        time.sleep(processing_time)
        print(f"[Request-{request_id}] Released connection")


def main() -> None:
    """Run the database connection pool semaphore demonstration."""
    print("SEMAPHORE DEMO: DATABASE CONNECTION POOL")
    max_connections = 3
    connection_pool = threading.Semaphore(max_connections)
    request_threads: List[threading.Thread] = []

    for request_id in range(1, 8):
        thread = threading.Thread(
            target=handle_request,
            args=(request_id, connection_pool),
            name=f"DbRequest-{request_id}",
        )
        request_threads.append(thread)
        thread.start()

    for thread in request_threads:
        thread.join()

    print("All database requests have been processed.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - No more than three request threads occupy the connection pool at once.
# - Requests queue until a connection becomes available.
# - The final summary confirms completion.

# Execution Flow
# ----------------
# 1. Create a semaphore limiting concurrent connections.
# 2. Start multiple request threads.
# 3. Each thread acquires the semaphore before processing.
# 4. Threads release the permit automatically after work.

# Architecture Explanation
# ----------------
# Semaphore enforces a maximum number of active resources.
# It is a common pattern for connection pools and rate-limited services.

# Advantages
# ----------------
# - Controls concurrency without manual queue management.
# - Supports multiple threads competing for a fixed-size pool.

# Limitations
# ----------------
# - Excessive waiting can increase request latency.
# - Semaphores do not guarantee fairness by default.

# Performance Considerations
# ----------------
# - Use semaphores to protect limited resources.
# - Choose the pool size based on capacity and latency targets.

# Best Practices
# ----------------
# - Keep the semaphore scope around the actual resource use.
# - Release permits automatically using context managers.

# Common Mistakes
# ----------------
# - Acquiring a semaphore without releasing it.
# - Using a semaphore count larger than actual resources.

# Debugging Tips
# ----------------
# - Log when threads acquire and release permits.
# - Track waiting threads if throughput is unexpectedly low.

# Interview Questions
# ----------------
# 1. What is a semaphore used for?
# 2. How does it differ from Lock?
# 3. Why is the connection pool size limited?
# 4. What happens if a thread fails while holding a permit?
# 5. When is a semaphore preferable to a queue?

# Hands-on Exercise
# ----------------
# Add a queue of requests and consume them with semaphore-protected workers.

# Challenge Exercise
# ----------------
# Build a bounded connection pool manager that tracks active sessions.
