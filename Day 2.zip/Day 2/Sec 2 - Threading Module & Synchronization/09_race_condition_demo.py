"""Python Threading — Race Condition Demo.

A bank account balance example that demonstrates why concurrent updates can
produce incorrect results without synchronization.
"""

import threading
import time


class BankAccount:
    """A simple bank account model with an unsynchronized balance."""

    def __init__(self, initial_balance: float) -> None:
        self.balance = initial_balance

    def deposit(self, amount: float) -> None:
        """Add funds to the account balance."""
        local_balance = self.balance
        time.sleep(0.01)
        self.balance = local_balance + amount

    def withdraw(self, amount: float) -> None:
        """Subtract funds from the account balance."""
        local_balance = self.balance
        time.sleep(0.01)
        self.balance = local_balance - amount


def transaction_worker(account: BankAccount, iterations: int) -> None:
    """Perform a series of deposits and withdrawals on the account."""
    for _ in range(iterations):
        account.deposit(100.0)
        account.withdraw(100.0)


def main() -> None:
    """Execute the race condition demonstration."""
    print("RACE CONDITION: BANK ACCOUNT BALANCE")
    account = BankAccount(initial_balance=10_000.0)

    threads = [
        threading.Thread(target=transaction_worker, args=(account, 50), name=f"TxnWorker-{i+1}")
        for i in range(4)
    ]

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    print(f"Final account balance: ${account.balance:,.2f}")
    print("Expected balance: $10,000.00")
    print(
        "If the final balance differs, the example demonstrates a lost update" 
        "due to race conditions."
    )


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - The final balance may differ from the expected value.
# - Observes lost updates caused by concurrent unsynchronized access.

# Execution Flow
# ----------------
# 1. Create an account with a starting balance.
# 2. Launch multiple worker threads.
# 3. Perform matching deposits and withdrawals concurrently.
# 4. Join threads and print the final balance.

# Architecture Explanation
# ----------------
# Each worker reads and writes the shared balance without protection.
# The race between threads causes stale reads and inconsistent results.

# Advantages
# ----------------
# - Clearly illustrates the need for synchronization.
# - Uses a realistic account update scenario.

# Limitations
# ----------------
# - The example is intentionally unsafe to show a bug.
# - Real banking systems must enforce strict synchronization.

# Performance Considerations
# ----------------
# - Synchronization will add overhead but is essential for correctness.
# - Without it, concurrency can silently corrupt shared state.

# Best Practices
# ----------------
# - Protect shared mutable state with locks.
# - Keep critical sections as small as possible.

# Common Mistakes
# ----------------
# - Assuming individual operations are atomic.
# - Ignoring read-modify-write sequences on shared data.

# Debugging Tips
# ----------------
# - Re-run the example multiple times to see inconsistent results.
# - Add logging around reads and writes to expose race conditions.

# Interview Questions
# ----------------
# 1. Why does this example produce an incorrect final balance?
# 2. What is a race condition?
# 3. How does thread scheduling affect shared state updates?
# 4. Why are locks necessary for banking workflows?
# 5. What does atomicity mean in the context of threads?

# Hands-on Exercise
# ----------------
# Add a Lock to the BankAccount methods and verify the final balance.

# Challenge Exercise
# ----------------
# Replace the sleep calls with a simulated database access delay.
