"""Python Threading — Lock Object for Thread Safety.

A warehouse inventory system that protects shared stock quantities with a lock.
"""

import threading
import time
from typing import Dict


class WarehouseInventory:
    """Warehouse inventory model protected by a Lock."""

    def __init__(self) -> None:
        self.stock: Dict[str, int] = {"widget": 1000}
        self._lock = threading.Lock()

    def reserve_stock(self, quantity: int) -> bool:
        """Reserve inventory for an order in a thread-safe manner."""
        with self._lock:
            available = self.stock["widget"]
            if quantity > available:
                return False
            time.sleep(0.01)
            self.stock["widget"] = available - quantity
            return True

    def replenish_stock(self, quantity: int) -> None:
        """Replenish inventory for the warehouse."""
        with self._lock:
            current = self.stock["widget"]
            time.sleep(0.01)
            self.stock["widget"] = current + quantity


def ship_order(inventory: WarehouseInventory, quantity: int) -> None:
    """Simulate shipping an order while reserving stock."""
    thread_name = threading.current_thread().name
    print(f"[{thread_name}] Attempting to reserve {quantity} widgets")
    if inventory.reserve_stock(quantity):
        print(f"[{thread_name}] Reserved {quantity} widgets successfully")
    else:
        print(f"[{thread_name}] Insufficient stock for {quantity} widgets")


def main() -> None:
    """Run the warehouse inventory lock demonstration."""
    print("THREAD SAFETY WITH LOCK: WAREHOUSE INVENTORY")
    inventory = WarehouseInventory()
    order_quantities = [120, 150, 180, 90, 200, 130]

    threads = [
        threading.Thread(
            target=ship_order,
            args=(inventory, quantity),
            name=f"OrderShip-{i+1}",
        )
        for i, quantity in enumerate(order_quantities)
    ]

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    print(f"Remaining warehouse stock: {inventory.stock['widget']} widgets")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Order threads reserve stock without corrupting the shared quantity.
# - The final stock count reflects safe concurrent access.

# Execution Flow
# ----------------
# 1. Initialize warehouse inventory with a lock.
# 2. Launch order shipment threads.
# 3. Each thread enters a protected critical section.
# 4. Join threads and display remaining stock.

# Architecture Explanation
# ----------------
# A Lock serializes access to the shared stock quantity.
# Protected operations prevent lost updates in inventory counts.

# Advantages
# ----------------
# - Correctness is enforced without needing complex coordination.
# - The lock scope remains minimal around shared state access.

# Limitations
# ----------------
# - Lock contention may reduce throughput under heavy load.
# - Long-held locks can delay other threads.

# Performance Considerations
# ----------------
# - Keep the critical section small to reduce contention.
# - For high throughput, consider batching updates.

# Best Practices
# ----------------
# - Use context managers for lock acquisition.
# - Protect all code that reads or mutates shared state.

# Common Mistakes
# ----------------
# - Forgetting to release the lock after an exception.
# - Holding the lock while performing unrelated work.

# Debugging Tips
# ----------------
# - Add logging inside the lock-protected section.
# - Ensure the same lock is used for all shared accesses.

# Interview Questions
# ----------------
# 1. Why does this example need a Lock?
# 2. What happens if reserve_stock is not protected?
# 3. How does with self._lock simplify lock handling?
# 4. When might a lock become a bottleneck?
# 5. How can you measure lock contention?

# Hands-on Exercise
# ----------------
# Add order cancelation logic that also updates inventory safely.

# Challenge Exercise
# ----------------
# Refactor the inventory model to support multiple product SKUs concurrently.
