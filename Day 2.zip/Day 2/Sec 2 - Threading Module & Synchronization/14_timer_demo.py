"""Python Threading — Timer Demo.

A scheduled invoice reminder system that triggers a reminder after a delay.
"""

import threading
import time


def send_invoice_reminder(invoice_id: str) -> None:
    """Simulate sending a reminder for an outstanding invoice."""
    print(f"[InvoiceReminder] Reminder sent for invoice {invoice_id}")


def main() -> None:
    """Execute the timer demonstration for invoice reminders."""
    print("TIMER DEMO: SCHEDULED INVOICE REMINDER")
    invoice_id = "INV-7832"
    delay_seconds = 2.5

    timer = threading.Timer(delay_seconds, send_invoice_reminder, args=(invoice_id,))
    timer.start()
    print(
        f"Scheduled reminder for {invoice_id} to run in {delay_seconds:.1f} seconds"
    )

    while timer.is_alive():
        print("Waiting for the scheduled reminder")
        time.sleep(0.7)

    print("Scheduled invoice reminder workflow completed.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - A reminder is sent after the configured delay.
# - The main thread waits until the timer completes.

# Execution Flow
# ----------------
# 1. Create a Timer to execute after a delay.
# 2. Start the timer.
# 3. Periodically observe if it is still alive.
# 4. Report completion after the callback runs.

# Architecture Explanation
# ----------------
# Timer schedules deferred execution without manual sleep tracking.
# It is useful for reminders, retries, and scheduled background actions.

# Advantages
# ----------------
# - Simplifies delayed task execution.
# - Keeps scheduling logic separate from the main workflow.

# Limitations
# ----------------
# - Single-shot timers are not recurring.
# - Use a scheduler loop or repeated Timer for recurring tasks.

# Performance Considerations
# ----------------
# - Timer overhead is minimal for occasional scheduled actions.
# - Avoid using long-running callbacks inside a Timer.

# Best Practices
# ----------------
# - Keep timer callbacks lightweight.
# - Cancel timers if the application shuts down early.

# Common Mistakes
# ----------------
# - Expecting Timer to persist across process exit.
# - Starting the timer then forgetting to keep the program alive.

# Debugging Tips
# ----------------
# - Verify the delay value and callback arguments.
# - Use timer.is_alive() to confirm the scheduled task is pending.

# Interview Questions
# ----------------
# 1. How does threading.Timer work?
# 2. When should you use Timer instead of sleep()?
# 3. Can you cancel a Timer before it executes?
# 4. What types of tasks are appropriate for Timer callbacks?
# 5. How can you implement a recurring scheduled job?

# Hands-on Exercise
# ----------------
# Add cancellation logic before the reminder triggers.

# Challenge Exercise
# ----------------
# Build a scheduler that creates multiple timers for invoice reminders.
