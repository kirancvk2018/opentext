"""Enterprise logging helper for multithreaded Python examples."""

import logging
from logging import Logger
from pathlib import Path

LOG_FORMAT = "%(asctime)s [%(levelname)s] %(message)s"
LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"


def create_logger(name: str, log_file: Path | str | None = None) -> Logger:
    """Create a logger configured for console output and optional file output.

    Args:
        name: Module or component name for logs.
        log_file: Optional path to a log file.

    Returns:
        A configured Logger instance.
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        formatter = logging.Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATEFMT)

        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        if log_file:
            file_handler = logging.FileHandler(Path(log_file), encoding="utf-8")
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

    return logger
