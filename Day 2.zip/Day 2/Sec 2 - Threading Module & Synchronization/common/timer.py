"""Utility module for measuring execution duration in examples."""

import time
from contextlib import contextmanager


@contextmanager
def stopwatch(label: str):
    """Context manager that logs elapsed time for a code block.

    Args:
        label: Human-readable label for the timed block.
    """
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        print(f"{label} completed in {elapsed:.3f} seconds")
