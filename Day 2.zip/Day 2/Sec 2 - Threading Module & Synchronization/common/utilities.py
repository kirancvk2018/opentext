"""Reusable helper functions for threading examples."""

from pathlib import Path
from typing import Any


def safe_write_text(path: Path, content: str) -> None:
    """Write text to a file, creating parent directories if needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def format_currency(amount: float) -> str:
    """Format a float as a currency string used in enterprise reports."""
    return f"${amount:,.2f}"


def build_report_header(title: str) -> str:
    """Build a consistent report header for console-based summaries."""
    return f"{title}\n{'=' * len(title)}"
