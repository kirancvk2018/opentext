"""Python Threading — Starting Threads.

A background invoice generation scenario that shows how thread start() enables
concurrent execution.
"""

import threading
import time
from datetime import datetime
from typing import Dict, List


def generate_invoice(batch_info: Dict[str, str]) -> None:
    """Simulate generating an invoice document for a client batch."""
    batch_name = batch_info["batch_name"]
    print(f"[{threading.current_thread().name}] Preparing invoices for {batch_name}")
    time.sleep(0.9)
    print(
        f"[{threading.current_thread().name}] Invoice generation complete for"
        f" {batch_name} at {datetime.utcnow().isoformat()}"
    )


def build_invoice_batches() -> List[Dict[str, str]]:
    """Create metadata for invoice generation batches."""
    return [
        {"batch_name": "North America Q2"},
        {"batch_name": "EMEA Q2"},
        {"batch_name": "APAC Q2"},
    ]


def main() -> None:
    """Execute the invoice generation example."""
    print("STARTING THREADS: BACKGROUND INVOICE GENERATION")
    batches = build_invoice_batches()
    threads: List[threading.Thread] = []

    for index, batch in enumerate(batches, start=1):
        thread = threading.Thread(
            target=generate_invoice,
            args=(batch,),
            name=f"InvoiceGenerator-{index}",
        )
        threads.append(thread)
        print(f"Created {thread.name}")

    for thread in threads:
        print(f"Starting {thread.name}")
        thread.start()

    print("All invoice generation threads have been started.")

    for thread in threads:
        thread.join()

    print("Invoice generation workflow finished.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Threads are created and started sequentially.
# - Invoice batches generate concurrently after start().
# - The main thread waits for all workers to finish.
# - Output includes timestamps and thread context.

# Execution Flow
# ----------------
# 1. Build invoice batch metadata.
# 2. Create separate threads for each batch.
# 3. Start threads using start().
# 4. Join threads to ensure completion.

# Architecture Explanation
# ----------------
# Starting threads triggers the thread scheduler to run worker code.
# Before start(), threads are only configured objects.

# Advantages
# ----------------
# - start() decouples creation from execution.
# - Production systems can prepare work before launching threads.

# Limitations
# ----------------
# - Once started, a Thread instance cannot be restarted.
# - Use thread pools for repeated work.

# Performance Considerations
# ----------------
# - Concurrency yields better throughput for IO-bound tasks.
# - Avoid heavy CPU work in Python threads when scaling.

# Best Practices
# ----------------
# - Call start() only after the thread is fully configured.
# - Use descriptive thread names for monitoring.

# Common Mistakes
# ----------------
# - Calling run() directly instead of start().
# - Starting threads without capturing references.

# Debugging Tips
# ----------------
# - Confirm each thread enters the target function.
# - Use start() logs to verify lifecycle timing.

# Interview Questions
# ----------------
# 1. What is the difference between Thread.start() and Thread.run()?
# 2. Why must each Thread instance be started exactly once?
# 3. How does start() affect thread scheduling?
# 4. Which types of tasks benefit most from thread concurrency?
# 5. How do you handle thread startup failures?

# Hands-on Exercise
# ----------------
# Add a delay between thread starts and observe the execution overlap.

# Challenge Exercise
# ----------------
# Create a wrapper that starts threads in batches to limit concurrency.
