"""Lab 03 — Download Manager.

A download manager simulation that shows concurrent downloads, progress
reporting, retry handling, completion waiting, and a final report.
"""

import random
import threading
import time
from typing import Dict, List

MAX_RETRIES = 2


def download_file(file_name: str, results: Dict[str, str]) -> None:
    """Simulate downloading a file and record the result."""
    thread_name = threading.current_thread().name
    for attempt in range(1, MAX_RETRIES + 2):
        print(f"[{thread_name}] Downloading {file_name}, attempt {attempt}")
        time.sleep(random.uniform(0.5, 1.0))
        if random.random() < 0.8:
            results[file_name] = "Success"
            print(f"[{thread_name}] Download completed for {file_name}")
            return
        if attempt <= MAX_RETRIES:
            print(f"[{thread_name}] Retry {attempt} for {file_name}")
    results[file_name] = "Failed"
    print(f"[{thread_name}] Download failed for {file_name}")


def main() -> None:
    """Run the download manager lab exercise."""
    print("LAB 03: DOWNLOAD MANAGER")
    files_to_download = [
        "report_q1.pdf",
        "inventory_snapshot.csv",
        "audit_log.txt",
        "metrics_summary.json",
    ]
    results: Dict[str, str] = {}
    threads: List[threading.Thread] = []

    for file_name in files_to_download:
        thread = threading.Thread(
            target=download_file,
            args=(file_name, results),
            name=f"Downloader-{file_name}",
        )
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    print("Download report")
    for file_name in files_to_download:
        print(f"- {file_name}: {results.get(file_name)}")
    print("Download manager completed all tasks.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Multiple downloads execute concurrently.
# - The simulation retries failures automatically.
# - The final status report indicates success or failure per file.

# Execution Flow
# ----------------
# 1. Start a thread for each download task.
# 2. Each thread retries when needed.
# 3. Join threads when all downloads finish.
# 4. Print a consistent completion report.

# Architecture Explanation
# ----------------
# Each downloader thread tracks its own file and retry state.
# Shared results are updated via a thread-safe dictionary access pattern.

# Advantages
# ----------------
# - Concurrency improves aggregate download throughput.
# - Retry logic increases resilience to transient failures.

# Limitations
# ----------------
# - This simulation uses sleep instead of actual network I/O.
# - In real systems, thread-safe shared storage and timeouts are required.

# Performance Considerations
# ----------------
# - Too many simultaneous downloads could saturate network bandwidth.
# - Use connection throttling for production download managers.

# Best Practices
# ----------------
# - Keep retries limited and exponential backoff when appropriate.
# - Report final status in a clear, audit-friendly format.

# Common Mistakes
# ----------------
# - Ignoring failures after retries.
# - Sharing mutable result state without synchronization.

# Debugging Tips
# ----------------
# - Print download progress and retry attempts.
# - Verify final report contains all requested files.

# Interview Questions
# ----------------
# 1. How does this example handle transient download errors?
# 2. Why run downloads in parallel threads?
# 3. What is the role of MAX_RETRIES?
# 4. How would you add a progress bar?
# 5. When would a thread pool be beneficial here?

# Hands-on Exercise
# ----------------
# Add exponential backoff between retry attempts.

# Challenge Exercise
# ----------------
# Refactor to use a bounded semaphore to limit concurrent downloads.
