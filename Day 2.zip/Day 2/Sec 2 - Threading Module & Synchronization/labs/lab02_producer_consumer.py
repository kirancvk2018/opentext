"""Lab 02 — Producer Consumer System.

An enterprise-style producer-consumer system that uses queue.Queue,
producer threads, consumer threads, graceful shutdown, and logging.
"""

import logging
import queue
import threading
import time
from pathlib import Path
from typing import List

LOG_FILE = Path("labs") / "producer_consumer.log"


def setup_logger() -> logging.Logger:
    """Create a logger for the producer-consumer lab."""
    logger = logging.getLogger("ProducerConsumerLab")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
        formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger


def produce_tasks(task_queue: queue.Queue[str], task_count: int, logger: logging.Logger) -> None:
    """Enqueue a fixed number of tasks into the queue."""
    for index in range(1, task_count + 1):
        task_name = f"task-{index}"
        task_queue.put(task_name)
        logger.info(f"Produced {task_name}")
        time.sleep(0.1)
    logger.info("Producer finished producing tasks")


def consume_tasks(
    task_queue: queue.Queue[str],
    stop_event: threading.Event,
    logger: logging.Logger,
) -> None:
    """Consume tasks until the producer signals completion and the queue drains."""
    while not (stop_event.is_set() and task_queue.empty()):
        try:
            task_name = task_queue.get(timeout=0.2)
        except queue.Empty:
            continue
        logger.info(f"[{threading.current_thread().name}] Processing {task_name}")
        time.sleep(0.2)
        task_queue.task_done()
        logger.info(f"[{threading.current_thread().name}] Completed {task_name}")
    logger.info(f"[{threading.current_thread().name}] Consumer shutdown")


def main() -> None:
    """Run the producer-consumer lab exercise."""
    print("LAB 02: PRODUCER CONSUMER SYSTEM")
    logger = setup_logger()
    task_queue: queue.Queue[str] = queue.Queue()
    stop_event = threading.Event()

    producer = threading.Thread(
        target=produce_tasks,
        args=(task_queue, 12, logger),
        name="ProducerThread",
    )
    consumers: List[threading.Thread] = []

    for i in range(3):
        consumer = threading.Thread(
            target=consume_tasks,
            args=(task_queue, stop_event, logger),
            name=f"Consumer-{i+1}",
        )
        consumers.append(consumer)
        consumer.start()

    producer.start()
    producer.join()

    stop_event.set()
    task_queue.join()

    for consumer in consumers:
        consumer.join()

    print(f"Producer-consumer workflow complete. Logs written to {LOG_FILE}")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Producer generates tasks and puts them into a queue.
# - Consumers process tasks concurrently until shutdown.
# - A file-based log captures task lifecycle events.

# Execution Flow
# ----------------
# 1. Start consumer threads first.
# 2. Start producer thread to enqueue work.
# 3. Signal consumers after production completes.
# 4. Wait for the queue to drain and join consumers.

# Architecture Explanation
# ----------------
# queue.Queue safely passes tasks between producer and consumers.
# Event and queue.join() coordinate graceful shutdown.

# Advantages
# ----------------
# - Decouples task generation from task execution.
# - Improves throughput by using multiple consumers.

# Limitations
# ----------------
# - Consumers may wait when the queue is empty.
# - Real workloads require error handling and retry logic.

# Performance Considerations
# ----------------
# - Balance producer and consumer speeds to avoid queue overload.
# - Use more consumers if tasks are CPU-bound or IO-light.

# Best Practices
# ----------------
# - Call task_done() for every consumed item.
# - Set stop_event only after the producer is finished.

# Common Mistakes
# ----------------
# - Forgetting to join the queue, causing the main thread to exit early.
# - Starting consumers after the producer has already produced all tasks.

# Debugging Tips
# ----------------
# - Inspect log output for queue and thread activity.
# - Use timeout on get() to remain responsive to shutdown.

# Interview Questions
# ----------------
# 1. What role does queue.Queue play in this system?
# 2. Why do consumers use a timeout on get()?
# 3. How does task_done() work with queue.join()?
# 4. What could happen if stop_event is set too early?
# 5. How do you scale the number of consumers?

# Hands-on Exercise
# ----------------
# Add a second producer thread that generates a different type of task.

# Challenge Exercise
# ----------------
# Implement backpressure when the queue grows beyond a threshold.
