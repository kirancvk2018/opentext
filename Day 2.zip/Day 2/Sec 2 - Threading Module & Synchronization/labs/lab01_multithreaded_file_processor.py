"""Lab 01 — Multithreaded File Processor.

A lab exercise that reads multiple CSV files concurrently, validates records,
and generates a summary report while measuring execution time.
"""

import csv
import threading
import time
from pathlib import Path
from typing import Dict, List

DATA_DIRECTORY = Path("lab_data")
SUMMARY_FILE = DATA_DIRECTORY / "summary_report.txt"


def read_csv_file(file_path: Path) -> List[Dict[str, str]]:
    """Read CSV data from a file and return parsed records."""
    with file_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return [row for row in reader]


def validate_record(record: Dict[str, str]) -> bool:
    """Validate a single data record for required fields."""
    return bool(record.get("transaction_id")) and bool(record.get("amount"))


def process_file(file_path: Path, results: List[str], lock: threading.Lock) -> None:
    """Read and validate records from a file, then add the summary to results."""
    records = read_csv_file(file_path)
    valid_count = sum(1 for record in records if validate_record(record))
    invalid_count = len(records) - valid_count
    summary = (
        f"{file_path.name}: {valid_count} valid records, {invalid_count} invalid records"
    )
    with lock:
        results.append(summary)
    print(f"[{threading.current_thread().name}] Processed {file_path.name}")


def create_sample_files() -> None:
    """Create sample CSV files for the lab if they do not exist."""
    DATA_DIRECTORY.mkdir(parents=True, exist_ok=True)
    sample_files = {
        "transactions_north.csv": [
            {"transaction_id": "T1001", "amount": "1200"},
            {"transaction_id": "T1002", "amount": "850"},
            {"transaction_id": "", "amount": "500"},
        ],
        "transactions_east.csv": [
            {"transaction_id": "T2001", "amount": "2300"},
            {"transaction_id": "T2002", "amount": ""},
            {"transaction_id": "T2003", "amount": "1850"},
        ],
    }
    for file_name, rows in sample_files.items():
        path = DATA_DIRECTORY / file_name
        if not path.exists():
            with path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=["transaction_id", "amount"])
                writer.writeheader()
                writer.writerows(rows)


def write_summary(summary_lines: List[str]) -> None:
    """Write the summary report to disk."""
    SUMMARY_FILE.write_text("\n".join(summary_lines), encoding="utf-8")


def main() -> None:
    """Run the multithreaded file processor lab exercise."""
    print("LAB 01: MULTITHREADED FILE PROCESSOR")
    create_sample_files()
    file_paths = sorted(DATA_DIRECTORY.glob("transactions_*.csv"))
    results: List[str] = []
    lock = threading.Lock()
    threads: List[threading.Thread] = []

    start = time.perf_counter()
    for file_path in file_paths:
        thread = threading.Thread(
            target=process_file,
            args=(file_path, results, lock),
            name=f"FileProcessor-{file_path.stem}",
        )
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    write_summary(results)
    elapsed = time.perf_counter() - start

    print("Summary report generated:")
    for line in results:
        print(f"- {line}")
    print(f"Execution time: {elapsed:.3f} seconds")
    print(f"Summary file written to {SUMMARY_FILE}")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Process multiple CSV files in parallel.
# - Validate records and report valid/invalid counts.
# - Measure total execution time and write a summary file.

# Execution Flow
# ----------------
# 1. Create sample CSV files if needed.
# 2. Start a thread for each file.
# 3. Protect shared result collection with a Lock.
# 4. Write a summary report when complete.

# Architecture Explanation
# ----------------
# Each file is processed independently, and results are aggregated safely.
# The workplace demonstrates multithreading with shared output collection.

# Advantages
# ----------------
# - Parallel file processing reduces I/O batching latency.
# - Locking ensures result collection remains thread-safe.

# Limitations
# ----------------
# - This lab uses a small number of files.
# - Large file counts require thread pooling or async I/O.

# Performance Considerations
# ----------------
# - Use thread count proportional to disk throughput.
# - Avoid heavy CPU processing in each file thread.

# Best Practices
# ----------------
# - Keep file read and validation logic separate.
# - Guard shared collections with locks.

# Common Mistakes
# ----------------
# - Mutating shared state without synchronization.
# - Blocking the main thread before starting workers.

# Debugging Tips
# ----------------
# - Verify sample files exist and contain headers.
# - Log file path processing start and completion.

# Interview Questions
# ----------------
# 1. Why use threads for file processing?
# 2. How is the shared results list protected?
# 3. What happens if task_done() is omitted with queues?
# 4. How can this lab scale to more files?
# 5. When would async file I/O be more appropriate?

# Hands-on Exercise
# ----------------
# Add validation that checks numeric values and reports malformed rows.

# Challenge Exercise
# ----------------
# Refactor the processor to use a thread-safe queue for file tasks.
