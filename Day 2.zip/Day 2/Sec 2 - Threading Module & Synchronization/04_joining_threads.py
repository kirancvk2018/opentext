"""Python Threading — Joining Threads.

A regional sales reporting workflow that waits for all reporting threads before
building the executive dashboard.
"""

import threading
import time
from typing import Dict, List


def generate_sales_report(region: str, delay: float) -> None:
    """Simulate report generation for a single sales region."""
    print(f"[{threading.current_thread().name}] Generating {region} report")
    time.sleep(delay)
    print(f"[{threading.current_thread().name}] {region} report complete")


def build_regions() -> List[Dict[str, str | float]]:
    """Return sample regions and associated processing delays."""
    return [
        {"region": "North America", "delay": 1.1},
        {"region": "EMEA", "delay": 1.4},
        {"region": "APAC", "delay": 1.0},
    ]


def main() -> None:
    """Execute the sales report join demonstration."""
    print("JOINING THREADS: REGIONAL SALES REPORTS")
    regions = build_regions()
    report_threads: List[threading.Thread] = []

    for region in regions:
        thread = threading.Thread(
            target=generate_sales_report,
            args=(region["region"], region["delay"]),
            name=f"ReportThread-{region['region'].replace(' ', '')}",
        )
        report_threads.append(thread)
        thread.start()
        print(f"Started report thread for {region['region']}")

    print("Waiting for all regional reports to complete...")
    for report_thread in report_threads:
        report_thread.join()
        print(f"Joined {report_thread.name}")

    print("Executive dashboard can now be generated.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Regional report threads run concurrently.
# - The main thread blocks on join() until each report completes.
# - A final message indicates the dashboard may be generated.

# Execution Flow
# ----------------
# 1. Create regional report threads.
# 2. Start each thread.
# 3. Join each thread sequentially.
# 4. Generate the final dashboard notice.

# Architecture Explanation
# ----------------
# join() enforces a deterministic synchronization point.
# The dashboard build waits for dependent reports.

# Advantages
# ----------------
# - Ensures all data is ready before proceeding.
# - Simplifies workflow coordination.

# Limitations
# ----------------
# - join() may block longer than necessary if a single thread is slow.
# - Use timeouts or partial progress reporting in real systems.

# Performance Considerations
# ----------------
# - Threads can overlap IO and CPU work when generating reports.
# - join() cost is small compared to long-running report tasks.

# Best Practices
# ----------------
# - Join threads in a controlled order if dependencies exist.
# - Avoid join() inside tight loops for many threads.

# Common Mistakes
# ----------------
# - Forgetting to join threads when the main program continues.
# - Joining a thread before it has been started.

# Debugging Tips
# ----------------
# - Log thread start and completion markers.
# - Use join(timeout=...) if a thread may hang.

# Interview Questions
# ----------------
# 1. What does Thread.join() do?
# 2. Can join() be called multiple times on the same thread?
# 3. Why is join() important for report generation pipelines?
# 4. How do you prevent deadlocks when joining multiple threads?
# 5. What is the effect of join(timeout=...)?

# Hands-on Exercise
# ----------------
# Add a timeout to the join and log a warning if a report is delayed.

# Challenge Exercise
# ----------------
# Refactor the code to use a work queue for dynamic region assignments.
