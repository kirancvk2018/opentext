"""Python Threading — Reentrant Lock Demo.

A nested accounting transaction example that uses RLock for recursive locking.
"""

import threading
import time


class AccountingProcessor:
    """Accounting processor that supports nested transaction operations."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.total_reconciled = 0.0

    def reconcile_transaction(self, amount: float) -> None:
        """Perform a reconciliation step while holding the lock."""
        with self._lock:
            print(f"[{threading.current_thread().name}] Reconciling amount ${amount:,.2f}")
            self.total_reconciled += amount
            time.sleep(0.02)
            self.log_reconciliation(amount)

    def log_reconciliation(self, amount: float) -> None:
        """Log reconciliation details while the outer lock remains held."""
        with self._lock:
            print(
                f"[{threading.current_thread().name}] Logged reconciliation of ${amount:,.2f}"
            )
            time.sleep(0.01)


def accounting_worker(processor: AccountingProcessor, amounts: list[float]) -> None:
    """Process multiple reconciliation amounts in a threaded worker."""
    for amount in amounts:
        processor.reconcile_transaction(amount)


def main() -> None:
    """Run the reentrant lock demonstration."""
    print("REENTRANT LOCK: NESTED ACCOUNTING TRANSACTIONS")
    processor = AccountingProcessor()

    threads = [
        threading.Thread(
            target=accounting_worker,
            args=(processor, [1200.0, 540.0, 860.0]),
            name=f"AccountingWorker-{i+1}",
        )
        for i in range(2)
    ]

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    print(f"Total reconciled: ${processor.total_reconciled:,.2f}")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Nested lock acquisition succeeds without deadlock.
# - Each transaction logs reconciliation details safely.
# - The total reconciled amount reflects all threaded work.

# Execution Flow
# ----------------
# 1. Create an AccountingProcessor with an RLock.
# 2. Launch multiple accounting worker threads.
# 3. Each worker calls a method that re-enters the lock.
# 4. Join threads and print aggregated results.

# Architecture Explanation
# ----------------
# RLock allows the same thread to acquire the lock multiple times.
# This is essential when nested methods need to protect shared state.

# Advantages
# ----------------
# - Prevents deadlock in recursive or nested lock acquisition.
# - Keeps the locking structure expressive and safe.

# Limitations
# ----------------
# - RLocks have more overhead than simple Locks.
# - Avoid unnecessary nested locking.

# Performance Considerations
# ----------------
# - Use RLock only when recursion or reentrancy is required.
# - Keep nested critical sections short.

# Best Practices
# ----------------
# - Use RLock when a thread needs to re-enter a lock it already holds.
# - Keep the number of nested acquisitions manageable.

# Common Mistakes
# ----------------
# - Using RLock where a simple Lock would suffice.
# - Forgetting that RLock still serializes access between threads.

# Debugging Tips
# ----------------
# - Verify that the same thread acquires the lock recursively.
# - Log each acquisition and release if needed.

# Interview Questions
# ----------------
# 1. What is an RLock and how does it differ from Lock?
# 2. Why is recursive locking useful in nested methods?
# 3. Can different threads acquire the same RLock simultaneously?
# 4. What is the cost of using RLock compared to Lock?
# 5. When should you avoid reentrant locking?

# Hands-on Exercise
# ----------------
# Add a method that combines multiple reconciliation steps under the same RLock.

# Challenge Exercise
# ----------------
# Implement a withdraw/deposit transaction that uses RLock for nested audit logging.
