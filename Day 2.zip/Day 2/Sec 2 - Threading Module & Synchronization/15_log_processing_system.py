"""Python Threading — Enterprise Log Processing System.

A multithreaded log processing pipeline that handles multiple sources,
coordinates workers, and writes thread-safe aggregated output.
"""

import logging
import queue
import threading
import time
from pathlib import Path
from typing import List

LOG_DIRECTORY = Path("logs")
PROCESSED_LOG_FILE = LOG_DIRECTORY / "processed_summary.txt"


def configure_logging() -> logging.Logger:
    """Create a logger for the log processing system."""
    logger = logging.getLogger("LogProcessor")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger


def produce_log_entries(source_name: str, record_count: int) -> List[str]:
    """Generate sample log entries for a source.

    In a real system, these would come from files or network streams.
    """
    return [
        f"{source_name} | INFO | event {i} processed"
        for i in range(1, record_count + 1)
    ]


def log_source_worker(source_name: str, output_queue: queue.Queue[str], logger: logging.Logger) -> None:
    """Simulate reading log source data and enqueue entries for processing."""
    entries = produce_log_entries(source_name, record_count=6)
    for entry in entries:
        logger.info(f"[{threading.current_thread().name}] Enqueuing log entry")
        output_queue.put(f"{source_name}: {entry}")
        time.sleep(0.1)
    logger.info(f"[{threading.current_thread().name}] Source complete")


def processor_worker(input_queue: queue.Queue[str], done_event: threading.Event, logger: logging.Logger) -> None:
    """Process log entries from the queue until all sources complete."""
    while not (done_event.is_set() and input_queue.empty()):
        try:
            log_entry = input_queue.get(timeout=0.2)
        except queue.Empty:
            continue
        logger.info(f"[{threading.current_thread().name}] Processing: {log_entry}")
        time.sleep(0.15)
        input_queue.task_done()
    logger.info(f"[{threading.current_thread().name}] Processor shutting down")


def write_summary_file(lines: List[str]) -> None:
    """Write a processed summary file for audit purposes."""
    LOG_DIRECTORY.mkdir(parents=True, exist_ok=True)
    PROCESSED_LOG_FILE.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    """Run the log processing system demonstration."""
    logger = configure_logging()
    logger.info("ENTERPRISE LOG PROCESSING SYSTEM START")

    log_queue: queue.Queue[str] = queue.Queue()
    gateway_ready = threading.Event()
    processed_entries: List[str] = []

    source_threads = [
        threading.Thread(
            target=log_source_worker,
            args=(source, log_queue, logger),
            name=f"SourceReader-{source}",
        )
        for source in ("AuthService", "OrderService", "BillingService")
    ]

    processor_threads = [
        threading.Thread(
            target=processor_worker,
            args=(log_queue, gateway_ready, logger),
            name=f"LogProcessor-{i+1}",
        )
        for i in range(2)
    ]

    for thread in source_threads + processor_threads:
        thread.start()

    for thread in source_threads:
        thread.join()

    logger.info("All log sources finished, signaling processors")
    gateway_ready.set()

    log_queue.join()

    for thread in processor_threads:
        thread.join()

    write_summary_file([
        "Log processing completed successfully.",
        f"Processed sources: {', '.join(['AuthService', 'OrderService', 'BillingService'])}",
    ])
    logger.info(f"Summary written to {PROCESSED_LOG_FILE}")
    logger.info("ENTERPRISE LOG PROCESSING SYSTEM FINISHED")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Log source reader threads enqueue entries concurrently.
# - Processor threads consume entries in a thread-safe queue.
# - A summary file is written once processing completes.

# Execution Flow
# ----------------
# 1. Configure logging and queue structures.
# 2. Start source readers and log processors.
# 3. Wait for all sources to finish.
# 4. Signal processors and join them after queue drain.

# Architecture Explanation
# ----------------
# This example models log ingestion and processing in an enterprise system.
# Source threads produce data while worker threads consume and handle it.

# Advantages
# ----------------
# - Thread-safe queue decouples producers from consumers.
# - Event signaling enables clean shutdown.

# Limitations
# ----------------
# - In a real system, log entries would come from external sources.
# - The file write is simplified for demonstration.

# Performance Considerations
# ----------------
# - Queue-based processing scales with additional worker threads.
# - Avoid long processing tasks in a single thread if throughput matters.

# Best Practices
# ----------------
# - Use queue.Queue for producer-consumer coordination.
# - Signal consumers after all producers complete.

# Common Mistakes
# ----------------
# - Forgetting to call task_done(), which can hang join().
# - Relying on empty() without proper synchronization.

# Debugging Tips
# ----------------
# - Log queue operations and thread lifecycle events.
# - Ensure the done_event is set after producers finish.

# Interview Questions
# ----------------
# 1. Why use queue.Queue in a threaded log processor?
# 2. How does task_done() relate to join()?
# 3. What problem does the event solve here?
# 4. Why are multiple processor threads useful?
# 5. When would you choose multiprocessing instead of threading?

# Hands-on Exercise
# ----------------
# Add a retry mechanism for failed log entries.

# Challenge Exercise
# ----------------
# Extend the system to partition logs by source and write separate summaries.
