# Threading Module and Synchronization

## Project Overview

This repository demonstrates enterprise-grade Python threading and synchronization patterns using realistic business scenarios. Each example is implemented as an independent Python script, allowing learners to execute and inspect one concept at a time.

## Folder Structure

- `README.md` — project overview and usage guidance
- `requirements.txt` — Python standard library only
- `src/` — placeholder for extended source modules
- `01_thread_class_intro.py` through `16_background_service.py` — independent threading demonstrations
- `labs/` — practical lab exercises for multithreaded systems
- `common/` — reusable utilities and logging helpers

## Learning Objectives

- Understand Python thread lifecycle and thread objects
- Learn thread creation, starting, joining, naming, and daemon behavior
- Recognize race conditions and apply lock-based synchronization
- Use advanced primitives: `RLock`, `Event`, `Semaphore`, `Timer`
- Model enterprise services such as background monitors, payment gateways, and log processors

## Prerequisites

- Python 3.12+
- Basic familiarity with Python syntax
- No third-party dependencies required

## Python Version

- Python 3.12 or newer

## VS Code Setup

1. Open the workspace folder in VS Code.
2. Ensure your selected interpreter is Python 3.12+.
3. Use the integrated terminal to run examples.

## How to Run

Execute any sample directly from the workspace root:

```bash
python 01_thread_class_intro.py
python 10_thread_safety_with_lock.py
python labs/lab02_producer_consumer.py
```

## Expected Outputs

Each script prints structured, enterprise-oriented runtime logs with:

- operational context for the scenario
- thread activity and synchronization behavior
- final result summary

## Execution Order

1. Basic thread concepts: `01_` through `09_`
2. Synchronization primitives: `10_` through `14_`
3. Enterprise systems and services: `15_` and `16_`
4. Labs: `labs/`

## Thread Lifecycle Diagram

```
New -> Runnable -> Running -> Waiting/Blocked -> Completed
```

## Synchronization Primitive Comparison

- `Lock` — exclusive access for critical sections
- `RLock` — reentrant lock for nested acquisition
- `Event` — thread coordination and one-time signal
- `Semaphore` — limit concurrent resource usage
- `Timer` — deferred execution in background

## Recommended Learning Path

1. Start with thread creation examples
2. Observe thread start/join behavior
3. Reproduce the race condition and fix it with locks
4. Study event and semaphore coordination
5. Explore enterprise examples and lab exercises
