"""Python Threading — Thread Class Introduction.

A realistic enterprise customer order processing workflow using a custom
Thread subclass.
"""

import threading
import time
from typing import List


class OrderProcessingThread(threading.Thread):
    """Thread subclass that simulates processing a customer order."""

    def __init__(self, order_id: str, processing_seconds: float) -> None:
        super().__init__(name=f"OrderThread-{order_id}")
        self.order_id = order_id
        self.processing_seconds = processing_seconds

    def run(self) -> None:
        """Execute the order processing workflow for this thread."""
        print(f"[{self.name}] Starting order processing for order {self.order_id}")
        time.sleep(self.processing_seconds)
        print(f"[{self.name}] Completed order {self.order_id}")


def main() -> None:
    """Run the enterprise order processing demonstration."""
    print("THREAD CLASS INTRODUCTION: CUSTOMER ORDER PROCESSING")

    orders: List[OrderProcessingThread] = [
        OrderProcessingThread(order_id="1001", processing_seconds=1.0),
        OrderProcessingThread(order_id="1002", processing_seconds=1.2),
        OrderProcessingThread(order_id="1003", processing_seconds=0.8),
    ]

    for order_thread in orders:
        print(
            f"Preparing thread {order_thread.name} - daemon={order_thread.daemon}"
        )
        order_thread.start()

    for order_thread in orders:
        while order_thread.is_alive():
            print(f"Waiting for {order_thread.name} to finish")
            time.sleep(0.3)
        print(f"{order_thread.name} final identifier: {order_thread.ident}")

    print("All customer orders have been processed.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Thread objects are created and assigned names.
# - Each thread executes independently.
# - The lifecycle is observed using is_alive() and ident.
# - The application finishes after all order threads complete.

# Execution Flow
# ----------------
# 1. Create order processing thread instances.
# 2. Start each thread.
# 3. Poll each thread until completion.
# 4. Print final thread identifiers and summary.

# Architecture Explanation
# ----------------
# A custom Thread subclass encapsulates order metadata and the execution logic.
# This structure matches production systems where worker threads bundle state
# and behavior together.

# Advantages
# ----------------
# - Clear separation of thread logic and orchestration.
# - Thread attributes like name and ident are available for diagnostics.

# Limitations
# ----------------
# - This example uses thread polling rather than join() for demonstration.
# - Real applications should avoid busy polling or use events.

# Performance Considerations
# ----------------
# - CPU-bound work would not benefit from Python threads due to the GIL.
# - IO-bound order workflows are appropriate for threading.

# Best Practices
# ----------------
# - Use meaningful thread names for logging and monitoring.
# - Avoid long-running work inside run() without progress reporting.

# Common Mistakes
# ----------------
# - Starting the same Thread instance multiple times.
# - Using daemon threads for critical order completion work.

# Debugging Tips
# ----------------
# - Check thread.is_alive() to verify lifecycle state.
# - Use thread.name in logs to correlate concurrent activities.

# Interview Questions
# ----------------
# 1. Why would you subclass threading.Thread instead of using Thread(target=...)?
# 2. What does thread.ident represent?
# 3. When is a thread considered alive?
# 4. Why is daemon=False used for order processing?
# 5. What are the limitations of threading for CPU-bound tasks?

# Hands-on Exercise
# ----------------
# Modify the script to use a shared result list protected by a Lock.

# Challenge Exercise
# ----------------
# Extend the example to record order start and end timestamps in a thread-safe
# audit record structure.
