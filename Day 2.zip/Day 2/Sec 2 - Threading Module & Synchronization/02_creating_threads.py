"""Python Threading — Creating Threads.

A payroll processing example that creates worker threads using a reusable
function.
"""

import threading
import time
from typing import Dict, List


def process_payroll(employee_record: Dict[str, str]) -> None:
    """Simulate payroll calculations for a single employee."""
    employee_id = employee_record["employee_id"]
    employee_name = employee_record["name"]
    salary = float(employee_record["salary"])

    print(f"[PayrollWorker-{employee_id}] Calculating payroll for {employee_name}")
    time.sleep(0.6)
    print(
        f"[PayrollWorker-{employee_id}] Processed payroll for {employee_name} -"
        f" net salary ${salary * 0.78:,.2f}"
    )


def build_employee_records() -> List[Dict[str, str]]:
    """Return a sample list of employee payroll records.

    The values are representative of a regional payroll batch.
    """
    return [
        {"employee_id": "E001", "name": "Sophia Patel", "salary": "9200"},
        {"employee_id": "E002", "name": "Marcus Chen", "salary": "8700"},
        {"employee_id": "E003", "name": "Lina Gomez", "salary": "7800"},
        {"employee_id": "E004", "name": "Noah Brooks", "salary": "9800"},
    ]


def main() -> None:
    """Run the payroll thread creation demonstration."""
    print("CREATING THREADS: EMPLOYEE PAYROLL PROCESSING")
    employee_records = build_employee_records()
    workers: List[threading.Thread] = []

    for record in employee_records:
        thread = threading.Thread(
            target=process_payroll,
            args=(record,),
            name=f"PayrollWorker-{record['employee_id']}",
        )
        workers.append(thread)
        print(f"Initializing thread {thread.name}")

    for worker in workers:
        worker.start()
        print(f"Started {worker.name}")

    for worker in workers:
        worker.join()
        print(f"Completed {worker.name}")

    print("Payroll batch processing complete.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Worker threads are initialized and started.
# - Payroll calculations execute concurrently.
# - Each thread reports its own employee processing result.
# - The main process waits until every thread complete.

# Execution Flow
# ----------------
# 1. Build sample employee records.
# 2. Create a thread per payroll record.
# 3. Start all worker threads.
# 4. Join threads and print completion messages.

# Architecture Explanation
# ----------------
# The example separates worker behavior from orchestration.
# A reusable target function is passed to multiple thread instances.

# Advantages
# ----------------
# - Reusable worker logic simplifies business workflows.
# - Thread creation is explicit and maintainable.

# Limitations
# ----------------
# - Shared state is not required in this example.
# - Real payroll systems need secure data handling.

# Performance Considerations
# ----------------
# - Thread startup overhead is low for moderate batch sizes.
# - Use thread pools for large-scale payroll workloads.

# Best Practices
# ----------------
# - Keep target functions small and clearly scoped.
# - Use meaningful thread names to improve diagnostics.

# Common Mistakes
# ----------------
# - Passing mutable shared data without synchronization.
# - Starting threads after a long delay without necessity.

# Debugging Tips
# ----------------
# - Verify the target function is callable and arguments are correct.
# - Use print or logging inside the worker to trace progress.

# Interview Questions
# ----------------
# 1. How do you pass arguments to a thread target?
# 2. Why is a reusable worker function useful?
# 3. What happens if you forget to call start()?
# 4. When should you use Thread subclassing instead of target=...?
# 5. How does join() affect the main thread?

# Hands-on Exercise
# ----------------
# Add a shared exception list to collect worker failures.

# Challenge Exercise
# ----------------
# Refactor the example to use a thread pool abstraction with worker reuse.
