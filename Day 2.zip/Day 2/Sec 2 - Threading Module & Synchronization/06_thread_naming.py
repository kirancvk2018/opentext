"""Python Threading — Thread Naming.

A network monitoring system that assigns meaningful names to each monitor
thread.
"""

import threading
import time
from typing import Dict, List


def monitor_component(component_name: str, interval_seconds: float) -> None:
    """Simulate a monitoring cycle for a network component."""
    thread_name = threading.current_thread().name
    print(f"[{thread_name}] Checking health of {component_name}")
    time.sleep(interval_seconds)
    print(f"[{thread_name}] {component_name} is healthy")


def build_components() -> List[Dict[str, str | float]]:
    """Return a list of network components for monitoring."""
    return [
        {"component_name": "Database Server", "interval": 0.9},
        {"component_name": "Application Server", "interval": 1.1},
        {"component_name": "API Gateway", "interval": 0.8},
        {"component_name": "Load Balancer", "interval": 1.0},
    ]


def main() -> None:
    """Execute the thread naming demonstration."""
    print("THREAD NAMING: NETWORK MONITORING SYSTEM")
    components = build_components()
    threads: List[threading.Thread] = []

    for component in components:
        thread = threading.Thread(
            target=monitor_component,
            args=(component["component_name"], component["interval"]),
            name=f"Monitor-{component['component_name'].replace(' ', '')}",
        )
        threads.append(thread)
        thread.start()
        print(f"Started {thread.name}")

    for thread in threads:
        thread.join()
    print("Network monitoring cycle complete.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Each monitor thread prints its assigned name.
# - The thread name is used for traceability.
# - The workflow completes once all monitors finish.

# Execution Flow
# ----------------
# 1. Define network monitoring targets.
# 2. Create threads with explicit names.
# 3. Start and join each thread.

# Architecture Explanation
# ----------------
# Meaningful thread names improve observability in logs and diagnostics.
# In enterprise systems, thread identity helps trace work across components.

# Advantages
# ----------------
# - Easier debugging when multiple worker threads run.
# - Supports thread-level health and audit tracking.

# Limitations
# ----------------
# - Names are metadata only and do not affect behavior.
# - Do not rely on names for program logic.

# Performance Considerations
# ----------------
# - Naming is inexpensive and often worth the clarity it provides.

# Best Practices
# ----------------
# - Use structured naming conventions for thread owners and workload.
# - Avoid ambiguous or duplicate thread names.

# Common Mistakes
# ----------------
# - Relying on default thread names for enterprise diagnostics.
# - Using names that do not clearly indicate the thread's purpose.

# Debugging Tips
# ----------------
# - Include thread.name in logs and error messages.
# - Verify that named threads correspond to the correct workloads.

# Interview Questions
# ----------------
# 1. Why is thread naming important in production systems?
# 2. How do you retrieve the current thread name?
# 3. When should you avoid using thread names in logic?
# 4. Can multiple threads share the same name?
# 5. How does naming improve monitoring and tracing?

# Hands-on Exercise
# ----------------
# Add a monitoring interval schedule that names threads based on frequency.

# Challenge Exercise
# ----------------
# Build a status summary that groups logs by thread name.
