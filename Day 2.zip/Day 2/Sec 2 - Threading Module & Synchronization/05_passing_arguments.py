"""Python Threading — Passing Arguments to Threads.

A customer notification system where each worker thread receives specific
parameters to build and send notifications.
"""

import threading
import time
from typing import Dict, List


def send_customer_notification(
    customer_id: str,
    email: str,
    notification_type: str,
) -> None:
    """Simulate sending an email notification to a customer."""
    print(
        f"[{threading.current_thread().name}] Sending {notification_type}"
        f" notification to customer {customer_id} at {email}"
    )
    time.sleep(0.7)
    print(
        f"[{threading.current_thread().name}] Delivered {notification_type}"
        f" notification to {customer_id}"
    )


def build_notifications() -> List[Dict[str, str]]:
    """Build a list of customer notification payloads."""
    return [
        {"customer_id": "C001", "email": "sara.brown@example.com", "type": "Order Confirmation"},
        {"customer_id": "C002", "email": "david.lee@example.com", "type": "Shipping Update"},
        {"customer_id": "C003", "email": "marta.kim@example.com", "type": "Delivery Reminder"},
    ]


def main() -> None:
    """Run the notification parameter passing demonstration."""
    print("PASSING ARGUMENTS: CUSTOMER NOTIFICATION SYSTEM")
    payloads = build_notifications()
    threads: List[threading.Thread] = []

    for payload in payloads:
        thread = threading.Thread(
            target=send_customer_notification,
            args=(payload["customer_id"], payload["email"], payload["type"]),
            name=f"Notifier-{payload['customer_id']}",
        )
        threads.append(thread)
        thread.start()
        print(f"Started notifier thread for {payload['customer_id']}")

    for thread in threads:
        thread.join()

    print("All customer notifications have been dispatched.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Each notification thread receives customer-specific inputs.
# - Threads run concurrently and print delivery status.
# - The main thread waits until all notification tasks are complete.

# Execution Flow
# ----------------
# 1. Create payloads for each customer notification.
# 2. Start a thread passing args via args=().
# 3. Join each thread to ensure completion.

# Architecture Explanation
# ----------------
# Thread arguments are passed at creation time,
# enabling worker threads to execute parameterized business logic.

# Advantages
# ----------------
# - Thread-specific data remains local to each worker.
# - No shared state is required for this workflow.

# Limitations
# ----------------
# - Arguments are immutable copies or references.
# - Use synchronization when shared mutable structures are passed.

# Performance Considerations
# ----------------
# - Network-style notifications benefit from concurrent dispatch.
# - Threading reduces wait time for IO-bound tasks.

# Best Practices
# ----------------
# - Keep thread argument lists explicit and small.
# - Avoid passing large mutable objects unless protected.

# Common Mistakes
# ----------------
# - Passing arguments in the wrong order.
# - Reusing the same dict across threads without copying.

# Debugging Tips
# ----------------
# - Print received argument values at the beginning of the worker.
# - Ensure target functions accept the same number of parameters.

# Interview Questions
# ----------------
# 1. How do you pass multiple parameters to a thread target?
# 2. Why should thread arguments be kept simple?
# 3. How can you pass keyword arguments to Thread?
# 4. What issues arise when passing mutable objects to threads?
# 5. When is thread-local storage preferable?

# Hands-on Exercise
# ----------------
# Modify the script to use kwargs and include a priority label.

# Challenge Exercise
# ----------------
# Add a shared status dictionary with a Lock to track delivery results.
