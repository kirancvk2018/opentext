"""Python Threading — Event Synchronization.

A payment gateway workflow where worker threads wait until the gateway becomes
available.
"""

import threading
import time
from typing import List


def payment_worker(payment_id: int, gateway_ready: threading.Event) -> None:
    """Wait until the payment gateway is available and then process payment."""
    print(f"[PaymentWorker-{payment_id}] Waiting for payment gateway")
    gateway_ready.wait()
    print(f"[PaymentWorker-{payment_id}] Gateway is ready, processing payment")
    time.sleep(0.6)
    print(f"[PaymentWorker-{payment_id}] Payment {payment_id} completed")


def main() -> None:
    """Execute the payment gateway event synchronization demonstration."""
    print("EVENT SYNCHRONIZATION: PAYMENT GATEWAY")
    gateway_ready = threading.Event()
    workers: List[threading.Thread] = []

    for payment_id in range(1, 5):
        thread = threading.Thread(
            target=payment_worker,
            args=(payment_id, gateway_ready),
            name=f"PaymentWorker-{payment_id}",
        )
        workers.append(thread)
        thread.start()

    print("Initializing payment gateway startup sequence")
    time.sleep(2.0)
    gateway_ready.set()
    print("Payment gateway is now available")

    for worker in workers:
        worker.join()

    print("All payments were processed after the gateway became available.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Payment workers wait until gateway readiness is signaled.
# - Once gateway_ready is set, all waiting workers proceed.
# - The main thread joins workers after the signal.

# Execution Flow
# ----------------
# 1. Start payment worker threads.
# 2. Workers wait on gateway_ready.
# 3. Simulate gateway startup delay.
# 4. Set the event and continue workers.

# Architecture Explanation
# ----------------
# Event allows many threads to wait for a one-time signal.
# It is ideal for readiness or configuration gating.

# Advantages
# ----------------
# - Simplifies coordination of worker start conditions.
# - Avoids polling by blocking threads until the event is signaled.

# Limitations
# ----------------
# - Event is a one-time broadcast and does not queue state.
# - Workers that start after set() still proceed immediately.

# Performance Considerations
# ----------------
# - Event wait is lightweight and efficient.
# - Use for startup coordination and feature gate signals.

# Best Practices
# ----------------
# - Set the event only when the prerequisite is truly ready.
# - Clear or recreate the event if a new wait cycle is required.

# Common Mistakes
# ----------------
# - Using Event for per-thread ordering rather than broadcast signaling.
# - Forgetting to set the event and causing deadlock.

# Debugging Tips
# ----------------
# - Log when workers start waiting and when the event is set.
# - Use is_set() only for informational checks, not as a replacement for wait().

# Interview Questions
# ----------------
# 1. When should you use threading.Event?
# 2. What is the difference between wait() and set()?
# 3. Can a thread miss a signal from Event?
# 4. How do you reset an Event for another cycle?
# 5. What are typical use cases for Event in enterprise workflows?

# Hands-on Exercise
# ----------------
# Add a timeout to gateway_ready.wait() and handle unavailable gateway cases.

# Challenge Exercise
# ----------------
# Build a scheduled retry mechanism that resets gateway readiness after a failure.
