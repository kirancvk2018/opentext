"""Python Threading — Background Service.

A server health monitoring service that uses a daemon thread and stop event
for graceful shutdown.
"""

import threading
import time
from random import uniform


def gather_metric(metric_name: str) -> float:
    """Simulate gathering a server health metric."""
    return round(uniform(10.0, 90.0), 2)


def health_monitor(stop_event: threading.Event, interval_seconds: float) -> None:
    """Continuously monitor server health until a stop event is signaled."""
    while not stop_event.is_set():
        cpu = gather_metric("cpu")
        memory = gather_metric("memory")
        disk = gather_metric("disk")
        network = gather_metric("network")
        print(
            f"[HealthMonitor] CPU={cpu}% Memory={memory}% Disk={disk}% Network={network}%"
        )
        time.sleep(interval_seconds)
    print("[HealthMonitor] Received stop signal. Shutting down gracefully.")


def main() -> None:
    """Run the server health monitoring background service."""
    stop_event = threading.Event()
    monitor_thread = threading.Thread(
        target=health_monitor,
        args=(stop_event, 1.0),
        name="HealthMonitorThread",
        daemon=True,
    )

    print("Starting server health monitoring service")
    monitor_thread.start()

    try:
        print("Service is running. Press Ctrl+C to stop.")
        time.sleep(4.0)
    finally:
        print("Signaling the background service to stop")
        stop_event.set()
        monitor_thread.join(timeout=2.0)
        print("Background service stopped")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - The daemon thread prints periodic health data.
# - The stop event ends the loop and the thread shuts down gracefully.
# - The main thread joins with a timeout to avoid hanging.

# Execution Flow
# ----------------
# 1. Create a stop event and a daemon monitor thread.
# 2. Start the background health monitor.
# 3. Keep the service alive briefly.
# 4. Signal stop and join the thread.

# Architecture Explanation
# ----------------
# A background daemon thread handles monitoring while the main thread
# controls lifecycle and shutdown.

# Advantages
# ----------------
# - The service runs independently of the main control flow.
# - The stop event provides a clean shutdown path.

# Limitations
# ----------------
# - Since the thread is daemonized, the process may terminate if the main
#   thread exits unexpectedly.

# Performance Considerations
# ----------------
# - Monitoring tasks should remain lightweight.
# - Use a timeout on join() to avoid blocking during shutdown.

# Best Practices
# ----------------
# - Separate background work from lifecycle control.
# - Use events to avoid hard process termination.

# Common Mistakes
# ----------------
# - Relying on a daemon thread to complete critical work at shutdown.
# - Not signaling the thread to stop before exiting.

# Debugging Tips
# ----------------
# - Log both startup and shutdown events.
# - Use a stop event even for daemon background threads.

# Interview Questions
# ----------------
# 1. Why use a stop event with a daemon thread?
# 2. What does daemon=True imply for lifecycle?
# 3. How is graceful shutdown implemented here?
# 4. Why join the thread with a timeout?
# 5. When should you avoid daemon threads entirely?

# Hands-on Exercise
# ----------------
# Add a configuration to change the monitoring interval dynamically.

# Challenge Exercise
# ----------------
# Build a service launcher that manages multiple daemon health checks.
