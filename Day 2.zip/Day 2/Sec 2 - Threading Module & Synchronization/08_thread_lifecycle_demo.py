"""Python Threading — Thread Lifecycle Demo.

A loan approval workflow that illustrates thread lifecycle states.
"""

import threading
import time
from typing import List


def loan_review(review_id: int, delay: float) -> None:
    """Simulate a loan review process for an application."""
    current_thread = threading.current_thread()
    print(f"[{current_thread.name}] Review {review_id} entered running state")
    time.sleep(delay)
    print(f"[{current_thread.name}] Review {review_id} complete")


def main() -> None:
    """Execute the loan approval lifecycle demonstration."""
    print("THREAD LIFECYCLE: LOAN APPROVAL WORKFLOW")
    threads: List[threading.Thread] = []

    for review_id, delay in enumerate((1.0, 1.3, 0.95), start=1):
        thread = threading.Thread(
            target=loan_review,
            args=(review_id, delay),
            name=f"LoanReview-{review_id}",
        )
        threads.append(thread)
        print(f"Created {thread.name} in new state")

    for thread in threads:
        thread.start()
        print(f"Started {thread.name} and moved to runnable")

    while any(thread.is_alive() for thread in threads):
        alive_names = [thread.name for thread in threads if thread.is_alive()]
        print(f"Active threads: {alive_names}")
        time.sleep(0.5)

    for thread in threads:
        print(f"{thread.name} has completed and is no longer alive")

    print("Loan approval workflow completed.")


if __name__ == "__main__":
    main()


# Expected Output
# ----------------
# - Threads are created in a new state.
# - start() transitions threads to runnable/running.
# - Active thread names are displayed while work executes.
# - Completed threads are reported after all work finishes.

# Execution Flow
# ----------------
# 1. Create loan review threads.
# 2. Start each thread.
# 3. Periodically inspect alive threads.
# 4. Report final completion.

# Architecture Explanation
# ----------------
# The example models thread lifecycle observation in a review process.
# It demonstrates how threads move from creation to execution and completion.

# Advantages
# ----------------
# - Provides visibility into concurrent thread states.
# - Useful for monitoring and debugging workflows.

# Limitations
# ----------------
# - Thread lifecycle states are approximated with is_alive().
# - Python does not expose all low-level thread states directly.

# Performance Considerations
# ----------------
# - Polling active threads is acceptable for a small number.
# - Use event-driven coordination for larger thread counts.

# Best Practices
# ----------------
# - Use thread names and alive checks to confirm operation progress.
# - Avoid busy-wait loops in production.

# Common Mistakes
# ----------------
# - Assuming a thread is running immediately after start().
# - Ignoring thread completion signals in the main process.

# Debugging Tips
# ----------------
# - Log when threads are created, started, and completed.
# - Use join() to enforce final synchronization if needed.

# Interview Questions
# ----------------
# 1. How do you determine whether a thread is alive?
# 2. What lifecycle states are visible in Python threading?
# 3. Why is thread polling not ideal for production systems?
# 4. How can lifecycle information improve monitoring?
# 5. What does thread.start() do internally?

# Hands-on Exercise
# ----------------
# Replace periodic polling with a shared Event that signals completion.

# Challenge Exercise
# ----------------
# Build a thread lifecycle dashboard that tracks start and end timestamps.
