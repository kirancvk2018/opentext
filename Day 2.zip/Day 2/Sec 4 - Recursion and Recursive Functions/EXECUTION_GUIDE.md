# Python Recursion Learning Project - Execution Guide

## Quick Start

```bash
cd "Recursion_and_Recursive_Functions"
python src/01_intro_to_recursion.py
```

## Complete Module List

### Phase 1: Foundations (Days 1-2)

| File | Concept | Business Scenario | Time |
|------|---------|------------------|------|
| `01_intro_to_recursion.py` | What is recursion? | Corporate folder hierarchy | 20 min |
| `02_recursive_thinking.py` | Problem decomposition | E-commerce categories | 20 min |
| `03_base_and_recursive_case.py` | Base vs recursive case | Document approval workflow | 20 min |
| `04_call_stack_demo.py` | Call stack & frames | Support ticket escalation | 20 min |

### Phase 2: Classic Algorithms (Days 3-4)

| File | Concept | Business Scenario | Time |
|------|---------|------------------|------|
| `05_factorial.py` | Factorial recursion | Workflow combinations | 15 min |
| `06_fibonacci.py` | Naive vs optimized | Revenue forecasting | 30 min |
| `07_power_function.py` | Divide-and-conquer | System capacity growth | 15 min |
| `08_reverse_string.py` | String operations | Transaction reversal | 10 min |
| `09_gcd_algorithm.py` | Euclidean algorithm | Batch optimization | 15 min |
| `10_recursive_sum.py` | Aggregation | Sales hierarchy | 15 min |

### Phase 3: Real-World Applications (Days 5-7)

| File | Concept | Business Scenario | Time |
|------|---------|------------------|------|
| `11_binary_search.py` | Divide-and-conquer | Customer lookup | 20 min |
| `12_directory_traversal.py` | File systems | Backup utility | 20 min |
| `13_tree_traversal.py` | Tree methods | Organization structure | 25 min |
| `14_recursion_depth.py` | Depth tracking | Repository analysis | 10 min |

### Phase 4: Advanced Topics (Day 8)

| File | Concept | Business Scenario | Time |
|------|---------|------------------|------|
| `15_recursion_limit_demo.py` | System limits | System configuration | 15 min |
| `16_recursion_error_demo.py` | Error handling | Configuration parsing | 20 min |
| `17_memoized_fibonacci.py` | Optimization | Financial forecasting | 25 min |
| `18_recursive_configuration_loader.py` | Enterprise pattern | Config management | 25 min |

### Phase 5: Lab Exercises (Days 9-10)

| File | Task | Complexity | Time |
|------|------|-----------|------|
| `lab01_recursive_file_explorer.py` | Build file explorer | Intermediate | 45 min |
| `lab02_recursive_menu_generator.py` | Generate menus | Intermediate | 45 min |
| `lab03_recursive_tree_traversal.py` | Organization tree | Advanced | 60 min |

## Execution by Learning Path

### Fast Track (2 Days)
```bash
# Core concepts only
python src/01_intro_to_recursion.py
python src/02_recursive_thinking.py
python src/03_base_and_recursive_case.py
python src/05_factorial.py
python src/06_fibonacci.py
python src/17_memoized_fibonacci.py
```

### Standard Track (1 Week)
```bash
# All core modules
for i in {01..13}; do
    python "src/${i}_*.py"
done
```

### Complete Track (2 Weeks)
```bash
# All modules + labs
for i in {01..18}; do
    python "src/${i}_*.py"
done

for i in {01..03}; do
    python "labs/lab${i}_*.py"
done
```

### Deep Dive (3 Weeks)
```bash
# Complete + challenges + review
# Run all modules
# Complete all lab challenges
# Implement custom recursion problems
# Review interview questions
```

## Key Concepts Coverage

### Recursion Fundamentals ✓
- [x] What is recursion?
- [x] Base case vs recursive case
- [x] Call stack and frames
- [x] Problem decomposition
- [x] Recursive thinking patterns

### Recursion Algorithms ✓
- [x] Factorial
- [x] Fibonacci (naive and optimized)
- [x] Power function
- [x] String operations
- [x] GCD algorithm
- [x] Recursive sum
- [x] Binary search
- [x] Tree traversal

### Real-World Applications ✓
- [x] File system traversal
- [x] Organization hierarchies
- [x] Configuration loading
- [x] Menu generation
- [x] Backup utilities
- [x] Database searches

### Performance & Optimization ✓
- [x] Time complexity analysis
- [x] Space complexity
- [x] Divide-and-conquer
- [x] Memoization
- [x] Dynamic programming
- [x] Naive vs optimized

### Error Handling ✓
- [x] RecursionError
- [x] Recursion limits
- [x] Stack overflow prevention
- [x] Graceful error handling
- [x] Debugging techniques

### Best Practices ✓
- [x] Code clarity
- [x] Memory management
- [x] Performance monitoring
- [x] Documentation
- [x] Testing strategies

## Running Individual Modules

### See all modules
```bash
ls -la src/
```

### Run specific module
```bash
python src/05_factorial.py
```

### Run with Python verbose mode (debug)
```bash
python -v src/06_fibonacci.py
```

### Run with profiling
```bash
python -m cProfile -s cumulative src/06_fibonacci.py
```

## Recommended Study Sequence

### Day 1: Foundations
1. `01_intro_to_recursion.py` - Understand basics
2. `02_recursive_thinking.py` - Learn decomposition
3. `03_base_and_recursive_case.py` - Master base/recursive cases
4. `04_call_stack_demo.py` - Visualize call stack

### Day 2: Classic Algorithms
1. `05_factorial.py` - Simple factorial
2. `06_fibonacci.py` - Naive implementation
3. `17_memoized_fibonacci.py` - Optimization
4. `07_power_function.py` - Divide-and-conquer

### Day 3: More Algorithms
1. `08_reverse_string.py` - String reversal
2. `09_gcd_algorithm.py` - Euclidean algorithm
3. `10_recursive_sum.py` - Aggregation
4. `11_binary_search.py` - Binary search

### Day 4: Real-World Apps
1. `12_directory_traversal.py` - File systems
2. `13_tree_traversal.py` - Tree traversal
3. `18_recursive_configuration_loader.py` - Configuration

### Day 5: Advanced Topics
1. `14_recursion_depth.py` - Depth tracking
2. `15_recursion_limit_demo.py` - System limits
3. `16_recursion_error_demo.py` - Error handling

### Days 6-7: Labs
1. `lab01_recursive_file_explorer.py` - File explorer
2. `lab02_recursive_menu_generator.py` - Menu generation
3. `lab03_recursive_tree_traversal.py` - Organization tree

## Learning Outcomes

### Knowledge ✓
- Understand recursion concepts deeply
- Know when to use recursion vs iteration
- Understand call stack mechanics
- Know recursion complexity analysis
- Understand optimization techniques

### Skills ✓
- Write correct recursive functions
- Design solutions using recursion
- Optimize recursive code
- Handle recursion errors
- Debug recursive problems
- Implement real-world recursion

### Interview Ready ✓
- Explain recursion clearly
- Solve recursion problems
- Optimize recursive solutions
- Handle edge cases
- Discuss trade-offs
- Implement in production code

## Troubleshooting

### Module won't run
```bash
# Check Python version
python --version  # Should be 3.12+

# Check imports
python -c "import os; import sys; print('OK')"
```

### RecursionError during execution
```bash
# This is expected in some examples!
# Shows what happens at recursion limit
# Shows how to handle errors
```

### ModuleNotFoundError
```bash
# Make sure you're in the project root
cd "Recursion_and_Recursive_Functions"

# Check folder structure
ls -la src/
ls -la common/
ls -la labs/
```

### File permissions issues
```bash
# Make Python files executable
chmod +x src/*.py
chmod +x labs/*.py

# Or run with python directly
python src/01_intro_to_recursion.py
```

## Next Steps After Completion

1. **Review Interview Questions** - Each module has 5 interview questions
2. **Complete Challenge Exercises** - Each module has challenges
3. **Implement Custom Problems** - Try your own recursion problems
4. **Read Production Code** - Look for recursion in real projects
5. **Practice on LeetCode** - Problem tags: "recursion", "backtracking"
6. **Learn Advanced Topics**:
   - Backtracking algorithms
   - Dynamic programming
   - Graph recursion
   - Advanced tree algorithms

## Resources Included

- ✓ 18 comprehensive learning modules
- ✓ 3 hands-on lab exercises
- ✓ 90+ interview questions (5 per module)
- ✓ Call stack visualizations
- ✓ Performance comparisons
- ✓ Business scenarios
- ✓ Production code patterns
- ✓ Best practices guide
- ✓ Error handling examples
- ✓ Debugging techniques

## Time Estimates

- **Fast Track**: 8 hours
- **Standard Track**: 15 hours
- **Complete Track**: 25 hours
- **Deep Dive**: 40 hours

## Additional Learning

### Books
- "Cracking the Coding Interview" - Recursion chapter
- "Introduction to Algorithms" - Recursion and divide-and-conquer

### Online Resources
- Python Tutor (visualize recursion)
- LeetCode (practice problems)
- HackerRank (guided problems)

### Concepts to Explore Next
- Backtracking (8 Queens, Sudoku)
- Dynamic Programming (LCS, Knapsack)
- Graph Traversal (DFS, BFS)
- Tree Algorithms (BST, AVL, Red-Black)

---

**Happy Learning! Master recursion and become a better engineer! 🚀**
