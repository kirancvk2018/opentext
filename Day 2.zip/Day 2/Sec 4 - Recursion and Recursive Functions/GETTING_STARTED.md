# Getting Started with Recursion and Recursive Functions

## 🚀 Quick Start (5 minutes)

### 1. Verify Python Version
```bash
python --version
# Should show: Python 3.12+ (or 3.11+)
```

### 2. Navigate to Project Directory
```bash
cd "d:\Kiran\Open text\Day 2\Sec 4 - Recursion and Recursive Functions"
# Or: cd "Recursion_and_Recursive_Functions"
```

### 3. Run Your First Module
```bash
python src/01_intro_to_recursion.py
```

You should see:
```
================================================================================
                    INTRODUCTION TO RECURSION
================================================================================

Creating sample folder structure for demonstration...
✓ Created folder structure at: sample_company_folders
...
```

### 4. Read the Output
- Observe the recursive folder traversal
- See how call stack grows and shrinks
- Understand base case and recursive case

### 5. Go to Next Module
```bash
python src/02_recursive_thinking.py
```

## 📚 Recommended Learning Path

### Day 1: Foundations (4 modules)
```bash
# Morning: Understand recursion basics
python src/01_intro_to_recursion.py
python src/02_recursive_thinking.py

# Afternoon: Master base and recursive cases
python src/03_base_and_recursive_case.py
python src/04_call_stack_demo.py
```

**Concepts learned**: What is recursion, when to use it, call stack mechanics

---

### Day 2: Classic Algorithms (3 modules)
```bash
# Morning: Simple algorithms
python src/05_factorial.py
python src/06_fibonacci.py

# Afternoon: Optimization
python src/17_memoized_fibonacci.py
```

**Concepts learned**: Recursion patterns, performance optimization, memoization

---

### Day 3: More Algorithms (4 modules)
```bash
# Morning: Mathematical algorithms
python src/07_power_function.py
python src/09_gcd_algorithm.py

# Afternoon: Data processing
python src/08_reverse_string.py
python src/10_recursive_sum.py
```

**Concepts learned**: Divide-and-conquer, mathematical recursion, aggregation

---

### Day 4: Real-World Applications (3 modules)
```bash
# Morning: Search and traversal
python src/11_binary_search.py
python src/12_directory_traversal.py

# Afternoon: Enterprise patterns
python src/13_tree_traversal.py
```

**Concepts learned**: Practical recursion, file systems, tree processing

---

### Day 5: Advanced Topics (3 modules)
```bash
# Morning: Depth and limits
python src/14_recursion_depth.py
python src/15_recursion_limit_demo.py

# Afternoon: Error handling
python src/16_recursion_error_demo.py
```

**Concepts learned**: System limits, error handling, production considerations

---

### Days 6-7: Labs (3 hands-on projects)
```bash
# Lab 1: Build a file explorer
python labs/lab01_recursive_file_explorer.py

# Lab 2: Generate navigation menus
python labs/lab02_recursive_menu_generator.py

# Lab 3: Process organization hierarchy
python labs/lab03_recursive_tree_traversal.py
```

**Skills developed**: Real coding, problem-solving, performance optimization

---

## 🎯 Choose Your Track

### Track 1: Fast (8 hours)
**Goal**: Understand recursion basics and common algorithms

```bash
# Day 1
python src/01_intro_to_recursion.py
python src/02_recursive_thinking.py
python src/03_base_and_recursive_case.py

# Day 2
python src/05_factorial.py
python src/06_fibonacci.py
python src/17_memoized_fibonacci.py

# Interview prep
Read README.md - Interview Questions section
```

**Outcome**: Interview-ready for basic recursion questions

---

### Track 2: Standard (15 hours)
**Goal**: Master recursion with real-world applications

```bash
# Run all modules 1-13
for i in {01..13}; do
    echo "Running module $i..."
    python "src/${i}_"*.py
    echo "Press Enter to continue..."
    read
done

# Complete labs 1-2
python labs/lab01_recursive_file_explorer.py
python labs/lab02_recursive_menu_generator.py
```

**Outcome**: Can solve most recursion interview questions

---

### Track 3: Complete (25 hours)
**Goal**: Become recursion expert with all topics

```bash
# Run all 18 modules
for i in {01..18}; do
    echo "Running module $i..."
    python "src/${i}_"*.py
done

# Complete all 3 labs
for i in {01..03}; do
    python "labs/lab${i}_"*.py
done
```

**Outcome**: Can solve any recursion problem, teach others

---

### Track 4: Mastery (40 hours)
**Goal**: Deep expertise with challenges and extensions

```bash
# All modules and labs (as above)
# Plus challenge exercises from each module
# Plus extension exercises from labs
```

**Outcome**: Can design recursive systems, optimize production code

---

## 📖 Reading Materials

### Essential Reading (Start Here!)
1. **README.md** - Project overview and fundamentals
2. **EXECUTION_GUIDE.md** - How to run everything
3. **This file** - You're reading it!

### Reference Materials
- **INDEX.md** - Complete module reference
- **VERIFICATION.md** - Project completion checklist

### During Learning
- Read docstrings in each module
- Study ASCII diagrams
- Review interview questions

---

## ❓ Common Questions

### Q: Do I need to install anything?
**A**: No! Python standard library is all you need. Just run the Python files.

### Q: What Python version do I need?
**A**: Python 3.12+ recommended (3.11+ will work). Check: `python --version`

### Q: How long will this take?
**A**: 
- Fast track: 8 hours
- Standard: 15 hours
- Complete: 25 hours
- Mastery: 40 hours

### Q: Should I run modules in order?
**A**: Yes! Each module builds on previous concepts. Don't skip ahead.

### Q: What if I don't understand something?
**A**: 
1. Re-read the module
2. Study the ASCII diagrams
3. Run it in Python Tutor (visualize recursion)
4. Check interview questions
5. Try the hands-on exercises

### Q: Are there solutions to the labs?
**A**: Lab code includes complete implementations. Study and modify them.

### Q: Can I use this for teaching?
**A**: Yes! This project is designed for teaching. Each module is self-contained.

---

## 💡 Study Tips

### Tip 1: Run, Read, Modify
```bash
# Run the module
python src/05_factorial.py

# Read the output carefully
# Modify the code to explore

# Example: Change factorial(5) to factorial(10)
# See how call stack grows
```

### Tip 2: Draw Call Stacks
```
Paper and pencil help!

factorial(5)
├── factorial(4)
│   ├── factorial(3)
│   │   └── factorial(2)
│   │       └── factorial(1)
│   │           └── factorial(0) → 1
│   │       └── 2 * 1 = 2
│   │   └── 3 * 2 = 6
│   └── 4 * 6 = 24
└── 5 * 24 = 120
```

### Tip 3: Answer Interview Questions
```bash
After each module, answer the 5 interview questions
Write answers down
Compare with module explanations
Refine your understanding
```

### Tip 4: Modify and Experiment
```bash
# After understanding a module:
# 1. Change input values
# 2. Modify algorithms
# 3. Add new features
# 4. Test edge cases
# 5. Measure performance
```

### Tip 5: Teach Someone Else
```bash
# Best way to learn: teach others
# Explain each concept out loud
# Answer hypothetical questions
# Help someone with their recursion questions
```

---

## 🎓 What You'll Know After This Project

### Week 1
- What recursion is and why it works
- Base case and recursive case patterns
- How call stack works
- Simple recursion examples
- When to use recursion vs iteration

### Week 2
- 15+ recursion algorithms
- Performance optimization techniques
- Memoization and caching
- Real-world applications
- Tree and graph traversal

### Week 3
- Enterprise recursion patterns
- Error handling and limits
- Production code writing
- Technical interview excellence
- Can teach others

---

## 🏆 Success Checklist

### Basic Competency
- [ ] Run all modules without errors
- [ ] Understand call stack concept
- [ ] Know base case vs recursive case
- [ ] Can explain recursion to others

### Intermediate Competency
- [ ] Can write recursive functions
- [ ] Understand time/space complexity
- [ ] Know optimization techniques
- [ ] Can solve moderate recursion problems

### Advanced Competency
- [ ] Can design recursive solutions
- [ ] Can optimize performance
- [ ] Handle edge cases and errors
- [ ] Can solve complex recursion problems
- [ ] Can teach and mentor others

---

## 🔧 Troubleshooting

### Module won't run
```bash
# Check Python version
python --version

# Check file exists
ls src/05_factorial.py

# Try running with verbose
python -v src/05_factorial.py
```

### Import errors
```bash
# Check you're in correct directory
pwd
cd "Recursion_and_Recursive_Functions"

# Check Python path
python -c "import sys; print(sys.path)"
```

### RecursionError
```bash
# Expected in some examples!
# Shows what happens at recursion limit
# Shows how to handle errors
# Read the error message carefully
```

### File not found
```bash
# Correct directory structure required:
# Recursion_and_Recursive_Functions/
# ├── src/
# ├── labs/
# ├── common/
# └── README.md
```

---

## 📞 Getting Help

### If Stuck:
1. **Read the module docstring** - explains the concept
2. **Check the comments** - WHY not WHAT
3. **Look at the ASCII diagram** - visualizes the process
4. **Review interview questions** - tests understanding
5. **Try hands-on exercise** - learn by doing
6. **Read best practices** - common patterns
7. **Check debugging tips** - how to debug

### Online Resources:
- **Python Tutor**: visualize recursion execution
- **LeetCode**: practice recursion problems
- **HackerRank**: guided recursion tutorials
- **GeeksforGeeks**: recursion reference

---

## ⏰ Time Management

### 30-Minute Session
```bash
1. Run one module (5 min)
2. Read output carefully (10 min)
3. Answer one interview question (10 min)
4. Modify and experiment (5 min)
```

### 1-Hour Session
```bash
1. Run one module (5 min)
2. Read and understand (20 min)
3. Answer all 5 interview questions (20 min)
4. Try hands-on exercise (15 min)
```

### 2-Hour Session
```bash
1. Run and understand one module (30 min)
2. Solve interview questions (30 min)
3. Complete hands-on exercise (30 min)
4. Modify code and experiment (30 min)
```

### Full Day (8 hours)
```bash
1. Morning: 2-3 modules (4 hours)
2. Afternoon: Labs or challenges (4 hours)
3. Evening: Review and practice (optional)
```

---

## 🎯 Your First 5 Steps

### Step 1: Verify Environment
```bash
python --version
# Should show 3.12+ (or 3.11+)
```

### Step 2: Navigate to Project
```bash
cd "d:\Kiran\Open text\Day 2\Sec 4 - Recursion and Recursive Functions"
```

### Step 3: Run First Module
```bash
python src/01_intro_to_recursion.py
```

### Step 4: Read README
```bash
# Open README.md and skim it
# Understand project structure
# See learning objectives
```

### Step 5: Run Second Module
```bash
python src/02_recursive_thinking.py
```

---

## 🚀 Ready to Start?

```bash
# Execute this command now:
python src/01_intro_to_recursion.py
```

### Expected Output:
✓ Welcome message  
✓ Recursion explanation  
✓ Folder traversal demonstration  
✓ Call stack visualization  
✓ Interview questions  

### Next Command:
```bash
python src/02_recursive_thinking.py
```

---

## 📊 Progress Tracking

### Module Completion Log
```
Day 1:
  [ ] 01_intro_to_recursion.py
  [ ] 02_recursive_thinking.py
  [ ] 03_base_and_recursive_case.py
  [ ] 04_call_stack_demo.py

Day 2:
  [ ] 05_factorial.py
  [ ] 06_fibonacci.py
  [ ] 07_power_function.py
  [ ] 08_reverse_string.py
  ... (continue for all 18 modules)
```

---

## ✅ Final Checklist Before Starting

- [ ] Python 3.12+ installed
- [ ] Correct directory location
- [ ] README.md reviewed
- [ ] First module ready to run
- [ ] Understanding what recursion is
- [ ] Ready to invest 8-40 hours

---

**You're all set! Start with:**
```bash
python src/01_intro_to_recursion.py
```

**Then follow the recommended learning path above. Good luck! 🎉**
