# Python Recursion and Recursive Functions - Complete Index

## Project Overview

**Comprehensive Python learning project covering recursion through 18 enterprise-focused modules + 3 hands-on labs**

- **Total Modules**: 21 (18 tutorials + 3 labs)
- **Total Lines of Code**: 3,500+
- **Interview Questions**: 90+ (5 per module)
- **Learning Hours**: 8-40 hours (depending on track)
- **Python Version**: 3.12+
- **Prerequisites**: Basic Python knowledge

---

## Complete File Structure

```
Recursion_and_Recursive_Functions/
│
├── README.md                               ← Start here!
├── EXECUTION_GUIDE.md                      ← Run instructions
├── requirements.txt                        ← Python dependencies
│
├── src/                                    ← 18 Learning Modules
│   ├── 01_intro_to_recursion.py
│   ├── 02_recursive_thinking.py
│   ├── 03_base_and_recursive_case.py
│   ├── 04_call_stack_demo.py
│   ├── 05_factorial.py
│   ├── 06_fibonacci.py
│   ├── 07_power_function.py
│   ├── 08_reverse_string.py
│   ├── 09_gcd_algorithm.py
│   ├── 10_recursive_sum.py
│   ├── 11_binary_search.py
│   ├── 12_directory_traversal.py
│   ├── 13_tree_traversal.py
│   ├── 14_recursion_depth.py
│   ├── 15_recursion_limit_demo.py
│   ├── 16_recursion_error_demo.py
│   ├── 17_memoized_fibonacci.py
│   └── 18_recursive_configuration_loader.py
│
├── labs/                                   ← 3 Hands-On Labs
│   ├── lab01_recursive_file_explorer.py
│   ├── lab02_recursive_menu_generator.py
│   └── lab03_recursive_tree_traversal.py
│
└── common/                                 ← Shared Utilities
    ├── __init__.py
    ├── logger.py
    ├── utilities.py
    └── timer.py
```

---

## Module Directory

### PHASE 1: FOUNDATIONS (4 modules - 1.5 hours)

#### 01_intro_to_recursion.py
**Concept**: Introduction to Recursion  
**Business**: Corporate Folder Hierarchy  
**Topics**: Recursive thinking, when recursion is useful, call stack basics  
**Complexity**: Beginner  
**Run**: `python src/01_intro_to_recursion.py`

**Key Learning**:
- What is recursion
- Why recursion works
- Recursive vs iterative
- Call stack visualization
- Problem decomposition

---

#### 02_recursive_thinking.py
**Concept**: Problem Decomposition  
**Business**: E-Commerce Product Categories  
**Topics**: Breaking problems into recursive and base cases  
**Complexity**: Beginner  
**Run**: `python src/02_recursive_thinking.py`

**Key Learning**:
- Identifying recursive structures
- Natural decomposition
- Base case recognition
- Progress toward base case
- Recursive problem templates

---

#### 03_base_and_recursive_case.py
**Concept**: Base Case and Recursive Case  
**Business**: Document Approval Workflow  
**Topics**: Multiple base cases, conditions for stopping  
**Complexity**: Intermediate  
**Run**: `python src/03_base_and_recursive_case.py`

**Key Learning**:
- Multiple base cases
- Checking all conditions
- Preventing missing cases
- Progress toward termination
- Error patterns

---

#### 04_call_stack_demo.py
**Concept**: Call Stack and Stack Frames  
**Business**: Support Ticket Escalation  
**Topics**: Frame creation/destruction, depth monitoring  
**Complexity**: Intermediate  
**Run**: `python src/04_call_stack_demo.py`

**Key Learning**:
- What is a stack frame
- LIFO principle
- Recursion depth limits
- Memory usage
- RecursionError handling

---

### PHASE 2: CLASSIC ALGORITHMS (6 modules - 2 hours)

#### 05_factorial.py
**Concept**: Factorial Recursion  
**Business**: Workflow Combination Calculator  
**Topics**: Classic recursion, simple base/recursive cases  
**Complexity**: Beginner  
**Run**: `python src/05_factorial.py`

**Key Learning**:
- n! = n × (n-1)!
- Recursive definition
- Time/Space complexity: O(n)
- Factorial properties
- Permutations and combinations

---

#### 06_fibonacci.py
**Concept**: Naive vs Optimized Recursion  
**Business**: Revenue Growth Forecast  
**Topics**: Overlapping subproblems, memoization, optimization  
**Complexity**: Advanced  
**Run**: `python src/06_fibonacci.py`

**Key Learning**:
- Naive recursion: O(2^n)
- Overlapping subproblems
- Memoization technique
- Performance comparison
- Dynamic programming intro
- fib(50): 40 billion → 50 calls

---

#### 07_power_function.py
**Concept**: Power Recursion with Divide-and-Conquer  
**Business**: System Capacity Growth  
**Topics**: Logarithmic complexity, optimization  
**Complexity**: Intermediate  
**Run**: `python src/07_power_function.py`

**Key Learning**:
- Naive: O(n) recursion
- Optimized: O(log n)
- Divide-and-conquer strategy
- Even/odd exponent handling
- Real-world applications

---

#### 08_reverse_string.py
**Concept**: String Reversal  
**Business**: Transaction ID Reversal  
**Topics**: Simple recursion, index-based processing  
**Complexity**: Beginner  
**Run**: `python src/08_reverse_string.py`

**Key Learning**:
- Reversing with recursion
- Index-based recursion
- Recursive vs iterative
- String operations
- When to use each approach

---

#### 09_gcd_algorithm.py
**Concept**: Euclidean Algorithm  
**Business**: Manufacturing Batch Optimization  
**Topics**: Mathematical recursion, elegance  
**Complexity**: Intermediate  
**Run**: `python src/09_gcd_algorithm.py`

**Key Learning**:
- GCD definition
- Euclidean algorithm
- Time: O(log(min(a,b)))
- Mathematical elegance
- Real-world applications

---

#### 10_recursive_sum.py
**Concept**: Recursive Aggregation  
**Business**: Sales Hierarchy Processing  
**Topics**: Aggregating results from recursive calls  
**Complexity**: Intermediate  
**Run**: `python src/10_recursive_sum.py`

**Key Learning**:
- Recursive aggregation
- Accumulating results
- Hierarchical data processing
- Business metrics
- Organizational reporting

---

### PHASE 3: REAL-WORLD APPLICATIONS (4 modules - 2 hours)

#### 11_binary_search.py
**Concept**: Binary Search with Divide-and-Conquer  
**Business**: Customer Database Lookup  
**Topics**: Search algorithms, logarithmic complexity  
**Complexity**: Intermediate  
**Run**: `python src/11_binary_search.py`

**Key Learning**:
- Binary search O(log n)
- Divide-and-conquer strategy
- Search algorithm efficiency
- Linear vs logarithmic comparison
- Enterprise search patterns

---

#### 12_directory_traversal.py
**Concept**: File System Traversal  
**Business**: Enterprise Backup Utility  
**Topics**: Real file system operations, error handling  
**Complexity**: Intermediate  
**Run**: `python src/12_directory_traversal.py`

**Key Learning**:
- Traversing file hierarchies
- Permission handling
- Size calculations
- Practical recursion
- Error management

---

#### 13_tree_traversal.py
**Concept**: Tree Traversal Methods  
**Business**: Organization Structure Processing  
**Topics**: Preorder, inorder, postorder, level-order  
**Complexity**: Advanced  
**Run**: `python src/13_tree_traversal.py`

**Key Learning**:
- Preorder: parent first
- Inorder: left-center-right
- Postorder: children first
- Level-order (BFS)
- When to use each

---

#### 14_recursion_depth.py
**Concept**: Monitoring Recursion Depth  
**Business**: Large Repository Analysis  
**Topics**: Depth tracking, safety monitoring  
**Complexity**: Intermediate  
**Run**: `python src/14_recursion_depth.py`

**Key Learning**:
- Tracking depth parameter
- Recursion limit: default 1000
- Safe usage guidelines
- Depth monitoring
- Prevention strategies

---

### PHASE 4: ADVANCED TOPICS (4 modules - 2 hours)

#### 15_recursion_limit_demo.py
**Concept**: System Recursion Limits  
**Business**: Large Knowledge Repository  
**Topics**: Changing limits, risks, alternatives  
**Complexity**: Advanced  
**Run**: `python src/15_recursion_limit_demo.py`

**Key Learning**:
- sys.getrecursionlimit()
- sys.setrecursionlimit()
- When to increase limit
- Risks and trade-offs
- Best practices

---

#### 16_recursion_error_demo.py
**Concept**: RecursionError Handling  
**Business**: Configuration Parser  
**Topics**: Error handling, debugging, prevention  
**Complexity**: Advanced  
**Run**: `python src/16_recursion_error_demo.py`

**Key Learning**:
- Missing base case error
- Wrong progress error
- Catching RecursionError
- Debugging techniques
- Prevention strategies

---

#### 17_memoized_fibonacci.py
**Concept**: Memoization and Optimization  
**Business**: Financial Forecasting  
**Topics**: @lru_cache, caching, performance optimization  
**Complexity**: Advanced  
**Run**: `python src/17_memoized_fibonacci.py`

**Key Learning**:
- @lru_cache decorator
- Manual memoization
- Performance impact: 2^50 → linear
- Cache statistics
- When to use memoization

---

#### 18_recursive_configuration_loader.py
**Concept**: Enterprise Recursive Pattern  
**Business**: Configuration Management  
**Topics**: Recursive validation, transformation, processing  
**Complexity**: Advanced  
**Run**: `python src/18_recursive_configuration_loader.py`

**Key Learning**:
- Recursive validation
- Configuration transformation
- Tree structure processing
- Real-world patterns
- Error handling

---

### LABS (3 hands-on exercises - 3 hours)

#### lab01_recursive_file_explorer.py
**Task**: Build a file explorer  
**Difficulty**: Intermediate  
**Time**: 45 minutes  
**Skills**: File system recursion, statistics, reporting  

**Requirements**:
- Traverse directories recursively
- Count files and folders
- Calculate total size
- Display hierarchy
- Generate summary report

---

#### lab02_recursive_menu_generator.py
**Task**: Generate navigation menus from nested dictionaries  
**Difficulty**: Intermediate  
**Time**: 45 minutes  
**Skills**: Data transformation, tree building, output formatting  

**Requirements**:
- Build menu tree from dict
- Support unlimited depth
- Display with indentation
- Generate HTML
- Handle menu states

---

#### lab03_recursive_tree_traversal.py
**Task**: Build and traverse organization hierarchy  
**Difficulty**: Advanced  
**Time**: 60 minutes  
**Skills**: Tree operations, metrics calculation, reporting  

**Requirements**:
- Represent employees hierarchically
- Implement multiple traversals
- Calculate team metrics
- Find reporting chains
- Generate org reports

---

## Quick Reference

### Running the Project

**See all available modules:**
```bash
ls -la src/
```

**Run one module:**
```bash
python src/05_factorial.py
```

**Run all modules in sequence:**
```bash
for i in {01..18}; do
    echo "Running module $i..."
    python "src/${i}_"*.py
done
```

**Run all labs:**
```bash
for i in {01..03}; do
    python "labs/lab${i}_"*.py
done
```

---

## Concepts Covered

### Core Concepts (100% coverage)
- [x] Recursion definition and use cases
- [x] Base case and recursive case
- [x] Call stack and frames
- [x] Stack overflow and limits
- [x] Time and space complexity
- [x] Divide-and-conquer algorithms
- [x] Memoization and optimization
- [x] Recursion vs iteration
- [x] Error handling
- [x] Debugging techniques

### Algorithms Implemented (15+)
- [x] Factorial
- [x] Fibonacci (naive and optimized)
- [x] Power function
- [x] String reversal
- [x] GCD (Euclidean algorithm)
- [x] Recursive sum
- [x] Binary search
- [x] Directory traversal
- [x] Tree traversal (3 types)
- [x] Configuration loading
- [x] Menu generation
- [x] File explorer
- [x] Organization hierarchy

### Real-World Applications (12+)
- [x] Corporate folder hierarchies
- [x] E-commerce categories
- [x] Document approval workflows
- [x] Support ticket escalation
- [x] Workflow path calculation
- [x] Revenue forecasting
- [x] System capacity growth
- [x] Transaction ID reversal
- [x] Manufacturing optimization
- [x] Sales aggregation
- [x] Customer database search
- [x] Enterprise backup
- [x] Configuration management

### Business Scenarios (12+)
- [x] Banking
- [x] E-commerce
- [x] HR/Organization
- [x] Manufacturing
- [x] Cloud Infrastructure
- [x] File Management
- [x] Data Analysis
- [x] Financial Forecasting
- [x] Configuration Management
- [x] Navigation/UI
- [x] Document Management
- [x] Enterprise Systems

---

## Learning Progression

### Level 1: Absolute Beginner
Start with modules 1-3, run them, understand the output

### Level 2: Beginner
Complete modules 1-10, answer interview questions

### Level 3: Intermediate
Complete modules 1-14, do labs 1-2, optimize solutions

### Level 4: Advanced
Complete all 18 modules, complete all 3 labs, implement challenges

### Level 5: Expert
Teach others, review production code using recursion, mentor

---

## Interview Preparation

**Total Interview Questions**: 90+ (5 per module)

**Topics Covered**:
- Explain recursion in one sentence
- Base vs recursive case
- Call stack explanation
- When to use recursion
- Time/space complexity
- Optimization techniques
- Error handling
- Real-world applications
- Design decisions
- Trade-offs

**Practice Path**:
1. Read all interview questions (15 min)
2. Answer without looking at module (30 min)
3. Check answers (15 min)
4. Review explanations (30 min)

---

## Performance Benchmarks

### Optimization Examples from Project

| Problem | Naive | Optimized | Speedup |
|---------|-------|-----------|---------|
| Fibonacci(50) | 40 billion calls | 50 calls | 800M x |
| Power(2,100) | 100 calls | 7 calls | 14x |
| Binary search (1M items) | 1M comparisons | 20 comparisons | 50K x |
| Directory (10K files) | Linear scan | Recursive | Same O(n), cleaner |

---

## Time Estimates

| Track | Duration | Modules | Labs | Deep Dive |
|-------|----------|---------|------|-----------|
| Fast | 8 hours | 1-6, 17 | None | Interview Q only |
| Standard | 15 hours | 1-13 | 1-2 | Full coverage |
| Complete | 25 hours | 1-18 | 1-3 | + challenges |
| Mastery | 40 hours | 1-18 | 1-3 | + extensions |

---

## What You'll Learn

### Knowledge
- Deep understanding of recursion
- When and why to use recursion
- How call stack works
- Complexity analysis
- Optimization techniques
- Real-world patterns
- Enterprise applications

### Skills
- Write correct recursive functions
- Design recursive solutions
- Optimize recursion
- Handle edge cases
- Debug recursion problems
- Implement in production

### Career
- Ace technical interviews
- Write better code
- Understand algorithms
- Design scalable solutions
- Lead technical discussions

---

## Success Criteria

### Module Understanding
✓ Can explain each concept in simple terms  
✓ Can run and modify each module  
✓ Can answer all 5 interview questions  
✓ Can identify real-world applications  

### Lab Completion
✓ Can build solution from scratch  
✓ Can implement all requirements  
✓ Can handle error cases  
✓ Can optimize performance  

### Interview Ready
✓ Can explain recursion clearly  
✓ Can solve recursion problems  
✓ Can analyze complexity  
✓ Can optimize solutions  
✓ Can discuss trade-offs  

---

## Next Steps After Completion

### Immediate (Week 1)
1. Review all interview questions
2. Solve challenge exercises in each module
3. Practice explaining concepts aloud
4. Write own recursion examples

### Short Term (Month 1)
1. Solve LeetCode recursion problems
2. Study backtracking algorithms
3. Learn dynamic programming
4. Review production code using recursion

### Long Term (Ongoing)
1. Master advanced algorithms
2. Learn graph algorithms
3. Study distributed systems
4. Contribute to open source

---

## Resources Included

- ✅ 18 comprehensive tutorials
- ✅ 3 hands-on labs
- ✅ 90+ interview questions
- ✅ Call stack visualizations
- ✅ Performance comparisons
- ✅ Business scenarios
- ✅ Production patterns
- ✅ Best practices guide
- ✅ Error handling examples
- ✅ Debugging techniques
- ✅ Common utilities library
- ✅ Execution guide
- ✅ Complete documentation

---

## Project Statistics

| Metric | Count |
|--------|-------|
| Total Modules | 21 |
| Lines of Code | 3,500+ |
| Interview Questions | 90+ |
| Business Scenarios | 12+ |
| Algorithms Implemented | 15+ |
| Real-World Applications | 12+ |
| Visualizations | 10+ |
| Challenge Exercises | 20+ |
| Learning Hours (std) | 15-25 |
| Time to Interview Ready | 1-2 weeks |

---

## Support & Troubleshooting

### Common Issues

**Q: Module won't run**  
A: Check Python 3.12+, verify file permissions, check from correct directory

**Q: RecursionError during execution**  
A: Expected in some examples! Shows what happens at limit, how to handle it

**Q: Can't understand a concept**  
A: Re-read module, check visualization, answer interview questions, try lab

---

## Credits

**Developed by**: Enterprise Python Training Team  
**Python Version**: 3.12+  
**Last Updated**: 2024  
**Status**: Complete and Production Ready  

---

## License

Educational content. Free for learning, training, and personal development.

---

**Ready to Master Recursion? Start with `python src/01_intro_to_recursion.py` 🚀**
