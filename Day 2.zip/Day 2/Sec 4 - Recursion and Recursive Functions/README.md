# Recursion and Recursive Functions in Enterprise Python

## Project Overview

This comprehensive project teaches **Python Recursion and Recursive Functions** using realistic enterprise business scenarios. Unlike academic examples, every module demonstrates how recursion solves real-world problems in banking, healthcare, inventory management, and cloud infrastructure.

**Target Audience:** Intermediate Python developers preparing for senior engineer roles or technical interviews.

**Duration:** 6-8 weeks of study (self-paced)

**Difficulty Level:** Intermediate to Advanced

---

## Learning Objectives

By completing this project, you will:

- ✅ Understand recursive thinking and problem decomposition
- ✅ Master base cases and recursive cases
- ✅ Analyze call stacks and stack frames
- ✅ Implement recursion in 15+ real-world scenarios
- ✅ Optimize recursion using memoization and tail recursion
- ✅ Handle recursion limits and RecursionError exceptions
- ✅ Compare recursion vs iteration performance
- ✅ Design solutions for tree traversal and graph processing
- ✅ Apply divide-and-conquer algorithms
- ✅ Write production-quality recursive code

---

## Prerequisites

- **Python 3.12+** (Python 3.11+ minimum)
- VS Code with Python extension
- Basic understanding of functions and control flow
- Familiarity with data structures (lists, dictionaries, trees)
- Command-line experience

---

## Project Structure

```
Recursion_and_Recursive_Functions/
│
├── README.md                              # This file
├── requirements.txt                       # Python dependencies (stdlib only)
│
├── src/                                   # Core learning modules
│   ├── 01_intro_to_recursion.py          # Introduction and recursive thinking
│   ├── 02_recursive_thinking.py          # Problem decomposition
│   ├── 03_base_and_recursive_case.py     # Base & recursive cases
│   ├── 04_call_stack_demo.py             # Stack frames and call stacks
│   ├── 05_factorial.py                   # Factorial recursion
│   ├── 06_fibonacci.py                   # Naive vs optimized fibonacci
│   ├── 07_power_function.py              # Exponentiation
│   ├── 08_reverse_string.py              # String reversal
│   ├── 09_gcd_algorithm.py               # Greatest common divisor
│   ├── 10_recursive_sum.py               # Aggregation patterns
│   ├── 11_binary_search.py               # Divide-and-conquer
│   ├── 12_directory_traversal.py         # File system traversal
│   ├── 13_tree_traversal.py              # Tree processing
│   ├── 14_recursion_depth.py             # Depth tracking
│   ├── 15_recursion_limit_demo.py        # System limits
│   ├── 16_recursion_error_demo.py        # Error handling
│   ├── 17_memoized_fibonacci.py          # Performance optimization
│   └── 18_recursive_configuration_loader.py  # Enterprise pattern
│
├── labs/                                  # Hands-on lab exercises
│   ├── lab01_recursive_file_explorer.py  # Build a file explorer
│   ├── lab02_recursive_menu_generator.py # Generate navigation menus
│   └── lab03_recursive_tree_traversal.py # Organization hierarchy
│
└── common/                                # Shared utilities
    ├── __init__.py
    ├── logger.py                         # Logging utilities
    ├── utilities.py                      # Helper functions
    └── timer.py                          # Performance measurement
```

---

## Python Version & Dependencies

**Python Version:** 3.12+ (tested on 3.11+)

**Dependencies:** Python Standard Library only
- `functools` - Memoization and cache decorators
- `os` / `pathlib` - File system operations
- `time` - Performance measurement
- `typing` - Type hints
- `collections` - Data structures
- `dataclasses` - Data classes
- `json` - Configuration parsing
- `sys` - System utilities
- `logging` - Structured logging

No third-party packages required.

---

## VS Code Setup

### 1. Install Python Extension
```bash
# Search for "Python" in VS Code extensions
# Install by Microsoft (ms-python.python)
```

### 2. Select Python Interpreter
```
Cmd/Ctrl + Shift + P → Python: Select Interpreter → Choose 3.12+
```

### 3. Create Virtual Environment (Optional but Recommended)
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate
```

### 4. Open Project in VS Code
```bash
cd "Recursion_and_Recursive_Functions"
code .
```

---

## How to Run

### Run a Single Module
```bash
# From project root
python src/01_intro_to_recursion.py
```

### Run All Modules in Sequence
```bash
# Execute in learning order
python src/01_intro_to_recursion.py
python src/02_recursive_thinking.py
# ... continue through all modules
```

### Run Labs
```bash
python labs/lab01_recursive_file_explorer.py
python labs/lab02_recursive_menu_generator.py
python labs/lab03_recursive_tree_traversal.py
```

### VS Code Keyboard Shortcut
```
Alt + Ctrl + N  →  Run current file
Ctrl + Shift + P  →  Python: Run Selection/Line
```

---

## Recommended Learning Path

### Week 1: Foundations (Days 1-2)
- `01_intro_to_recursion.py` - Understand recursion basics
- `02_recursive_thinking.py` - Learn decomposition
- `03_base_and_recursive_case.py` - Master base/recursive cases
- `04_call_stack_demo.py` - Visualize call stacks

### Week 2: Simple Algorithms (Days 3-4)
- `05_factorial.py` - Classic factorial
- `06_fibonacci.py` - Sequence generation
- `07_power_function.py` - Exponentiation
- `08_reverse_string.py` - String operations

### Week 3: Mathematical Algorithms (Day 5)
- `09_gcd_algorithm.py` - GCD algorithm
- `10_recursive_sum.py` - Aggregation
- `11_binary_search.py` - Divide-and-conquer

### Week 4: Real-World Applications (Day 6-7)
- `12_directory_traversal.py` - File systems
- `13_tree_traversal.py` - Tree processing
- `14_recursion_depth.py` - Depth analysis

### Week 5: Advanced Topics (Day 8)
- `15_recursion_limit_demo.py` - System limits
- `16_recursion_error_demo.py` - Error handling
- `17_memoized_fibonacci.py` - Optimization

### Week 6: Enterprise Patterns (Day 9)
- `18_recursive_configuration_loader.py` - Configuration parsing

### Week 7: Labs (Days 10-12)
- `lab01_recursive_file_explorer.py` - File exploration
- `lab02_recursive_menu_generator.py` - Menu generation
- `lab03_recursive_tree_traversal.py` - Organization hierarchy

---

## Recursion Flow Diagram

### General Recursion Pattern

```
INPUT
  │
  ├─→ [BASE CASE CHECK]
  │   │
  │   ├─→ YES → RETURN BASE VALUE
  │   │
  │   └─→ NO
  │       │
  │       └─→ [RECURSIVE CASE]
  │           │
  │           ├─→ Modify input (reduce problem size)
  │           ├─→ Call function recursively
  │           ├─→ Receive recursive result
  │           ├─→ Process result
  │           └─→ RETURN processed result
  │
  └─→ OUTPUT
```

### Call Stack Illustration

```
Main Program Flow:
  main()
    │
    └─→ factorial(5)                    ← Stack Frame 1
        │
        └─→ factorial(4)                ← Stack Frame 2
            │
            └─→ factorial(3)            ← Stack Frame 3
                │
                └─→ factorial(2)        ← Stack Frame 4
                    │
                    └─→ factorial(1)    ← Stack Frame 5 (BASE CASE)
                        │
                        └─→ return 1
                    │
                    └─→ return 2 * 1 = 2
                │
                └─→ return 3 * 2 = 6
            │
            └─→ return 4 * 6 = 24
        │
        └─→ return 5 * 24 = 120
    │
    └─→ print(120)
```

---

## Comparison: Recursion vs Iteration

| Aspect | Recursion | Iteration |
|--------|-----------|-----------|
| **Code Clarity** | More elegant for tree/graph problems | Better for simple loops |
| **Space Complexity** | O(n) call stack overhead | O(1) typically |
| **Time Complexity** | Same as iteration (if memoized) | Baseline |
| **Stack Overflow Risk** | Yes (need recursion limit) | No |
| **Debugging** | Complex (deep stack traces) | Easier to follow |
| **Problem Fit** | Trees, graphs, backtracking | Sequential, linear tasks |
| **Performance** | Slower without optimization | Faster baseline |
| **Readability** | High (for domain experts) | High (for everyone) |
| **Tail Recursion** | Not optimized in Python | N/A |

---

## Recursion Advantages

✅ **Natural Problem Decomposition** - Matches mathematical definitions

✅ **Elegant Code** - Less boilerplate for trees/graphs

✅ **Divide-and-Conquer** - Scales complex problems

✅ **Tree/Graph Friendly** - Perfect for hierarchical data

✅ **Backtracking Support** - Natural for search problems

✅ **Mathematical Elegance** - Direct formula implementation

---

## Recursion Limitations

❌ **Stack Overflow Risk** - Limited recursion depth

❌ **Performance Overhead** - Function call costs

❌ **Debugging Difficulty** - Deep stack traces

❌ **Memory Usage** - O(n) stack space

❌ **No Tail Recursion Optimization** - Python doesn't optimize

❌ **Not Suitable for Simple Loops** - Overkill for sequential iteration

---

## Performance Considerations

### Naive Recursion Problems
```
Fibonacci(50) with naive recursion: ~56 seconds
Fibonacci(50) with memoization: <1 millisecond
```

### When to Use Recursion
- ✅ Tree/graph traversal
- ✅ Backtracking algorithms
- ✅ Divide-and-conquer
- ✅ Depth-first search
- ✅ Binary search
- ✅ Directory/file processing

### When to Avoid Recursion
- ❌ Simple loops
- ❌ Very large datasets
- ❌ Performance-critical code
- ❌ Embedded systems (limited stack)
- ❌ Real-time systems

---

## Memoization Benefits

**Memoization** - Cache function results to avoid recomputation

### Performance Impact
```python
# Naive Recursion: O(2^n)
fibonacci(35) → 29,860,703 function calls → ~5 seconds

# Memoized Recursion: O(n)
fibonacci(35) → 35 function calls → <1 millisecond
```

### Key Decorator
```python
from functools import lru_cache

@lru_cache(maxsize=None)
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)
```

---

## Best Practices

### ✅ DO:

1. **Always define a base case** - Prevent infinite recursion
2. **Ensure progress toward base case** - Each call should move closer
3. **Keep recursive case simple** - Easier to understand and debug
4. **Use type hints** - Document expected inputs/outputs
5. **Add docstrings** - Explain recursion strategy
6. **Test edge cases** - Empty inputs, single elements, large inputs
7. **Consider memoization** - Optimize overlapping subproblems
8. **Monitor recursion depth** - Use `sys.getrecursionlimit()`
9. **Comment decision points** - Why this is the base case
10. **Profile performance** - Verify recursion is appropriate

### ❌ DON'T:

1. **Forget the base case** - Causes infinite recursion
2. **Make recursive case complex** - Reduces clarity
3. **Use recursion for simple loops** - Unnecessary overhead
4. **Ignore stack limits** - Can crash with deep recursion
5. **Over-optimize prematurely** - Clarity first, optimization second
6. **Create circular recursion** - A calls B calls A
7. **Assume Python optimizes tail calls** - It doesn't
8. **Ignore memoization opportunities** - Huge performance gains
9. **Skip error handling** - RecursionError can crash programs
10. **Use cryptic variable names** - `n`, `result`, `remainder` are better than `x`, `y`, `z`

---

## Common Mistakes

### ❌ Mistake 1: Missing Base Case
```python
# WRONG - Infinite recursion!
def countdown(n):
    print(n)
    countdown(n - 1)  # Never stops!

# CORRECT - Base case prevents infinite recursion
def countdown(n):
    if n == 0:  # BASE CASE
        return
    print(n)
    countdown(n - 1)  # RECURSIVE CASE
```

### ❌ Mistake 2: Incorrect Base Case Logic
```python
# WRONG - Base case never reached
def sum_list(items):
    if len(items) == 1:
        return items[0]
    return items[0] + sum_list(items[1:])  # Crashes on empty list

# CORRECT - Handle all terminating conditions
def sum_list(items):
    if not items:  # BASE CASE for empty list
        return 0
    if len(items) == 1:  # BASE CASE for single item
        return items[0]
    return items[0] + sum_list(items[1:])
```

### ❌ Mistake 3: Not Making Progress Toward Base Case
```python
# WRONG - Problem size never reduces
def recursive_func(n):
    if n == 0:
        return 1
    return recursive_func(n)  # Same n! Infinite recursion

# CORRECT - Reduce problem size
def recursive_func(n):
    if n == 0:
        return 1
    return recursive_func(n - 1)  # n decreases
```

### ❌ Mistake 4: Ignoring Stack Limits
```python
# WRONG - Deep recursion crashes
def process_large_list(items, index=0):
    if index >= len(items):
        return 0
    return items[index] + process_large_list(items, index + 1)

process_large_list(list(range(10000)))  # RecursionError!

# CORRECT - Check recursion limit or use iteration
import sys
def process_large_list(items, index=0, depth=0):
    if depth > sys.getrecursionlimit() - 100:
        raise ValueError("Recursion depth too deep")
    if index >= len(items):
        return 0
    return items[index] + process_large_list(items, index + 1, depth + 1)
```

### ❌ Mistake 5: Forgetting to Return Recursive Result
```python
# WRONG - Result lost
def multiply(a, b):
    if b == 0:
        return 0
    print(a + multiply(a, b - 1))  # Doesn't return!
    
# CORRECT - Return the result
def multiply(a, b):
    if b == 0:
        return 0
    return a + multiply(a, b - 1)
```

---

## Debugging Tips

### 1. Add Debug Print Statements
```python
def factorial(n, depth=0):
    print("  " * depth + f"→ factorial({n})")  # Entry
    
    if n <= 1:
        print("  " * depth + f"← return 1 (base case)")
        return 1
    
    result = n * factorial(n - 1, depth + 1)
    print("  " * depth + f"← return {result}")
    return result
```

### 2. Visualize Call Stack
```python
import sys
def trace_recursion(frame, event, arg):
    if event == 'call':
        print(f"Called: {frame.f_code.co_name}")
    return trace_recursion

sys.settrace(trace_recursion)
```

### 3. Check Recursion Depth
```python
import sys
def check_depth(func):
    def wrapper(*args, **kwargs):
        current_depth = len([f for f in sys._current_frames().values()])
        limit = sys.getrecursionlimit()
        if current_depth > limit * 0.9:
            raise RuntimeError(f"Recursion depth {current_depth} exceeds 90% of limit {limit}")
        return func(*args, **kwargs)
    return wrapper
```

### 4. Use try-except for RecursionError
```python
try:
    result = recursive_function(large_input)
except RecursionError as e:
    print(f"Recursion limit exceeded: {e}")
    # Fall back to iterative solution
```

### 5. Validate Base Case with Unit Tests
```python
def test_base_cases():
    assert factorial(0) == 1  # Edge case
    assert factorial(1) == 1  # Base case
    assert factorial(2) == 2  # First recursive call
```

---

## Interview Questions

### Q1: Explain Recursion in One Sentence
**Answer:** Recursion is a technique where a function calls itself to solve smaller instances of the same problem until reaching a base case.

### Q2: What's the Difference Between Base Case and Recursive Case?
**Answer:**
- **Base Case:** Terminating condition that stops recursion (e.g., `if n == 0`)
- **Recursive Case:** Problem decomposition that calls the function with a smaller input (e.g., `return n * factorial(n-1)`)

### Q3: How Do You Avoid Stack Overflow?
**Answer:**
- Define clear base case
- Ensure progress toward base case
- Check `sys.getrecursionlimit()`
- Use memoization to reduce calls
- Consider iterative alternative
- Use tail recursion pattern

### Q4: Explain Memoization and Its Benefits
**Answer:** Memoization caches function results to avoid recomputation. Python's `@lru_cache` decorator enables this. For Fibonacci, this reduces O(2^n) to O(n).

### Q5: When Should You Use Recursion vs Iteration?
**Answer:**
- **Recursion:** Trees, graphs, backtracking, elegant mathematical solutions
- **Iteration:** Loops, sequential processing, performance-critical code

---

## Hands-On Exercises

### Exercise 1: Implement Recursion
Modify a given iterative solution to use recursion:
```python
# Iterative version
def countdown(n):
    while n > 0:
        print(n)
        n -= 1

# Your turn: Convert to recursion
def countdown_recursive(n):
    # TODO: Implement recursively
    pass
```

### Exercise 2: Identify Base and Recursive Cases
For each function, write down:
- The base case
- The recursive case
- Why each case is necessary

### Exercise 3: Trace Execution
Draw the call stack for `factorial(4)`:
```
factorial(4)
├── factorial(3)
│   ├── factorial(2)
│   │   ├── factorial(1)
│   │   │   └── factorial(0) → BASE CASE
```

### Exercise 4: Debug Infinite Recursion
Fix the broken function:
```python
def sum_digits(n):
    if n < 10:
        return n
    return (n % 10) + sum_digits(n // 10)  # Find the bug!
```

---

## Challenge Exercises

### Challenge 1: Recursive Palindrome Checker
Write a recursive function to check if a string is a palindrome without using slicing shortcuts.

### Challenge 2: Recursive Power Set Generator
Generate all subsets of a list using recursion.

### Challenge 3: Recursive Maze Solver
Implement a recursive backtracking algorithm to solve a maze.

### Challenge 4: Recursive JSON Parser
Write a recursive parser for deeply nested JSON structures.

### Challenge 5: Recursive Merge Sort
Implement the merge sort algorithm using divide-and-conquer recursion.

---

## Additional Resources

### Books
- "Cracking the Coding Interview" - Chapter on Recursion
- "Introduction to Algorithms" (CLRS) - Recursion and Divide-and-Conquer
- "The Pragmatic Programmer" - Problem-solving techniques

### Online Resources
- **LeetCode:** Problems tagged "recursion"
- **HackerRank:** Recursion practice problems
- **VisuAlgo.net:** Algorithm visualization including recursion
- **Python Official Docs:** `functools.lru_cache` and recursion limits

### Tools
- **Python Tutor:** Visualize recursion execution step-by-step
- **VS Code Debugger:** Step through recursive calls
- **Memory Profiler:** Analyze stack usage

---

## Getting Help

### If a Module Fails:
1. Check Python version: `python --version`
2. Verify file permissions
3. Review error message carefully
4. Check module imports: `python -c "import functools; import pathlib"`
5. Enable debug logging

### Common Issues:

**Issue:** `RecursionError: maximum recursion depth exceeded`
- **Solution:** Check recursion limit, verify base case, use memoization

**Issue:** `ModuleNotFoundError: No module named 'src'`
- **Solution:** Ensure you're running from project root directory

**Issue:** `FileNotFoundError: [Errno 2] No such file or directory`
- **Solution:** Create sample directories for file traversal examples

---

## Author & Contribution

**Developed by:** Enterprise Python Training Team
**Python Version:** 3.12+
**Last Updated:** 2024

---

## License

This educational project is provided as-is for learning purposes.

---

## Next Steps

1. ✅ Clone/download this project
2. ✅ Setup Python 3.12+ environment
3. ✅ Open in VS Code
4. ✅ Start with `01_intro_to_recursion.py`
5. ✅ Complete modules in recommended order
6. ✅ Complete lab exercises
7. ✅ Review solutions and compare approaches
8. ✅ Practice challenge exercises
9. ✅ Refer to this README frequently
10. ✅ Share learnings with team

---

**Happy Coding! Master recursion and become a better software engineer. 🚀**
