"""
================================================================================
LAB 02: RECURSIVE MENU GENERATOR
================================================================================

Enterprise Lab: Generate application navigation menus from nested dictionaries

REQUIREMENTS
============
1. Support unlimited nesting depth
2. Display with proper indentation
3. Generate menu IDs automatically
4. Handle different menu types
5. Display with visual indicators

BUSINESS SCENARIO
================
A web application needs to generate navigation menus from configuration
where menus can have unlimited submenu depth.

TASKS
=====
1. Build menu tree from nested dictionary
2. Recursively display with indentation
3. Generate sequential menu IDs
4. Support menu icons/indicators
5. Handle active menu highlighting
"""

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class MenuItem:
    """Represents a menu item."""
    label: str
    url: str
    icon: str = "📌"
    children: List['MenuItem'] = None
    menu_id: int = 0

    def __post_init__(self):
        if self.children is None:
            self.children = []


class MenuGenerator:
    """Recursive menu generator."""

    def __init__(self):
        """Initialize menu generator."""
        self.menu_counter = 0

    def build_menu_from_dict(self, menu_dict: Dict) -> MenuItem:
        """
        Recursively build menu tree from dictionary.

        Structure:
        {
            "label": "Home",
            "url": "/",
            "icon": "🏠",
            "children": [
                {"label": "Products", ...}
            ]
        }
        """
        self.menu_counter += 1
        menu_id = self.menu_counter

        item = MenuItem(
            label=menu_dict.get("label", "Menu"),
            url=menu_dict.get("url", "#"),
            icon=menu_dict.get("icon", "📌"),
            menu_id=menu_id
        )

        # Recursively process children
        if "children" in menu_dict:
            for child_dict in menu_dict["children"]:
                child_item = self.build_menu_from_dict(child_dict)
                item.children.append(child_item)

        return item

    def display_menu(
        self,
        item: MenuItem,
        depth: int = 0,
        active_id: int = None
    ) -> None:
        """
        Recursively display menu with indentation.

        Args:
            item: Menu item to display
            depth: Current depth for indentation
            active_id: ID of active menu item
        """
        indent = "  " * depth
        prefix = "▶ " if item.children else "└ "
        active_marker = "→ " if item.menu_id == active_id else ""

        print(f"{indent}{active_marker}{prefix}{item.icon} {item.label}")

        # Recursively display children
        for child in item.children:
            self.display_menu(child, depth + 1, active_id)

    def generate_html(self, item: MenuItem, depth: int = 0) -> str:
        """
        Recursively generate HTML menu code.

        Args:
            item: Menu item to convert
            depth: Current depth

        Returns:
            HTML string
        """
        indent = "  " * depth
        html = f'{indent}<li><a href="{item.url}">{item.label}</a>'

        if item.children:
            html += f"\n{indent}  <ul>\n"
            for child in item.children:
                html += self.generate_html(child, depth + 2)
            html += f"{indent}  </ul>\n"
        else:
            html += "\n"

        html += f"{indent}</li>\n"
        return html


def create_sample_menu() -> Dict:
    """Create sample navigation menu."""
    return {
        "label": "Main Menu",
        "url": "/",
        "icon": "🏠",
        "children": [
            {
                "label": "Products",
                "url": "/products",
                "icon": "📦",
                "children": [
                    {
                        "label": "Electronics",
                        "url": "/products/electronics",
                        "icon": "💻",
                        "children": [
                            {"label": "Laptops", "url": "/products/electronics/laptops", "icon": "💻"},
                            {"label": "Phones", "url": "/products/electronics/phones", "icon": "📱"},
                            {"label": "Tablets", "url": "/products/electronics/tablets", "icon": "📲"},
                        ]
                    },
                    {
                        "label": "Clothing",
                        "url": "/products/clothing",
                        "icon": "👕",
                        "children": [
                            {"label": "Men", "url": "/products/clothing/men", "icon": "👔"},
                            {"label": "Women", "url": "/products/clothing/women", "icon": "👗"},
                        ]
                    }
                ]
            },
            {
                "label": "Services",
                "url": "/services",
                "icon": "🔧",
                "children": [
                    {"label": "Support", "url": "/services/support", "icon": "💬"},
                    {"label": "Training", "url": "/services/training", "icon": "📚"},
                ]
            },
            {
                "label": "About",
                "url": "/about",
                "icon": "ℹ️"
            }
        ]
    }


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("LAB 02: RECURSIVE MENU GENERATOR".center(80))
    print("=" * 80)

    # Create menu generator
    generator = MenuGenerator()

    # Build menu from dictionary
    menu_dict = create_sample_menu()
    print("\n1. BUILDING MENU FROM DICTIONARY:")
    print("-" * 80)
    root_menu = generator.build_menu_from_dict(menu_dict)
    print("✓ Menu built successfully")

    # Display menu
    print("\n2. DISPLAYING MENU:")
    print("-" * 80)
    print()
    generator.display_menu(root_menu)

    # Display with active item
    print("\n3. HIGHLIGHTING ACTIVE MENU ITEM (ID=6):")
    print("-" * 80)
    print()
    generator.display_menu(root_menu, active_id=6)

    # Generate HTML
    print("\n4. GENERATING HTML:")
    print("-" * 80)
    html = '<ul>\n'
    for child in root_menu.children:
        html += generator.generate_html(child, 1)
    html += '</ul>'
    print(html)

    print("\n" + "=" * 80)
    print("CHALLENGE EXTENSIONS".center(80))
    print("=" * 80)
    print(f"""
    1. ADD PERMISSIONS
       - Only show menu items user has access to
       - Recursively filter based on roles

    2. ADD BREADCRUMB
       - Generate breadcrumb trail for current page
       - Show path from root to current item

    3. ADD SEARCH
       - Find menu item by label recursively
       - Return full path to item

    4. ADD EXPORT
       - Generate sitemap.xml from menu
       - Export to JSON with hierarchy
       - Generate plain text TOC

    5. ADD ANALYTICS
       - Track which menu items are clicked
       - Count menu depth
       - Find most accessed paths

    6. DYNAMIC MENUS
       - Load menu from database
       - Cache generated menus
       - Update menu on-the-fly
    """)
