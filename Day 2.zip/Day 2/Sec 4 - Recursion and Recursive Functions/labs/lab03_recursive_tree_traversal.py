"""
================================================================================
LAB 03: RECURSIVE ORGANIZATION TREE TRAVERSAL
================================================================================

Enterprise Lab: Build and traverse organization hierarchy

REQUIREMENTS
============
1. Represent organizational hierarchy
2. Implement preorder traversal
3. Implement postorder traversal
4. Calculate team metrics recursively
5. Find managers and report structures

BUSINESS SCENARIO
================
HR system manages complex organization with hundreds of employees
in a hierarchical reporting structure.

TASKS
=====
1. Build employee tree
2. Traverse in different orders
3. Calculate team sizes
4. Find reporting chains
5. Generate reports
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Employee:
    """Represents an employee in organization."""
    emp_id: str
    name: str
    title: str
    salary: float = 0.0
    manager: Optional['Employee'] = None
    team_members: List['Employee'] = None

    def __post_init__(self):
        if self.team_members is None:
            self.team_members = []


class OrganizationTree:
    """Recursive organization tree operations."""

    @staticmethod
    def preorder_traversal(employee: Employee, depth: int = 0) -> List[Employee]:
        """
        Preorder: Process employee, then team members
        Useful for: Reporting chains
        """
        result = [employee]
        print(f"{'  ' * depth}→ {employee.name} ({employee.title})")

        for member in employee.team_members:
            result.extend(OrganizationTree.preorder_traversal(member, depth + 1))

        return result

    @staticmethod
    def postorder_traversal(employee: Employee, depth: int = 0) -> List[Employee]:
        """
        Postorder: Process team members, then employee
        Useful for: Calculating metrics from bottom up
        """
        result = []

        for member in employee.team_members:
            result.extend(OrganizationTree.postorder_traversal(member, depth + 1))

        print(f"{'  ' * depth}← {employee.name}")
        result.append(employee)
        return result

    @staticmethod
    def get_team_size(employee: Employee) -> int:
        """Recursively calculate total team size (including employee)."""
        size = 1  # Count self

        for member in employee.team_members:
            size += OrganizationTree.get_team_size(member)

        return size

    @staticmethod
    def calculate_total_salary(employee: Employee) -> float:
        """Recursively calculate total salary spend for team."""
        total = employee.salary

        for member in employee.team_members:
            total += OrganizationTree.calculate_total_salary(member)

        return total

    @staticmethod
    def find_manager_chain(employee: Employee) -> List[str]:
        """Find reporting chain up to CEO."""
        chain = [employee.name]

        if employee.manager:
            # Recursive call to find manager's chain
            manager_chain = OrganizationTree.find_manager_chain(employee.manager)
            chain.extend(manager_chain)

        return chain

    @staticmethod
    def display_hierarchy(employee: Employee, depth: int = 0) -> None:
        """Display organization hierarchy."""
        indent = "  " * depth
        prefix = "├→" if employee.team_members else "└→"

        print(f"{indent}{prefix} {employee.name}")
        print(f"{indent}  └─ {employee.title}")

        for member in employee.team_members:
            OrganizationTree.display_hierarchy(member, depth + 1)


def create_sample_organization() -> Employee:
    """Create sample organization structure."""
    # Level 3: Individual Contributors
    alice = Employee("E001", "Alice Johnson", "Senior Developer", 120000)
    bob = Employee("E002", "Bob Smith", "Developer", 95000)
    charlie = Employee("E003", "Charlie Brown", "QA Engineer", 90000)
    diana = Employee("E004", "Diana Prince", "Designer", 100000)
    eve = Employee("E005", "Eve Wilson", "Product Manager", 110000)

    # Level 2: Managers
    frank = Employee("M001", "Frank Miller", "Engineering Manager", 130000)
    frank.team_members = [alice, bob, charlie]

    grace = Employee("M002", "Grace Lee", "Product Manager", 125000)
    grace.team_members = [diana, eve]

    # Level 1: Director
    henry = Employee("D001", "Henry Davis", "VP Engineering", 160000)
    henry.team_members = [frank, grace]

    # Setup manager references
    frank.manager = henry
    grace.manager = henry
    alice.manager = frank
    bob.manager = frank
    charlie.manager = frank
    diana.manager = grace
    eve.manager = grace

    return henry


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("LAB 03: RECURSIVE ORGANIZATION TREE TRAVERSAL".center(80))
    print("=" * 80)

    # Create organization
    ceo = create_sample_organization()

    # Display hierarchy
    print("\n1. ORGANIZATION HIERARCHY:")
    print("-" * 80)
    print()
    OrganizationTree.display_hierarchy(ceo)

    # Preorder traversal
    print("\n2. PREORDER TRAVERSAL (top-down):")
    print("-" * 80)
    print()
    employees = OrganizationTree.preorder_traversal(ceo)
    print(f"\nTotal employees: {len(employees)}")

    # Postorder traversal
    print("\n3. POSTORDER TRAVERSAL (bottom-up):")
    print("-" * 80)
    print()
    employees = OrganizationTree.postorder_traversal(ceo)

    # Team metrics
    print("\n4. TEAM METRICS:")
    print("-" * 80)
    print(f"\nCEO ({ceo.name}):")
    print(f"  Direct reports: {len(ceo.team_members)}")
    print(f"  Total team size: {OrganizationTree.get_team_size(ceo)}")
    print(f"  Total salary: ${OrganizationTree.calculate_total_salary(ceo):,.2f}")

    for manager in ceo.team_members:
        print(f"\n{manager.title} ({manager.name}):")
        print(f"  Direct reports: {len(manager.team_members)}")
        print(f"  Total team size: {OrganizationTree.get_team_size(manager)}")
        print(f"  Total salary: ${OrganizationTree.calculate_total_salary(manager):,.2f}")

    # Reporting chain
    print("\n5. REPORTING CHAINS:")
    print("-" * 80)
    print()

    # Find a leaf employee
    alice = ceo.team_members[0].team_members[0]
    chain = OrganizationTree.find_manager_chain(alice)
    print(f"{alice.name}'s reporting chain:")
    for i, name in enumerate(chain):
        print(f"  {i}. {name}")

    print("\n" + "=" * 80)
    print("CHALLENGE EXTENSIONS".center(80))
    print("=" * 80)
    print(f"""
    1. ADVANCED SEARCHES
       - Find all employees with title "Developer"
       - Find employees earning > $X
       - Find shortest reporting chain
       - Find longest reporting chain

    2. REORGANIZATION
       - Move employee to different manager
       - Recursively update reporting chains
       - Calculate impact of changes

    3. REPORTING
       - Generate org chart as text
       - Export to CSV
       - Generate headcount report by level
       - Calculate average salary by level

    4. VALIDATION
       - Detect circular references
       - Validate reporting chain integrity
       - Find orphaned employees

    5. OPTIMIZATION
       - Cache team metrics
       - Parallel team calculations
       - Memory-efficient for large orgs (10,000+ employees)
    """)
