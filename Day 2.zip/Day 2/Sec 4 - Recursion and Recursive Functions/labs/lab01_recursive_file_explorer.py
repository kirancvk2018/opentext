"""
================================================================================
LAB 01: RECURSIVE FILE EXPLORER
================================================================================

Enterprise Lab: Build a file explorer that recursively traverses directories

REQUIREMENTS
============
1. Traverse directories recursively
2. Display folder hierarchy with indentation
3. Count files and folders
4. Calculate total size
5. Generate summary report
6. Handle errors gracefully

BUSINESS SCENARIO
================
A data governance system needs to analyze file storage across enterprise servers.

TASKS
=====
1. Implement recursive directory traversal
2. Track statistics (folders, files, sizes)
3. Display tree-like output
4. Handle permission errors
5. Generate detailed report
"""

import os
from pathlib import Path
from typing import Tuple


class DirectoryExplorer:
    """Recursive file system explorer."""

    def __init__(self, root_path: str):
        """Initialize explorer with root path."""
        self.root_path = root_path
        self.total_folders = 0
        self.total_files = 0
        self.total_size = 0
        self.max_depth = 0

    def explore(self, path: str = None, depth: int = 0) -> None:
        """Recursively explore directory tree."""
        if path is None:
            path = self.root_path

        try:
            items = os.listdir(path)
        except PermissionError:
            print(f"{'  ' * depth}✗ Permission denied")
            return

        # Display folder name
        folder_name = os.path.basename(path) or path
        print(f"{'  ' * depth}📁 {folder_name}/")

        self.max_depth = max(self.max_depth, depth)

        # Process items
        for item in sorted(items):
            item_path = os.path.join(path, item)

            if os.path.isdir(item_path):
                # Recursive call for subdirectories
                self.explore(item_path, depth + 1)
                self.total_folders += 1
            else:
                # File processing
                try:
                    size = os.path.getsize(item_path)
                    self.total_size += size
                    self.total_files += 1
                    print(f"{'  ' * (depth + 1)}📄 {item} ({size} bytes)")
                except OSError:
                    pass

    def report(self) -> None:
        """Generate summary report."""
        print(f"\n{'=' * 80}")
        print(f"DIRECTORY EXPLORER REPORT".center(80))
        print(f"{'=' * 80}")
        print(f"Root: {self.root_path}")
        print(f"Folders: {self.total_folders}")
        print(f"Files: {self.total_files}")
        print(f"Total Size: {self.total_size:,} bytes ({self.total_size / 1024 / 1024:.2f} MB)")
        print(f"Max Depth: {self.max_depth}")


def create_sample_structure() -> str:
    """Create sample directory structure."""
    base = "sample_explorer"
    Path(base).mkdir(exist_ok=True)

    folders = [
        f"{base}/documents",
        f"{base}/documents/reports",
        f"{base}/documents/invoices",
        f"{base}/media",
        f"{base}/media/images",
        f"{base}/media/videos",
        f"{base}/archive",
    ]

    for folder in folders:
        Path(folder).mkdir(parents=True, exist_ok=True)

    # Create sample files
    files = {
        f"{base}/README.md": "Project overview" * 100,
        f"{base}/documents/contract.pdf": "x" * 50000,
        f"{base}/documents/reports/2024_q1.xlsx": "x" * 30000,
        f"{base}/documents/invoices/inv_001.pdf": "x" * 10000,
        f"{base}/media/images/logo.png": "x" * 100000,
        f"{base}/media/images/banner.jpg": "x" * 150000,
        f"{base}/media/videos/intro.mp4": "x" * 500000,
        f"{base}/archive/backup.zip": "x" * 1000000,
    }

    for file_path, content in files.items():
        Path(file_path).write_text(content)

    return base


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("LAB 01: RECURSIVE FILE EXPLORER".center(80))
    print("=" * 80)

    # Create sample structure
    root = create_sample_structure()

    # Explore recursively
    print(f"\nExploring: {root}\n")
    explorer = DirectoryExplorer(root)
    explorer.explore()

    # Generate report
    explorer.report()

    # Cleanup
    import shutil
    try:
        shutil.rmtree(root)
    except:
        pass

    print("\n" + "=" * 80)
    print("CHALLENGE EXTENSIONS".center(80))
    print("=" * 80)
    print(f"""
    1. ADD FILTERING
       - Only show .pdf files
       - Only show folders > 1MB
       - Show only first N levels

    2. ADD SORTING
       - Sort by file size
       - Sort by date modified
       - Sort by name

    3. ADD EXPORT
       - Export report to CSV
       - Export tree structure to text
       - Export file listing to JSON

    4. ADD SEARCHING
       - Find all files matching pattern
       - Find largest files recursively
       - Find oldest/newest files

    5. ADD ANALYSIS
       - File type distribution
       - Size distribution by type
       - Recommendations for cleanup

    6. PERFORMANCE OPTIMIZATION
       - Parallel folder traversal
       - Caching results
       - Memory-efficient streaming
    """)
