"""
Tree Traversal: Organization Structure Processing

Business: HR system must traverse organization hierarchy and generate
reports using different traversal orders (preorder, inorder, postorder)

Learning: Tree traversal methods, understanding order of processing
"""

from dataclasses import dataclass


@dataclass
class Employee:
    """Employee node in organizational tree."""
    name: str
    title: str
    children: list['Employee'] = None

    def __post_init__(self):
        if self.children is None:
            self.children = []


def preorder_traversal(employee: Employee, depth: int = 0) -> list[str]:
    """
    Preorder: Process node, then children
    Useful for: Organizational hierarchies, team structures
    """
    indent = "  " * depth
    print(f"{indent}→ {employee.name} ({employee.title})")
    result = [f"{'  ' * depth}{employee.name}"]

    for child in employee.children:
        result.extend(preorder_traversal(child, depth + 1))

    return result


def inorder_traversal(employee: Employee, depth: int = 0, side: str = "root") -> list[str]:
    """
    Inorder: Left, node, right
    Useful for: Binary search trees (sorted order)
    """
    indent = "  " * depth
    result = []

    if employee.children:
        # Process first half
        for i, child in enumerate(employee.children[:len(employee.children)//2]):
            result.extend(inorder_traversal(child, depth + 1, "left"))

    # Process current node
    print(f"{indent}→ {employee.name} ({employee.title})")
    result.append(f"{'  ' * depth}{employee.name}")

    if employee.children:
        # Process second half
        for child in employee.children[len(employee.children)//2:]:
            result.extend(inorder_traversal(child, depth + 1, "right"))

    return result


def postorder_traversal(employee: Employee, depth: int = 0) -> list[str]:
    """
    Postorder: Process children, then node
    Useful for: Calculating totals, tree deletion
    """
    indent = "  " * depth
    result = []

    # Process children first
    for child in employee.children:
        result.extend(postorder_traversal(child, depth + 1))

    # Then process node
    print(f"{indent}→ {employee.name} ({employee.title})")
    result.append(f"{'  ' * depth}{employee.name}")

    return result


def create_org_tree() -> Employee:
    """Create sample organizational hierarchy."""
    # Leaf employees
    alice = Employee("Alice", "Developer")
    bob = Employee("Bob", "Developer")
    charlie = Employee("Charlie", "QA Engineer")
    diana = Employee("Diana", "Product Manager")

    # Managers
    engineering = Employee("Emma", "Engineering Manager", [alice, bob, charlie])
    product = Employee("Frank", "Product Manager", [diana])

    # Director
    vp = Employee("Grace", "VP Engineering", [engineering, product])

    # CEO
    ceo = Employee("Henry", "CEO", [vp])

    return ceo


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("TREE TRAVERSAL: ORGANIZATION STRUCTURE".center(80))
    print("=" * 80)

    org = create_org_tree()

    print("\n" + "=" * 80)
    print("PREORDER TRAVERSAL (Node, then Children)".center(80))
    print("=" * 80)
    print("\nUseful for: Company hierarchies, folder trees, XML documents\n")
    result = preorder_traversal(org)
    print("\nOrder:", " → ".join(result))

    print("\n" + "=" * 80)
    print("POSTORDER TRAVERSAL (Children, then Node)".center(80))
    print("=" * 80)
    print("\nUseful for: Calculating totals, deleting trees\n")
    result = postorder_traversal(org)
    print("\nOrder:", " → ".join(result))

    print("\n" + "=" * 80)
    print("LEVEL-ORDER (BREADTH-FIRST)".center(80))
    print("=" * 80)

    def level_order(root: Employee) -> None:
        """Level-order traversal using queue."""
        from collections import deque
        queue = deque([(root, 0)])

        while queue:
            emp, depth = queue.popleft()
            indent = "  " * depth
            print(f"{indent}→ {emp.name} ({emp.title})")

            for child in emp.children:
                queue.append((child, depth + 1))

    print("\nUseful for: Spanning tree, BFS shortest path\n")
    level_order(org)

    print("\n" + "=" * 80)
    print("TRAVERSAL COMPARISON".center(80))
    print("=" * 80)
    print(f"""
    PREORDER (Node → Children):
    - Process each node before children
    - Creates hierarchical output
    - Good for: Company org charts, indented lists
    - Time: O(n), Space: O(h)

    INORDER (Left → Node → Right):
    - For binary trees: gives sorted order
    - Useful for: Binary search trees
    - Time: O(n), Space: O(h)

    POSTORDER (Children → Node):
    - Process children before parent
    - Good for: Calculating tree-wide metrics
    - Example: Team size = sum of all subteam sizes
    - Time: O(n), Space: O(h)

    LEVEL-ORDER (BFS):
    - Process all nodes at same depth
    - Useful for: Finding shortest paths
    - Uses queue instead of recursion
    - Time: O(n), Space: O(w) where w=max width
    """)
