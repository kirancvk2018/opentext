"""
Recursion Limit Demonstration and Configuration

Business: System administrators need to safely adjust limits for specific workloads

Learning: Understanding and modifying recursion limits safely
"""

import sys


def demonstrate_limits() -> None:
    """Show recursion limit configuration."""
    print("\n" + "=" * 80)
    print("RECURSION LIMIT DEMONSTRATION".center(80))
    print("=" * 80)

    print(f"\nDefault recursion limit: {sys.getrecursionlimit()}")

    # Recursive function to test limits
    def deep_recursion(n: int) -> int:
        if n == 0:
            return 0
        return 1 + deep_recursion(n - 1)

    print("\nTesting recursion to depth 1000:")
    try:
        result = deep_recursion(1000)
        print(f"✓ Success: recursed {result} levels")
    except RecursionError as e:
        print(f"✗ RecursionError: {e}")

    print(f"\nCurrent limit allows ~{sys.getrecursionlimit() - 100} safe calls")


def demonstrate_limit_change() -> None:
    """Show how to change recursion limit."""
    print("\n" + "=" * 80)
    print("CHANGING RECURSION LIMIT".center(80))
    print("=" * 80)

    original = sys.getrecursionlimit()
    print(f"Original limit: {original}")

    # Increase limit
    new_limit = 5000
    sys.setrecursionlimit(new_limit)
    print(f"New limit: {sys.getrecursionlimit()}")

    # Note: Do NOT leave it changed!
    sys.setrecursionlimit(original)
    print(f"Restored to: {sys.getrecursionlimit()}")

    print("\n⚠ WARNING:")
    print("  - Changing limits affects memory usage")
    print("  - Large stacks can crash the program")
    print("  - Only change if you understand the risks")
    print("  - Restore original limit after use")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("SYSTEM RECURSION LIMITS".center(80))
    print("Large Knowledge Repository".center(80))
    print("=" * 80)

    demonstrate_limits()
    demonstrate_limit_change()

    print("\n" + "=" * 80)
    print("BEST PRACTICES".center(80))
    print("=" * 80)
    print(f"""
    ✓ DO:
      - Monitor recursion depth with parameters
      - Use memoization to reduce calls
      - Test with realistic data sizes
      - Handle RecursionError gracefully
      - Document recursion depth requirements
      - Consider iterative alternatives

    ✗ DON'T:
      - Blindly increase recursion limit
      - Ignore depth warnings
      - Use recursion for very deep problems
      - Assume limit is sufficient
      - Change limit in library code
      - Leave limit changed after completion

    WHEN TO INCREASE LIMIT:
      - Trusted, tested recursive algorithms
      - Known depth requirements < 5000
      - Sufficient system memory
      - Temporarily for specific analysis
      - With explicit documentation
    """)
