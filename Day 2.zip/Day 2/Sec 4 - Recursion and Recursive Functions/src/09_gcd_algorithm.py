"""
Greatest Common Divisor (GCD) using Euclidean Algorithm

Business: Manufacturing needs largest common batch size for multiple SKUs

Learning: Recursive algorithm with elegant mathematical solution (Euclidean algorithm)
"""

def gcd_recursive(a: int, b: int, depth: int = 0) -> int:
    """
    Calculate GCD using Euclidean algorithm recursively.
    GCD(a, b) = GCD(b, a mod b)
    Base case: GCD(n, 0) = n
    Time: O(log(min(a,b)))
    """
    indent = "  " * depth
    print(f"{indent}→ GCD({a}, {b})")

    if b == 0:
        print(f"{indent}  ← [BASE CASE] GCD({a}, 0) = {a}")
        return a

    remainder = a % b
    print(f"{indent}  {a} mod {b} = {remainder}")
    result = gcd_recursive(b, remainder, depth + 1)
    print(f"{indent}  ← GCD({a}, {b}) = {result}")
    return result


def gcd_iterative(a: int, b: int) -> int:
    """Calculate GCD iteratively."""
    while b != 0:
        a, b = b, a % b
    return a


def batch_optimization() -> None:
    """Apply GCD to manufacturing batch optimization."""
    print("\n" + "=" * 80)
    print("MANUFACTURING BATCH OPTIMIZATION".center(80))
    print("=" * 80)

    # Product SKUs with production quantities
    products = [
        ("SKU-001", 240),
        ("SKU-002", 180),
        ("SKU-003", 120),
    ]

    print("\nFinding largest batch size that divides evenly into all SKUs:\n")
    for sku, qty in products:
        print(f"  {sku}: {qty} units")

    # Calculate GCD of all quantities
    gcd_result = products[0][1]
    for _, qty in products[1:]:
        gcd_result = gcd_iterative(gcd_result, qty)

    print(f"\n✓ Largest common batch size: {gcd_result} units")
    print(f"\nOptimal production batches:")
    for sku, qty in products:
        batches = qty // gcd_result
        print(f"  {sku}: {batches} batches of {gcd_result} units")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("EUCLIDEAN ALGORITHM: GCD CALCULATION".center(80))
    print("Manufacturing Batch Optimization".center(80))
    print("=" * 80)

    print(f"\nFinding GCD(48, 18):\n")
    result = gcd_recursive(48, 18)
    print(f"\n✓ Result: GCD(48, 18) = {result}")

    batch_optimization()

    print(f"\n" + "=" * 80)
    print("KEY INSIGHTS".center(80))
    print("=" * 80)
    print(f"""
    EUCLIDEAN ALGORITHM:
    - Base case: GCD(n, 0) = n
    - Recursive case: GCD(a, b) = GCD(b, a mod b)
    - Time: O(log(min(a,b))) very efficient
    - Elegantly reduces problem using modulo operation

    WHY THIS WORKS:
    GCD(48, 18):
      → GCD(48, 18) = GCD(18, 48 mod 18 = 12)
      → GCD(18, 12) = GCD(12, 18 mod 12 = 6)
      → GCD(12, 6) = GCD(6, 12 mod 6 = 0)
      → GCD(6, 0) = 6

    Result: 6 is largest number dividing both 48 and 18

    APPLICATIONS:
    - Manufacturing batch optimization
    - Cryptography (RSA, extended Euclidean algorithm)
    - Fraction reduction (simplify a/b)
    - Music theory (harmony ratios)
    - Computer graphics (scaling)
    """)
