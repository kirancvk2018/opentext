"""
================================================================================
CALL STACK DEMONSTRATION
================================================================================

Customer Support Ticket Escalation System

PROBLEM STATEMENT
----------------
Support tickets escalate through management chain:
    Level 1 Support → Level 2 Support → Supervisor → Manager → Director

Each level can resolve or escalate. Track the call stack depth and
show how frames are created and destroyed.

LEARNING OBJECTIVES
------------------
- Understand call stack structure
- Visualize frame creation and destruction
- Monitor recursion depth
- Recognize stack overflow risks

SOLUTION OVERVIEW
-----------------
This module focuses on call stack mechanics, not just recursion logic.
"""

import sys
from typing import Optional


class CallStackTracker:
    """Tracks call stack depth and frame information."""

    def __init__(self):
        self.current_depth = 0
        self.max_depth = 0
        self.call_log = []

    def enter_call(self, func_name: str, params: str) -> None:
        """Record entering a function call."""
        self.current_depth += 1
        self.max_depth = max(self.max_depth, self.current_depth)
        self.call_log.append(f"→ ENTER {func_name}({params}) [Depth: {self.current_depth}]")

    def exit_call(self, func_name: str, result: str) -> None:
        """Record exiting a function call."""
        self.call_log.append(f"← EXIT {func_name}() → {result} [Depth: {self.current_depth}]")
        self.current_depth -= 1

    def print_log(self) -> None:
        """Print formatted call log."""
        print("\nCALL STACK LOG:")
        print("=" * 80)
        for entry in self.call_log:
            print(entry)
        print("=" * 80)


# Global tracker
tracker = CallStackTracker()


def escalate_ticket(
    ticket_id: str,
    level: int = 1,
    resolved: bool = False,
    depth: int = 0
) -> bool:
    """
    Recursively escalate support ticket through management chain.

    Shows call stack frame creation and destruction.

    Args:
        ticket_id: Ticket identifier
        level: Current support level (1-5)
        resolved: Whether ticket is resolved at this level
        depth: Recursion depth for visualization

    Returns:
        True if resolved, False if escalated to top
    """
    indent = "  " * depth
    max_level = 5

    # Inform tracker
    tracker.enter_call(f"escalate_ticket", f"level={level}")

    # Display frame entry
    print(f"{indent}┌─ FRAME {depth + 1}: escalate_ticket(level={level})")
    print(f"{indent}│  Stack Depth: {depth + 1}/{sys.getrecursionlimit()}")

    # BASE CASE 1: Ticket is resolved
    if resolved:
        print(f"{indent}│  ✓ [BASE CASE] Ticket RESOLVED at level {level}")
        tracker.exit_call("escalate_ticket", f"RESOLVED=True")
        print(f"{indent}└─ [RETURN] RESOLVED=True\n")
        return True

    # BASE CASE 2: Reached director (top level)
    if level >= max_level:
        print(f"{indent}│  ✓ [BASE CASE] Reached director (level {max_level}) - RESOLVED")
        tracker.exit_call("escalate_ticket", f"RESOLVED=True")
        print(f"{indent}└─ [RETURN] RESOLVED=True\n")
        return True

    # RECURSIVE CASE: Escalate to next level
    print(f"{indent}│  ⟳ [RECURSIVE CASE] Escalating from level {level} to {level + 1}")
    print(f"{indent}│  └─ Creating new stack frame...\n")

    # RECURSIVE CALL - This creates a new frame
    result = escalate_ticket(ticket_id, level + 1, resolved=False, depth=depth + 1)

    # Back from recursive call
    print(f"{indent}┌─ [RETURN] Back from level {level + 1}")
    tracker.exit_call("escalate_ticket", f"RESOLVED={result}")
    print(f"{indent}└─ FRAME {depth + 1} destroyed\n")
    return result


def visualize_stack_frames() -> None:
    """
    Explain stack frames and how they work.
    """
    print("\n" + "=" * 80)
    print("STACK FRAMES EXPLAINED".center(80))
    print("=" * 80)

    print("""
    WHAT IS A STACK FRAME?
    ======================
    A stack frame is memory allocated when a function is called.
    Each frame stores:
    - Local variables
    - Function parameters
    - Return address (where to return after function ends)
    - Temporary values

    Stack Lifecycle:
    1. Function called → Frame CREATED and pushed onto stack
    2. Function executes → Frame is current
    3. Function returns → Frame POPPED and destroyed

    LIFO: Last In, First Out
    The most recent frame (deepest call) is removed first.


    CALL STACK WITH RECURSION
    ==========================

    Non-recursive (normal) function calls:
        main()
          └─> func_a()
              └─> func_b()
                  └─> func_c()

        Stack grows and shrinks as calls occur
        Maximum stack size = 4 frames


    Recursive function calls:
        main()
          └─> recursive(1)
              └─> recursive(2)
                  └─> recursive(3)
                      └─> recursive(4)
                          └─> recursive(5)

        Stack grows deeper with each call
        All frames exist simultaneously until returning
        Maximum stack size depends on recursion depth


    EXAMPLE: Escalate Ticket Through 3 Levels
    ==========================================

    Initial call:
        escalate_ticket(ticket_001, level=1)

    Execution timeline:

    1. escalate_ticket(1) [Frame 1]
       Stack: [1]
       → Not resolved, level < 5 → RECURSIVE CASE
       → Call escalate_ticket(2)

    2. escalate_ticket(2) [Frame 2]
       Stack: [1, 2]
       → Not resolved, level < 5 → RECURSIVE CASE
       → Call escalate_ticket(3)

    3. escalate_ticket(3) [Frame 3]
       Stack: [1, 2, 3]
       → level = 5 (director) → BASE CASE
       → Return True
       → Frame 3 destroyed

    4. Back in escalate_ticket(2)
       Stack: [1, 2]
       → Received True from recursive call
       → Return True
       → Frame 2 destroyed

    5. Back in escalate_ticket(1)
       Stack: [1]
       → Received True from recursive call
       → Return True
       → Frame 1 destroyed

    6. Back in main()
       Stack: []
       → Done!


    STACK MEMORY USAGE
    ==================
    Each frame uses memory for:
    - Function parameters: ~8 bytes per variable
    - Local variables: ~8 bytes per variable
    - Return address: ~8 bytes
    - Misc overhead: ~32 bytes

    Deep recursion example:
        100 levels × 100 bytes = 10 KB (fine)
        1000 levels × 100 bytes = 100 KB (fine)
        10000 levels × 100 bytes = 1 MB (getting tight)
        1000000 levels × 100 bytes = 100 MB (stack overflow!)

    Python recursion limit: default 1000 (most systems)
    This prevents runaway recursion from crashing the program
    """)


def demonstrate_stack_monitoring() -> None:
    """
    Monitor stack depth during execution.
    """
    print("\n" + "=" * 80)
    print("STACK MONITORING DEMONSTRATION".center(80))
    print("=" * 80)

    print(f"\nSystem recursion limit: {sys.getrecursionlimit()}")
    print("Safe recursion depth: ~90% of limit")
    safe_depth = int(sys.getrecursionlimit() * 0.9)
    print(f"Safe to use: {safe_depth} levels\n")

    # Run escalation
    print("Escalating ticket through support levels:\n")
    result = escalate_ticket("TICKET_001", level=1, resolved=False, depth=0)

    # Show tracker results
    tracker.print_log()

    print(f"\nStack Statistics:")
    print(f"  Maximum depth reached: {tracker.max_depth}")
    print(f"  Total calls: {len(tracker.call_log) // 2}")
    print(f"  Final result: {'RESOLVED' if result else 'UNRESOLVED'}")


def stack_overflow_example() -> None:
    """
    Show what happens with recursion limit.
    """
    print("\n" + "=" * 80)
    print("RECURSION LIMIT AND STACK OVERFLOW".center(80))
    print("=" * 80)

    def risky_recursion(n: int) -> int:
        """Function that easily hits recursion limit."""
        if n == 0:
            return 0
        # Each call adds to stack
        return 1 + risky_recursion(n - 1)

    limit = sys.getrecursionlimit()
    print(f"\nCurrent recursion limit: {limit}")
    print(f"Attempting to recurse {limit + 100} times...\n")

    try:
        result = risky_recursion(limit + 100)
        print(f"Result: {result}")
    except RecursionError as e:
        print(f"✗ RecursionError caught!")
        print(f"  Message: {e}")
        print(f"\nExplanation:")
        print(f"  - Each call to risky_recursion() added a stack frame")
        print(f"  - After {limit} frames, Python stopped to prevent crash")
        print(f"  - RecursionError prevents entire program from crashing")


def monitoring_with_decorator() -> None:
    """
    Show how to monitor stack depth with decorator.
    """
    print("\n" + "=" * 80)
    print("DECORATOR FOR STACK MONITORING".center(80))
    print("=" * 80)

    # Simple recursion depth tracker
    call_depth = 0

    def monitor_depth(func):
        """Decorator to track recursion depth."""
        def wrapper(*args, **kwargs):
            global call_depth
            call_depth += 1
            limit = sys.getrecursionlimit()

            # Warning at 80% of limit
            if call_depth > limit * 0.8:
                print(f"⚠ WARNING: Recursion depth {call_depth}/{limit} (80%)")

            # Error at 95% of limit
            if call_depth > limit * 0.95:
                raise RuntimeError(f"Recursion depth {call_depth} exceeds safe limit")

            try:
                result = func(*args, **kwargs)
                return result
            finally:
                call_depth -= 1

        return wrapper

    @monitor_depth
    def safe_recursion(n: int) -> int:
        """Recursion with depth monitoring."""
        if n == 0:
            return 0
        return n + safe_recursion(n - 1)

    print("\nTesting monitored recursion:")
    try:
        result = safe_recursion(100)
        print(f"✓ Recursion complete: sum(1..100) = {result}")
    except RuntimeError as e:
        print(f"✗ Caught by monitor: {e}")


def interview_questions() -> None:
    """
    Interview questions about call stacks.
    """
    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS".center(80))
    print("=" * 80)

    questions = [
        {
            "Q": "Explain what a stack frame is.",
            "A": """
            A stack frame is the memory allocated when a function is called.
            Each frame contains:
            - Function parameters
            - Local variables
            - Return address (where execution resumes after function ends)
            - Temporary values

            Frames are created (pushed) when functions are called
            Frames are destroyed (popped) when functions return
            LIFO principle: Last frame pushed is first frame popped
            """
        },
        {
            "Q": "How deep can recursion go in Python?",
            "A": """
            Python has a recursion limit (default 1000) to prevent stack overflow.
            Get limit: sys.getrecursionlimit()
            Set limit: sys.setrecursionlimit(2000)

            Why the limit exists:
            - Prevent runaway recursion from crashing OS
            - Stack is finite resource (typically 1-8 MB)
            - Each frame uses memory for variables and overhead
            - Deep recursion exhausts stack → program crash

            Safe practice: Use ~90% of limit
            At limit, Python raises RecursionError
            """
        },
        {
            "Q": "What causes RecursionError?",
            "A": """
            RecursionError happens when recursion exceeds limit.

            Common causes:
            1. Missing base case → infinite recursion
            2. Base case never reached → infinite recursion
            3. Legitimate deep recursion → hit system limit

            Example: Binary search on 1,000,000 items
            Depth = log2(1,000,000) ≈ 20 (no problem)

            Example: Linked list of 1,000,000 nodes
            Depth = 1,000,000 (exceeds limit → RecursionError)

            Fix: Use iteration instead for very deep problems
            """
        },
        {
            "Q": "How much memory does each frame use?",
            "A": """
            Typical frame size: 100-200 bytes

            Composition:
            - Parameters: 8 bytes each
            - Local variables: 8 bytes each
            - Return address: 8 bytes
            - Stack overhead: ~32 bytes

            Example: function with 3 parameters + 2 local variables
            Frame ≈ 8 + 8 + 8 + 8 + 8 + 32 = 72 bytes

            Stack memory impact:
            - 1,000 frames × 100 bytes = 100 KB (fine)
            - 10,000 frames × 100 bytes = 1 MB (tight)
            - 100,000 frames × 100 bytes = 10 MB (exceeds typical stack)
            """
        },
        {
            "Q": "How do you safely monitor recursion depth?",
            "A": """
            Methods:

            1. Check within function:
               if sys._getframe().f_back.f_back is None:
                   # Near top of stack

            2. Use decorator:
               @monitor_recursion_depth
               def recursive_func(...): ...

            3. Count manually:
               counter = 0
               def recursive(n):
                   global counter
                   counter += 1
                   # ... recursion ...

            4. Track in parameter:
               def recursive(n, depth=0):
                   if depth > SAFE_LIMIT:
                       raise RuntimeError("Too deep")
                   # ... recursion ..., depth+1
            """
        }
    ]

    for i, qa in enumerate(questions, 1):
        print(f"\n❓ Question {i}: {qa['Q']}")
        print(f"{qa['A']}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("CALL STACK DEMONSTRATION".center(80))
    print("Customer Support Ticket Escalation".center(80))
    print("=" * 80)

    # Explain stack frames
    visualize_stack_frames()

    # Demonstrate stack monitoring
    demonstrate_stack_monitoring()

    # Show stack overflow
    stack_overflow_example()

    # Decorator example
    monitoring_with_decorator()

    # Interview questions
    interview_questions()

    # Summary
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS".center(80))
    print("=" * 80)
    print("""
    ✓ Stack frame: Memory for one function call
    ✓ Each recursion adds frame to stack
    ✓ Frames removed in LIFO order (Last In First Out)
    ✓ Python limits recursion to ~1000 by default
    ✓ Deep recursion uses memory and can overflow
    ✓ Monitor depth with sys.getrecursionlimit()
    ✓ RecursionError prevents program crash

    NEXT: See 05_factorial.py for classic recursion example
    """)
