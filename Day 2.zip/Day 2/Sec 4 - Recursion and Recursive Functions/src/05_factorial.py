"""
================================================================================
FACTORIAL: CLASSIC RECURSION EXAMPLE
================================================================================

Workflow Combination Calculator

PROBLEM STATEMENT
----------------
A workflow engine can execute tasks in different sequences.
Number of possible execution paths = n! (factorial)

For 5 tasks: 5! = 5 × 4 × 3 × 2 × 1 = 120 possible execution sequences

BUSINESS SCENARIO
----------------
A software deployment pipeline has 5 sequential stages:
1. Compile code
2. Run tests
3. Security scan
4. Deploy to staging
5. Deploy to production

The system can run some stages in parallel, creating multiple paths.
Calculate total possible execution sequences.

LEARNING OBJECTIVES
------------------
- Understand factorial recursively
- Simple base case (n=0 or n=1 returns 1)
- Simple recursive case (n! = n × (n-1)!)
- Classic recursion example
- Compare recursive vs iterative

SOLUTION OVERVIEW
-----------------
Factorial(n) = n × Factorial(n-1)
Factorial(0) = 1 (by definition)

Base Case: n ≤ 1 return 1
Recursive Case: n × factorial(n-1)

Time Complexity: O(n)
Space Complexity: O(n) call stack
"""

import time
from typing import Tuple


# ============================================================================
# RECURSIVE SOLUTION
# ============================================================================

def factorial_recursive(n: int, depth: int = 0) -> int:
    """
    Calculate factorial recursively: n! = n × (n-1)!

    WHY recursive:
        Factorial has natural recursive definition.
        n! = n × (n-1)!

    Args:
        n: Number to calculate factorial of
        depth: Recursion depth (for visualization)

    Returns:
        Factorial of n

    Raises:
        ValueError: If n < 0
    """
    indent = "  " * depth

    if n < 0:
        raise ValueError("Factorial undefined for negative numbers")

    print(f"{indent}→ factorial_recursive({n})")

    # BASE CASE: n ≤ 1
    # Why: factorial(0) = 1 by definition, factorial(1) = 1
    # No need to recurse further
    if n <= 1:
        print(f"{indent}  ← [BASE CASE] factorial({n}) = 1")
        return 1

    # RECURSIVE CASE: n × factorial(n-1)
    # Why: n! = n × (n-1)!
    # Recursively calculate (n-1)!, then multiply by n
    print(f"{indent}  → Calculating {n} × factorial({n-1})")
    result = n * factorial_recursive(n - 1, depth + 1)
    print(f"{indent}  ← {n} × factorial({n-1}) = {result}")
    return result


# ============================================================================
# ITERATIVE SOLUTION (for comparison)
# ============================================================================

def factorial_iterative(n: int) -> int:
    """
    Calculate factorial iteratively.

    This shows iteration is simpler for this problem.

    Args:
        n: Number to calculate factorial of

    Returns:
        Factorial of n
    """
    if n < 0:
        raise ValueError("Factorial undefined for negative numbers")

    print(f"→ factorial_iterative({n})")

    result = 1
    for i in range(n, 1, -1):
        print(f"  {result} × {i} = {result * i}")
        result *= i

    print(f"  ← Result: {result}")
    return result


# ============================================================================
# MATHEMATICAL DEFINITION
# ============================================================================

def explain_factorial() -> None:
    """
    Explain factorial mathematically.
    """
    print("\n" + "=" * 80)
    print("FACTORIAL EXPLAINED".center(80))
    print("=" * 80)

    print("""
    MATHEMATICAL DEFINITION
    =======================
    n! (factorial of n) = n × (n-1) × (n-2) × ... × 2 × 1

    Examples:
        0! = 1 (by definition)
        1! = 1
        2! = 2 × 1 = 2
        3! = 3 × 2 × 1 = 6
        4! = 4 × 3 × 2 × 1 = 24
        5! = 5 × 4 × 3 × 2 × 1 = 120

    Special case: 0! = 1
    Why? Mathematical convention for empty product


    RECURSIVE DEFINITION
    ====================
    n! = n × (n-1)! for n > 1
    1! = 1
    0! = 1


    BASE CASE
    =========
    When n ≤ 1, return 1
    Why: Can't multiply further, 0! and 1! both equal 1


    RECURSIVE CASE
    ==============
    return n × factorial(n-1)
    Why: Reduces problem: calculate (n-1)!, then multiply by n


    CALL STACK EXAMPLE: factorial(5)
    ================================

    factorial(5)
      └─> 5 × factorial(4)
          └─> 4 × factorial(3)
              └─> 3 × factorial(2)
                  └─> 2 × factorial(1)
                      └─> [BASE CASE] return 1
                  └─> 2 × 1 = 2
              └─> 3 × 2 = 6
          └─> 4 × 6 = 24
      └─> 5 × 24 = 120


    BUSINESS APPLICATION: WORKFLOW PATHS
    =====================================
    5 deployment stages can be executed in 5! = 120 different orders
    (in reality, dependencies prevent this, but theoretically...)

    Calculating all possibilities:
        120! = ??? (HUGE number)
        Factorial grows extremely fast!

        10! = 3,628,800
        20! = 2,432,902,008,176,640,000
        30! = astronomical
    """)


# ============================================================================
# PERFORMANCE COMPARISON
# ============================================================================

def compare_performance() -> None:
    """
    Compare recursive vs iterative performance.
    """
    print("\n" + "=" * 80)
    print("PERFORMANCE COMPARISON".center(80))
    print("=" * 80)

    test_values = [5, 10, 15, 20, 25]

    print("\nComparing recursive vs iterative factorial:")
    print(f"{'N':<5} {'Recursive (ms)':<18} {'Iterative (ms)':<18} {'Speedup':<10}")
    print("-" * 60)

    for n in test_values:
        # Recursive
        start = time.perf_counter()
        for _ in range(1000):
            factorial_recursive(n)
        recursive_time = (time.perf_counter() - start) * 1000

        # Iterative
        start = time.perf_counter()
        for _ in range(1000):
            factorial_iterative(n)
        iterative_time = (time.perf_counter() - start) * 1000

        speedup = recursive_time / iterative_time if iterative_time > 0 else 1

        print(f"{n:<5} {recursive_time:<18.4f} {iterative_time:<18.4f} {speedup:<10.2f}x")


# ============================================================================
# FACTORIAL PROPERTIES
# ============================================================================

def demonstrate_factorial_properties() -> None:
    """
    Demonstrate interesting properties of factorial.
    """
    print("\n" + "=" * 80)
    print("FACTORIAL PROPERTIES AND PATTERNS".center(80))
    print("=" * 80)

    print("\nFactorial Values:")
    print("-" * 40)

    factorials = {}
    for n in range(11):
        f = factorial_recursive(n) if n <= 6 else factorial_iterative(n)
        factorials[n] = f
        print(f"  {n:2d}! = {f:>15,}")

    print("\n\nFactorial Ratios:")
    print("-" * 40)
    print("Each factorial is n times the previous:")

    for n in range(1, 8):
        ratio = factorials[n] / factorials[n-1]
        print(f"  {n}! / {n-1}! = {ratio:.1f} (should be {n})")

    print("\n\nFactorial Growth:")
    print("-" * 40)
    print("Factorial grows VERY rapidly:")

    for n in [5, 10, 15, 20, 21]:
        f = factorial_recursive(n) if n <= 12 else factorial_iterative(n)
        print(f"  {n}! = {f:,}")


# ============================================================================
# REAL-WORLD APPLICATION
# ============================================================================

def permutation_example() -> None:
    """
    Show real-world use: calculating permutations.
    """
    print("\n" + "=" * 80)
    print("REAL-WORLD APPLICATION: PERMUTATIONS".center(80))
    print("=" * 80)

    print("""
    PERMUTATION FORMULA
    ===================
    P(n,r) = n! / (n-r)!

    Number of ways to arrange r items from n items.

    Example: Arranging 5 workers in 3 shift slots:
    P(5,3) = 5! / (5-3)! = 5! / 2! = 120 / 2 = 60 ways


    COMBINATION FORMULA
    ===================
    C(n,r) = n! / (r! × (n-r)!)

    Number of ways to choose r items from n items (order doesn't matter).

    Example: Choosing 3 people from 5 for a committee:
    C(5,3) = 5! / (3! × 2!) = 120 / (6 × 2) = 10 ways
    """)

    # Calculate some examples
    def permutation(n: int, r: int) -> int:
        """Calculate P(n,r) = n! / (n-r)!"""
        return factorial_iterative(n) // factorial_iterative(n - r)

    def combination(n: int, r: int) -> int:
        """Calculate C(n,r) = n! / (r! × (n-r)!)"""
        return factorial_iterative(n) // (factorial_iterative(r) * factorial_iterative(n - r))

    print("\nPermutation Examples:")
    print(f"  P(5,3) = arrangements of 3 from 5 = {permutation(5, 3)}")
    print(f"  P(5,4) = arrangements of 4 from 5 = {permutation(5, 4)}")

    print("\nCombination Examples:")
    print(f"  C(5,3) = choosing 3 from 5 = {combination(5, 3)}")
    print(f"  C(5,2) = choosing 2 from 5 = {combination(5, 2)}")


# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================

def interview_questions() -> None:
    """
    Interview questions about factorial and recursion.
    """
    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS".center(80))
    print("=" * 80)

    questions = [
        {
            "Q": "Write the recursive definition of factorial.",
            "A": """
            n! = n × (n-1)! for n > 1
            1! = 1
            0! = 1

            Or more concisely:
            f(n) = 1 if n ≤ 1 else n × f(n-1)
            """
        },
        {
            "Q": "Why is factorial a good recursion example?",
            "A": """
            1. Natural recursive definition (matches math)
            2. Clear base case (n ≤ 1)
            3. Clear recursive case (n × factorial(n-1))
            4. Easy to understand
            5. Shows how recursion mirrors mathematical definition

            However: Iterative is simpler and faster for factorial
            Better examples: trees, graphs, divide-and-conquer
            """
        },
        {
            "Q": "What's the time complexity of factorial recursion?",
            "A": """
            Time Complexity: O(n)
            - Must make n recursive calls (5 → 4 → 3 → 2 → 1 → base)
            - Each call does constant work

            Space Complexity: O(n)
            - Each recursive call uses stack space
            - n levels deep = n stack frames
            - Total: n × (frame size)

            Note: Iterative factorial is also O(n) time, O(1) space
            """
        },
        {
            "Q": "How would you optimize factorial for large numbers?",
            "A": """
            For computing factorial once: Use iteration
            - O(n) time, O(1) space
            - No function call overhead

            For computing many factorials: Use memoization
            - Cache results: 0!, 1!, 2!, ..., n!
            - Reuse computed values
            - @lru_cache decorator in Python

            For very large factorials:
            - Use math.factorial() (built-in, optimized)
            - Or use libraries for big integers (Python handles this)
            """
        },
        {
            "Q": "Why does factorial grow so quickly?",
            "A": """
            Each increase in n multiplies the result by n:
            - 5! = 120
            - 6! = 120 × 6 = 720
            - 7! = 720 × 7 = 5,040
            - 8! = 5,040 × 8 = 40,320
            - 10! = 3,628,800
            - 20! ≈ 2.4 × 10^18

            This exponential growth is why:
            - Factorial is used to calculate extremely fast-growing counts
            - It's impractical to compute large factorials (20! is huge)
            - It's used in combinatorics to quantify possibilities
            """
        }
    ]

    for i, qa in enumerate(questions, 1):
        print(f"\n❓ Question {i}: {qa['Q']}")
        print(f"{qa['A']}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("FACTORIAL: CLASSIC RECURSION EXAMPLE".center(80))
    print("Workflow Combination Calculator".center(80))
    print("=" * 80)

    # Explain factorial
    explain_factorial()

    # Demonstrate with small numbers
    print("\n" + "=" * 80)
    print("RECURSIVE CALCULATION: factorial(5)".center(80))
    print("=" * 80)
    print()
    result = factorial_recursive(5)
    print(f"\n✓ Result: 5! = {result}")

    # Compare approaches
    print("\n" + "=" * 80)
    print("ITERATIVE CALCULATION: factorial(5)".center(80))
    print("=" * 80)
    print()
    result = factorial_iterative(5)
    print(f"✓ Result: 5! = {result}")

    # Show properties
    demonstrate_factorial_properties()

    # Real-world application
    permutation_example()

    # Interview questions
    interview_questions()

    # Summary
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS".center(80))
    print("=" * 80)
    print("""
    ✓ Factorial: n! = n × (n-1)! with base case n ≤ 1
    ✓ Recursive naturally mirrors mathematical definition
    ✓ Time: O(n), Space: O(n) for recursion
    ✓ Iterative is more efficient for factorial
    ✓ Factorial grows extremely quickly (explosive growth)
    ✓ Used for permutations, combinations, counting problems

    NEXT: See 06_fibonacci.py for comparing naive vs optimized recursion
    """)
