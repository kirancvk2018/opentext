"""
Compound Growth Projection using Power Recursion

Business Scenario: A cloud infrastructure team projects system capacity growth
where capacity doubles each period: capacity = base × 2^periods

Learning: Recursive power calculation with divide-and-conquer optimization
"""

def power_naive(base: float, exponent: int, depth: int = 0) -> float:
    """
    Calculate base^exponent recursively (naive approach).
    base * base * base ... (exponent times)
    Time: O(n), Space: O(n)
    """
    indent = "  " * depth
    print(f"{indent}→ power({base}, {exponent})")

    if exponent == 0:
        print(f"{indent}  ← [BASE CASE] {base}^0 = 1")
        return 1

    result = base * power_naive(base, exponent - 1, depth + 1)
    print(f"{indent}  ← {base}^{exponent} = {result}")
    return result


def power_optimized(base: float, exponent: int, depth: int = 0) -> float:
    """
    Calculate base^exponent using divide-and-conquer.
    If exponent is even: x^n = (x^(n/2))^2
    If exponent is odd: x^n = x * x^(n-1)
    Time: O(log n), Space: O(log n)
    """
    indent = "  " * depth
    print(f"{indent}→ power({base}, {exponent})")

    if exponent == 0:
        print(f"{indent}  ← [BASE CASE] {base}^0 = 1")
        return 1

    if exponent == 1:
        print(f"{indent}  ← [BASE CASE] {base}^1 = {base}")
        return base

    # Divide-and-conquer: reduce exponent logarithmically
    if exponent % 2 == 0:
        # Even: x^n = (x^(n/2))^2
        print(f"{indent}  (even) x^{exponent} = (x^{exponent//2})^2")
        half = power_optimized(base, exponent // 2, depth + 1)
        result = half * half
    else:
        # Odd: x^n = x * x^(n-1)
        print(f"{indent}  (odd) x^{exponent} = x * x^{exponent-1}")
        result = base * power_optimized(base, exponent - 1, depth + 1)

    print(f"{indent}  ← {base}^{exponent} = {result}")
    return result


def capacity_growth_forecast() -> None:
    """Apply power recursion to cloud capacity forecasting."""
    print("\n" + "=" * 80)
    print("CLOUD CAPACITY GROWTH FORECAST".center(80))
    print("=" * 80)

    initial_capacity = 1000  # 1000 GB
    periods = 12  # 12 months

    print(f"\nInitial capacity: {initial_capacity:,} GB")
    print(f"Growth model: Capacity doubles each period (capacity × 2^periods)")
    print(f"\nMonthly capacity progression:\n")

    for month in range(periods + 1):
        capacity = initial_capacity * power_optimized(2, month)
        print(f"  Month {month:2d}: {capacity:>15,.0f} GB")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("POWER FUNCTION: DIVIDE-AND-CONQUER".center(80))
    print("System Capacity Growth Recursion".center(80))
    print("=" * 80)

    print("\n" + "=" * 80)
    print("NAIVE APPROACH: 2^10 = 1024".center(80))
    print("=" * 80)
    print()
    result_naive = power_naive(2, 10)
    print(f"\n✓ Result: 2^10 = {result_naive}")

    print("\n" + "=" * 80)
    print("OPTIMIZED APPROACH: 2^10 = 1024".center(80))
    print("=" * 80)
    print()
    result_opt = power_optimized(2, 10)
    print(f"\n✓ Result: 2^10 = {result_opt}")

    print("\n" + "=" * 80)
    print("PERFORMANCE COMPARISON".center(80))
    print("=" * 80)
    print(f"""
    NAIVE approach: O(n) - makes n recursive calls
        2^10: 10 calls
        2^20: 20 calls
        2^100: 100 calls

    OPTIMIZED approach: O(log n) - divides exponent by 2
        2^10: ~4 calls (log₂(10) ≈ 3.3)
        2^20: ~5 calls (log₂(20) ≈ 4.3)
        2^100: ~7 calls (log₂(100) ≈ 6.6)

    For large exponents, divide-and-conquer is MUCH faster!
    This is same technique used in matrix exponentiation and fast modular exponentiation.
    """)

    capacity_growth_forecast()

    print(f"\n" + "=" * 80)
    print("KEY CONCEPTS".center(80))
    print("=" * 80)
    print("""
    ✓ Naive recursion: linear progression (exponent - 1)
    ✓ Divide-and-conquer: logarithmic reduction (exponent / 2)
    ✓ Optimization reduces O(n) to O(log n) complexity
    ✓ This technique used in cryptography, big integer math, ML
    """)
