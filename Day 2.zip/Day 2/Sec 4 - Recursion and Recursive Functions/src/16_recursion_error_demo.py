"""
RecursionError Handling and Debugging

Business: Production systems must handle recursive errors gracefully

Learning: Error handling, debugging, preventing infinite recursion
"""

import sys
import traceback


def faulty_recursion_missing_base_case(n: int) -> int:
    """ERROR: Missing base case causes infinite recursion."""
    print(f"Recursing with n={n}")
    # MISSING BASE CASE - INFINITE RECURSION!
    return n + faulty_recursion_missing_base_case(n + 1)


def faulty_recursion_wrong_progress(n: int) -> int:
    """ERROR: Not making progress toward base case."""
    print(f"Recursing with n={n}")
    if n == 1000:  # Base case never reached for n < 1000
        return 1
    return n + faulty_recursion_wrong_progress(n + 1)


def correct_recursion(n: int) -> int:
    """CORRECT: Clear base case and progress."""
    print(f"Recursing with n={n}")
    if n <= 0:  # BASE CASE
        return 0
    return n + correct_recursion(n - 1)  # PROGRESS


def demonstrate_errors() -> None:
    """Demonstrate and catch recursion errors."""
    print("\n" + "=" * 80)
    print("RECURSION ERROR DEMONSTRATION".center(80))
    print("=" * 80)

    print("\n1. MISSING BASE CASE:")
    print("-" * 80)
    try:
        result = faulty_recursion_missing_base_case(1)
        print(f"Result: {result}")
    except RecursionError as e:
        print(f"✗ RecursionError caught!")
        print(f"  Message: {str(e)[:60]}...")
        print(f"  Cause: No base case to stop recursion")
        print(f"  Fix: Add 'if n >= LIMIT: return value'")

    print("\n2. NOT MAKING PROGRESS:")
    print("-" * 80)
    try:
        result = faulty_recursion_wrong_progress(1)
        print(f"Result: {result}")
    except RecursionError as e:
        print(f"✗ RecursionError caught!")
        print(f"  Message: {str(e)[:60]}...")
        print(f"  Cause: Base case unreachable (n never equals 1000)")
        print(f"  Fix: Change base case condition to match problem")

    print("\n3. CORRECT RECURSION:")
    print("-" * 80)
    try:
        result = correct_recursion(5)
        print(f"✓ Success! Result: {result}")
        print(f"  Base case reached when n <= 0")
        print(f"  Progress made: each call decreases n by 1")
    except RecursionError as e:
        print(f"✗ Unexpected error: {e}")


def error_handling_strategies() -> None:
    """Show strategies to handle recursion safely."""
    print("\n" + "=" * 80)
    print("ERROR HANDLING STRATEGIES".center(80))
    print("=" * 80)

    print("""
    STRATEGY 1: TRY-EXCEPT
    =====================
    try:
        result = recursive_function(large_input)
    except RecursionError:
        result = iterative_fallback(large_input)
        print("Switched to iterative due to recursion limit")

    Benefits: Graceful fallback to iteration
    Risk: May return different results or have different performance


    STRATEGY 2: DEPTH CHECKING
    ===========================
    def safe_recursion(n, depth=0, max_depth=900):
        if depth > max_depth:
            raise ValueError(f"Recursion too deep: {depth}")
        if base_case(n):
            return solution
        return safe_recursion(n-1, depth+1, max_depth)

    Benefits: Fails early with clear message
    Risk: May reject valid deep problems


    STRATEGY 3: ITERATIVE CONVERSION
    ================================
    def recursive_to_iterative(n):
        stack = [n]
        result = 0
        while stack:
            current = stack.pop()
            if base_case(current):
                result += base_value(current)
            else:
                stack.append(current - 1)
        return result

    Benefits: No recursion limit, faster
    Risk: More complex code


    STRATEGY 4: MEMOIZATION + RECURSION
    ====================================
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def optimized_recursion(n):
        if base_case(n):
            return solution
        return optimized_recursion(n-1)

    Benefits: Fewer recursive calls, faster
    Risk: Requires suitable subproblem structure
    """)


def debugging_recursive_errors() -> None:
    """Strategies to debug recursion issues."""
    print("\n" + "=" * 80)
    print("DEBUGGING RECURSIVE ERRORS".center(80))
    print("=" * 80)

    print("""
    DEBUG TECHNIQUE 1: PRINT STATEMENTS
    ===================================
    def debug_recursion(n, depth=0):
        print(f"{'  ' * depth}→ Called with n={n}, depth={depth}")
        if n <= 0:
            print(f"{'  ' * depth}  [BASE CASE] return 1")
            return 1
        result = n * debug_recursion(n-1, depth+1)
        print(f"{'  ' * depth}  ← return {result}")
        return result

    Shows: Exactly what the function does, call order, values


    DEBUG TECHNIQUE 2: TRACK DEPTH
    ==============================
    import sys
    def track_depth_recursion(n, depth=0):
        print(f"Depth: {depth}/{sys.getrecursionlimit()}")
        if depth > sys.getrecursionlimit() * 0.9:
            print("WARNING: Too deep!")
        # ... recursion ...

    Shows: How deep recursion goes, when approaching limit


    DEBUG TECHNIQUE 3: VALIDATE BASE CASE
    =====================================
    def test_base_cases():
        assert recursive_func(0) == expected_0
        assert recursive_func(1) == expected_1
        assert recursive_func(2) == expected_2
        # Test boundary conditions

    Shows: Base cases work correctly before testing recursion


    DEBUG TECHNIQUE 4: LIMIT TEST INPUT
    ===================================
    # Test with small input first
    try:
        result = recursive_func(5)  # Small input
        print(f"✓ Works for n=5: {result}")
    except RecursionError:
        print("✗ Fails even for small input - base case issue")

    # Then test progressively larger inputs
    for n in [10, 20, 50, 100]:
        try:
            result = recursive_func(n)
            print(f"✓ n={n}: {result}")
        except RecursionError:
            print(f"✗ n={n}: RecursionError - limit {sys.getrecursionlimit()}")
            break
    """)


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("RECURSION ERROR HANDLING AND DEBUGGING".center(80))
    print("Faulty Configuration Parser".center(80))
    print("=" * 80)

    demonstrate_errors()
    error_handling_strategies()
    debugging_recursive_errors()

    print("\n" + "=" * 80)
    print("CHECKLIST: AVOID RECURSION ERRORS".center(80))
    print("=" * 80)
    print("""
    ✓ BEFORE WRITING RECURSION:
      □ Clear base case exists
      □ Base case will definitely be reached
      □ Each call makes progress toward base case
      □ Input size will eventually match base case

    ✓ WHILE TESTING:
      □ Test with minimum input (edge cases)
      □ Test with small input (n=5, n=10)
      □ Test with medium input (n=50, n=100)
      □ Test with large input only if needed
      □ Verify base case is correct
      □ Monitor recursion depth

    ✓ IN PRODUCTION:
      □ Add error handling (try-except)
      □ Log recursion depth if possible
      □ Have iterative fallback
      □ Document depth requirements
      □ Monitor for RecursionError in logs
    """)
