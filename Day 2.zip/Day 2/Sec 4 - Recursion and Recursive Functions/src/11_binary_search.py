"""
Binary Search: Customer Record Lookup using Divide-and-Conquer

Business: Customer database search must quickly locate records in sorted list

Learning: Divide-and-conquer recursion, logarithmic complexity
"""

def binary_search_recursive(
    arr: list[int],
    target: int,
    low: int = 0,
    high: int = None,
    depth: int = 0
) -> int:
    """
    Recursively search for target in sorted array using binary search.
    Divides search space in half each call.
    Time: O(log n) - MUCH faster than linear O(n)
    """
    if high is None:
        high = len(arr) - 1

    indent = "  " * depth
    print(f"{indent}→ Search for {target} in arr[{low}:{high+1}] = {arr[low:high+1]}")

    if low > high:
        print(f"{indent}  ← [BASE CASE] Not found")
        return -1

    mid = (low + high) // 2
    mid_value = arr[mid]
    print(f"{indent}  Mid: arr[{mid}] = {mid_value}")

    if mid_value == target:
        print(f"{indent}  ← [FOUND] at index {mid}")
        return mid

    if mid_value > target:
        print(f"{indent}  {mid_value} > {target}, search left")
        return binary_search_recursive(arr, target, low, mid - 1, depth + 1)
    else:
        print(f"{indent}  {mid_value} < {target}, search right")
        return binary_search_recursive(arr, target, mid + 1, high, depth + 1)


def customer_lookup() -> None:
    """Search for customer ID in database."""
    print("\n" + "=" * 80)
    print("CUSTOMER RECORD LOOKUP".center(80))
    print("=" * 80)

    customer_ids = [1001, 1005, 1012, 1023, 1045, 1067, 1089, 1102, 1115, 1234]

    print(f"\nCustomer database (sorted): {customer_ids}")
    print(f"Total customers: {len(customer_ids)}\n")

    search_ids = [1023, 1000, 1115]

    for cid in search_ids:
        print(f"\nSearching for customer {cid}:")
        result = binary_search_recursive(customer_ids, cid)
        if result != -1:
            print(f"✓ Found at index {result}")
        else:
            print(f"✗ Customer not found")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("BINARY SEARCH: DIVIDE-AND-CONQUER".center(80))
    print("Customer Lookup System".center(80))
    print("=" * 80)

    arr = [10, 20, 30, 40, 50, 60, 70, 80, 90]
    target = 70

    print(f"\nSearching for {target} in {arr}:\n")
    result = binary_search_recursive(arr, target)
    print(f"\n✓ Result: {target} found at index {result}")

    customer_lookup()

    print(f"\n" + "=" * 80)
    print("COMPLEXITY ANALYSIS".center(80))
    print("=" * 80)
    print(f"""
    BINARY SEARCH vs LINEAR SEARCH:

    Array size: 1,000,000 customers

    LINEAR SEARCH (O(n)):
    - Worst case: 1,000,000 comparisons
    - Average: 500,000 comparisons
    - Time: ~1 second (slow!)

    BINARY SEARCH (O(log n)):
    - Worst case: 20 comparisons (log₂(1,000,000) ≈ 20)
    - Average: 10 comparisons
    - Time: <1 millisecond (FAST!)

    SPEEDUP: 50,000x faster!

    DIVIDE-AND-CONQUER STRATEGY:
    1. Find middle element
    2. Compare with target
    3. Eliminate half of remaining elements
    4. Recursively search remaining half
    5. Each call halves the search space → O(log n)
    """)
