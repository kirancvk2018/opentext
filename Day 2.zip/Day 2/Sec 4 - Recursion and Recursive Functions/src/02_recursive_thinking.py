"""
================================================================================
RECURSIVE THINKING: PROBLEM DECOMPOSITION
================================================================================

E-Commerce Product Category Navigation

PROBLEM STATEMENT
----------------
An online retailer organizes products in nested categories:
    Electronics/
    ├── Computers/
    │   ├── Laptops
    │   ├── Desktops
    │   └── Servers
    ├── Phones/
    │   ├── Smartphones
    │   └── Feature Phones
    └── Accessories/
        ├── Cases
        └── Chargers

A product search engine must find all products in a category and subcategories.

BUSINESS SCENARIO
----------------
E-commerce platform with user-defined category hierarchies. When a user
clicks "Electronics", they should see products from:
- Electronics directly
- All products in Computers subcategory
- All products in Phones subcategory
- Etc.

LEARNING OBJECTIVES
------------------
- Break problems into recursive and base cases
- Understand problem decomposition
- Recognize recursive structures in real data
- Think about subproblems, not implementation

SOLUTION OVERVIEW
-----------------
Key Insight: A category contains:
    1. Products directly in this category
    2. All products from child categories

This naturally decomposes recursively:
    find_products(category) =
        products_here +
        find_products(child_1) +
        find_products(child_2) +
        find_products(child_n)

Base Case: Leaf category with no children

Time Complexity: O(n) where n = total categories
Space Complexity: O(h) where h = depth of category tree
"""

from typing import Optional
from dataclasses import dataclass, field


# ============================================================================
# DATA MODEL
# ============================================================================

@dataclass
class Product:
    """Represents a single product."""
    product_id: str
    name: str
    price: float
    category: str


@dataclass
class Category:
    """
    Represents a product category with subcategories.

    This recursive data structure mirrors the problem: a category
    contains both products and child categories (same structure).
    """
    name: str
    products: list[Product] = field(default_factory=list)
    subcategories: list['Category'] = field(default_factory=list)

    def __repr__(self) -> str:
        return f"Category('{self.name}', products={len(self.products)}, subcategories={len(self.subcategories)})"


# ============================================================================
# RECURSIVE SOLUTION
# ============================================================================

def find_all_products(category: Category, depth: int = 0) -> list[Product]:
    """
    Recursively find all products in a category and its subcategories.

    WHY recursive:
        A category is a tree structure. Each category may contain
        subcategories (same structure). This recursion is natural.

    WHAT it does:
        1. Collect products from current category
        2. Recursively collect from each subcategory
        3. Return all products combined

    HOW it works:
        BASE CASE: Category with no subcategories (leaf node)
        RECURSIVE CASE: Combine products + recursive calls on subcategories

    Args:
        category: Category to search
        depth: Current recursion depth (for visualization)

    Returns:
        List of all products in category and subcategories
    """
    indent = "  " * depth

    # Display current level
    print(f"{indent}→ Searching category: {category.name}")
    print(f"{indent}  Products here: {len(category.products)}")

    # COLLECT PRODUCTS FROM THIS CATEGORY
    # This is the "base level" processing - happens at every recursion level
    all_products = list(category.products)

    # BASE CASE: Check if this category has any subcategories
    if not category.subcategories:
        # Leaf node - no children to process
        print(f"{indent}  ← [BASE CASE] No subcategories. Found {len(all_products)} products")
        return all_products

    # RECURSIVE CASE: Process each subcategory
    # For each child category, recursively find products
    print(f"{indent}  Subcategories to explore: {len(category.subcategories)}")

    for subcategory in category.subcategories:
        # RECURSIVE CALL - Process child category
        # This call will itself make recursive calls if children have children
        subcategory_products = find_all_products(subcategory, depth + 1)
        all_products.extend(subcategory_products)

    # Return total products from this level and all children
    total = len(all_products)
    print(f"{indent}  ← [RETURN] {category.name}: {total} total products")
    return all_products


# ============================================================================
# PROBLEM DECOMPOSITION EXPLANATION
# ============================================================================

def explain_decomposition() -> None:
    """
    Explain how to decompose a problem recursively.
    """
    print("\n" + "=" * 80)
    print("RECURSIVE PROBLEM DECOMPOSITION".center(80))
    print("=" * 80)

    print("""
    STEP 1: Identify the Recursive Structure
    =========================================
    Ask: "Does this problem contain smaller versions of itself?"

    Example - Product Categories:
        A category contains:
        - Direct products (data)
        - Subcategories (same structure!)

    Observation: Each subcategory is also a Category with the same
    structure. This is the KEY to recursion!


    STEP 2: Define the Base Case
    ============================
    Ask: "What is the simplest version? When can we stop?"

    Example - Product Categories:
        A leaf category (no subcategories) is simplest.
        We can directly return its products without recursion.

    Base Case Recognition:
        ✓ No children to process
        ✓ Problem size is zero or one
        ✓ Can be solved without recursion


    STEP 3: Define the Recursive Case
    =================================
    Ask: "How do we decompose this into smaller problems?"

    Example - Product Categories:
        For a category with subcategories:
        1. Get products directly in this category
        2. Recursively get products from each subcategory
        3. Combine all results

    Recursive Case Template:
        solve(problem) = solve_base_part(problem) +
                        solve(smaller_problem_1) +
                        solve(smaller_problem_2)


    STEP 4: Ensure Progress Toward Base Case
    ========================================
    Ask: "Does each recursive call move closer to base case?"

    Example - Product Categories:
        ✓ Each recursive call processes a child category
        ✓ Child has fewer items/levels than parent
        ✓ Eventually reaches leaf categories (base case)


    STEP 5: Combine Results Appropriately
    ====================================
    Ask: "How do we combine results from recursive calls?"

    Example - Product Categories:
        - Collect products from this level
        - Add products from all subcategories
        - Return total combined list

    Combination Strategies:
        ✓ Sum: total = this_value + sum(recursive_calls)
        ✓ Collect: results = this_items + [results from children]
        ✓ Process: apply operation recursively and combine
        ✓ Choose: select based on condition in recursive call
    """)


# ============================================================================
# COMPARISON: RECURSIVE VS ITERATIVE
# ============================================================================

def find_all_products_iterative(root_category: Category) -> list[Product]:
    """
    Find all products using iteration (stack-based).

    This shows the complexity hidden in recursion.
    The recursive version is much cleaner!
    """
    print("\n" + "=" * 80)
    print("ITERATIVE APPROACH (for comparison)".center(80))
    print("=" * 80)

    print("\nProcessing categories iteratively using a stack...")

    # Manual stack to track what to process
    stack = [root_category]
    all_products = []

    while stack:
        # Pop category from stack
        category = stack.pop()
        print(f"Processing: {category.name} ({len(category.products)} products)")

        # Add products from this category
        all_products.extend(category.products)

        # Add subcategories to stack for later processing
        # Must add in reverse order to process left-to-right
        for subcategory in reversed(category.subcategories):
            stack.append(subcategory)

    return all_products


# ============================================================================
# PRACTICAL EXAMPLE
# ============================================================================

def create_sample_category_tree() -> Category:
    """
    Create a sample product category tree.

    Represents:
        Electronics/
        ├── Computers/
        │   ├── Laptops
        │   └── Desktops
        ├── Phones/
        │   ├── Smartphones
        │   └── Feature Phones
        └── Accessories/
            ├── Cases
            └── Chargers
    """
    # Leaf categories with products
    laptops = Category(
        name="Laptops",
        products=[
            Product("L001", "MacBook Pro 16", 2499.99, "Laptops"),
            Product("L002", "Dell XPS 13", 1299.99, "Laptops"),
            Product("L003", "Lenovo ThinkPad", 1199.99, "Laptops"),
        ]
    )

    desktops = Category(
        name="Desktops",
        products=[
            Product("D001", "iMac 27", 1799.99, "Desktops"),
            Product("D002", "Dell Tower", 899.99, "Desktops"),
        ]
    )

    smartphones = Category(
        name="Smartphones",
        products=[
            Product("S001", "iPhone 15 Pro", 999.99, "Smartphones"),
            Product("S002", "Samsung Galaxy S24", 899.99, "Smartphones"),
            Product("S003", "Google Pixel 8", 799.99, "Smartphones"),
        ]
    )

    feature_phones = Category(
        name="Feature Phones",
        products=[
            Product("F001", "Nokia 3310 Reboot", 49.99, "Feature Phones"),
        ]
    )

    cases = Category(
        name="Cases",
        products=[
            Product("C001", "Phone Case", 19.99, "Cases"),
            Product("C002", "Laptop Case", 49.99, "Cases"),
        ]
    )

    chargers = Category(
        name="Chargers",
        products=[
            Product("CH001", "USB-C Charger", 29.99, "Chargers"),
            Product("CH002", "Wireless Charger", 39.99, "Chargers"),
        ]
    )

    # Mid-level categories
    computers = Category(
        name="Computers",
        subcategories=[laptops, desktops]
    )

    phones = Category(
        name="Phones",
        subcategories=[smartphones, feature_phones]
    )

    accessories = Category(
        name="Accessories",
        subcategories=[cases, chargers]
    )

    # Root category
    electronics = Category(
        name="Electronics",
        subcategories=[computers, phones, accessories]
    )

    return electronics


def demonstrate() -> None:
    """
    Demonstrate recursive problem decomposition.
    """
    print("\n" + "=" * 80)
    print("PRACTICAL DEMONSTRATION".center(80))
    print("=" * 80)

    # Create sample data
    root = create_sample_category_tree()

    # Recursive approach
    print("\n🔍 RECURSIVE APPROACH:")
    print("-" * 80)
    products_recursive = find_all_products(root)

    print(f"\n✓ Found {len(products_recursive)} products recursively:")
    for product in products_recursive:
        print(f"  - {product.name}: ${product.price:.2f}")

    # Iterative approach
    products_iterative = find_all_products_iterative(root)
    print(f"\n✓ Found {len(products_iterative)} products iteratively")

    # Verify both approaches found same products
    assert len(products_recursive) == len(products_iterative)
    print(f"\n✓ Both approaches found {len(products_recursive)} products")


# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================

def interview_questions() -> None:
    """
    Interview questions about recursive problem decomposition.
    """
    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS".center(80))
    print("=" * 80)

    questions = [
        {
            "Q": "How do you identify if a problem is recursively solvable?",
            "A": """
            Look for these patterns:

            1. SELF-SIMILAR STRUCTURE
               Does the problem contain smaller versions of itself?
               Examples: folders in folders, categories in categories, trees

            2. NATURAL DECOMPOSITION
               Can you break it into subproblems of the same type?
               Example: find_in_category = find_here + find_in_subcategories

            3. BASE CASE EXISTS
               Can you identify when to stop?
               Example: leaf categories (no children)

            4. PROGRESS TOWARD BASE
               Does each recursive call get smaller?
               Example: processing child instead of parent
            """
        },
        {
            "Q": "Explain the base case and recursive case for finding products.",
            "A": """
            BASE CASE:
            - Condition: Category has no subcategories (leaf node)
            - Action: Return only products directly in this category
            - Why: No need to go deeper - no children to explore

            RECURSIVE CASE:
            - Condition: Category has subcategories
            - Action: Combine this category's products + products from all children
            - How: Call find_products() on each subcategory

            Example:
                Electronics (has children)
                  → Combine:
                    - Products in Electronics
                    - find_products(Computers)  ← recursive call
                    - find_products(Phones)    ← recursive call
                    - find_products(Accessories) ← recursive call
            """
        },
        {
            "Q": "What makes recursion elegant for tree structures?",
            "A": """
            Tree structures are naturally recursive:
            - A tree is a node with children that are also trees
            - Recursive functions mirror this structure
            - Code directly expresses the problem structure

            Example:
                Iterative version: Manual stack, while loop, tracking visited
                Recursive version: Simple function calling itself

            Result: Recursive code is shorter, clearer, more maintainable
            """
        },
        {
            "Q": "How do you handle combining results from recursive calls?",
            "A": """
            Different strategies for different problems:

            1. AGGREGATION (Sum/Count)
               total = this_value + sum(recursive_results)

            2. COLLECTION (Combine into list)
               results = this_items + [from_child_1] + [from_child_2]

            3. PROCESSING (Transform and combine)
               result = apply_operation(recursive_results)

            4. SELECTION (Choose based on logic)
               result = child_1 if condition else child_2

            For products: We use COLLECTION (extend list with products)
            """
        },
        {
            "Q": "Why is the recursive version better than iterative here?",
            "A": """
            RECURSIVE advantages for tree traversal:

            1. CLARITY: Code structure matches problem structure
               Recursive: exactly mirrors category hierarchy
               Iterative: requires manual stack management

            2. CONCISENESS: Less code, fewer variables
               Recursive: ~15 lines
               Iterative: ~20 lines + stack logic

            3. NATURAL THINKING: Matches how you'd explain it
               "Find products in category and all subcategories"
               → find_products(cat) = products + find in subcats

            4. MAINTAINABILITY: Easier to modify/extend
               Add filtering? Just modify one place
               Handle special cases? One function

            Trade-off: Iterative is sometimes faster/uses less stack memory
            """
        }
    ]

    for i, qa in enumerate(questions, 1):
        print(f"\n❓ Question {i}: {qa['Q']}")
        print(f"{qa['A']}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("RECURSIVE THINKING: PROBLEM DECOMPOSITION".center(80))
    print("E-Commerce Product Category Navigation".center(80))
    print("=" * 80)

    # Explain decomposition
    explain_decomposition()

    # Practical demonstration
    demonstrate()

    # Interview questions
    interview_questions()

    # Summary
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS".center(80))
    print("=" * 80)
    print("""
    ✓ Identify recursive structure: problem contains smaller versions
    ✓ Base case: When to stop (leaf nodes)
    ✓ Recursive case: Decompose and combine results
    ✓ Ensure progress: Each call gets simpler
    ✓ Recursive is elegant for tree/hierarchical data
    ✓ Recursive code mirrors problem structure

    NEXT: See 03_base_and_recursive_case.py for deeper base/recursive analysis
    """)
