"""
================================================================================
INTRODUCTION TO RECURSION
================================================================================

Corporate Folder Hierarchy Traversal

PROBLEM STATEMENT
----------------
A corporate file server stores documents in a deep folder hierarchy:
    /company/
    ├── marketing/
    │   ├── campaigns/
    │   │   ├── 2024_q1/
    │   │   └── 2024_q2/
    │   └── reports/
    ├── engineering/
    │   ├── frontend/
    │   └── backend/
    └── finance/
        ├── budgets/
        └── invoices/

A file management system needs to count total files in all folders recursively.
Iterative traversal is complex (requires explicit stack). Recursion handles
this elegantly: each folder calls itself on subfolders.

BUSINESS SCENARIO
----------------
A company manages thousands of documents across nested department folders.
The system must:
- Traverse folders at unknown depth
- Count total files recursively
- Stop at leaf nodes (folders with no subfolders)
- Work for arbitrarily deep hierarchies

LEARNING OBJECTIVES
------------------
- Understand what recursion is
- Learn when recursion is useful
- Understand how recursion works (call stack)
- Recognize base case and recursive case
- Compare recursion vs iteration

SOLUTION OVERVIEW
-----------------
Why Recursion is Perfect Here:
    The folder structure is hierarchical. Each folder contains subfolders
    which themselves contain subfolders. This matches recursion perfectly:
    a function that processes a folder can call itself on each subfolder.

Base Case:
    "When do we stop recursing?"
    Stop when we reach a folder with no subfolders (leaf node).

Recursive Case:
    "What is the problem decomposition?"
    For each folder, process it, then recursively process all subfolders.

Time Complexity: O(n) where n = total number of folders
Space Complexity: O(h) where h = maximum folder depth (call stack)

Call Stack Example:
    main()
      └─> count_files("company")        [Depth 1]
          └─> count_files("marketing")  [Depth 2]
              └─> count_files("campaigns")  [Depth 3]
                  └─> (no subfolders - BASE CASE)
          └─> count_files("engineering")
          └─> count_files("finance")
"""

# ============================================================================
# IMPORTS
# ============================================================================

import os
from pathlib import Path
from typing import Optional


# ============================================================================
# CORE RECURSION EXAMPLE
# ============================================================================

def count_total_files(folder_path: str, depth: int = 0) -> int:
    """
    Recursively count total files in a folder and all subfolders.

    WHY this is recursive:
        Each folder may contain subfolders that also need to be counted.
        We don't know depth in advance, so we recursively process subfolders.

    WHAT this does:
        1. Counts files in current folder
        2. For each subfolder, recursively counts its files
        3. Returns total from this folder + all subfolders

    HOW this works:
        BASE CASE: If folder is empty or has no subfolders, return file count
        RECURSIVE CASE: Count current files + sum of recursive calls

    Args:
        folder_path: Path to folder to analyze
        depth: Current recursion depth (for visualization)

    Returns:
        Total number of files in folder and all subfolders
    """
    # Display current recursion depth
    indent = "  " * depth

    # RECURSIVE STRATEGY: Process one folder at a time
    try:
        # Get all items in this folder
        items = os.listdir(folder_path)

        # Count files in current folder
        files_here = sum(1 for item in items if os.path.isfile(os.path.join(folder_path, item)))

        print(f"{indent}→ Folder: {os.path.basename(folder_path) or folder_path}")
        print(f"{indent}  Files here: {files_here}")

        # Find subfolders that need recursive processing
        subfolders = [
            os.path.join(folder_path, item)
            for item in items
            if os.path.isdir(os.path.join(folder_path, item))
        ]

        # BASE CASE: If no subfolders, return only files in this folder
        if not subfolders:
            print(f"{indent}  ← [BASE CASE] No subfolders. Total files: {files_here}")
            return files_here

        # RECURSIVE CASE: Process each subfolder recursively
        total_from_subfolders = 0
        for subfolder in subfolders:
            # RECURSIVE CALL: This function calls itself on subfolders
            subfolder_total = count_total_files(subfolder, depth + 1)
            total_from_subfolders += subfolder_total

        total = files_here + total_from_subfolders
        print(f"{indent}  ← [RETURN] Total files in {os.path.basename(folder_path) or folder_path}: {total}")
        return total

    except PermissionError:
        print(f"{indent}  ✗ Permission denied: {folder_path}")
        return 0
    except Exception as e:
        print(f"{indent}  ✗ Error: {e}")
        return 0


# ============================================================================
# DEMONSTRATION: RECURSION VS ITERATION
# ============================================================================

def explain_recursion_vs_iteration() -> None:
    """
    Explain the difference between recursive and iterative approaches.
    """
    print("\n" + "=" * 80)
    print("RECURSION VS ITERATION".center(80))
    print("=" * 80)

    print("\n📌 RECURSIVE APPROACH (used above):")
    print("""
    def count_recursively(folder):
        files = count files in folder
        if no subfolders:              # BASE CASE
            return files
        else:                          # RECURSIVE CASE
            for each subfolder:
                files += count_recursively(subfolder)
            return files

    ✓ Advantages:
      - Elegant: matches problem structure (nested folders)
      - Concise: no explicit stack management
      - Natural: mirrors mathematical definition
      - Readable: clear base and recursive cases

    ✗ Disadvantages:
      - Stack usage: one call per folder depth
      - Slower: function call overhead
      - Limited depth: recursion limit in Python
    """)

    print("\n📌 ITERATIVE APPROACH (alternative):")
    print("""
    def count_iteratively(start_folder):
        stack = [start_folder]
        total_files = 0

        while stack:                   # Process all folders
            folder = stack.pop()
            files = count files in folder
            total_files += files

            for each subfolder:
                stack.append(subfolder)  # Add for later processing

        return total_files

    ✓ Advantages:
      - Fast: minimal function call overhead
      - Unlimited: no recursion depth limit
      - Memory: stack is on heap (more space)

    ✗ Disadvantages:
      - Complex: requires explicit stack management
      - Verbose: more code
      - Harder to understand: manual stack tracking
    """)


# ============================================================================
# CALL STACK VISUALIZATION
# ============================================================================

def visualize_call_stack() -> None:
    """
    Explain how the call stack works with recursion.
    """
    print("\n" + "=" * 80)
    print("CALL STACK EXPLANATION".center(80))
    print("=" * 80)

    print("""
    When count_total_files() is called, Python creates a "stack frame" for each call.
    Stack frames remember local variables and return values.

    Example: Folder structure with 3 levels
        company/
        ├── marketing/
        │   └── campaigns/
        └── engineering/

    EXECUTION FLOW (with call stack):

    1. count_total_files("company")     [Frame 1 created]
       Stack: [count("company")]

       ├─> count_total_files("marketing")  [Frame 2 created]
           Stack: [count("company"), count("marketing")]

           └─> count_total_files("campaigns")  [Frame 3 created]
               Stack: [count("company"), count("marketing"), count("campaigns")]

               ✓ BASE CASE: no subfolders
               └─> return 5 files  [Frame 3 destroyed]
               Stack: [count("company"), count("marketing")]

           ✓ return 5 + 10 = 15  [Frame 2 destroyed]
           Stack: [count("company")]

       ├─> count_total_files("engineering")  [Frame 4 created]
           Stack: [count("company"), count("engineering")]
           ✓ return 8 files  [Frame 4 destroyed]
           Stack: [count("company")]

       ✓ return 15 + 8 + 3 = 26  [Frame 1 destroyed]
       Stack: []

    KEY INSIGHT:
    - Each recursive call adds a new frame to the stack
    - Frames are removed when functions return
    - Deep recursion = large stack = more memory
    - Python limits recursion depth to prevent stack overflow

    Stack Memory Usage:
    - Each frame stores: local variables, return address, parameters
    - Shallow recursion (< 100 levels): negligible overhead
    - Deep recursion (> 1000 levels): warning sign
    - Extremely deep (> 3000 levels): RecursionError in Python
    """)


# ============================================================================
# PRACTICAL EXAMPLE: SMALL FOLDER STRUCTURE
# ============================================================================

def demonstrate_with_sample_folders() -> None:
    """
    Create sample folder structure and demonstrate recursion.
    """
    print("\n" + "=" * 80)
    print("PRACTICAL DEMONSTRATION".center(80))
    print("=" * 80)

    print("\n📁 Creating sample folder structure for demonstration...")

    # Create temporary folder structure
    base_path = "sample_company_folders"

    try:
        # Create folder structure
        folders_to_create = [
            f"{base_path}",
            f"{base_path}/marketing",
            f"{base_path}/marketing/campaigns",
            f"{base_path}/marketing/campaigns/q1",
            f"{base_path}/marketing/campaigns/q2",
            f"{base_path}/marketing/reports",
            f"{base_path}/engineering",
            f"{base_path}/engineering/frontend",
            f"{base_path}/engineering/backend",
            f"{base_path}/finance",
            f"{base_path}/finance/budgets",
            f"{base_path}/finance/invoices",
        ]

        # Create directories
        for folder in folders_to_create:
            Path(folder).mkdir(parents=True, exist_ok=True)

        # Create sample files
        files_to_create = [
            f"{base_path}/marketing/campaigns/q1/campaign_budget.txt",
            f"{base_path}/marketing/campaigns/q1/creative_brief.txt",
            f"{base_path}/marketing/campaigns/q2/strategy.txt",
            f"{base_path}/marketing/reports/monthly_report.xlsx",
            f"{base_path}/engineering/frontend/component_library.md",
            f"{base_path}/engineering/frontend/design_system.md",
            f"{base_path}/engineering/backend/api_docs.md",
            f"{base_path}/engineering/backend/deployment_guide.md",
            f"{base_path}/finance/budgets/2024_budget.xlsx",
            f"{base_path}/finance/invoices/invoice_001.pdf",
            f"{base_path}/finance/invoices/invoice_002.pdf",
        ]

        for file_path in files_to_create:
            Path(file_path).touch()

        print(f"✓ Created folder structure at: {base_path}")

        # Run recursive count
        print(f"\n🔍 Recursively traversing folder structure...\n")
        total_files = count_total_files(base_path)

        print(f"\n{'=' * 80}")
        print(f"✓ TOTAL FILES FOUND: {total_files}".center(80))
        print(f"{'=' * 80}\n")

    except Exception as e:
        print(f"Error creating sample folders: {e}")

    finally:
        # Cleanup (optional - comment out to inspect folders)
        print("\n🧹 Cleaning up sample folders...")
        import shutil
        try:
            shutil.rmtree(base_path, ignore_errors=True)
            print(f"✓ Removed {base_path}")
        except Exception as e:
            print(f"Note: Could not clean up folders: {e}")


# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================

def interview_questions() -> None:
    """
    Five interview questions about recursion.
    """
    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS".center(80))
    print("=" * 80)

    questions = [
        {
            "Q": "What is recursion and when is it useful?",
            "A": """
            Recursion is when a function calls itself to solve a smaller instance
            of the same problem. It's useful for:
            - Hierarchical data (trees, folders, organization charts)
            - Divide-and-conquer problems
            - Backtracking algorithms
            - Problems matching mathematical definitions

            Key: Every recursion needs a BASE CASE (when to stop) and a RECURSIVE
            CASE (how to make progress toward the base case).
            """
        },
        {
            "Q": "What's the difference between base case and recursive case?",
            "A": """
            Base Case: The stopping condition. When the problem is small enough
            to solve directly without further recursion. Example: empty folder.

            Recursive Case: Breaks the problem into smaller pieces and calls
            the function on each piece. Example: process each subfolder.

            Without a base case → infinite recursion → RecursionError
            Without progress toward base case → infinite recursion
            """
        },
        {
            "Q": "Explain the call stack in recursion.",
            "A": """
            Each function call creates a "stack frame" storing:
            - Local variables
            - Parameters
            - Return address

            Stack frames are added when functions are called, removed when
            they return. With recursion:
            - First call goes on stack
            - Recursive calls keep adding frames
            - Base case returns (frame removed)
            - Frames removed in reverse order (LIFO - Last In First Out)

            Deep recursion = many frames = more memory
            """
        },
        {
            "Q": "When should you use recursion vs iteration?",
            "A": """
            Use Recursion When:
            - Problem is inherently recursive (trees, folders)
            - Code clarity is paramount
            - Problem depth is small (< 100 levels)
            - Divide-and-conquer is natural

            Use Iteration When:
            - Simple loops
            - Very deep recursion needed (> 1000 levels)
            - Performance is critical
            - Stack memory is limited

            Many problems can use either - choose based on clarity vs performance.
            """
        },
        {
            "Q": "What happens if you forget the base case?",
            "A": """
            The function will call itself infinitely, adding frames to the
            call stack until Python's recursion limit is reached, causing:

            RecursionError: maximum recursion depth exceeded

            To prevent this:
            1. Always define a clear base case
            2. Ensure each recursive call makes progress toward base case
            3. Test with edge cases (empty input, single element)
            4. Set recursion limit: sys.getrecursionlimit()
            """
        }
    ]

    for i, qa in enumerate(questions, 1):
        print(f"\n❓ Question {i}: {qa['Q']}")
        print(f"{qa['A']}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("INTRODUCTION TO RECURSION".center(80))
    print("Corporate Folder Hierarchy Traversal".center(80))
    print("=" * 80)

    # Explain recursion vs iteration
    explain_recursion_vs_iteration()

    # Visualize call stack
    visualize_call_stack()

    # Practical demonstration
    demonstrate_with_sample_folders()

    # Interview questions
    interview_questions()

    # Learning summary
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS".center(80))
    print("=" * 80)
    print("""
    ✓ Recursion: Function calling itself to solve smaller problems
    ✓ Base Case: When to stop (folder with no subfolders)
    ✓ Recursive Case: How to decompose (process each subfolder)
    ✓ Call Stack: Each call adds a frame, removed when returning
    ✓ Use When: Hierarchical data, elegant solution needed
    ✓ Avoid When: Simple loops, very deep recursion required

    NEXT: See 02_recursive_thinking.py for recursive problem decomposition
    """)
