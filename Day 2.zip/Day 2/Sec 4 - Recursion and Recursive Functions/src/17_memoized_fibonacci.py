"""
Memoized Fibonacci: Performance Optimization

Business: Financial forecasting needs efficient Fibonacci calculations

Learning: Memoization pattern, functools.lru_cache, performance measurement
"""

import time
from functools import lru_cache


# ============================================================================
# IMPLEMENTATIONS
# ============================================================================

def fibonacci_naive(n: int) -> int:
    """Naive recursion: O(2^n) - SLOW"""
    if n <= 1:
        return n
    return fibonacci_naive(n - 1) + fibonacci_naive(n - 2)


@lru_cache(maxsize=None)
def fibonacci_cached(n: int) -> int:
    """Memoized with @lru_cache: O(n) - FAST"""
    if n <= 1:
        return n
    return fibonacci_cached(n - 1) + fibonacci_cached(n - 2)


# Manual memoization
def fibonacci_memo(n: int, memo: dict = None) -> int:
    """Memoized manually: O(n) - FAST"""
    if memo is None:
        memo = {}

    if n in memo:
        return memo[n]

    if n <= 1:
        return n

    memo[n] = fibonacci_memo(n - 1, memo) + fibonacci_memo(n - 2, memo)
    return memo[n]


def fibonacci_iterative(n: int) -> int:
    """Iterative: O(n) - FASTEST"""
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


# ============================================================================
# PERFORMANCE TESTING
# ============================================================================

def compare_approaches() -> None:
    """Compare all approaches."""
    print("\n" + "=" * 80)
    print("MEMOIZATION PERFORMANCE COMPARISON".center(80))
    print("=" * 80)

    test_cases = [10, 20, 25, 30, 35, 40]

    print(f"\n{'N':<5} {'Naive (ms)':<15} {'Memo (ms)':<15} {'Speedup':<10}")
    print("-" * 60)

    for n in test_cases:
        # Naive (skip for large n)
        if n <= 25:
            start = time.perf_counter()
            result_naive = fibonacci_naive(n)
            time_naive = (time.perf_counter() - start) * 1000
        else:
            result_naive = None
            time_naive = float('inf')

        # Memoized
        fibonacci_cached.cache_clear()
        start = time.perf_counter()
        result_memo = fibonacci_cached(n)
        time_memo = (time.perf_counter() - start) * 1000

        # Iterative
        start = time.perf_counter()
        result_iter = fibonacci_iterative(n)
        time_iter = (time.perf_counter() - start) * 1000

        if time_naive < float('inf'):
            speedup = time_naive / time_memo
            print(f"{n:<5} {time_naive:<15.4f} {time_memo:<15.4f} {speedup:<10.1f}x")
        else:
            print(f"{n:<5} {'SLOW':<15} {time_memo:<15.4f} {'N/A':<10}")

    print("\nNote: Naive recursion becomes impractically slow after n=25")


def cache_statistics() -> None:
    """Show caching statistics."""
    print("\n" + "=" * 80)
    print("CACHE STATISTICS".center(80))
    print("=" * 80)

    print("\nCalculating fib(30) with memoization...")
    fibonacci_cached.cache_clear()

    start = time.perf_counter()
    result = fibonacci_cached(30)
    elapsed = time.perf_counter() - start

    # Get cache info
    cache_info = fibonacci_cached.cache_info()

    print(f"\nResult: fib(30) = {result}")
    print(f"Time: {elapsed * 1000:.4f} ms")
    print(f"\nCache Statistics:")
    print(f"  Hits: {cache_info.hits}")
    print(f"  Misses: {cache_info.misses}")
    print(f"  Hit rate: {cache_info.hits / (cache_info.hits + cache_info.misses) * 100:.1f}%")
    print(f"  Cache size: {cache_info.currsize}")

    print(f"\nInterpretation:")
    print(f"  - {cache_info.misses} new values computed")
    print(f"  - {cache_info.hits} values reused from cache")
    print(f"  - {cache_info.hits / cache_info.misses:.1f}x more cache hits than computations")


def financial_forecast() -> None:
    """Apply Fibonacci to financial forecasting."""
    print("\n" + "=" * 80)
    print("FINANCIAL FORECASTING APPLICATION".center(80))
    print("=" * 80)

    print("\nRevenue growth following Fibonacci pattern:")
    print(f"{'Month':<10} {'Revenue':<20} {'Growth':<15}")
    print("-" * 50)

    for month in range(1, 13):
        fib_val = fibonacci_cached(month)
        revenue = 1000 * fib_val
        if month == 1:
            growth = "Baseline"
        else:
            prev_fib = fibonacci_cached(month - 1)
            growth = f"+{((fib_val - prev_fib) / prev_fib * 100):.1f}%"

        print(f"{month:<10} ${revenue:>18,} {growth:>15}")

    print(f"\nNote: Each month = sum of previous two months' revenues")
    print(f"This Fibonacci pattern shows accelerating growth")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("MEMOIZED FIBONACCI".center(80))
    print("Financial Forecasting".center(80))
    print("=" * 80)

    # Performance comparison
    compare_approaches()

    # Cache statistics
    cache_statistics()

    # Financial application
    financial_forecast()

    print("\n" + "=" * 80)
    print("MEMOIZATION PATTERNS".center(80))
    print("=" * 80)
    print(f"""
    PATTERN 1: @lru_cache DECORATOR (Recommended)
    ==============================================
    from functools import lru_cache

    @lru_cache(maxsize=None)  # None = unlimited cache
    def fibonacci(n):
        if n <= 1:
            return n
        return fibonacci(n-1) + fibonacci(n-2)

    Pros:
    - Simple, clean syntax
    - Thread-safe
    - Built-in cache info: cache_info(), cache_clear()
    - Handles multiple arguments

    Cons:
    - Returns must be hashable
    - Binds to specific function


    PATTERN 2: MANUAL DICT CACHE
    =============================
    def fibonacci(n, memo=None):
        if memo is None:
            memo = {{}}

        if n in memo:
            return memo[n]

        if n <= 1:
            return n

        memo[n] = fibonacci(n-1, memo) + fibonacci(n-2, memo)
        return memo[n]

    Pros:
    - Full control over cache
    - Educational
    - Custom cache logic

    Cons:
    - More boilerplate
    - Must pass memo through calls


    PATTERN 3: CLASS-BASED CACHING
    ==============================
    class MemoizedFibonacci:
        def __init__(self):
            self.cache = {{}}

        def calculate(self, n):
            if n in self.cache:
                return self.cache[n]
            if n <= 1:
                return n
            self.cache[n] = self.calculate(n-1) + self.calculate(n-2)
            return self.cache[n]

    Pros:
    - Object-oriented
    - Maintains state
    - Multiple instances possible

    Cons:
    - More code
    - Less elegant


    WHEN TO USE MEMOIZATION:
    ========================
    ✓ Overlapping subproblems (like Fibonacci)
    ✓ Expensive calculations that repeat
    ✓ Recursive algorithms with repeated work
    ✓ Dynamic programming solutions

    ✗ Avoid when:
    ✗ No overlapping subproblems
    ✗ Memory is severely limited
    ✗ Results are not deterministic
    ✗ Cache invalidation is complex
    """)

    print("\nNEXT STEPS:")
    print("  - Use @lru_cache for production code")
    print("  - Profile recursion to find slow spots")
    print("  - Consider iterative alternatives for very deep problems")
    print("  - Document cache behavior and limitations")
