"""
Recursive Configuration Loader: Enterprise Pattern

Business: System needs to load nested JSON configuration files recursively,
validate them recursively, and process them recursively

Learning: Real-world enterprise recursive pattern combining multiple techniques
"""

import json
from pathlib import Path
from typing import Any, Dict
from dataclasses import dataclass


@dataclass
class ConfigNode:
    """Represents a configuration node."""
    name: str
    value: Any = None
    children: Dict[str, 'ConfigNode'] = None

    def __post_init__(self):
        if self.children is None:
            self.children = {}


def load_config_file(file_path: str) -> Dict[str, Any]:
    """Load JSON configuration file."""
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"✗ Error loading {file_path}: {e}")
        return {}


def validate_config(config: Dict[str, Any], depth: int = 0) -> bool:
    """
    Recursively validate configuration structure.
    Check for required keys, valid values, etc.
    """
    indent = "  " * depth
    print(f"{indent}→ Validating configuration")

    if not isinstance(config, dict):
        print(f"{indent}  ✗ Invalid: not a dictionary")
        return False

    required_keys = ['name', 'type']
    for key in required_keys:
        if key not in config:
            print(f"{indent}  ✗ Missing required key: {key}")
            return False

    # Recursively validate children
    if 'children' in config and isinstance(config['children'], list):
        print(f"{indent}  → Validating {len(config['children'])} children")
        for child in config['children']:
            if not validate_config(child, depth + 1):
                return False

    print(f"{indent}  ← ✓ Valid configuration")
    return True


def load_recursive_config(
    config_data: Dict[str, Any],
    parent_name: str = "root",
    depth: int = 0
) -> ConfigNode:
    """
    Recursively load configuration into tree structure.
    Converts nested dict to ConfigNode tree.
    """
    indent = "  " * depth
    print(f"{indent}→ Loading: {parent_name}")

    node = ConfigNode(
        name=config_data.get('name', parent_name),
        value=config_data.get('value')
    )

    # BASE CASE: No children
    if 'children' not in config_data or not config_data['children']:
        print(f"{indent}  ← [LEAF] {node.name}")
        return node

    # RECURSIVE CASE: Load each child
    print(f"{indent}  {len(config_data['children'])} children to load")
    for child_data in config_data['children']:
        child_node = load_recursive_config(child_data, depth + 1)
        node.children[child_node.name] = child_node

    print(f"{indent}  ← {node.name} loaded with {len(node.children)} children")
    return node


def process_config(node: ConfigNode, depth: int = 0) -> Dict[str, Any]:
    """
    Recursively process configuration tree.
    Apply transformations, gather metrics, etc.
    """
    indent = "  " * depth
    print(f"{indent}→ Processing: {node.name}")

    result = {
        'name': node.name,
        'value': node.value,
        'child_count': len(node.children),
    }

    # BASE CASE: Leaf node
    if not node.children:
        print(f"{indent}  ← [LEAF] {node.name}")
        return result

    # RECURSIVE CASE: Process children
    children_results = {}
    for child_name, child_node in node.children.items():
        children_results[child_name] = process_config(child_node, depth + 1)

    result['children'] = children_results
    print(f"{indent}  ← {node.name} processed")
    return result


def demonstrate_config_loader() -> None:
    """Demonstrate configuration loader with sample data."""
    print("\n" + "=" * 80)
    print("CONFIGURATION LOADING DEMONSTRATION".center(80))
    print("=" * 80)

    # Create sample configuration data
    sample_config = {
        "name": "Application",
        "type": "app",
        "value": "MyApp v1.0",
        "children": [
            {
                "name": "Database",
                "type": "service",
                "value": "PostgreSQL",
                "children": [
                    {
                        "name": "Connection Pool",
                        "type": "config",
                        "value": "max_connections=100",
                    },
                    {
                        "name": "Replication",
                        "type": "config",
                        "value": "enabled=true",
                    }
                ]
            },
            {
                "name": "API",
                "type": "service",
                "value": "REST",
                "children": [
                    {
                        "name": "Authentication",
                        "type": "config",
                        "value": "jwt_enabled=true",
                    },
                    {
                        "name": "Rate Limiting",
                        "type": "config",
                        "value": "requests_per_minute=1000",
                    }
                ]
            }
        ]
    }

    print("\n1. VALIDATING CONFIGURATION:")
    print("-" * 80)
    is_valid = validate_config(sample_config)
    print(f"\nValidation result: {'✓ VALID' if is_valid else '✗ INVALID'}\n")

    if is_valid:
        print("2. LOADING CONFIGURATION:")
        print("-" * 80)
        config_tree = load_recursive_config(sample_config)

        print("\n3. PROCESSING CONFIGURATION:")
        print("-" * 80)
        processed = process_config(config_tree)

        print("\n4. PROCESSED CONFIGURATION STRUCTURE:")
        print("-" * 80)
        print(json.dumps(processed, indent=2))


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("RECURSIVE CONFIGURATION LOADER".center(80))
    print("Enterprise Configuration Management".center(80))
    print("=" * 80)

    demonstrate_config_loader()

    print("\n" + "=" * 80)
    print("ENTERPRISE RECURSION PATTERNS".center(80))
    print("=" * 80)
    print(f"""
    PATTERN 1: VALIDATION
    =====================
    Recursively validate nested structures:
    - Check each level
    - Recursively check children
    - Collect all validation errors
    - Return true/false for entire tree

    Example: JSON schema validation


    PATTERN 2: TRANSFORMATION
    ==========================
    Convert one nested structure to another:
    - Parse JSON → build tree
    - Transform tree → apply rules
    - Flatten tree → output format

    Example: Configuration normalization


    PATTERN 3: AGGREGATION
    ======================
    Calculate metrics across tree:
    - Count nodes
    - Sum values
    - Find max/min depth
    - Collect all leaf values

    Example: Configuration inventory


    PATTERN 4: TRAVERSAL
    ====================
    Visit every node in tree:
    - Preorder: parent before children
    - Postorder: children before parent
    - Apply action at each node

    Example: Apply configuration patches


    BEST PRACTICES
    ==============
    ✓ Separate validation from processing
    ✓ Handle errors gracefully
    ✓ Limit recursion depth for safety
    ✓ Add progress indicators for large configs
    ✓ Cache results if processing expensive
    ✓ Document recursion requirements
    ✓ Test with realistic nested depth

    APPLICATIONS IN PRODUCTION
    ==========================
    - Infrastructure as Code (Terraform, Ansible)
    - Microservices configuration
    - Cloud resource hierarchies
    - XML/JSON document processing
    - Permission/policy evaluation
    - Dependency resolution
    - Build system processing
    """)

    print("\nRECURSION PROJECT COMPLETE!")
    print("You've learned 18 different recursion patterns and applications.")
    print("Ready for technical interviews and production recursion problems!")
