"""
Directory Traversal: Enterprise Backup Utility

Business: Backup system must recursively traverse all folders and files,
count them, and calculate total size

Learning: Real-world file system recursion, practical application
"""

import os
from pathlib import Path
from typing import Tuple


def traverse_directory(
    path: str,
    depth: int = 0
) -> Tuple[int, int, int]:
    """
    Recursively traverse directory tree.
    Returns: (folder_count, file_count, total_size)
    """
    indent = "  " * depth

    try:
        items = os.listdir(path)
    except PermissionError:
        print(f"{indent}✗ Permission denied")
        return 0, 0, 0

    folders = 0
    files = 0
    size = 0

    folder_name = os.path.basename(path) or path
    print(f"{indent}📁 {folder_name}/")

    for item in items:
        item_path = os.path.join(path, item)

        if os.path.isdir(item_path):
            # Recursive call for subdirectories
            subfolders, subfiles, subsize = traverse_directory(item_path, depth + 1)
            folders += subfolders + 1
            files += subfiles
            size += subsize
        else:
            # File processing
            try:
                file_size = os.path.getsize(item_path)
                size += file_size
                files += 1
                print(f"{indent}  📄 {item} ({file_size} bytes)")
            except OSError:
                pass

    return folders, files, size


def demonstrate_backup() -> None:
    """Demonstrate backup on sample folder structure."""
    print("\n" + "=" * 80)
    print("BACKUP ANALYSIS".center(80))
    print("=" * 80)

    base_path = "sample_backup_data"

    try:
        # Create sample structure
        folders = [
            base_path,
            f"{base_path}/documents",
            f"{base_path}/documents/reports",
            f"{base_path}/documents/proposals",
            f"{base_path}/images",
            f"{base_path}/images/photos",
            f"{base_path}/archives",
        ]

        for folder in folders:
            Path(folder).mkdir(parents=True, exist_ok=True)

        # Create sample files
        files_create = [
            (f"{base_path}/README.txt", "Project information"),
            (f"{base_path}/documents/report_2024.pdf", "x" * 50000),
            (f"{base_path}/documents/reports/q1_report.xlsx", "x" * 30000),
            (f"{base_path}/documents/reports/q2_report.xlsx", "x" * 35000),
            (f"{base_path}/documents/proposals/proposal_001.docx", "x" * 20000),
            (f"{base_path}/images/logo.png", "x" * 100000),
            (f"{base_path}/images/photos/photo_001.jpg", "x" * 250000),
            (f"{base_path}/images/photos/photo_002.jpg", "x" * 280000),
            (f"{base_path}/archives/archive_2023.zip", "x" * 1000000),
        ]

        for file_path, content in files_create:
            Path(file_path).write_text(content)

        print(f"\nTraversing: {base_path}\n")
        folders_count, files_count, total_size = traverse_directory(base_path)

        print(f"\n{'=' * 80}")
        print(f"BACKUP SUMMARY".center(80))
        print(f"{'=' * 80}")
        print(f"Folders found: {folders_count}")
        print(f"Files found: {files_count}")
        print(f"Total size: {total_size:,} bytes ({total_size / 1024 / 1024:.2f} MB)")

    finally:
        # Cleanup
        import shutil
        try:
            shutil.rmtree(base_path, ignore_errors=True)
        except:
            pass


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("DIRECTORY TRAVERSAL: BACKUP UTILITY".center(80))
    print("Enterprise File System Recursion".center(80))
    print("=" * 80)

    demonstrate_backup()

    print(f"\n" + "=" * 80)
    print("ALGORITHM EXPLANATION".center(80))
    print("=" * 80)
    print(f"""
    RECURSIVE DIRECTORY TRAVERSAL:

    traverse(directory):
        For each item in directory:
            If item is folder:
                Recursively traverse that folder
                Accumulate results
            If item is file:
                Count file
                Add file size
        Return accumulated totals

    BASE CASE:
    - Empty directory (no items to process)
    - File encountered (no recursion needed)

    RECURSIVE CASE:
    - Subdirectory found
    - Call traverse on that subdirectory
    - Add its results to totals

    APPLICATIONS:
    - Backup utilities
    - Disk space analyzers
    - File search tools
    - Cleanup/deduplication
    - Cloud sync systems
    """)
