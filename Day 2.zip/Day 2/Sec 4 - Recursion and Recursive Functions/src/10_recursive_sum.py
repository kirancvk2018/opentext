"""
Recursive Sum: Sales Aggregation Across Regional Hierarchies

Business: Sales reporting system aggregates revenue recursively through
regional hierarchy: World → Regions → Countries → Cities → Stores

Learning: Recursive aggregation across nested structures
"""

from dataclasses import dataclass

@dataclass
class SalesRegion:
    """Represents a regional sales node."""
    name: str
    sales: float = 0.0  # Sales at this level
    children: list['SalesRegion'] = None

    def __post_init__(self):
        if self.children is None:
            self.children = []


def calculate_total_sales(region: SalesRegion, depth: int = 0) -> float:
    """Recursively calculate total sales for region and all subregions."""
    indent = "  " * depth
    print(f"{indent}→ {region.name}: ${region.sales:,.2f}")

    if not region.children:
        print(f"{indent}  ← [BASE CASE] Leaf region. Total: ${region.sales:,.2f}")
        return region.sales

    total = region.sales
    print(f"{indent}  Subregions to process: {len(region.children)}")

    for child in region.children:
        child_total = calculate_total_sales(child, depth + 1)
        total += child_total

    print(f"{indent}  ← {region.name} total: ${total:,.2f}")
    return total


def create_sales_hierarchy() -> SalesRegion:
    """Create sample regional sales hierarchy."""
    # North America cities
    ny = SalesRegion("New York Store", 50000)
    la = SalesRegion("Los Angeles Store", 45000)
    chicago = SalesRegion("Chicago Store", 35000)

    usa = SalesRegion("USA", children=[
        SalesRegion("Northeast", children=[ny]),
        SalesRegion("West", children=[la]),
        SalesRegion("Midwest", children=[chicago]),
    ])

    # Europe
    london = SalesRegion("London Store", 40000)
    paris = SalesRegion("Paris Store", 38000)
    europe = SalesRegion("Europe", children=[
        SalesRegion("UK", children=[london]),
        SalesRegion("France", children=[paris]),
    ])

    # Asia
    tokyo = SalesRegion("Tokyo Store", 55000)
    asia = SalesRegion("Asia", children=[
        SalesRegion("Japan", children=[tokyo]),
    ])

    world = SalesRegion("World Headquarters", children=[usa, europe, asia])
    return world


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("RECURSIVE SUM: SALES AGGREGATION".center(80))
    print("Regional Hierarchy Processing".center(80))
    print("=" * 80)

    hierarchy = create_sales_hierarchy()
    print("\nCalculating total sales recursively:\n")
    total = calculate_total_sales(hierarchy)

    print(f"\n{'=' * 80}")
    print(f"TOTAL WORLDWIDE SALES: ${total:,.2f}".center(80))
    print(f"{'=' * 80}\n")

    print(f"""
    RECURSIVE AGGREGATION PATTERN:
    ==============================
    sum(region) = region.sales + sum(all children)

    BASE CASE:
    - Leaf region (no children)
    - Return only its sales

    RECURSIVE CASE:
    - Sum this region's sales
    - Plus recursive sum of all children
    - Return total

    BUSINESS BENEFITS:
    - Automatic aggregation through hierarchy
    - Add new regions easily (adds to parent)
    - Scalable to any depth
    - Clean, maintainable code
    """)
