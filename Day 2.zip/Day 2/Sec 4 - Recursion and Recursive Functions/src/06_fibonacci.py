"""
================================================================================
FIBONACCI: NAIVE VS OPTIMIZED RECURSION
================================================================================

Revenue Growth Forecast Model

PROBLEM STATEMENT
----------------
Revenue analyst needs to forecast revenue growth using Fibonacci model:
    This month = Last month + Month before last

Pattern: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144...

Model revenue as Fibonacci sequence where each month's revenue depends
on combining previous two months' revenues.

BUSINESS SCENARIO
----------------
A startup has growing revenue:
- Month 1: $1,000
- Month 2: $1,000
- Month 3: $2,000 (1000 + 1000)
- Month 4: $3,000 (1000 + 2000)
- Month 5: $5,000 (2000 + 3000)

LEARNING OBJECTIVES
------------------
- Understand naive recursion problem
- Recognize overlapping subproblems
- Measure performance of naive vs optimized
- Introduce memoization concept
- Understand time complexity exponential vs linear

SOLUTION OVERVIEW
-----------------
Naive Recursion:
    fib(n) = fib(n-1) + fib(n-2)
    Calls fib(n-1), which calls fib(n-2), which calls fib(n-1) again!
    Many redundant calculations
    Time: O(2^n) EXPONENTIAL
    Space: O(n) call stack

Memoized Recursion:
    Cache results: fib(5) computed once, reused many times
    Time: O(n) LINEAR
    Space: O(n) cache + call stack

This is why some problems need optimization!
"""

import time
from typing import Dict
from functools import lru_cache


# ============================================================================
# NAIVE RECURSIVE SOLUTION (INEFFICIENT)
# ============================================================================

call_count = 0


def fibonacci_naive(n: int, depth: int = 0) -> int:
    """
    Calculate nth Fibonacci number using naive recursion.

    CRITICAL: This is INEFFICIENT for large n!

    Visualization of redundant calls for fib(5):
                fib(5)
               /      \\
            fib(4)    fib(3)
           /     \\    /     \\
        fib(3) fib(2) fib(2) fib(1)
        /   \\
    fib(2) fib(1)

    Notice: fib(3) calculated twice, fib(2) calculated THREE times!

    Args:
        n: Position in Fibonacci sequence
        depth: Recursion depth (for visualization)

    Returns:
        nth Fibonacci number
    """
    global call_count
    call_count += 1

    indent = "  " * depth

    # BASE CASES
    if n <= 1:
        print(f"{indent}→ fib({n}) = {n} [call #{call_count}]")
        return n

    # RECURSIVE CASE: fib(n) = fib(n-1) + fib(n-2)
    print(f"{indent}→ fib({n}) [call #{call_count}]")

    # This causes the inefficiency!
    # Both calls compute overlapping subproblems
    left = fibonacci_naive(n - 1, depth + 1)
    right = fibonacci_naive(n - 2, depth + 1)

    result = left + right
    print(f"{indent}← fib({n}) = {result}")

    return result


# ============================================================================
# OPTIMIZED RECURSIVE SOLUTION (MEMOIZATION)
# ============================================================================

def fibonacci_memo(n: int, memo: Dict[int, int] = None, depth: int = 0) -> int:
    """
    Calculate nth Fibonacci number using memoization.

    Caches previously computed results.
    Each fib(k) is computed exactly ONCE, then reused.

    Args:
        n: Position in Fibonacci sequence
        memo: Memoization cache (results dictionary)
        depth: Recursion depth (for visualization)

    Returns:
        nth Fibonacci number
    """
    if memo is None:
        memo = {}

    indent = "  " * depth

    # BASE CASES
    if n <= 1:
        print(f"{indent}→ fib({n}) = {n} [computed]")
        memo[n] = n
        return n

    # CHECK CACHE: Is this already computed?
    if n in memo:
        print(f"{indent}→ fib({n}) = {memo[n]} [cached]")
        return memo[n]

    # RECURSIVE CASE: Compute if not cached
    print(f"{indent}→ fib({n}) [computing...]")

    # Recursive calls use same memoization cache
    left = fibonacci_memo(n - 1, memo, depth + 1)
    right = fibonacci_memo(n - 2, memo, depth + 1)

    result = left + right
    memo[n] = result  # Cache the result

    print(f"{indent}← fib({n}) = {result} [cached]")
    return result


# ============================================================================
# PYTHON DECORATOR SOLUTION
# ============================================================================

@lru_cache(maxsize=None)
def fibonacci_cached(n: int) -> int:
    """
    Calculate nth Fibonacci number using Python's lru_cache decorator.

    @lru_cache automatically memoizes function results.

    Args:
        n: Position in Fibonacci sequence

    Returns:
        nth Fibonacci number
    """
    if n <= 1:
        return n
    return fibonacci_cached(n - 1) + fibonacci_cached(n - 2)


# ============================================================================
# ITERATIVE SOLUTION
# ============================================================================

def fibonacci_iterative(n: int) -> int:
    """
    Calculate nth Fibonacci number iteratively.

    Most efficient: O(n) time, O(1) space

    Args:
        n: Position in Fibonacci sequence

    Returns:
        nth Fibonacci number
    """
    if n <= 1:
        return n

    prev2, prev1 = 0, 1
    for _ in range(2, n + 1):
        current = prev1 + prev2
        prev2, prev1 = prev1, current

    return prev1


# ============================================================================
# PERFORMANCE COMPARISON
# ============================================================================

def explain_inefficiency() -> None:
    """
    Explain why naive recursion is inefficient.
    """
    print("\n" + "=" * 80)
    print("INEFFICIENCY OF NAIVE RECURSION".center(80))
    print("=" * 80)

    print("""
    THE PROBLEM: OVERLAPPING SUBPROBLEMS
    =====================================

    When computing fib(5):

                    fib(5)                    Level 1: 1 call
                   /      \\
                fib(4)    fib(3)             Level 2: 2 calls
               /     \\    /     \\
            fib(3) fib(2) fib(2) fib(1)      Level 3: 3 calls + 2 repeats!
            /   \\   / \\   / \\
        fib(2) fib(1) ...                    Level 4: redundant calls


    REDUNDANT CALCULATIONS:
    fib(4) calculated: 1 time
    fib(3) calculated: 2 times ← REDUNDANT
    fib(2) calculated: 3 times ← REDUNDANT
    fib(1) calculated: 5 times ← REDUNDANT
    fib(0) calculated: 3 times ← REDUNDANT

    Total function calls for fib(5): 15 calls (many redundant!)
    Total function calls for fib(10): 177 calls
    Total function calls for fib(30): 2,178,309 calls
    Total function calls for fib(50): ??? (millions of billions)


    TIME COMPLEXITY
    ================

    Naive Recursion: O(2^n)
    - Each call branches into 2 more calls
    - Binary tree of calls
    - Exponential growth is VERY fast

    fib(10): ~177 calls = 2^7 calls
    fib(20): ~21,891 calls = 2^14 calls
    fib(30): ~2,178,309 calls = 2^21 calls
    fib(40): ~267,914,296 calls = 2^28 calls (SLOW!)
    fib(50): ~40 BILLION calls = 2^35 calls (EXTREMELY SLOW!)

    Memoized Recursion: O(n)
    - Each value computed exactly once
    - Linear scaling instead of exponential

    fib(50): 50 calls (vastly faster!)


    THE SOLUTION: MEMOIZATION
    ===========================

    Cache results so we don't recompute:

    fib(5):
    - Call fib(4), fib(3)
    - fib(4) calls fib(3), fib(2)
    - fib(3) is CACHED from first call
    - fib(2) is NEW, computed once
    - etc.

    Result:
    - Each fib(k) computed exactly once
    - Huge performance improvement
    - fib(50) goes from 40 billion calls to 50 calls!
    """)


def compare_performance() -> None:
    """
    Measure performance of different approaches.
    """
    print("\n" + "=" * 80)
    print("PERFORMANCE COMPARISON".center(80))
    print("=" * 80)

    print("\nCalculating Fibonacci numbers with different methods:\n")

    test_values = [5, 10, 15, 20, 25, 30]

    for n in test_values:
        print(f"\n{'─' * 80}")
        print(f"Calculating fib({n}):")
        print(f"{'─' * 80}")

        # Naive (only for small n)
        if n <= 25:
            global call_count
            call_count = 0
            start = time.perf_counter()
            result_naive = fibonacci_naive(n)
            time_naive = time.perf_counter() - start
            print(f"  Naive:       {result_naive:>8} ({call_count:>10} calls) ({time_naive*1000:>8.2f} ms)")
        else:
            print(f"  Naive:       (TOO SLOW - skipped)")

        # Memoized
        start = time.perf_counter()
        result_memo = fibonacci_memo(n)
        time_memo = time.perf_counter() - start
        print(f"  Memoized:    {result_memo:>8} ({n + 1:>10} calls) ({time_memo*1000:>8.2f} ms)")

        # Cached decorator
        fibonacci_cached.cache_clear()
        start = time.perf_counter()
        result_cached = fibonacci_cached(n)
        time_cached = time.perf_counter() - start
        print(f"  Cached:      {result_cached:>8} ({n + 1:>10} calls) ({time_cached*1000:>8.2f} ms)")

        # Iterative
        start = time.perf_counter()
        result_iter = fibonacci_iterative(n)
        time_iter = time.perf_counter() - start
        print(f"  Iterative:   {result_iter:>8} ({n:>10} iterations) ({time_iter*1000:>8.2f} ms)")

        # Verify all give same result
        assert result_memo == result_cached == result_iter, "Results mismatch!"


# ============================================================================
# BUSINESS APPLICATION
# ============================================================================

def revenue_forecast() -> None:
    """
    Apply Fibonacci to revenue forecasting.
    """
    print("\n" + "=" * 80)
    print("BUSINESS APPLICATION: REVENUE FORECASTING".center(80))
    print("=" * 80)

    print("\nStartup Revenue Growth Model (Fibonacci-based):")
    print("-" * 60)

    # Initial revenue
    months = [
        (1, 1000),
        (2, 1000),
    ]

    # Generate forecast using Fibonacci pattern
    for month in range(3, 13):
        revenue = months[-1][1] + months[-2][1]  # Fibonacci pattern
        months.append((month, revenue))

    print(f"{'Month':<10} {'Revenue':<15} {'Growth':<15} {'Growth %':<10}")
    print("-" * 60)

    for i, (month, revenue) in enumerate(months):
        if i == 0:
            growth = 0
            growth_pct = 0
        else:
            growth = revenue - months[i-1][1]
            growth_pct = (growth / months[i-1][1]) * 100

        print(f"{month:<10} ${revenue:>12,} ${growth:>12,} {growth_pct:>8.1f}%")

    total_revenue = sum(r for _, r in months)
    print("-" * 60)
    print(f"Total 12-month revenue: ${total_revenue:,}")


# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================

def interview_questions() -> None:
    """
    Interview questions about Fibonacci and recursion optimization.
    """
    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS".center(80))
    print("=" * 80)

    questions = [
        {
            "Q": "Why is naive Fibonacci recursion inefficient?",
            "A": """
            Naive recursion has OVERLAPPING SUBPROBLEMS:
            - fib(n) = fib(n-1) + fib(n-2)
            - fib(n-1) = fib(n-2) + fib(n-3)
            - Notice: fib(n-2) computed in both!
            - This redundancy grows exponentially

            Result:
            - fib(30) requires 2,178,309 function calls
            - 90% of these are redundant calculations
            - Time complexity: O(2^n) exponential
            """
        },
        {
            "Q": "How does memoization fix the inefficiency?",
            "A": """
            Memoization: Cache results to avoid recomputation

            Without memoization: fib(5) calls fib(3) twice
            With memoization:
            - First call to fib(3): compute and cache
            - Second call to fib(3): return cached result

            Result:
            - Each value fib(k) computed exactly once
            - Total calls: n instead of 2^n
            - fib(30): 30 calls instead of 2.1 million
            - Time complexity: O(n) linear
            """
        },
        {
            "Q": "How would you use @lru_cache in production?",
            "A": """
            @lru_cache(maxsize=128)
            def fibonacci(n):
                if n <= 1:
                    return n
                return fibonacci(n-1) + fibonacci(n-2)

            Benefits:
            - Automatic caching decorator
            - lru_cache manages cache size
            - Thread-safe
            - Works with any function
            - Easy to add to existing code

            maxsize parameter:
            - None = unlimited cache
            - N = keep only N most recent results
            - Prevents memory bloat for long-running processes
            """
        },
        {
            "Q": "When should you use recursion vs iteration?",
            "A": """
            Use Recursion When:
            - Overlapping subproblems exist (use memoization)
            - Problem is naturally recursive (tree, graph)
            - Code clarity is paramount

            Use Iteration When:
            - Simple loops
            - Performance critical
            - No overlapping subproblems
            - Memory limited

            For Fibonacci specifically:
            - Use iterative (simplest, fastest, O(1) space)
            - Or use cached decorator if need recursive style
            - Avoid naive recursion (except learning)
            """
        },
        {
            "Q": "What's dynamic programming and how does it relate?",
            "A": """
            Dynamic Programming: Solve complex problems by
            1. Breaking into subproblems
            2. Solving each subproblem once
            3. Storing results (memoization)
            4. Building up to final solution

            Fibonacci is a classic DP example:
            - Subproblems: fib(0), fib(1), ... fib(n)
            - Solve each once: memoization
            - Build up: fib(n) from previous results

            DP Approaches:
            1. Top-down (recursive + memoization)
               - Start with fib(n), work down to base cases
            2. Bottom-up (iterative, build from base)
               - Start with fib(0), build up to fib(n)
            """
        }
    ]

    for i, qa in enumerate(questions, 1):
        print(f"\n❓ Question {i}: {qa['Q']}")
        print(f"{qa['A']}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("FIBONACCI: NAIVE VS OPTIMIZED RECURSION".center(80))
    print("Revenue Growth Forecast Model".center(80))
    print("=" * 80)

    # Explain inefficiency
    explain_inefficiency()

    # Show naive recursion for small numbers
    print("\n" + "=" * 80)
    print("NAIVE RECURSION: fib(7)".center(80))
    print("=" * 80)
    print()
    call_count = 0
    result = fibonacci_naive(7)
    print(f"\n✓ Result: fib(7) = {result}")
    print(f"✓ Total function calls: {call_count}")

    # Compare performance
    compare_performance()

    # Business application
    revenue_forecast()

    # Interview questions
    interview_questions()

    # Summary
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS".center(80))
    print("=" * 80)
    print("""
    ✓ Naive recursion: O(2^n) - exponential (SLOW)
    ✓ Overlapping subproblems cause redundant calls
    ✓ Memoization reduces O(2^n) to O(n) (FAST)
    ✓ Three ways to optimize: memoization, caching, iteration
    ✓ Dynamic programming: solve subproblems, cache results
    ✓ @lru_cache decorator handles memoization automatically

    NEXT: See 07_power_function.py for another recursion example
    """)
