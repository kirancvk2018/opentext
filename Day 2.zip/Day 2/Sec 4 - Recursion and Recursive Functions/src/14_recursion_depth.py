"""
Recursion Depth Tracking and Analysis

Business: Large repository analysis must track recursion depth safely

Learning: Monitor and manage recursion depth, prevent overflow
"""

import sys


def track_depth(node_id: int, max_depth: int, current_depth: int = 0, safe_limit: int = 900) -> None:
    """Recursively process with depth tracking."""
    print(f"{'  ' * current_depth}→ Node {node_id} (Depth: {current_depth})")

    if current_depth > safe_limit:
        print(f"{'  ' * current_depth}⚠ WARNING: Approaching recursion limit!")
        return

    if current_depth >= max_depth:
        print(f"{'  ' * current_depth}✓ Reached target depth {max_depth}")
        return

    track_depth(node_id + 1, max_depth, current_depth + 1, safe_limit)


def check_recursion_limit() -> None:
    """Display and analyze recursion limits."""
    print("\n" + "=" * 80)
    print("RECURSION LIMIT ANALYSIS".center(80))
    print("=" * 80)

    limit = sys.getrecursionlimit()
    safe_limit = int(limit * 0.9)
    warning_limit = int(limit * 0.8)

    print(f"\nSystem recursion limit: {limit}")
    print(f"Safe usage (90%): {safe_limit}")
    print(f"Warning threshold (80%): {warning_limit}")

    print(f"\nGuidelines:")
    print(f"  0-{warning_limit}: Safe, no concerns")
    print(f"  {warning_limit}-{safe_limit}: Getting tight, monitor")
    print(f"  {safe_limit}-{limit}: Danger zone, likely to fail")
    print(f"  {limit}+: RecursionError")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("RECURSION DEPTH TRACKING".center(80))
    print("Large Knowledge Repository Analysis".center(80))
    print("=" * 80)

    check_recursion_limit()

    print("\n" + "=" * 80)
    print("DEPTH TRACKING DEMONSTRATION".center(80))
    print("=" * 80)

    print("\nTraversing to depth 15 (safe):\n")
    track_depth(1, 15)

    print("\n" + "=" * 80)
    print("DEPTH MANAGEMENT STRATEGIES".center(80))
    print("=" * 80)
    print(f"""
    1. INCREASE LIMIT (if necessary):
       sys.setrecursionlimit(5000)
       - Use only for well-tested code
       - Requires more stack memory
       - Risky on embedded systems

    2. DECREASE PROBLEM SIZE:
       - Limit input depth
       - Batch process large datasets
       - Use iteration for deep problems

    3. HYBRID APPROACH:
       - Recursion for shallow parts (trees)
       - Iteration for deep parts (lists)
       - Combine both for optimal performance

    4. MONITORING:
       - Track current depth parameter
       - Raise error if too deep
       - Use decorators to add checks

    5. ALTERNATIVE ALGORITHMS:
       - Convert to iteration
       - Use stack-based traversal
       - Implement iterative DP
    """)
