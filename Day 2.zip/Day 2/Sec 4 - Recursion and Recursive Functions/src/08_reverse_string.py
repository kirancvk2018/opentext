"""
String Reversal using Recursion

Business: Payment system must reverse transaction IDs for validation encoding

Learning: Simple string recursion, base case on index
"""

def reverse_string_recursive(s: str, index: int = None, depth: int = 0) -> str:
    """Reverse string recursively."""
    if index is None:
        index = len(s) - 1

    indent = "  " * depth
    print(f"{indent}→ reverse_string('{s}', index={index})")

    if index < 0:
        print(f"{indent}  ← [BASE CASE] Return empty string")
        return ""

    current_char = s[index]
    print(f"{indent}  Current char: '{current_char}'")
    result = current_char + reverse_string_recursive(s, index - 1, depth + 1)
    print(f"{indent}  ← Result: '{result}'")
    return result


def reverse_string_iterative(s: str) -> str:
    """Reverse string iteratively (for comparison)."""
    return s[::-1]


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("STRING REVERSAL: RECURSIVE vs ITERATIVE".center(80))
    print("=" * 80)

    test_string = "INVOICE"

    print(f"\nReversing: '{test_string}'\n")
    print("=" * 80)
    print("RECURSIVE APPROACH".center(80))
    print("=" * 80)
    print()
    result_recursive = reverse_string_recursive(test_string)
    print(f"\n✓ Result: '{result_recursive}'")

    print(f"\n" + "=" * 80)
    print("ITERATIVE APPROACH".center(80))
    print("=" * 80)
    result_iterative = reverse_string_iterative(test_string)
    print(f"✓ Result: '{result_iterative}'")

    print(f"\n" + "=" * 80)
    print("ANALYSIS".center(80))
    print("=" * 80)
    print(f"""
    String: '{test_string}' (length {len(test_string)})

    RECURSIVE:
    - Base case: index < 0 (reached before first character)
    - Recursive case: current_char + reverse(rest)
    - Time: O(n)
    - Space: O(n) call stack + O(n) string concatenation

    ITERATIVE (Python slicing):
    - Time: O(n)
    - Space: O(n) for reversed string
    - Much simpler and faster

    BUSINESS APPLICATION:
    Reversing transaction identifiers for encoding:
    - Transaction: TXN20240115001234
    - Reversed: 4321005110241T0201XNT
    - Used for checksums, validation, encoding schemes

    RECOMMENDATION:
    Use iterative (s[::-1]) in production - simpler and faster
    Recursion is good for learning but not practical here
    """)
