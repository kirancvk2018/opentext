"""
================================================================================
BASE CASE AND RECURSIVE CASE
================================================================================

Document Approval Workflow System

PROBLEM STATEMENT
----------------
A document management system processes approval workflows where documents must
pass through multiple approval stages:

Workflow:
    Employee → Manager → Director → Executive → Approved

Each stage can APPROVE or REJECT. Process must stop at APPROVED or REJECT.

BUSINESS SCENARIO
----------------
Document approval systems common in:
- Expense reports (employee → manager → finance)
- Purchase orders (requester → manager → director)
- Leave requests (employee → manager → HR)
- Contract reviews (originator → manager → legal → executive)

The system must:
1. Process each approval stage
2. Stop if document is rejected (base case)
3. Stop if document is approved at final stage (base case)
4. Continue to next stage if still pending (recursive case)

LEARNING OBJECTIVES
------------------
- Master base case conditions
- Master recursive case execution
- Understand when to stop recursion
- Prevent infinite recursion
- Handle multiple stopping conditions

SOLUTION OVERVIEW
-----------------
Base Cases (TWO conditions for stopping):
    1. Document is REJECTED at any stage → Stop, return REJECTED
    2. Document reaches FINAL stage and is APPROVED → Stop, return APPROVED

Recursive Case:
    1. Document is in middle stage
    2. Move to next stage
    3. Recursively process remaining stages

Time Complexity: O(n) where n = number of approval stages
Space Complexity: O(n) call stack for n stages
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


# ============================================================================
# DATA MODELS
# ============================================================================

class ApprovalStatus(Enum):
    """Possible approval statuses."""
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


@dataclass
class ApprovalStage:
    """Represents one stage in approval workflow."""
    stage_number: int
    stage_name: str
    approver_name: str


@dataclass
class Document:
    """Document being approved."""
    doc_id: str
    title: str
    current_stage: int = 0
    status: ApprovalStatus = ApprovalStatus.PENDING
    approval_history: list[str] = None

    def __post_init__(self):
        if self.approval_history is None:
            self.approval_history = []


# ============================================================================
# WORKFLOW STAGES
# ============================================================================

APPROVAL_WORKFLOW = [
    ApprovalStage(1, "Employee Submission", "Employee"),
    ApprovalStage(2, "Manager Review", "Manager"),
    ApprovalStage(3, "Director Approval", "Director"),
    ApprovalStage(4, "Executive Sign-off", "Executive"),
]

FINAL_STAGE = len(APPROVAL_WORKFLOW)


# ============================================================================
# CORE RECURSIVE FUNCTION
# ============================================================================

def process_approval_workflow(
    document: Document,
    stages: list[ApprovalStage],
    current_stage_index: int = 0,
    approve_at_stage: Optional[int] = None,
    reject_at_stage: Optional[int] = None,
    depth: int = 0
) -> ApprovalStatus:
    """
    Recursively process document through approval stages.

    CRITICAL: This function demonstrates TWO BASE CASES.

    Args:
        document: Document being approved
        stages: List of approval stages
        current_stage_index: Current stage (0-indexed)
        approve_at_stage: Stage number where document gets approved (1-indexed)
        reject_at_stage: Stage number where document gets rejected (1-indexed)
        depth: Recursion depth (for visualization)

    Returns:
        Final approval status
    """
    indent = "  " * depth
    current_stage = stages[current_stage_index]

    print(f"{indent}→ Stage {current_stage.stage_number}: {current_stage.stage_name}")
    print(f"{indent}  Approver: {current_stage.approver_name}")

    # Add to history
    document.approval_history.append(f"Stage {current_stage.stage_number}: {current_stage.stage_name}")

    # ============================================================
    # BASE CASE 1: DOCUMENT IS REJECTED
    # ============================================================
    # Why: Rejection stops workflow immediately (no point continuing)
    # What: Return REJECTED status
    # When: If rejecting at this stage
    if reject_at_stage and reject_at_stage == current_stage.stage_number:
        print(f"{indent}  ✗ [BASE CASE 1] Document REJECTED at {current_stage.stage_name}")
        document.status = ApprovalStatus.REJECTED
        document.approval_history.append(f"REJECTED at stage {current_stage.stage_number}")
        return ApprovalStatus.REJECTED

    # ============================================================
    # BASE CASE 2: DOCUMENT IS APPROVED AT FINAL STAGE
    # ============================================================
    # Why: Reached end of workflow - document is approved
    # What: Return APPROVED status
    # When: Final stage is reached and approved
    if current_stage_index == FINAL_STAGE - 1:
        # This is the last stage
        if approve_at_stage is None or approve_at_stage > FINAL_STAGE:
            # Default: approve at final stage
            print(f"{indent}  ✓ [BASE CASE 2] Document APPROVED at final stage ({current_stage.stage_name})")
            document.status = ApprovalStatus.APPROVED
            document.approval_history.append("APPROVED at final stage")
            return ApprovalStatus.APPROVED

        # Or explicitly approved here
        if approve_at_stage == current_stage.stage_number:
            print(f"{indent}  ✓ [BASE CASE 2] Document APPROVED at {current_stage.stage_name}")
            document.status = ApprovalStatus.APPROVED
            document.approval_history.append(f"APPROVED at stage {current_stage.stage_number}")
            return ApprovalStatus.APPROVED

        # Not approved yet, but reached final stage - reject
        print(f"{indent}  ✗ [BASE CASE 1] Document not approved by final stage - REJECTED")
        document.status = ApprovalStatus.REJECTED
        document.approval_history.append("REJECTED - not approved at final stage")
        return ApprovalStatus.REJECTED

    # ============================================================
    # RECURSIVE CASE: DOCUMENT IS STILL PENDING
    # ============================================================
    # Why: Not rejected, not at final stage → continue processing
    # What: Move to next stage and recursively process
    # How: Call process_approval_workflow on next stage

    if approve_at_stage and approve_at_stage == current_stage.stage_number:
        # Approved at this stage (not final)
        print(f"{indent}  ✓ Approved at {current_stage.stage_name}, moving to next stage")
    else:
        # Default approval at this stage - move forward
        print(f"{indent}  → Stage {current_stage.stage_number} processing, moving to next")

    # RECURSIVE CALL: Process next stage
    # Notice: current_stage_index increments (makes progress toward base case)
    print(f"{indent}  ↓ [RECURSIVE CASE] Moving to next stage...")
    return process_approval_workflow(
        document,
        stages,
        current_stage_index + 1,  # KEY: Progress toward base case
        approve_at_stage,
        reject_at_stage,
        depth + 1
    )


# ============================================================================
# EXPLANATION: BASE CASES VS RECURSIVE CASE
# ============================================================================

def explain_base_and_recursive_cases() -> None:
    """
    Explain base cases and recursive case for this problem.
    """
    print("\n" + "=" * 80)
    print("BASE CASE vs RECURSIVE CASE EXPLANATION".center(80))
    print("=" * 80)

    print("""
    PROBLEM STRUCTURE
    =================
    Approval workflow has 3 possible outcomes:

    1. REJECTED at some stage → STOP (don't continue)
    2. APPROVED at final stage → STOP (reached end)
    3. STILL PENDING → CONTINUE (go to next stage)


    BASE CASE 1: DOCUMENT IS REJECTED
    ==================================
    Condition: Document gets rejected at current stage
    Why Stop: Rejection terminates workflow (approval process is over)
    Action: Return REJECTED immediately (no recursive call)
    Example: Manager rejects expense report → done, return to employee

    Code:
        if reject_at_stage == current_stage:
            return ApprovalStatus.REJECTED  # Stop here


    BASE CASE 2: DOCUMENT IS APPROVED AT FINAL STAGE
    =================================================
    Condition: Reached last stage AND document is approved
    Why Stop: All stages completed successfully (approval complete)
    Action: Return APPROVED (no more stages to process)
    Example: Executive approves purchase order → done, approved

    Code:
        if current_stage == FINAL_STAGE:
            return ApprovalStatus.APPROVED  # Stop here


    RECURSIVE CASE: DOCUMENT IS PENDING
    ===================================
    Condition: Not rejected, not at final stage
    Why Continue: More stages to process
    Action: Move to next stage, recursively process
    What Happens:
        1. Update current stage
        2. Call process_approval_workflow on next stage (RECURSIVE CALL)
        3. Return result from recursive call

    Code:
        else:  # Still pending, not at final
            return process_approval_workflow(
                document,
                stages,
                current_stage + 1,  # ← Progress toward base case!
                ...
            )


    KEY INSIGHT: PROGRESS TOWARD BASE CASE
    ======================================
    Each recursive call MUST move closer to a base case:

        Initial: current_stage = 0 (Stage 1)
        Call 1: current_stage = 1 (Stage 2)
        Call 2: current_stage = 2 (Stage 3)
        Call 3: current_stage = 3 (Stage 4) ← BASE CASE 2 (final stage)
        STOP

    Without this progress → Infinite recursion → RecursionError!


    WHY TWO BASE CASES?
    ===================
    Some problems have multiple stopping conditions:

    Condition 1: Error/Failure (REJECTED)
    Condition 2: Success (APPROVED at final stage)
    Condition 3: Some other terminal state

    Each condition needs its own base case check.
    Without all base cases → Missing termination conditions → Bugs!


    COMMON MISTAKE: FORGETTING BASE CASES
    ====================================
    ✗ WRONG: No base case for rejection
        def process(doc, stage_idx):
            if stage_idx == FINAL_STAGE:
                return APPROVED
            # Missing: what if rejected?
            return process(doc, stage_idx + 1)

    Problem: If document is rejected, recursion continues endlessly!

    ✓ CORRECT: All base cases
        def process(doc, stage_idx):
            if is_rejected:
                return REJECTED  # ← Base case 1
            if stage_idx == FINAL_STAGE:
                return APPROVED  # ← Base case 2
            return process(doc, stage_idx + 1)  # ← Recursive case
    """)


# ============================================================================
# PRACTICAL DEMONSTRATION
# ============================================================================

def demonstrate() -> None:
    """
    Demonstrate approval workflow with different scenarios.
    """
    print("\n" + "=" * 80)
    print("PRACTICAL DEMONSTRATION".center(80))
    print("=" * 80)

    scenarios = [
        {
            "name": "Approved Workflow",
            "doc_id": "DOC001",
            "title": "Travel Expense Report",
            "approve_at": None,  # Approve at each stage (default)
            "reject_at": None,
        },
        {
            "name": "Rejected by Manager",
            "doc_id": "DOC002",
            "title": "Expensive Equipment Purchase",
            "approve_at": None,
            "reject_at": 2,  # Reject at stage 2 (Manager)
        },
        {
            "name": "Rejected by Director",
            "doc_id": "DOC003",
            "title": "Budget Request",
            "approve_at": None,
            "reject_at": 3,  # Reject at stage 3 (Director)
        },
    ]

    for scenario in scenarios:
        print(f"\n{'=' * 80}")
        print(f"SCENARIO: {scenario['name']}")
        print(f"{'=' * 80}\n")

        doc = Document(
            doc_id=scenario["doc_id"],
            title=scenario["title"]
        )

        status = process_approval_workflow(
            doc,
            APPROVAL_WORKFLOW,
            current_stage_index=0,
            approve_at_stage=scenario["approve_at"],
            reject_at_stage=scenario["reject_at"],
            depth=0
        )

        print(f"\n{'─' * 80}")
        print(f"✓ Final Status: {status.value}")
        print(f"✓ Approval History:")
        for entry in doc.approval_history:
            print(f"  - {entry}")
        print()


# ============================================================================
# CALL STACK VISUALIZATION
# ============================================================================

def visualize_call_stack() -> None:
    """
    Visualize the call stack for approval workflow.
    """
    print("\n" + "=" * 80)
    print("CALL STACK VISUALIZATION".center(80))
    print("=" * 80)

    print("""
    Scenario: Document approved normally (3 stages)

    Execution Timeline:
    ===================

    process_approval(doc, stages, stage=0)     ← Frame 1: Stage 1
        ↓ Not at final, not rejected → RECURSIVE CASE
        process_approval(doc, stages, stage=1)     ← Frame 2: Stage 2
            ↓ Not at final, not rejected → RECURSIVE CASE
            process_approval(doc, stages, stage=2)     ← Frame 3: Stage 3
                ↓ At final stage, not rejected → BASE CASE 2
                ↓ Return APPROVED
            ← return APPROVED (Frame 3 destroyed)
        ← return APPROVED (Frame 2 destroyed)
    ← return APPROVED (Frame 1 destroyed)

    Final Result: APPROVED


    Scenario: Document rejected at Stage 2

    process_approval(doc, stages, stage=0)
        ↓ Not rejected at stage 0 → RECURSIVE CASE
        process_approval(doc, stages, stage=1)
            ↓ REJECTED at stage 1 → BASE CASE 1
            ↓ Return REJECTED
        ← return REJECTED (Frame 2 destroyed)
    ← return REJECTED (Frame 1 destroyed)

    Final Result: REJECTED (stops early, doesn't process stage 3)

    KEY INSIGHT:
    - Base case 1 (rejection) exits early
    - Base case 2 (approval at final) exits at end
    - Recursive case continues to next stage
    - Stack grows with number of stages
    - Stack shrinks as base cases are reached
    """)


# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================

def interview_questions() -> None:
    """
    Interview questions about base and recursive cases.
    """
    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS".center(80))
    print("=" * 80)

    questions = [
        {
            "Q": "What's the difference between base case and recursive case?",
            "A": """
            BASE CASE: The stopping condition
            - Checks if we should continue recursing
            - If true, return value directly without recursion
            - Prevents infinite recursion
            Example: "if rejected or at final stage, return status"

            RECURSIVE CASE: The continuation condition
            - Only executes if base case is false
            - Calls function on simpler/smaller problem
            - Makes progress toward base case
            Example: "otherwise, call on next stage"
            """
        },
        {
            "Q": "Why did this problem need TWO base cases?",
            "A": """
            Because there are two ways to stop the workflow:

            1. REJECTION (early termination)
               - Can happen at any stage
               - Stops immediately, doesn't continue
               - Returns REJECTED status

            2. APPROVAL (successful termination)
               - Happens at final stage
               - All approval levels satisfied
               - Returns APPROVED status

            Without checking rejection early:
            - Document would continue to final stage even if rejected
            - Wrong logic: rejected documents shouldn't advance

            Many recursive problems have multiple termination conditions.
            Must handle all of them!
            """
        },
        {
            "Q": "How do you ensure progress toward base case?",
            "A": """
            In this problem: increment the stage number
                current_stage_index + 1

            Each recursive call processes stage 1, then 2, then 3, then 4.
            Eventually reaches final stage (base case).

            Rules for progress:
            1. Each recursive call must handle a "smaller" problem
            2. Input parameters must change (smaller, fewer items, etc.)
            3. Eventually must match base case condition
            4. Without progress → infinite recursion → RecursionError
            """
        },
        {
            "Q": "What happens if you forget a base case?",
            "A": """
            The recursion won't stop at expected condition.

            Example: If you forget to check for rejection:
                def process(doc, stage):
                    if stage == FINAL:
                        return APPROVED
                    return process(doc, stage + 1)

            Problem: If document is rejected at stage 2:
            - Rejection is ignored
            - Process continues: stage 2 → 3 → 4
            - Eventually reaches final stage
            - Returns APPROVED (WRONG!)

            Fix: Add rejection check:
                if is_rejected:
                    return REJECTED  # ← Base case
            """
        },
        {
            "Q": "How would you add another base case?",
            "A": """
            Example: Add "STUCK IN REVIEW" status (pending > 30 days)

            Base Case 3: Document stuck in review
                if days_pending > 30:
                    return ApprovalStatus.STUCK

            Check this BEFORE recursive case:
                if is_rejected:
                    return REJECTED  # Base case 1
                if days_pending > 30:
                    return STUCK     # Base case 2
                if stage == FINAL:
                    return APPROVED  # Base case 3
                return process(...)  # Recursive case

            Each base case handles one stopping condition.
            All must be checked before recursive case.
            """
        }
    ]

    for i, qa in enumerate(questions, 1):
        print(f"\n❓ Question {i}: {qa['Q']}")
        print(f"{qa['A']}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("BASE CASE AND RECURSIVE CASE".center(80))
    print("Document Approval Workflow System".center(80))
    print("=" * 80)

    # Explain base and recursive cases
    explain_base_and_recursive_cases()

    # Visualize call stack
    visualize_call_stack()

    # Practical demonstration
    demonstrate()

    # Interview questions
    interview_questions()

    # Summary
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS".center(80))
    print("=" * 80)
    print("""
    ✓ Base Case: Stopping conditions (when NOT to recurse)
    ✓ Recursive Case: Continuation condition (when to recurse)
    ✓ Some problems have MULTIPLE base cases
    ✓ All base cases must be checked BEFORE recursive case
    ✓ Each recursive call must progress toward a base case
    ✓ Missing base case = infinite recursion = RecursionError

    NEXT: See 04_call_stack_demo.py for visual call stack demonstration
    """)
