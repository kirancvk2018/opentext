"""
Logging utilities for the recursion learning project.

Provides structured logging capabilities for tracking program execution,
debugging recursion, and monitoring performance metrics.
"""

import logging
import sys
from typing import Optional

# Global logger instance
_logger: Optional[logging.Logger] = None


def setup_logger(
    name: str = "recursion_project",
    level: int = logging.INFO
) -> logging.Logger:
    """
    Initialize and configure the project logger.

    Args:
        name: Logger name (typically module name)
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)

    Returns:
        Configured logger instance
    """
    global _logger

    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Prevent duplicate handlers
    if logger.handlers:
        return logger

    # Console handler with detailed format
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)

    # Format: [LEVEL] [Module] Message
    formatter = logging.Formatter(
        fmt='[%(levelname)-8s] %(name)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(formatter)

    logger.addHandler(console_handler)

    _logger = logger
    return logger


def get_logger(name: str = "recursion_project") -> logging.Logger:
    """
    Get or create the project logger.

    Args:
        name: Logger name

    Returns:
        Logger instance
    """
    global _logger

    if _logger is None:
        _logger = setup_logger(name)

    return _logger


# Convenience logging functions
def log_debug(message: str) -> None:
    """Log debug message."""
    get_logger().debug(message)


def log_info(message: str) -> None:
    """Log info message."""
    get_logger().info(message)


def log_warning(message: str) -> None:
    """Log warning message."""
    get_logger().warning(message)


def log_error(message: str) -> None:
    """Log error message."""
    get_logger().error(message)


def log_critical(message: str) -> None:
    """Log critical message."""
    get_logger().critical(message)
