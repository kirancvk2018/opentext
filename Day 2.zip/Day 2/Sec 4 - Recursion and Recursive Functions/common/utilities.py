"""
Utility functions for the recursion learning project.

Provides helper functions for formatted output, printing results,
and common operations.
"""

from typing import Any, Optional
from datetime import datetime


# ANSI color codes for formatted output
class Colors:
    """ANSI color codes for terminal output."""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def print_section(title: str, width: int = 80) -> None:
    """
    Print a formatted section header.

    Args:
        title: Section title
        width: Header width in characters
    """
    print("\n" + "=" * width)
    print(f"{Colors.BOLD}{Colors.CYAN}{title.center(width)}{Colors.ENDC}")
    print("=" * width + "\n")


def print_subsection(title: str, width: int = 80) -> None:
    """
    Print a formatted subsection header.

    Args:
        title: Subsection title
        width: Header width in characters
    """
    print(f"\n{Colors.BOLD}{Colors.BLUE}{title}{Colors.ENDC}")
    print("-" * width)


def print_result(label: str, value: Any, indent: int = 0) -> None:
    """
    Print a labeled result value.

    Args:
        label: Label for the value
        value: The value to print
        indent: Number of spaces to indent
    """
    prefix = " " * indent
    print(f"{prefix}{Colors.GREEN}✓ {label}:{Colors.ENDC} {value}")


def print_error(message: str, indent: int = 0) -> None:
    """
    Print an error message.

    Args:
        message: Error message
        indent: Number of spaces to indent
    """
    prefix = " " * indent
    print(f"{prefix}{Colors.RED}✗ ERROR: {message}{Colors.ENDC}")


def print_info(message: str, indent: int = 0) -> None:
    """
    Print an informational message.

    Args:
        message: Message to print
        indent: Number of spaces to indent
    """
    prefix = " " * indent
    print(f"{prefix}{Colors.YELLOW}ℹ {message}{Colors.ENDC}")


def print_divider(char: str = "-", width: int = 80) -> None:
    """
    Print a divider line.

    Args:
        char: Character to use for divider
        width: Width in characters
    """
    print(char * width)


def print_table(headers: list[str], rows: list[list[str]], indent: int = 0) -> None:
    """
    Print a formatted table.

    Args:
        headers: Column headers
        rows: Table rows (list of lists)
        indent: Number of spaces to indent
    """
    prefix = " " * indent

    # Calculate column widths
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    # Print headers
    header_line = " | ".join(h.ljust(w) for h, w in zip(headers, col_widths))
    print(f"{prefix}{Colors.BOLD}{header_line}{Colors.ENDC}")

    # Print separator
    separator = "-+-".join("-" * w for w in col_widths)
    print(f"{prefix}{separator}")

    # Print rows
    for row in rows:
        row_line = " | ".join(str(cell).ljust(w) for cell, w in zip(row, col_widths))
        print(f"{prefix}{row_line}")


def print_execution_flow(steps: list[str], indent: int = 0) -> None:
    """
    Print an execution flow diagram.

    Args:
        steps: List of execution steps
        indent: Number of spaces to indent
    """
    prefix = " " * indent
    for i, step in enumerate(steps, 1):
        if i < len(steps):
            print(f"{prefix}{i}. {step}")
            print(f"{prefix}   ↓")
        else:
            print(f"{prefix}{i}. {step}")


def print_call_stack(calls: list[str], indent: int = 0) -> None:
    """
    Print a visual call stack.

    Args:
        calls: List of function calls (deepest first)
        indent: Number of spaces to indent
    """
    prefix = " " * indent
    for i, call in enumerate(calls):
        depth = " " * (i * 2)
        arrow = "├→" if i < len(calls) - 1 else "└→"
        print(f"{prefix}{depth}{arrow} {call}")


def format_number(num: int) -> str:
    """
    Format a number with thousand separators.

    Args:
        num: Number to format

    Returns:
        Formatted number string
    """
    return f"{num:,}"


def get_timestamp() -> str:
    """
    Get current timestamp as formatted string.

    Returns:
        Timestamp string
    """
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def indent_text(text: str, spaces: int = 4) -> str:
    """
    Indent multi-line text.

    Args:
        text: Text to indent
        spaces: Number of spaces to indent

    Returns:
        Indented text
    """
    prefix = " " * spaces
    return "\n".join(prefix + line for line in text.split("\n"))
