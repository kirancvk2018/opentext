"""
Performance measurement utilities for the recursion learning project.

Provides timing and profiling tools for measuring recursion performance
and comparing optimization techniques.
"""

import time
from typing import Callable, Any, Optional
from contextlib import contextmanager
from functools import wraps


class Timer:
    """Context manager and decorator for measuring execution time."""

    def __init__(self, name: str = "Operation"):
        """
        Initialize timer.

        Args:
            name: Name of the operation being timed
        """
        self.name = name
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None

    def __enter__(self):
        """Start timing when entering context."""
        self.start_time = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stop timing when exiting context."""
        self.end_time = time.perf_counter()

    @property
    def elapsed(self) -> float:
        """
        Get elapsed time in seconds.

        Returns:
            Elapsed time in seconds
        """
        if self.start_time is None or self.end_time is None:
            return 0.0
        return self.end_time - self.start_time

    @property
    def elapsed_ms(self) -> float:
        """
        Get elapsed time in milliseconds.

        Returns:
            Elapsed time in milliseconds
        """
        return self.elapsed * 1000

    @property
    def elapsed_us(self) -> float:
        """
        Get elapsed time in microseconds.

        Returns:
            Elapsed time in microseconds
        """
        return self.elapsed * 1_000_000

    def __str__(self) -> str:
        """String representation of timer results."""
        if self.elapsed < 0.001:
            return f"{self.name}: {self.elapsed_us:.2f} μs"
        elif self.elapsed < 1:
            return f"{self.name}: {self.elapsed_ms:.2f} ms"
        else:
            return f"{self.name}: {self.elapsed:.2f} s"


class TimerContext:
    """Alias for Timer for readability."""
    pass


def measure_time(func: Callable) -> Callable:
    """
    Decorator to measure function execution time.

    Args:
        func: Function to measure

    Returns:
        Wrapped function that measures and reports execution time
    """
    @wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        timer = Timer(func.__name__)
        with timer:
            result = func(*args, **kwargs)
        print(timer)
        return result

    return wrapper


def compare_performance(
    func1: Callable,
    func2: Callable,
    *args,
    iterations: int = 1,
    **kwargs
) -> tuple[float, float]:
    """
    Compare performance of two functions.

    Args:
        func1: First function to compare
        func2: Second function to compare
        *args: Arguments to pass to both functions
        iterations: Number of times to run each function
        **kwargs: Keyword arguments to pass to both functions

    Returns:
        Tuple of (time_func1, time_func2)
    """
    # Time function 1
    timer1 = Timer("Function 1")
    with timer1:
        for _ in range(iterations):
            func1(*args, **kwargs)

    # Time function 2
    timer2 = Timer("Function 2")
    with timer2:
        for _ in range(iterations):
            func2(*args, **kwargs)

    print(f"\n{timer1}")
    print(f"{timer2}")
    print(f"\nSpeedup: {timer1.elapsed / timer2.elapsed:.2f}x")

    return timer1.elapsed, timer2.elapsed


def profile_recursion_calls(func: Callable) -> Callable:
    """
    Decorator to count and profile recursive function calls.

    Args:
        func: Recursive function to profile

    Returns:
        Wrapped function that tracks call count and depth
    """
    call_count = 0
    max_depth = 0
    current_depth = 0

    @wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        nonlocal call_count, max_depth, current_depth

        call_count += 1
        current_depth += 1
        max_depth = max(max_depth, current_depth)

        try:
            result = func(*args, **kwargs)
            return result
        finally:
            current_depth -= 1

    wrapper.get_stats = lambda: {
        'total_calls': call_count,
        'max_depth': max_depth,
    }

    return wrapper


@contextmanager
def timed_section(name: str):
    """
    Context manager for timing a code section.

    Args:
        name: Name of the section

    Yields:
        Timer object
    """
    timer = Timer(name)
    print(f"\n▶ Starting: {name}")
    with timer:
        yield timer
    print(f"◀ Completed: {timer}")


def format_time(seconds: float) -> str:
    """
    Format time in seconds to human-readable string.

    Args:
        seconds: Time in seconds

    Returns:
        Formatted time string
    """
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.2f} μs"
    elif seconds < 1:
        return f"{seconds * 1000:.2f} ms"
    elif seconds < 60:
        return f"{seconds:.2f} s"
    else:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.2f}s"
