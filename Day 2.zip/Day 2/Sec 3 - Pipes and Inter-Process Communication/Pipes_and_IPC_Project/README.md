# Python Pipes and Inter-Process Communication (IPC) – Enterprise Edition

## Project Overview

This comprehensive project teaches **Python Pipes and Inter-Process Communication** using realistic enterprise business scenarios. Rather than simple "hello world" examples, each module demonstrates production-quality patterns used in:

- **Financial Systems** – Order processing, payment validation, reconciliation
- **Healthcare** – Patient record processing, claims validation
- **Logistics** – Inventory synchronization, shipment tracking
- **Retail** – Transaction processing, fraud detection
- **Manufacturing** – Quality control, equipment monitoring
- **Telecommunications** – Call logging, network monitoring
- **Cloud Infrastructure** – Log aggregation, metrics collection

## Folder Structure

```
Pipes_and_IPC_Project/
│
├── README.md                          # This file
├── requirements.txt                   # Dependencies (Python 3.12+ built-in)
│
├── src/                               # Core educational modules
│   ├── 01_intro_to_ipc.py            # IPC fundamentals
│   ├── 02_why_pipes.py               # Pipes vs Sequential Processing
│   ├── 03_pipe_architecture_demo.py  # Producer-Consumer Architecture
│   ├── 04_simple_pipe.py             # Anonymous Pipe Basics
│   ├── 05_parent_child_pipe.py       # Parent-Child Communication
│   ├── 06_duplex_pipe.py             # Bidirectional Communication
│   ├── 07_object_transfer.py         # Serialization via Pipes
│   ├── 08_pipe_connection_management.py # Resource Management
│   ├── 09_fifo_writer_linux.py       # Linux FIFO Writer
│   ├── 10_fifo_reader_linux.py       # Linux FIFO Reader
│   ├── 11_windows_named_pipe_demo.py # Windows Named Pipe Concepts
│   ├── 12_fifo_blocking_behavior.py  # Blocking & Non-Blocking I/O
│   ├── 13_logging_system_pipe.py     # Enterprise Logging System
│   └── 14_ipc_architecture_demo.py   # Complex ETL Pipeline
│
├── labs/                              # Hands-on projects
│   ├── lab01_process_communication.py # Order Processing System
│   ├── lab02_pipe_chat_application.py # Bidirectional Chat
│   └── lab03_fifo_logger.py          # Linux FIFO Logger
│
└── common/                            # Shared utilities
    ├── logger.py                     # Logging utilities
    ├── utilities.py                  # Helper functions
    ├── timer.py                      # Performance measurement
    └── configuration.py              # Global settings
```

## Learning Objectives

Upon completing this project, you will understand:

1. **IPC Fundamentals**
   - Why processes need communication mechanisms
   - When to use pipes vs other IPC methods (queues, sockets, shared memory)
   - Trade-offs between different IPC approaches

2. **Anonymous Pipes**
   - Creating pipes with `multiprocessing.Pipe()`
   - Parent-child process communication
   - Unidirectional vs bidirectional communication

3. **Named Pipes (FIFO)**
   - Linux FIFO implementation and behavior
   - Reader-writer synchronization
   - Blocking behavior and timeouts

4. **Windows Named Pipes**
   - Conceptual understanding of Windows IPC
   - How to design cross-platform IPC solutions
   - Architectural patterns for OS-agnostic code

5. **Object Serialization**
   - Automatic pickling via multiprocessing
   - Sending complex Python objects (dicts, lists, dataclasses)
   - Performance implications

6. **Enterprise Patterns**
   - Logging aggregation from multiple processes
   - ETL pipeline architecture
   - Graceful process shutdown
   - Resource cleanup and exception handling

## Python Version & Prerequisites

**Required:** Python 3.12 or higher

**Dependencies:** None – uses Python Standard Library only

**Verified Modules:**
- `multiprocessing` – Process management and pipes
- `os` – FIFO creation (Linux/Unix)
- `time` – Timing and delays
- `pathlib` – Path manipulation
- `logging` – Structured logging
- `queue` – Comparison examples
- `dataclasses` – Structured data
- `typing` – Type hints
- `collections` – Advanced data structures
- `functools` – Functional utilities
- `datetime` – Timestamps
- `platform` – OS detection

## VS Code Setup

### Recommended Extensions
```
Python 3.12+
Pylance
Python Docstring Generator
Better Comments
```

### Recommended Settings (.vscode/settings.json)
```json
{
  "python.defaultInterpreterPath": "/usr/bin/python3.12",
  "python.linting.enabled": true,
  "python.linting.pylintEnabled": true,
  "editor.formatOnSave": true,
  "python.formatting.provider": "black",
  "[python]": {
    "editor.defaultFormatter": "ms-python.python",
    "editor.formatOnSave": true,
    "editor.rulers": [79, 119]
  }
}
```

### Launch Configuration (.vscode/launch.json)
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Python: Current File",
      "type": "python",
      "request": "launch",
      "program": "${file}",
      "console": "integratedTerminal",
      "justMyCode": true
    }
  ]
}
```

## How to Run

### Individual Modules

Execute any module directly:

```bash
# Linux/macOS
python3 src/01_intro_to_ipc.py
python3 src/04_simple_pipe.py

# Windows
python src/01_intro_to_ipc.py
python src/04_simple_pipe.py
```

### Lab Exercises

```bash
python3 labs/lab01_process_communication.py
python3 labs/lab02_pipe_chat_application.py

# Linux/macOS only (FIFO requires filesystem)
python3 labs/lab03_fifo_logger.py
```

### Run All Examples

```bash
# Create a test runner script
python3 -m src.01_intro_to_ipc
python3 -m src.04_simple_pipe
```

## Execution Order (Recommended Learning Path)

1. **Foundation**
   - `01_intro_to_ipc.py` – Understand IPC concepts
   - `02_why_pipes.py` – Grasp pipe advantages

2. **Basic Pipes**
   - `03_pipe_architecture_demo.py` – Visualize architecture
   - `04_simple_pipe.py` – First hands-on experience
   - `05_parent_child_pipe.py` – Parent-child patterns

3. **Advanced Pipes**
   - `06_duplex_pipe.py` – Bidirectional communication
   - `07_object_transfer.py` – Complex data types
   - `08_pipe_connection_management.py` – Best practices

4. **FIFO & Named Pipes** (Linux/macOS)
   - `09_fifo_writer_linux.py` – Write to FIFO
   - `10_fifo_reader_linux.py` – Read from FIFO
   - `12_fifo_blocking_behavior.py` – Advanced behavior

5. **Windows & Cross-Platform**
   - `11_windows_named_pipe_demo.py` – Windows concepts
   - `14_ipc_architecture_demo.py` – Complex systems

6. **Enterprise Systems**
   - `13_logging_system_pipe.py` – Real-world logging

7. **Hands-on Labs**
   - `lab01_process_communication.py` – Build from scratch
   - `lab02_pipe_chat_application.py` – Interactive systems
   - `lab03_fifo_logger.py` – Production patterns

## IPC Architecture Diagrams

### Simple Anonymous Pipe

```
Parent Process          Child Process
┌─────────────────┐     ┌──────────────┐
│  Producer       │────>│  Consumer    │
│  send("data")   │Pipe │  data = recv()
└─────────────────┘     └──────────────┘
     One-way Communication
```

### Duplex Pipe (Bidirectional)

```
Process A          Process B
┌──────────┐      ┌──────────┐
│  Both    │<───>│  Both    │
│  Sender  │Pipe │  Sender  │
│  Receiver│      │  Receiver│
└──────────┘      └──────────┘
    Two-way Communication
```

### FIFO (Named Pipe)

```
Process A         Filesystem         Process B
┌────────┐       [/tmp/fifo.pipe]   ┌────────┐
│ Writer │────>   Persistent         │ Reader │
│ Writer │<───────  Named Pipe ─────>│ Reader │
└────────┘                           └────────┘
   Survives Process Termination
```

### Enterprise Logging System

```
Worker 1 ─┐
Worker 2 ─┼──>  Logger Pipe  ──> Central Logger Process
Worker 3 ─┤                         │
Worker 4 ─┘                         └──> File / Console
              Multiple Writers, Single Reader
```

### ETL Pipeline

```
Source Data
    │
    ├──> Producer Process
           │
           Pipe (Raw Data)
           │
    ├──> Validation Process
           │
           Pipe (Clean Data)
           │
    ├──> Transform Process
           │
           Pipe (Formatted Data)
           │
    └──> Reporter Process
           │
           └──> Output
```

## Pipe Communication Flow

### Initialization
```
1. Parent calls multiprocessing.Pipe()
   → Returns (conn1, conn2) tuple
   
2. Parent passes conn2 to child via fork
   
3. Parent uses conn1, Child uses conn2
```

### Data Transfer
```
1. Sender calls: conn.send(data)
   → Data is pickled (serialized)
   → Data placed in kernel buffer
   
2. Receiver calls: data = conn.recv()
   → Blocks until data available
   → Data unpickled (deserialized)
   → Returns to receiver
```

### Cleanup
```
1. Parent closes: conn1.close()
   → Releases file descriptors
   → Notifies kernel
   
2. Child closes: conn2.close()
   → Cleanup complete when both close
```

## IPC Method Comparison

| Feature | Pipes | Queues | Sockets | Shared Memory |
|---------|-------|--------|---------|---------------|
| **Type** | Stream | FIFO Buffer | Network | Direct Memory |
| **Scope** | Process Family | Any Process | Network | OS-specific |
| **Speed** | Very Fast | Fast | Slow | Fastest |
| **Complexity** | Low | Medium | High | Very High |
| **Use Case** | Parent-Child | Thread Pool | Distributed | Real-time |
| **Blocking** | Natural | Configurable | Network-bound | Custom |
| **Security** | OS-controlled | File-based | TCP/IP | Manual |
| **Persistence** | No | No | Yes | No |
| **Named** | Yes (FIFO) | No | Yes | No |

### Pipes vs Queues

**Pipes (multiprocessing.Pipe)**
```python
# Direct connection between two processes
conn1, conn2 = multiprocessing.Pipe()
conn1.send(data)
data = conn2.recv()
# ✓ Simple
# ✓ Low latency
# ✗ Only two endpoints
```

**Queues (multiprocessing.Queue)**
```python
# Multiple producers and consumers
q = multiprocessing.Queue()
q.put(data)
data = q.get()
# ✓ Many endpoints
# ✓ Built-in locking
# ✗ Slightly slower
```

### Pipes vs Shared Memory

**Pipes**
```python
# Data copied through pipe
conn.send(large_data)  # Copied
data = conn.recv()     # Copied
```

**Shared Memory (Value, Array)**
```python
# Direct memory access
shared_value = Value('i', 0)
shared_value.value = 42  # No copy
print(shared_value.value)  # Direct read
```

### Pipes vs Sockets

**Pipes (Local)**
```python
# Within same machine
conn1.send(data)  # Fast, low latency
# ✓ Kernel-optimized
# ✗ Local only
```

**Sockets (Network)**
```python
# Across network
socket.send(data)  # Network overhead
# ✓ Distributed systems
# ✗ Network latency
```

## Advantages of Pipes

1. **Simplicity** – Easy to understand and implement
2. **Performance** – Kernel-optimized communication
3. **Automatic Serialization** – Python objects handled transparently
4. **Resource Efficiency** – Minimal memory overhead
5. **Ordered Delivery** – FIFO guarantee (important for transactional systems)
6. **Blocking Support** – Natural flow control
7. **Named Variant (FIFO)** – Survives process termination

## Limitations of Pipes

1. **Two Endpoints** – Anonymous pipes connect only parent-child
2. **Unidirectional** – Default pipe is one-way (though duplex available)
3. **No Network** – Limited to single machine
4. **Serialization Overhead** – Pickling adds CPU cost for large objects
5. **No Built-in Queuing** – Manual message framing required
6. **Platform Differences** – FIFO behavior varies (Linux vs macOS vs Windows)
7. **Deadlock Risk** – Possible if both processes wait to receive

## Performance Considerations

### Throughput Comparison

```
Small objects (< 1KB):      Pipes ~1M ops/sec
Medium objects (1-100KB):   Pipes ~100K ops/sec
Large objects (> 1MB):      Pipes ~10K ops/sec

Queues: 10-20% slower due to locking
Sockets: 100x slower (network overhead)
```

### Optimization Tips

1. **Batch Messages** – Send 100 items at once vs 100 individual sends
2. **Avoid Large Objects** – Break data into chunks if > 100MB
3. **Use Duplex** – Better than creating separate pipes
4. **Buffer Data** – Accumulate messages before sending
5. **Monitor File Descriptors** – Close unused connections

## Recommended Learning Path

### Week 1: Fundamentals
- Day 1: Intro + Why Pipes (01, 02)
- Day 2: Architecture Demo (03)
- Day 3: Simple Pipe (04)
- Day 4: Parent-Child (05)
- Day 5: Lab 01

### Week 2: Advanced Pipes
- Day 1: Duplex Pipe (06)
- Day 2: Object Transfer (07)
- Day 3: Connection Management (08)
- Day 4: Lab 02
- Day 5: Review & Refactor

### Week 3: Named Pipes & Enterprise
- Day 1: FIFO Writer (09)
- Day 2: FIFO Reader (10)
- Day 3: Blocking Behavior (12)
- Day 4: Logging System (13)
- Day 5: Lab 03

### Week 4: Architecture & Production
- Day 1: Windows Concepts (11)
- Day 2: ETL Architecture (14)
- Day 3: Production Patterns
- Day 4: Performance Tuning
- Day 5: Project Presentation

## Common Pitfalls to Avoid

1. **Forgetting to Close** – Always close unused connections
2. **Deadlock** – Both processes waiting to receive
3. **Serialization Errors** – Non-picklable objects
4. **Not Handling Exceptions** – Pipe broken during communication
5. **Blocking Reads** – Freezing if data never arrives
6. **Buffer Overflow** – Pipe buffer limits (typically 64KB)
7. **Not Testing Edge Cases** – Empty data, large objects, rapid sends

## Interview Preparation

### Common Questions

1. **Difference between pipes and queues?**
   - Pipes: Direct connection, two endpoints
   - Queues: Buffered, multiple endpoints

2. **Why close pipes?**
   - Release file descriptors
   - Signal end-of-data
   - Prevent deadlocks (broken pipe errors)

3. **How is data serialized?**
   - Python pickle protocol
   - Automatic by multiprocessing
   - Adds CPU overhead

4. **Named pipe vs anonymous pipe?**
   - Named: Filesystem entry, survives termination
   - Anonymous: In-memory, bound to processes

5. **How to prevent deadlock?**
   - Close unused connections
   - Use timeouts
   - Separate read/write processes

## Getting Started

1. **Verify Python Version**
   ```bash
   python3 --version  # Should be 3.12+
   ```

2. **Navigate to Project**
   ```bash
   cd Pipes_and_IPC_Project
   ```

3. **Run First Example**
   ```bash
   python3 src/01_intro_to_ipc.py
   ```

4. **Follow Learning Path**
   - Read each file's problem statement
   - Study the code
   - Run the example
   - Complete hands-on exercise
   - Try challenge exercise

5. **Complete Labs**
   - Build from requirements
   - Test thoroughly
   - Compare with provided solution

## Troubleshooting

### Script Won't Run
```bash
# Ensure Python 3.12+
python3 --version

# Add execute permission (Linux/macOS)
chmod +x src/01_intro_to_ipc.py

# Try direct python invocation
python3 src/01_intro_to_ipc.py
```

### FIFO Not Working (Linux)
```bash
# Check if /tmp is available
ls -la /tmp/

# Verify FIFO exists
ls -la /tmp/fifo_*.pipe

# Remove stale FIFO
rm -f /tmp/fifo_*.pipe
```

### Import Errors
```bash
# Ensure PYTHONPATH includes project
export PYTHONPATH="${PYTHONPATH}:$(pwd)"

# Try absolute imports
python3 -m src.04_simple_pipe
```

### Windows Issues
```bash
# Run from Command Prompt or PowerShell
python src/01_intro_to_ipc.py

# NOT bash – different behavior
```

## Next Steps

After completing this project:

1. **Explore multiprocessing.Queue** – See how queuing differs from pipes
2. **Study Socket Communication** – Extend to network IPC
3. **Investigate Shared Memory** – Value and Array for real-time data
4. **Build a Distributed System** – Use multiple machines
5. **Performance Profiling** – Measure pipe overhead in your systems
6. **Production Integration** – Apply to real enterprise systems

## License

Educational Use – Modify and redistribute freely

## Contact & Support

For questions or issues:
1. Review the relevant module's documentation
2. Check common pitfalls section
3. Try debugging tips section
4. Examine similar examples

---

**Happy Learning! 🚀**

*This project represents production-quality patterns used in enterprise systems processing millions of transactions daily.*
