"""
###############################################################################
Python IPC – FIFO Blocking Behavior & Message Queues
###############################################################################

PROBLEM STATEMENT: Understand blocking behavior of FIFO pipes and how to
handle timeouts in message processing systems.

BUSINESS SCENARIO: Message Queue Processing
Company: MessageFlow Systems
System: Asynchronous message processing
"""

import os
import sys
import time

if os.name != "posix":
    print("FIFO requires Linux/macOS. Showing conceptual examples.")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section


def demonstrate_blocking_behavior() -> None:
    """Demonstrate and explain blocking behavior."""
    logger = get_logger(__name__)

    log_section(logger, "FIFO/Pipe Blocking Behavior")

    logger.info("""
BLOCKING SCENARIOS:

1. READING WHEN EMPTY
   ───────────────────

   recv() when pipe empty:
   → BLOCKS (waits for data)
   → Process suspended
   → Resumes when data arrives

   Timeline:
   Writer:    [delayed]              send("data")
   Reader:    recv() ─ BLOCKED ─ ─ ─ ─ unblocked, data


2. WRITING WHEN FULL
   ──────────────────

   send() when buffer full (~64KB):
   → BLOCKS (waits for reader)
   → Process suspended
   → Resumes when buffer has space

   Timeline:
   Reader:    recv() ─ delayed ─ recv()  recv()
   Writer:    send() ─ BLOCKED ─ unblocked, send()


3. NORMAL CASE
   ────────────

   Balanced speed:
   → send() returns immediately (buffer has space)
   → recv() returns immediately (data in buffer)
   → No blocking


4. BOTH BLOCKED (DEADLOCK)
   ───────────────────────

   Reader: recv()   ← BLOCKED (waiting for write)
   Writer: send()   ← BLOCKED (buffer full, waiting for read)

   → DEADLOCK - neither can proceed
   → Problem: If both waiting, no one will wake other


SOLUTIONS TO DEADLOCK:

1. Use select() / poll()
   from select import select
   readable, _, _ = select([pipe], [], [], timeout=1.0)

2. Use non-blocking mode
   os.set_blocking(fd, False)
   # Returns immediately, raises exception if no data

3. Use separate processes
   Read and write from different processes

4. Use timeouts
   signal.alarm() or process timeout
    """)


def demonstrate_poll_timeout() -> None:
    """Show poll with timeout."""
    logger = get_logger(__name__)

    log_section(logger, "Using Poll with Timeout")

    logger.info("""
PROBLEM: recv() blocks forever if no data

SOLUTION: Use poll(timeout)

multiprocessing.Connection.poll(timeout):
    Returns True if data available
    Returns False if timeout
    Non-blocking check

EXAMPLE:

import multiprocessing as mp

conn1, conn2 = mp.Pipe()

# Parent: try to receive with timeout
if conn1.poll(timeout=1.0):
    data = conn1.recv()
    print(f"Received: {data}")
else:
    print("Timeout - no data after 1.0s")


USE CASES:

1. Timeout Handler
   if conn.poll(timeout=5.0):
       msg = conn.recv()
   else:
       logger.error("Request timeout")
       handle_timeout()

2. Non-blocking Loop
   while running:
       for pipe in pipes:
           if pipe.poll(timeout=0.1):
               msg = pipe.recv()
               process(msg)

3. Heartbeat
   if not conn.poll(timeout=30.0):
       logger.warning("No heartbeat")
       restart_process()
    """)


def demonstrate_queue_vs_pipe() -> None:
    """Compare Queue behavior vs Pipe."""
    logger = get_logger(__name__)

    log_section(logger, "Queue vs Pipe Blocking")

    logger.info("""
MULTIPROCESSING.QUEUE:

Purpose: Buffered, multiple producers/consumers

Behavior:
    q = mp.Queue(maxsize=5)

    q.put(item)      → Blocks if full
    q.get()          → Blocks if empty
    q.put_nowait()   → Raises if full
    q.get_nowait()   → Raises if empty

    q.qsize()        → Approximate size (unreliable)
    q.empty()        → Check if empty
    q.full()         → Check if full

Built-in Features:
    ✓ Multiple writers
    ✓ Multiple readers
    ✓ Thread-safe
    ✓ Process-safe
    ✓ Automatic locks


MULTIPROCESSING.PIPE:

Purpose: Direct connection, minimal overhead

Behavior:
    conn1, conn2 = mp.Pipe()

    conn.send(obj)   → Blocks if buffer full
    conn.recv()      → Blocks if empty
    conn.poll()      → Non-blocking check
    conn.close()     → Close connection

No Built-in:
    ✗ Multiple endpoints
    ✗ Automatic locking
    ✗ Size queries


COMPARISON:

              Queue          Pipe
─────────────────────────────────
Endpoints     Multiple       Two
Blocking      Yes            Yes
Non-blocking  get_nowait()   poll()
Built-in Lock ✓              ✗
Buffer Size   Configurable   Fixed (~64KB)
Use Case      General        Simple
────────────────────────────────

WHEN TO USE:

Use Pipe:
• Simple parent-child
• One-way communication
• Minimal overhead

Use Queue:
• Multiple producers/consumers
• Need locking
• Variable buffer size
    """)


def demonstrate_message_patterns() -> None:
    """Show message processing patterns."""
    logger = get_logger(__name__)

    log_section(logger, "Message Processing Patterns")

    logger.info("""
PATTERN 1: Blocking Wait (Simple)
─────────────────────────────────

while True:
    message = conn.recv()  # BLOCKS until data
    process(message)


Pros: Simple, CPU efficient
Cons: No timeout, can hang


PATTERN 2: Timeout (Robust)
──────────────────────────

while running:
    if conn.poll(timeout=5.0):
        message = conn.recv()
        process(message)
    else:
        logger.warning("Timeout")
        # Handle timeout


Pros: Won't hang forever
Cons: Slightly more complex


PATTERN 3: Non-blocking (Complex)
──────────────────────────────

import os
import fcntl

# Set non-blocking
fcntl.fcntl(conn.fileno(), fcntl.F_SETFL, os.O_NONBLOCK)

try:
    message = conn.recv()
    process(message)
except BlockingIOError:
    # No data available
    pass


Pros: Full control, can do other work
Cons: Must handle exceptions


PATTERN 4: Multiple Pipes (Round-robin)
───────────────────────────────────────

pipes = [pipe1, pipe2, pipe3, ...]

while running:
    for pipe in pipes:
        if pipe.poll(timeout=0.1):
            msg = pipe.recv()
            process(msg)


Pros: Monitor multiple sources
Cons: CPU usage if checking rapidly


PATTERN 5: Select/Poll (Unix)
─────────────────────────────

from select import select

pipes = [pipe1, pipe2, pipe3, ...]

readable, _, _ = select(pipes, [], [], timeout=5.0)

for pipe in readable:
    msg = pipe.recv()
    process(msg)


Pros: Efficient, scales to many pipes
Cons: Unix only, complex
    """)


def explain_queue_simulation() -> None:
    """Explain how to simulate queue behavior with pipes."""
    logger = get_logger(__name__)

    log_section(logger, "Implementing Queue with Pipes")

    logger.info("""
SIMPLE QUEUE CLASS USING PIPES:

class PipeQueue:
    def __init__(self):
        self.conn1, self.conn2 = mp.Pipe()

    def put(self, item):
        self.conn1.send(item)

    def get(self, timeout=None):
        if self.conn2.poll(timeout=timeout):
            return self.conn2.recv()
        else:
            raise TimeoutError("No item received")


USAGE:

q = PipeQueue()

# Producer
q.put("message1")
q.put("message2")

# Consumer
try:
    msg = q.get(timeout=1.0)
    print(msg)
except TimeoutError:
    print("Timeout")


ADVANTAGES:
✓ Simple implementation
✓ Works with pipes
✓ Minimal overhead

LIMITATIONS:
✗ Only two endpoints (producer-consumer)
✗ No multiple producers/consumers
✗ No automatic locking
✗ Use multiprocessing.Queue for complex cases
    """)


def main() -> None:
    """Entry point."""
    demonstrate_blocking_behavior()
    demonstrate_poll_timeout()
    demonstrate_queue_vs_pipe()
    demonstrate_message_patterns()
    explain_queue_simulation()


# ============================================================================
# KEY TAKEAWAYS
# ============================================================================
"""
1. recv() blocks when pipe empty - waits for data
2. send() blocks when buffer full - waits for space
3. Use poll(timeout) for non-blocking check
4. Deadlock possible if both processes wait
5. Separate read/write processes prevents deadlock
6. Queue better for multiple endpoints
7. Pipe better for simple parent-child
8. Always have timeout strategy
"""


if __name__ == "__main__":
    main()
