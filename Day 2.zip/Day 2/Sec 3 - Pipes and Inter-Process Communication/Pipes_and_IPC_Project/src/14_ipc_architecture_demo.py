"""
###############################################################################
Python IPC – Complex Architecture: ETL Processing Pipeline
###############################################################################

PROBLEM STATEMENT: ETL pipeline needs to process data through multiple
stages: extraction, transformation, validation, and loading.

BUSINESS SCENARIO: Data Warehouse ETL
Company: DataMart Solutions
System: Nightly ETL pipeline processing 1GB data
"""

import logging
import multiprocessing as mp
import time
from typing import Dict, Any

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section


def extractor(send_pipe, num_records: int) -> None:
    """Extract data from source."""
    logger = get_logger(__name__)
    logger.info("[EXTRACTOR] Starting")

    for i in range(1, num_records + 1):
        record = {
            "id": f"REC-{i:05d}",
            "raw_data": f"data_{i}",
            "value": i * 100,
        }
        send_pipe.send(record)
        logger.info(f"[EXTRACTOR] Extracted REC-{i:05d}")
        time.sleep(0.15)

    send_pipe.close()
    logger.info("[EXTRACTOR] Complete")


def transformer(recv_pipe, send_pipe) -> None:
    """Transform data."""
    logger = get_logger(__name__)
    logger.info("[TRANSFORMER] Started")

    try:
        while True:
            record = recv_pipe.recv()

            # Transform
            transformed = {
                "id": record["id"],
                "cleaned_data": record["raw_data"].upper(),
                "value": record["value"] * 1.1,  # Add 10%
            }

            send_pipe.send(transformed)
            logger.info(f"[TRANSFORMER] Transformed {record['id']}")
            time.sleep(0.1)

    except EOFError:
        logger.info("[TRANSFORMER] Complete")
    finally:
        recv_pipe.close()
        send_pipe.close()


def validator(recv_pipe, send_pipe) -> None:
    """Validate data."""
    logger = get_logger(__name__)
    logger.info("[VALIDATOR] Started")

    try:
        while True:
            record = recv_pipe.recv()

            # Validate
            valid = record["value"] > 0

            validated = {
                "id": record["id"],
                "data": record["cleaned_data"],
                "value": record["value"],
                "valid": valid,
            }

            send_pipe.send(validated)
            logger.info(f"[VALIDATOR] Validated {record['id']} - {'✓' if valid else '✗'}")
            time.sleep(0.12)

    except EOFError:
        logger.info("[VALIDATOR] Complete")
    finally:
        recv_pipe.close()
        send_pipe.close()


def loader(recv_pipe) -> None:
    """Load data to warehouse."""
    logger = get_logger(__name__)
    logger.info("[LOADER] Started")

    loaded = 0
    try:
        while True:
            record = recv_pipe.recv()

            if record["valid"]:
                # "Load" to warehouse
                logger.info(f"[LOADER] Loaded {record['id']} - ${record['value']:.2f}")
                loaded += 1

            time.sleep(0.15)

    except EOFError:
        logger.info(f"[LOADER] Complete - Loaded {loaded} records")
    finally:
        recv_pipe.close()


def demonstrate_etl_pipeline() -> None:
    """Demonstrate complex ETL pipeline."""
    logger = get_logger(__name__)

    log_section(logger, "ETL Pipeline Architecture")

    logger.info("\nArchitecture:")
    logger.info("""
    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
    │  EXTRACTOR   │───>│ TRANSFORMER  │───>│  VALIDATOR   │───>│   LOADER     │
    │              │    │              │    │              │    │              │
    │ Source Data  │    │ Clean & Enrich │ Validate Data  │    │ Load to DB   │
    └──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘
         Pipe 1              Pipe 2              Pipe 3

    4 processes, 3 pipes, parallel execution
    """)

    logger.info("\nInitialization:")
    logger.info("─" * 70)

    # Create pipes
    ext_trans_pipe_1, ext_trans_pipe_2 = mp.Pipe()
    trans_val_pipe_1, trans_val_pipe_2 = mp.Pipe()
    val_load_pipe_1, val_load_pipe_2 = mp.Pipe()

    logger.info("✓ Created 3 pipes")

    # Create processes
    extract_proc = mp.Process(
        target=extractor,
        args=(ext_trans_pipe_1, 5),
        name="Extractor",
    )
    transform_proc = mp.Process(
        target=transformer,
        args=(ext_trans_pipe_2, trans_val_pipe_1),
        name="Transformer",
    )
    validate_proc = mp.Process(
        target=validator,
        args=(trans_val_pipe_2, val_load_pipe_1),
        name="Validator",
    )
    load_proc = mp.Process(
        target=loader,
        args=(val_load_pipe_2,),
        name="Loader",
    )

    logger.info("✓ Created 4 processes\n")

    logger.info("Execution:")
    logger.info("─" * 70)

    # Start all processes
    extract_proc.start()
    transform_proc.start()
    validate_proc.start()
    load_proc.start()

    logger.info("✓ All 4 processes started")
    logger.info("✓ Pipeline running - data flowing through stages\n")

    # Wait for completion
    extract_proc.join()
    transform_proc.join()
    validate_proc.join()
    load_proc.join()

    logger.info("✓ All processes complete")

    # Cleanup
    if not ext_trans_pipe_1.closed:
        ext_trans_pipe_1.close()
    if not ext_trans_pipe_2.closed:
        ext_trans_pipe_2.close()
    if not trans_val_pipe_1.closed:
        trans_val_pipe_1.close()
    if not trans_val_pipe_2.closed:
        trans_val_pipe_2.close()
    if not val_load_pipe_1.closed:
        val_load_pipe_1.close()
    if not val_load_pipe_2.closed:
        val_load_pipe_2.close()

    logger.info("✓ All pipes closed\n")


def explain_pipeline_benefits() -> None:
    """Explain benefits of pipeline architecture."""
    logger = get_logger(__name__)

    log_section(logger, "Pipeline Benefits")

    logger.info("\nParallelism:")
    logger.info("─" * 70)
    logger.info("""
    Without Pipeline (Sequential):
    ┌──────┬──────┬──────┬──────┐
    │ EXT  │ XFRM │ VAL  │ LOAD │  Time: 4 × T
    └──────┴──────┴──────┴──────┘

    With Pipeline (Parallel):
    ┌──────┬──────┬──────┬──────┐
    │ EXT  │ EXT  │ EXT  │ EXT  │
    │      │ XFRM │ XFRM │ XFRM │
    │      │      │ VAL  │ VAL  │
    │      │      │      │ LOAD │  Time: T + overhead

    Speedup: ~4x for 4 stages
    """)

    logger.info("\nMemory Efficiency:")
    logger.info("  • Process full dataset at once? NO")
    logger.info("  • Stream through pipeline? YES")
    logger.info("  • Buffer between stages: ~64KB each")
    logger.info("  • Never hold entire dataset in memory")

    logger.info("\nLoad Balancing:")
    logger.info("  • Different stages have different speeds")
    logger.info("  • Fast stages wait for slow (buffer blocks)")
    logger.info("  • Automatic load balancing via pipe buffers")

    logger.info("\nModularity:")
    logger.info("  • Each process independent")
    logger.info("  • Easy to test each stage")
    logger.info("  • Easy to replace stage")
    logger.info("  • Easy to add new stages")


def explain_pipeline_design() -> None:
    """Explain pipeline design considerations."""
    logger = get_logger(__name__)

    log_section(logger, "Pipeline Design Considerations")

    logger.info("\n1. Balanced Stages")
    logger.info("─" * 70)
    logger.info("""
    Ideal: All stages take similar time
    ┌──────┐┌──────┐┌──────┐┌──────┐
    │ 1.0s ││ 1.0s ││ 1.0s ││ 1.0s │
    └──────┘└──────┘└──────┘└──────┘

    Reality: Stages have different speeds
    ┌──────────┐┌────┐┌──────────┐┌────┐
    │   2.0s   ││0.5s││  1.5s    ││0.5s│
    └──────────┘└────┘└──────────┘└────┘

    Bottleneck = slowest stage determines throughput
    """)

    logger.info("\n2. Pipe Ordering")
    logger.info("─" * 70)
    logger.info("  • FIFO guarantee - order preserved")
    logger.info("  • Data never skips ahead")
    logger.info("  • Can rely on ordering for dependencies")

    logger.info("\n3. Error Handling")
    logger.info("─" * 70)
    logger.info("  • Error in one stage affects pipeline")
    logger.info("  • Consider: continue or fail-fast?")
    logger.info("  • May need error queue parallel to pipeline")

    logger.info("\n4. Backpressure")
    logger.info("─" * 70)
    logger.info("  • Slow downstream blocks upstream")
    logger.info("  • Automatic via pipe buffer")
    logger.info("  • No data explosion")

    logger.info("\n5. Monitoring")
    logger.info("─" * 70)
    logger.info("  • Monitor each stage for bottleneck")
    logger.info("  • Track records processed per stage")
    logger.info("  • Watch for deadlocks")


def show_timing_analysis() -> None:
    """Show timing for sequential vs pipeline."""
    logger = get_logger(__name__)

    log_section(logger, "Timing Analysis")

    logger.info("\nExample: 5 records through 4 stages")
    logger.info("─" * 70)

    logger.info("""
    Stage times:
    - Extractor:   150ms per record
    - Transformer: 100ms per record
    - Validator:   120ms per record
    - Loader:      150ms per record

    SEQUENTIAL (each stage waits):
    Total = 5 × (150 + 100 + 120 + 150) = 2100ms

    PIPELINE (parallel execution):
    Record 1: 150ms (extract) + 100ms (transform) + 120ms (validate) + 150ms (load)
    Record 2-5: Overlap with Record 1
    Total ≈ 150 + 4×150 = 750ms (limited by slowest stage: 150ms each)

    Speedup: 2100 / 750 = 2.8x
    """)

    logger.info("\nOptimization Strategies:")
    logger.info("  1. Parallelize bottleneck stage (slow transformer?)")
    logger.info("  2. Batch small records")
    logger.info("  3. Increase buffer size if cheap")
    logger.info("  4. Profile to find real bottleneck")


def main() -> None:
    """Entry point."""
    demonstrate_etl_pipeline()
    explain_pipeline_benefits()
    explain_pipeline_design()
    show_timing_analysis()


# ============================================================================
# KEY CONCEPTS
# ============================================================================
"""
Pipeline: Multiple stages connected via pipes
Parallel Execution: All stages run simultaneously
Streaming: Data flows through, not batched
Throughput: Limited by slowest stage
Backpressure: Slow stage blocks fast stage
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: How does a multi-stage pipeline differ from sequential?
   A: Sequential: one stage at a time
      Pipeline: all stages run in parallel
      Result: significant speedup

2. Q: What limits pipeline throughput?
   A: Slowest stage (bottleneck)
      Pipe buffer size (limits buffering)

3. Q: How to find the bottleneck?
   A: Profile each stage
      Measure records/second per stage
      Slowest is bottleneck

4. Q: What if one stage crashes?
   A: Pipeline stops (sends detect EOF)
      Need error handling
      Maybe fallback queue

5. Q: When would pipeline NOT help?
   A: Tight dependencies between stages
      Very fast stages (IPC overhead > benefit)
      Single-record processing
"""


if __name__ == "__main__":
    main()
