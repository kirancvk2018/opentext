"""
###############################################################################
Python IPC – Pipe Architecture: Producer-Consumer Pattern
###############################################################################

PROBLEM STATEMENT: Data validation pipeline needs to show architecture
with producer, pipe, and consumer components working together.

BUSINESS SCENARIO: Real-time Data Validation
Company: DataFlow Technologies
System: ETL pipeline for data warehouse
"""

import logging
import multiprocessing as mp
import time
from typing import Dict, Any, List

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section, log_separator


def data_producer(conn, num_records: int) -> None:
    """Process that generates data."""
    logger = get_logger(__name__)
    logger.info(f"[PRODUCER] Starting - will generate {num_records} records")

    for i in range(1, num_records + 1):
        record = {
            "id": f"REC-{i:05d}",
            "value": i * 100,
            "timestamp": time.time(),
        }

        logger.info(f"[PRODUCER] Generated: {record['id']}")
        conn.send(record)
        time.sleep(0.2)

    conn.close()
    logger.info("[PRODUCER] Complete")


def data_consumer(conn) -> None:
    """Process that consumes and validates data."""
    logger = get_logger(__name__)
    logger.info("[CONSUMER] Waiting for data")

    count = 0
    try:
        while True:
            record = conn.recv()
            count += 1
            logger.info(f"[CONSUMER] Received & validated: {record['id']}")
            time.sleep(0.25)

    except EOFError:
        logger.info(f"[CONSUMER] Complete - processed {count} records")
    finally:
        conn.close()


def demonstrate_producer_consumer() -> None:
    """Show producer-consumer architecture."""
    logger = get_logger(__name__)

    log_section(logger, "Producer-Consumer Architecture")

    logger.info("\nArchitecture Diagram:")
    logger.info("""
    ┌─────────────┐        ┌──────────┐        ┌──────────────┐
    │  Producer   │───────>│   Pipe   │───────>│  Consumer    │
    │ (Generate)  │        │ (Buffer) │        │  (Validate)  │
    └─────────────┘        └──────────┘        └──────────────┘

    Producer writes data → Pipe buffers it → Consumer reads data
    """)

    logger.info("\nInitialization:")
    logger.info("─" * 70)

    # Create pipe
    prod_conn, cons_conn = mp.Pipe()
    logger.info("✓ Pipe created (capacity ~64KB)")

    # Create processes
    producer = mp.Process(
        target=data_producer,
        args=(prod_conn, 3),
        name="Producer",
    )
    consumer = mp.Process(
        target=data_consumer,
        args=(cons_conn,),
        name="Consumer",
    )

    logger.info("✓ Producer process created")
    logger.info("✓ Consumer process created")

    logger.info("\nExecution:")
    logger.info("─" * 70)

    # Start both simultaneously
    producer.start()
    consumer.start()

    logger.info("[PARENT] Both processes running simultaneously")
    logger.info("[PARENT] Producer generates, Consumer validates")

    # Wait for completion
    producer.join()
    consumer.join()

    logger.info("\n[PARENT] Both processes complete")

    # Cleanup
    if not prod_conn.closed:
        prod_conn.close()
    if not cons_conn.closed:
        cons_conn.close()

    logger.info("✓ All connections closed")


def explain_architecture_components() -> None:
    """Explain the three components of pipe architecture."""
    logger = get_logger(__name__)

    log_section(logger, "Architecture Components")

    logger.info("\n1. PRODUCER PROCESS")
    logger.info("─" * 70)
    logger.info("""
    Responsibility:
    • Generate or read source data
    • Prepare data for transmission
    • Send data through pipe

    Example: Invoice generator
    • Read from database
    • Create invoice objects
    • Send via conn.send()

    Characteristics:
    • Active: Generates work
    • Write-side: Sends data
    • Closes connection when done
    """)

    logger.info("\n2. PIPE (KERNEL BUFFER)")
    logger.info("─" * 70)
    logger.info("""
    Purpose:
    • Temporary data storage
    • Decouples producer and consumer
    • Handles serialization/deserialization

    Characteristics:
    • Kernel-managed: Part of OS
    • Buffered: ~64KB capacity (varies)
    • FIFO: First-in-first-out order
    • IPC mechanism: Inter-process communication

    Data Flow:
    1. Producer: conn.send(obj)
    2. Kernel: serialize → buffer
    3. Consumer: conn.recv()
    4. Kernel: buffer → deserialize → obj
    """)

    logger.info("\n3. CONSUMER PROCESS")
    logger.info("─" * 70)
    logger.info("""
    Responsibility:
    • Receive data from pipe
    • Process/validate data
    • Store or output results

    Example: Invoice validator
    • Receive invoice via conn.recv()
    • Validate amounts and fields
    • Mark as approved/rejected

    Characteristics:
    • Passive: Waits for work
    • Read-side: Receives data
    • Blocks until data available
    • Detects EOF when pipe closed
    """)


def explain_synchronization() -> None:
    """Explain how producer-consumer synchronization works."""
    logger = get_logger(__name__)

    log_section(logger, "Producer-Consumer Synchronization")

    logger.info("\nNatural Synchronization via Blocking:")
    logger.info("─" * 70)

    logger.info("""
    Scenario: Buffer has 64KB capacity

    Case 1: Producer Faster than Consumer
    ─────────────────────────────────────
    Producer:  ████████░  (generating quickly)
    Buffer:    ████████████████████  (filling up)
    Consumer:  ░░░░░░░░░░  (processing slowly)

    When buffer full:
    producer.send()  → BLOCKS (waits for consumer)
    ↓
    consumer.recv()  → frees space in buffer
    ↓
    producer.send()  → UNBLOCKS, continues


    Case 2: Consumer Faster than Producer
    ──────────────────────────────────────
    Producer:  ░░░░░░░░░░  (slow generation)
    Buffer:    ░░░░░░░░░░  (mostly empty)
    Consumer:  ████████████████████  (processing quickly)

    When buffer empty:
    consumer.recv()  → BLOCKS (waits for producer)
    ↓
    producer.send()  → puts data in buffer
    ↓
    consumer.recv()  → UNBLOCKS, receives data


    Case 3: Balanced Speed
    ──────────────────────
    Producer:  ░░████░░░░░░  (steady pace)
    Buffer:    ░░░░░░░░░░░░░  (steady flow)
    Consumer:  ░░░░░░░░░░░░  (matching pace)

    Natural balance:
    • Producer generates
    • Buffer buffers
    • Consumer processes
    • Flow reaches equilibrium
    """)

    logger.info("\nKey Benefits of Blocking:")
    logger.info("  ✓ No busy-waiting (wasted CPU)")
    logger.info("  ✓ Natural flow control")
    logger.info("  ✓ Memory efficient (no data explosion)")
    logger.info("  ✓ Simple coordination (no manual locking)")


def explain_data_flow() -> None:
    """Explain detailed data flow through architecture."""
    logger = get_logger(__name__)

    log_section(logger, "Detailed Data Flow")

    logger.info("\nStep-by-Step Data Transfer:")
    logger.info("─" * 70)

    logger.info("""
    1. PRODUCER SIDE - Sending Data
    ────────────────────────────────

    producer_conn.send({"id": "REC-001", "value": 100})

    Steps:
    a) Python object in memory
    b) pickle.dumps() → bytes
    c) Write to kernel pipe buffer
    d) Return immediately (or block if buffer full)

    Code:
    ```python
    obj = {"id": "REC-001", "value": 100}
    producer_conn.send(obj)  # Serializes automatically
    ```


    2. KERNEL PIPE BUFFER
    ──────────────────────

    [Pipe Buffer: ~64KB]

    ┌─────────────────────────────────────────────────────┐
    │  Serialized bytes for REC-001                       │
    │  Serialized bytes for REC-002                       │
    │  [Empty space]                                      │
    └─────────────────────────────────────────────────────┘

    FIFO: First-in-first-out guarantee
    Ordered: Items received in send order


    3. CONSUMER SIDE - Receiving Data
    ──────────────────────────────────

    obj = consumer_conn.recv()

    Steps:
    a) Check if buffer has data
    b) If empty: BLOCK (wait for producer)
    c) If data: Read from buffer
    d) pickle.loads() ← bytes
    e) Return Python object

    Code:
    ```python
    obj = consumer_conn.recv()  # Deserializes automatically
    # obj = {"id": "REC-001", "value": 100}
    ```
    """)


def show_timeline_comparison() -> None:
    """Show timeline of producer-consumer execution."""
    logger = get_logger(__name__)

    log_section(logger, "Execution Timeline")

    logger.info("\nTimeline with Actual Delays:")
    logger.info("─" * 70)

    logger.info("""
    Time   Producer              Buffer         Consumer
    ─────  ─────────────────────────────────────────────────
    0.0s   START
           Generate REC-001      [       ]
    0.2s   send(REC-001)    ──→  [REC-001]    START (waiting)
           Generate REC-002     [REC-001]
    0.25s  send(REC-002)    ──→  [REC-001]    recv() ──→
           Generate REC-003     [REC-001]    [got REC-001]
           (waits for buffer)   [REC-002]    PROCESS
    0.45s  send(REC-002)    ──→  [       ]    time.sleep()
           Generate REC-003     [REC-002]
    0.4s   send(REC-003)    ──→  [REC-002]    (sleeping 0.25s)
                                 [REC-003]

    0.5s   WAIT (buffer full)    [REC-002]    PROCESS DONE
           (blocked)             [REC-003]    recv() ──→
                                              [got REC-002]
    0.55s  send() UNBLOCKS       [REC-003]    PROCESS

    0.6s   DONE                  [REC-003]    PROCESS

    0.8s                         [REC-003]    recv() ──→
                                              [got REC-003]
    0.85s                        [       ]    PROCESS

    1.1s                         [       ]    PROCESS DONE
                                              Detects EOF
    1.1s   DONE                  [CLOSED]     DONE
    """)

    logger.info("\nKey Observations:")
    logger.info("  • Producer and Consumer run simultaneously")
    logger.info("  • Buffer holds data between them")
    logger.info("  • Blocking ensures synchronization")
    logger.info("  • No data loss")
    logger.info("  • Natural flow control")


def main() -> None:
    """Entry point."""
    demonstrate_producer_consumer()
    explain_architecture_components()
    explain_synchronization()
    explain_data_flow()
    show_timeline_comparison()


# ============================================================================
# KEY CONCEPTS
# ============================================================================
"""
Producer: Generates or reads source data
Pipe: Kernel buffer that stores serialized data
Consumer: Processes received data

Blocking: Natural synchronization mechanism
Serialization: Automatic conversion to/from bytes
FIFO: Data received in send order

Decoupling: Producer/Consumer independent
Throughput: Producer-speed limited by buffer capacity
"""

# ============================================================================
# ADVANTAGES
# ============================================================================
"""
1. Simple: Clear producer-consumer pattern
2. Efficient: Kernel-optimized buffering
3. Automatic Synchronization: Blocking provides flow control
4. Memory Safe: No shared memory races
5. Ordered: FIFO guarantee
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: How does the producer-consumer pattern work with pipes?
   A: Producer sends, pipe buffers, consumer receives
      Blocking ensures synchronization

2. Q: What happens if producer is faster?
   A: send() blocks when buffer full
      waits for consumer to free space

3. Q: What happens if consumer is faster?
   A: recv() blocks when buffer empty
      waits for producer to put data

4. Q: Why is blocking good?
   A: Natural flow control, no busy-waiting
      Automatic synchronization

5. Q: How large is the pipe buffer?
   A: Typically ~64KB, varies by system
"""


if __name__ == "__main__":
    main()
