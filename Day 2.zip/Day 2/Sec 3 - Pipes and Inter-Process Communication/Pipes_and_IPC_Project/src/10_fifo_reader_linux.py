"""
###############################################################################
Python IPC – Linux FIFO (Named Pipe) Reader
###############################################################################

PROBLEM STATEMENT: Monitoring system needs to continuously read logs from
a named pipe written by other processes.

BUSINESS SCENARIO: Log Monitoring
Company: LogHub Monitoring
System: Persistent named pipe reader
"""

import os
import time
from pathlib import Path

if os.name != "posix":
    print("ERROR: This example requires Linux/macOS (FIFO not available on Windows)")
    exit(1)

import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section
from common.configuration import FIFO_PATH


def read_logs_from_fifo() -> None:
    """Read logs from FIFO."""
    logger = get_logger(__name__)

    log_section(logger, "Linux FIFO Reader Demo")

    logger.info(f"\nFIFO Path: {FIFO_PATH}")
    logger.info("Waiting for FIFO to be created by writer...\n")

    # Wait for FIFO to be created by writer
    max_wait = 30
    waited = 0

    while not FIFO_PATH.exists() and waited < max_wait:
        logger.info("  (waiting for FIFO...)")
        time.sleep(1)
        waited += 1

    if not FIFO_PATH.exists():
        logger.error("FIFO was not created within timeout")
        logger.info("\nTo test FIFO communication:")
        logger.info("  Terminal 1: python3 09_fifo_writer_linux.py")
        logger.info("  Terminal 2: python3 10_fifo_reader_linux.py")
        return

    logger.info("✓ FIFO detected\n")

    logger.info("Opening FIFO for reading...")
    try:
        with open(FIFO_PATH, "r") as fifo:
            logger.info("✓ FIFO opened\n")

            logger.info("Reading messages:")
            logger.info("─" * 70)

            line_count = 0
            try:
                while True:
                    line = fifo.readline()

                    if not line:
                        # EOF - writer closed
                        logger.info("\n[READER] EOF detected - writer closed")
                        break

                    line_count += 1
                    logger.info(f"[READER] Received: {line.rstrip()}")

            except KeyboardInterrupt:
                logger.info("\n[READER] Interrupted by user")

            logger.info(f"\n✓ Received {line_count} messages")

    except Exception as e:
        logger.error(f"Error reading FIFO: {e}")


def demonstrate_fifo_blocking() -> None:
    """Explain blocking behavior of FIFO."""
    from common.logger import get_logger, log_section

    logger = get_logger(__name__)

    log_section(logger, "FIFO Blocking Behavior")

    logger.info("""
FIFO Blocking Semantics:

1. OPENING A FIFO
   ───────────────

   Writer opens FIFO:
   - BLOCKS until reader opens
   - Waits for reader on other side

   Reader opens FIFO:
   - BLOCKS until writer opens
   - Waits for writer on other side

   Both open → both unblock


2. WRITING TO FIFO
   ────────────────

   write() call:
   - If buffer has space: returns immediately
   - If buffer full (~4KB): BLOCKS
   - Waits until reader drains buffer


3. READING FROM FIFO
   ──────────────────

   read()/readline():
   - If data available: returns immediately
   - If empty AND writer still open: BLOCKS
   - If empty AND writer closed: returns EOF


4. PRACTICAL EXAMPLE
   ─────────────────

   Terminal 1 (Writer):
   $ python3 09_fifo_writer_linux.py
   [WRITER] Opening FIFO... (BLOCKS until reader opens)
   [WRITER] Reader opened!
   [WRITER] Sending message 1
   ... (continues)

   Terminal 2 (Reader):
   $ python3 10_fifo_reader_linux.py
   [READER] Opening FIFO... (BLOCKS until writer opens)
   [READER] Writer opened!
   [READER] Received message 1
   ... (continues)

DEBUGGING TIPS:

If writer seems stuck:
  • Check if reader opened FIFO
  • Use: lsof | grep fifo
  • Writer blocks until reader opens

If reader seems stuck:
  • Check if writer is still running
  • Reader blocks until writer opens
  • Reader gets EOF when writer closes

Multiple readers:
  • Only ONE reader can open FIFO
  • Try with one writer, one reader
    """)


def explain_fifo_use_cases() -> None:
    """Explain when to use FIFO."""
    from common.logger import get_logger, log_section

    logger = get_logger(__name__)

    log_section(logger, "When to Use FIFO")

    logger.info("""
Good Use Cases:

1. System Logging
   - Multiple processes write logs
   - Single logger process reads and archives
   - Persistent across restarts

2. Monitoring
   - Process A produces metrics
   - Process B consumes metrics
   - No file storage needed

3. Message Passing
   - IPC between unrelated processes
   - Don't need to parent-child
   - Unix socket alternative

4. Legacy System Integration
   - Scripts that expect named pipes
   - System tool integration


Bad Use Cases:

1. High-Speed Communication
   - Pipes are slower than sockets
   - Serialization overhead
   - Use multiprocessing.Pipe instead

2. Complex Protocols
   - Need request-response?
   - Need multiple endpoints?
   - Use sockets or queues instead

3. Cross-Network
   - FIFO is local only
   - Use sockets for network
   - Use message queues for distribution


Comparison:

                Anonymous Pipe   FIFO          Socket
────────────────────────────────────────────────────
Scope         Parent-child     Any process   Network
Persistence   No               Yes (file)    No
Setup         Simple           Simple        Complex
Speed         Fast             Fast          Slow
Order         FIFO             FIFO          Depends
Sync          Automatic        Automatic     Manual
────────────────────────────────────────────────────
    """)


def main() -> None:
    """Entry point."""
    read_logs_from_fifo()
    demonstrate_fifo_blocking()
    explain_fifo_use_cases()


if __name__ == "__main__":
    main()
