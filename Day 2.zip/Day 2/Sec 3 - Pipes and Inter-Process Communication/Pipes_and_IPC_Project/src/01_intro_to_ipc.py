"""
###############################################################################
Python IPC – Introduction to Inter-Process Communication
###############################################################################

PROBLEM STATEMENT
─────────────────────────────────────────────────────────────────────────────
A financial order processing system needs to handle multiple concurrent tasks:

1. One process generates order data (order ID, customer, amount)
2. Another process validates the orders
3. A third process stores approved orders in a database
4. A fourth process generates billing reports

Currently, all processing happens sequentially in a single process, creating
a bottleneck where validation waits for generation, reporting waits for
storage, etc.

The system needs a way for multiple processes to exchange structured data
efficiently without writing to files or databases.


BUSINESS SCENARIO – Distributed Order Processing
─────────────────────────────────────────────────────────────────────────────
Company: GlobalTech Financial Services
Context: High-volume order processing system

The current architecture:
- 100,000 orders/day
- Sequential processing: generate → validate → store → report
- Bottleneck: validation waits for disk I/O
- Latency: 8 seconds average order processing time
- Cost: Servers idle while waiting for I/O

Desired architecture:
- Parallel processes running simultaneously
- Order generator → Validator → Storage → Reporter
- Each process communicates via efficient IPC
- Target latency: 2 seconds
- Cost: Fully utilized server resources


LEARNING OBJECTIVES
─────────────────────────────────────────────────────────────────────────────
Upon completing this module, you will understand:

1. What Inter-Process Communication (IPC) is
2. Why IPC is needed in distributed systems
3. Common IPC mechanisms (pipes, sockets, shared memory, message queues)
4. When to use each IPC type
5. Benefits and trade-offs of parallel processing
6. How Python's multiprocessing module facilitates IPC


SOLUTION OVERVIEW
─────────────────────────────────────────────────────────────────────────────
Inter-Process Communication (IPC) allows separate processes to exchange data.

Without IPC:
    Process A writes to disk → Process B reads from disk
    (Slow, adds latency, requires file system)

With IPC:
    Process A → [Kernel Pipe] → Process B
    (Fast, low latency, memory-based)

Common IPC Methods in Python:

1. PIPES (multiprocessing.Pipe)
   ├─ Anonymous: Parent-child only
   ├─ Named (FIFO): Any process on system
   ├─ Bidirectional: Can send and receive
   └─ Use: Simple, low-overhead communication

2. QUEUES (multiprocessing.Queue)
   ├─ Multiple writers and readers
   ├─ Built-in thread safety
   ├─ Automatic locking
   └─ Use: Producer-consumer patterns

3. SOCKETS (socket module)
   ├─ Network communication
   ├─ Localhost or remote
   ├─ Protocol-agnostic
   └─ Use: Distributed systems, REST APIs

4. SHARED MEMORY (multiprocessing.Value, Array)
   ├─ Direct memory access
   ├─ No copying
   ├─ Requires manual synchronization
   └─ Use: Real-time data sharing

5. MESSAGE QUEUES (External)
   ├─ RabbitMQ, Redis, Kafka
   ├─ Persistent
   ├─ Distributed
   └─ Use: Production systems, microservices


KEY CONCEPTS
─────────────────────────────────────────────────────────────────────────────
Process:
    Independent program execution with separate memory space.
    Cannot directly access another process's memory.

Thread:
    Lightweight execution within a process.
    Shares memory with other threads (requires synchronization).

IPC Mechanism:
    Method for processes to communicate (pipe, socket, queue, etc.).

Serialization:
    Converting Python objects to bytes for transmission.
    Deserialization: Converting bytes back to Python objects.

Buffer:
    Temporary storage for data in transit (e.g., pipe buffer is ~64KB).

Blocking I/O:
    Call blocks (waits) until data available or transmitted.
    Example: conn.recv() waits if no data in pipe.

Non-Blocking I/O:
    Call returns immediately regardless of data availability.
    Requires polling or select-based notifications.


WHY IPC MATTERS
─────────────────────────────────────────────────────────────────────────────
Scalability:
    Multiple processes can run on multiple CPU cores simultaneously.
    Cannot achieve parallelism with threads (GIL limits threading).

Fault Isolation:
    One process crashing doesn't affect others.
    Threads share memory, so one thread's error affects all.

Resource Efficiency:
    Use server's multiple cores for real work.
    No waiting for I/O while other processes could run.

Modularity:
    Each process is independent and can be maintained separately.
    Easier to test, debug, and update individual components.

Performance:
    Order processing: 8 seconds → 2 seconds (4x improvement)
    Throughput: 100K orders/day → 400K orders/day


IPC ARCHITECTURE OVERVIEW
─────────────────────────────────────────────────────────────────────────────

Without IPC (Sequential):
    CPU:  ▓▓░░░░░░░░  (Idle waiting for I/O)
    I/O:  ░░▓▓░░░░░░  (Slow)
    Total time: 10 seconds

With IPC (Parallel):
    Process 1:  ▓▓▓▓░░░░░░  (Generate orders)
    Process 2:  ░░▓▓▓▓░░░░  (Validate in parallel)
    Process 3:  ░░░░▓▓▓▓░░  (Store in parallel)
    Process 4:  ░░░░░░▓▓▓▓  (Report in parallel)
    Total time: 4 seconds (Parallel execution)


HOW PIPES WORK
─────────────────────────────────────────────────────────────────────────────

Creation:
    conn1, conn2 = multiprocessing.Pipe()
    # Returns two ends of a pipe

Typical Setup:
    Parent keeps conn1, passes conn2 to child via fork()
    Parent writes to conn1, reads from conn1
    Child writes to conn2, reads from conn2

Data Transfer:
    conn1.send(data)    # Serialize and write data
    data = conn2.recv() # Read and deserialize data

Blocking Behavior:
    send() usually doesn't block (buffer available)
    recv() blocks until data available
    Both ends block on buffer full/empty

Cleanup:
    conn1.close()  # Release file descriptor
    conn2.close()  # Both ends should close


COMPARISON TABLE
─────────────────────────────────────────────────────────────────────────────

                 Pipes      Queues     Sockets    Shared Memory
────────────────────────────────────────────────────────────────────────────
Endpoints        2          Many       2+         2+
Scope            Process    Process    Network    Process
Speed            Fast       Fast       Slow       Fastest
Setup            Simple     Simple     Complex    Complex
Direction        One/Both   One        Both       Both
Persistence      No         No         Yes        No
Buffer Size      64KB       Unlimited  Network    Direct
Serialization    Auto       Auto       Manual     None
Lock/Sync        None       Auto       Manual     Manual
Deadlock Risk    Yes        Low        Low        High
Use Case         Simple     General    Distributed Real-time
────────────────────────────────────────────────────────────────────────────


WHEN TO USE WHAT
─────────────────────────────────────────────────────────────────────────────

Use PIPES when:
    ✓ Parent-child process communication
    ✓ Simple request-response pattern
    ✓ Low-overhead data transfer
    ✓ Order matters (FIFO)
    ✗ Multiple producers (use Queue instead)

Use QUEUES when:
    ✓ Multiple producers or consumers
    ✓ Thread pool worker pattern
    ✓ Decoupling between processes
    ✓ Priority handling needed
    ✗ Two-process parent-child (use Pipe for simplicity)

Use SOCKETS when:
    ✓ Distributed systems
    ✓ Network communication
    ✓ Pub-sub patterns
    ✓ Firewall traversal needed
    ✗ Local process communication (overengineered)

Use SHARED MEMORY when:
    ✓ Very high throughput (no serialization)
    ✓ Real-time data updates
    ✓ Frequent reads/writes to same data
    ✗ Complex objects (must use simple types: int, float, array)
    ✗ Processes not trusted (no isolation)

"""

import logging
import multiprocessing as mp
from dataclasses import dataclass
from typing import Any

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section, log_separator
from common.configuration import SAMPLE_ORDERS


@dataclass
class Order:
    """Represents a business order."""

    order_id: str
    customer: str
    amount: float
    status: str = "pending"

    def __repr__(self) -> str:
        return (
            f"Order({self.order_id}, {self.customer}, "
            f"${self.amount:.2f}, {self.status})"
        )


def demonstrate_ipc_need() -> None:
    """
    Demonstrate why IPC is needed in multiprocess systems.

    This example shows how processes need to communicate for
    coordinated work in a distributed order processing system.
    """
    logger = get_logger(__name__)

    log_section(logger, "IPC Fundamentals: Introduction")

    # =========================================================================
    # SECTION 1: Understanding the Problem
    # =========================================================================
    logger.info("\n1. THE PROBLEM: Sequential Processing Bottleneck\n")

    logger.info("Scenario: Order Processing System")
    logger.info("Current Architecture (Sequential):")
    logger.info("  1. Generate Orders        [████░░░░░░] 2 seconds")
    logger.info("  2. Validate Orders        [░░████░░░░] 2 seconds (waits for 1)")
    logger.info("  3. Store Orders           [░░░░████░░] 2 seconds (waits for 2)")
    logger.info("  4. Generate Reports       [░░░░░░████] 2 seconds (waits for 3)")
    logger.info("─" * 70)
    logger.info("  Total Time:               8 seconds ⚠️ SLOW")
    logger.info("  Throughput:               1 order per 0.08 seconds")
    logger.info("  CPU Utilization:          25% (3/4 time idle)")

    # =========================================================================
    # SECTION 2: The Solution
    # =========================================================================
    logger.info("\n2. THE SOLUTION: Parallel Processing with IPC\n")

    logger.info("With Inter-Process Communication:")
    logger.info("  Process 1 (Generator):    [████░░░░░░] Generates orders")
    logger.info("        ↓ (Pipe)")
    logger.info("  Process 2 (Validator):    [░░████░░░░] Validates in parallel")
    logger.info("        ↓ (Pipe)")
    logger.info("  Process 3 (Storage):      [░░░░████░░] Stores in parallel")
    logger.info("        ↓ (Pipe)")
    logger.info("  Process 4 (Reporter):     [░░░░░░████] Reports in parallel")
    logger.info("─" * 70)
    logger.info("  Total Time:               2 seconds ✓ 4x FASTER")
    logger.info("  Throughput:               1 order per 0.02 seconds")
    logger.info("  CPU Utilization:          100% (all processes working)")

    # =========================================================================
    # SECTION 3: IPC Methods Overview
    # =========================================================================
    logger.info("\n3. IPC MECHANISMS IN PYTHON\n")

    ipc_methods = {
        "Pipes": {
            "Use": "Parent-child, request-response",
            "Speed": "Very Fast",
            "Scope": "Process family",
            "Example": "multiprocessing.Pipe()",
        },
        "Queues": {
            "Use": "Multiple producers/consumers",
            "Speed": "Fast",
            "Scope": "Any process",
            "Example": "multiprocessing.Queue()",
        },
        "Sockets": {
            "Use": "Network/distributed",
            "Speed": "Slow (network)",
            "Scope": "Any host",
            "Example": "socket.socket()",
        },
        "Shared Memory": {
            "Use": "Real-time data sharing",
            "Speed": "Fastest",
            "Scope": "Process family",
            "Example": "multiprocessing.Value()",
        },
    }

    for method, details in ipc_methods.items():
        logger.info(f"\n{method}:")
        for key, value in details.items():
            logger.info(f"  {key:10} → {value}")

    # =========================================================================
    # SECTION 4: Practical Example
    # =========================================================================
    logger.info("\n4. PRACTICAL EXAMPLE: Order Processing\n")

    # Simulate order processing with IPC
    logger.info("Creating separate processes for each stage:")

    # Create pipes for communication
    gen_val_pipe = mp.Pipe()  # Between generator and validator
    val_store_pipe = mp.Pipe()  # Between validator and storage
    store_report_pipe = mp.Pipe()  # Between storage and reporter

    logger.info("  ✓ Generator → Validator pipe created")
    logger.info("  ✓ Validator → Storage pipe created")
    logger.info("  ✓ Storage → Reporter pipe created")

    logger.info("\nProcesses would run independently:")
    logger.info("  • Generator creates orders without waiting")
    logger.info("  • Validator receives via pipe, validates independently")
    logger.info("  • Storage receives validated orders via pipe")
    logger.info("  • Reporter receives stored data via pipe")
    logger.info("  • No process waits for previous stage")

    # =========================================================================
    # SECTION 5: Key Concepts
    # =========================================================================
    logger.info("\n5. KEY CONCEPTS\n")

    concepts = {
        "Process": "Separate program with own memory space",
        "Thread": "Lightweight execution in shared memory",
        "IPC": "Communication between separate processes",
        "Serialization": "Convert Python object to bytes for transmission",
        "Deserialization": "Convert bytes back to Python object",
        "Buffer": "Temporary storage for data in transit (~64KB for pipes)",
        "Blocking": "Operation waits for data/completion",
        "Non-Blocking": "Operation returns immediately",
    }

    for concept, definition in concepts.items():
        logger.info(f"  {concept:18} → {definition}")

    # =========================================================================
    # SECTION 6: Benefits Summary
    # =========================================================================
    logger.info("\n6. BENEFITS OF IPC & PARALLEL PROCESSING\n")

    benefits = {
        "Performance": "4-10x faster on multi-core systems",
        "Scalability": "Utilize multiple CPU cores",
        "Reliability": "Fault isolation (one crash doesn't affect others)",
        "Modularity": "Each process independently developed/tested",
        "Resource Efficiency": "No CPU idle time waiting for I/O",
        "Responsiveness": "No blocking on slow operations",
    }

    for benefit, description in benefits.items():
        logger.info(f"  ✓ {benefit:18} → {description}")

    # =========================================================================
    # SECTION 7: Challenges
    # =========================================================================
    logger.info("\n7. CHALLENGES & TRADE-OFFS\n")

    challenges = {
        "Complexity": "More components to coordinate",
        "Debugging": "Harder to trace issues across processes",
        "Memory": "Each process has separate memory (overhead)",
        "Deadlock": "Possible if processes wait on each other",
        "Serialization": "Overhead of converting objects to bytes",
    }

    for challenge, description in challenges.items():
        logger.info(f"  ⚠ {challenge:18} → {description}")

    # =========================================================================
    # SECTION 8: Decision Framework
    # =========================================================================
    logger.info("\n8. WHEN TO USE MULTIPROCESSING\n")

    logger.info("Use Multiprocessing when:")
    logger.info("  ✓ CPU-intensive work (calculations, algorithms)")
    logger.info("  ✓ I/O-bound work (multiple tasks waiting for I/O)")
    logger.info("  ✓ Need true parallelism (multiple cores)")
    logger.info("  ✓ Fault isolation is important")
    logger.info("  ✓ Python GIL is a bottleneck")

    logger.info("\nUse Threading when:")
    logger.info("  ✓ I/O-bound work (single task)")
    logger.info("  ✓ Shared data frequently accessed")
    logger.info("  ✓ Lower overhead needed")
    logger.info("  ✓ Simple synchronization needed")

    logger.info("\nUse Single Process when:")
    logger.info("  ✓ Sequential work required")
    logger.info("  ✓ Minimal overhead needed")
    logger.info("  ✓ Simple scripts and tools")

    log_separator(logger)


def main() -> None:
    """Entry point for the demonstration."""
    demonstrate_ipc_need()


# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
[Example Output]

================================================================================
  IPC Fundamentals: Introduction
================================================================================

1. THE PROBLEM: Sequential Processing Bottleneck

Scenario: Order Processing System
Current Architecture (Sequential):
  1. Generate Orders        [████░░░░░░] 2 seconds
  2. Validate Orders        [░░████░░░░] 2 seconds (waits for 1)
  3. Store Orders           [░░░░████░░] 2 seconds (waits for 2)
  4. Generate Reports       [░░░░░░████] 2 seconds (waits for 3)
──────────────────────────────────────────────────────────────────────────────
  Total Time:               8 seconds ⚠️ SLOW
  Throughput:               1 order per 0.08 seconds
  CPU Utilization:          25% (3/4 time idle)

2. THE SOLUTION: Parallel Processing with IPC

With Inter-Process Communication:
  Process 1 (Generator):    [████░░░░░░] Generates orders
        ↓ (Pipe)
  Process 2 (Validator):    [░░████░░░░] Validates in parallel
        ↓ (Pipe)
  Process 3 (Storage):      [░░░░████░░] Stores in parallel
        ↓ (Pipe)
  Process 4 (Reporter):     [░░░░░░████] Reports in parallel
──────────────────────────────────────────────────────────────────────────────
  Total Time:               2 seconds ✓ 4x FASTER
  Throughput:               1 order per 0.02 seconds
  CPU Utilization:          100% (all processes working)

[... Rest of output showing IPC mechanisms and concepts ...]
"""

# ============================================================================
# EXECUTION FLOW
# ============================================================================
"""
1. Main process starts
2. Displays problem with sequential processing
3. Shows solution with parallel + IPC
4. Explains IPC mechanisms (Pipes, Queues, Sockets, Shared Memory)
5. Demonstrates pipes creation (without forking)
6. Summarizes key concepts
7. Explains when to use multiprocessing
8. Process exits
"""

# ============================================================================
# ARCHITECTURE EXPLANATION
# ============================================================================
"""
Sequential Architecture:
    Stage 1 (Generate)
        → Stage 2 (Validate)
        → Stage 3 (Store)
        → Stage 4 (Report)

    Bottleneck: Each stage waits for previous to complete.
    Time: T1 + T2 + T3 + T4 = 8 seconds

Parallel Architecture with IPC:
    Stage 1 (Generate) ─────→ Pipe ─────→ Stage 2 (Validate)
    Stage 2 (Validate) ─────→ Pipe ─────→ Stage 3 (Store)
    Stage 3 (Store)    ─────→ Pipe ─────→ Stage 4 (Report)

    Each stage communicates via pipes
    All run simultaneously
    Time: max(T1, T2, T3, T4) ≈ 2 seconds (4x improvement)
"""

# ============================================================================
# ADVANTAGES
# ============================================================================
"""
1. Performance: 4-10x faster on multi-core systems
2. Scalability: Utilize all available CPU cores
3. Fault Isolation: One crash doesn't affect others
4. Modularity: Each process independently maintainable
5. Resource Efficiency: No CPU idle time
6. Responsiveness: No long blocking operations
7. Throughput: Can handle more orders per second
"""

# ============================================================================
# LIMITATIONS
# ============================================================================
"""
1. Complexity: More moving parts to coordinate
2. Debugging: Harder to trace issues across processes
3. Memory Overhead: Each process has separate memory
4. Serialization Cost: Converting objects to bytes
5. Deadlock Risk: Possible if processes wait incorrectly
6. Error Propagation: Harder to handle errors across processes
7. Testing: More complex test scenarios
"""

# ============================================================================
# PERFORMANCE CONSIDERATIONS
# ============================================================================
"""
Sequential Processing:
- CPU Usage: 25% (idle 75% of time)
- Memory: 100MB (single process)
- Latency: 8 seconds per order
- Throughput: 100K orders/day

Parallel with IPC:
- CPU Usage: 100% (full utilization)
- Memory: 400MB (4 processes × 100MB)
- Latency: 2 seconds per order
- Throughput: 400K orders/day

Trade-off: 300MB extra memory for 4x speedup
"""

# ============================================================================
# BEST PRACTICES
# ============================================================================
"""
1. Use multiprocessing for I/O-bound and CPU-bound parallel work
2. Use threading for simple I/O-bound sequential work
3. Always close pipes to release file descriptors
4. Use picklable objects (avoid local functions, lambdas)
5. Test error scenarios (pipe broken, process crash)
6. Monitor for deadlocks (both waiting to receive)
7. Use logging to track process behavior
8. Profile before and after parallelization
"""

# ============================================================================
# COMMON MISTAKES
# ============================================================================
"""
1. Using threads for CPU-bound work (GIL limits parallelism)
2. Not closing pipes (resource leak)
3. Assuming shared memory isn't needed (causes race conditions)
4. Not pickling test objects (fails in child process)
5. Not handling BrokenPipeError (pipe closed by other end)
6. Mixing synchronous and asynchronous patterns
7. Not using locks with shared memory
8. Assuming order of delivery across multiple processes
"""

# ============================================================================
# DEBUGGING TIPS
# ============================================================================
"""
1. Add logging to each process (use process-safe logging)
2. Check file descriptors: lsof -p <pid>
3. Monitor with: ps aux (processes), top (resources)
4. Use pdb.set_trace() in child processes (stdin/stdout issues)
5. Start with single process, gradually add processes
6. Test pipe closure (both ends must close)
7. Add timeouts to blocking operations
8. Verify objects are picklable: pickle.dumps(obj)
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: Why is IPC needed in multiprocessing systems?
   A: Processes need a way to communicate and coordinate work.
      Without IPC, they can't share data without files/database.

2. Q: What's the difference between pipes and queues?
   A: Pipes: Direct connection, 2 endpoints
      Queues: Buffered, multiple endpoints

3. Q: Why use multiprocessing instead of threading?
   A: True parallelism on multi-core (threading limited by GIL)
      Fault isolation if one process crashes
      Better for CPU-bound work

4. Q: How does pipe serialization work?
   A: Objects pickled (converted to bytes) on send side
      Pickled data sent through kernel pipe buffer
      Unpickled (converted back) on receive side

5. Q: What's a common deadlock scenario with pipes?
   A: Both processes trying to recv() with no data
      Both processes waiting for other to send data
      Solution: Close unused pipe ends, use timeouts
"""

# ============================================================================
# HANDS-ON EXERCISE
# ============================================================================
"""
Exercise 1: Process Communication Diagram

Draw a diagram showing:
1. Sequential processing (generate → validate → store → report)
2. Parallel processing with IPC pipes connecting each stage
3. Time comparison (total time reduction)

Exercise 2: IPC Method Selection

For each scenario, select appropriate IPC method:
1. Parent process spawning worker processes
   Answer: Pipes (simple, direct connection)

2. Multiple worker threads in thread pool
   Answer: Queue (multiple consumers)

3. Distributed servers across network
   Answer: Sockets (network communication)

4. High-frequency real-time data sharing
   Answer: Shared Memory (no serialization overhead)

Exercise 3: Identify the Bottleneck

Given: Order processing takes 2+2+2+2 = 8 seconds
- Generation: 2 seconds
- Validation: 2 seconds (waits for generation)
- Storage: 2 seconds (waits for validation)
- Reporting: 2 seconds (waits for storage)

Question: What's the critical path (longest dependency chain)?
Answer: All 4 stages (4 × 2 = 8 seconds total)

With IPC parallelization: 1 × 2 = 2 seconds (since they run in parallel)
"""

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
"""
Challenge: Design an Order Processing Pipeline

Requirements:
1. Four stages: Generator, Validator, Storage, Reporter
2. Each stage is a separate process
3. Stages communicate via pipes
4. Generator creates 5 orders
5. Validator marks as 'validated'
6. Storage marks as 'stored'
7. Reporter prints final status
8. All stages log their actions

Design questions:
1. How many pipes needed? (3 pipes for 4 stages)
2. Who creates pipes? (Parent process)
3. Who closes unused ends? (Each process closes write end if reader)
4. How to handle process termination?
5. How to measure overall latency?

Expected architecture:
Generator Process --Pipe1--> Validator Process --Pipe2--> Storage Process --Pipe3--> Reporter Process

Each process:
- Receives via pipe (except generator)
- Processes data
- Sends via pipe (except reporter)
- Logs progress
- Closes unused connections
"""


if __name__ == "__main__":
    main()
