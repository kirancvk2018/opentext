"""
###############################################################################
Python IPC – Simple Pipe: Anonymous Pipe Basics
###############################################################################

PROBLEM STATEMENT
─────────────────────────────────────────────────────────────────────────────
An invoice processing system needs to send invoice data from a generator
process to a validator process.

Requirements:
- Generator creates invoices (simulate database query)
- Validator checks invoices for completeness and correctness
- Both processes run simultaneously
- Communication must be direct and efficient
- No file system or database involved


BUSINESS SCENARIO – Invoice Processing
─────────────────────────────────────────────────────────────────────────────
Company: PayFlow Financial Services
System: Real-time Invoice Validation

Business Need:
- Invoices arrive from various sources
- Each invoice must be validated before payment processing
- Validation includes: amount check, account verification, tax calculation
- Current system bottleneck: validation waits for invoice generation

Solution:
- Invoice Generator process: Creates invoice data
- Invoice Validator process: Validates each invoice
- Pipe Connection: Direct communication between generator and validator
- Real-time processing: No queuing delays


LEARNING OBJECTIVES
─────────────────────────────────────────────────────────────────────────────
1. Create anonymous pipes with multiprocessing.Pipe()
2. Send data through pipes
3. Receive data from pipes
4. Close pipes properly
5. Understand pipe lifetimes
6. Handle pipe closure
"""

import logging
import multiprocessing as mp
import time
from typing import Optional, Tuple, Any

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section, log_separator
from common.configuration import SAMPLE_ORDERS, DEFAULT_MESSAGE_COUNT


def generate_invoices(conn, num_invoices: int) -> None:
    """
    Process that generates invoice data and sends through pipe.

    Args:
        conn: Connection object (write end of pipe)
        num_invoices: Number of invoices to generate
    """
    logger = get_logger(__name__)
    logger.info(f"[GENERATOR] Starting - will generate {num_invoices} invoices")

    # Simulate invoices from database
    invoices = [
        {
            "invoice_id": f"INV-2024-{i:05d}",
            "customer": f"Customer-{i % 10}",
            "amount": 1000 * (i % 50 + 1),
            "items": i % 5 + 1,
            "date": "2024-01-01",
        }
        for i in range(1, num_invoices + 1)
    ]

    # Send each invoice through the pipe
    for invoice in invoices:
        logger.info(
            f"[GENERATOR] Sending {invoice['invoice_id']} - "
            f"${invoice['amount']:.2f}"
        )

        # send() serializes the object and writes to pipe
        conn.send(invoice)

        # Simulate some processing time
        time.sleep(0.1)

    logger.info("[GENERATOR] Finished sending all invoices")

    # Close connection to signal end of data
    conn.close()
    logger.info("[GENERATOR] Pipe closed, process complete")


def validate_invoices(conn, num_invoices: int) -> None:
    """
    Process that receives invoices and validates them.

    Args:
        conn: Connection object (read end of pipe)
        num_invoices: Number of invoices to expect
    """
    logger = get_logger(__name__)
    logger.info(f"[VALIDATOR] Starting - will validate {num_invoices} invoices")

    validated_count = 0
    failed_count = 0

    # Receive invoices from pipe until closed
    for i in range(num_invoices):
        try:
            # recv() blocks until data available or pipe closed
            invoice = conn.recv()

            logger.info(f"[VALIDATOR] Received {invoice['invoice_id']}")

            # Perform validation
            is_valid = invoice["amount"] > 0 and invoice["items"] > 0

            if is_valid:
                validated_count += 1
                invoice["status"] = "validated"
                logger.info(f"[VALIDATOR] ✓ Validated {invoice['invoice_id']}")
            else:
                failed_count += 1
                invoice["status"] = "rejected"
                logger.info(f"[VALIDATOR] ✗ Rejected {invoice['invoice_id']}")

            # Simulate validation work
            time.sleep(0.15)

        except EOFError:
            # Pipe closed (no more data)
            logger.info("[VALIDATOR] Pipe closed - no more data")
            break

    logger.info(
        f"[VALIDATOR] Completed: {validated_count} valid, "
        f"{failed_count} rejected"
    )

    # Close connection
    conn.close()
    logger.info("[VALIDATOR] Process complete")


def demonstrate_simple_pipe() -> None:
    """
    Demonstrate basic anonymous pipe communication.

    Shows creation and usage of pipes in parent-child scenario.
    """
    logger = get_logger(__name__)

    log_section(logger, "Anonymous Pipe Demonstration")

    logger.info("\nScenario: Invoice Processing Pipeline")
    logger.info("─" * 70)
    logger.info("Generator Process ──Pipe──> Validator Process\n")

    # =========================================================================
    # SECTION 1: Create Pipe
    # =========================================================================
    logger.info("STEP 1: Create Pipe")
    logger.info("─" * 70)

    # Create anonymous pipe - returns tuple of two connection objects
    conn1, conn2 = mp.Pipe()

    logger.info("mp.Pipe() created successfully")
    logger.info(f"  Connection 1 (parent): {conn1}")
    logger.info(f"  Connection 2 (child):  {conn2}")

    logger.info("\nPipe Characteristics:")
    logger.info("  - Anonymous: No filesystem entry")
    logger.info("  - Unidirectional: Data flows one way (by convention)")
    logger.info("  - Buffer Size: ~64 KB")
    logger.info("  - Blocking: recv() blocks until data available")
    logger.info("  - Type: Connection objects, not file descriptors\n")

    # =========================================================================
    # SECTION 2: Spawn Processes
    # =========================================================================
    logger.info("STEP 2: Spawn Child Processes")
    logger.info("─" * 70)

    num_invoices = 5

    # Create generator process (writes to pipe)
    generator = mp.Process(
        target=generate_invoices,
        args=(conn1, num_invoices),
        name="InvoiceGenerator",
    )

    # Create validator process (reads from pipe)
    validator = mp.Process(
        target=validate_invoices,
        args=(conn2, num_invoices),
        name="InvoiceValidator",
    )

    logger.info(f"Generator process created: {generator.name}")
    logger.info(f"Validator process created: {validator.name}\n")

    # =========================================================================
    # SECTION 3: Start Processes
    # =========================================================================
    logger.info("STEP 3: Start Processes")
    logger.info("─" * 70)

    generator.start()
    validator.start()

    logger.info("Both processes started simultaneously")
    logger.info("(Parent process continues here)\n")

    # =========================================================================
    # SECTION 4: Wait for Completion
    # =========================================================================
    logger.info("STEP 4: Wait for Processes to Complete")
    logger.info("─" * 70)

    generator.join()
    validator.join()

    logger.info("Both processes completed\n")

    # =========================================================================
    # SECTION 5: Cleanup
    # =========================================================================
    logger.info("STEP 5: Cleanup")
    logger.info("─" * 70)

    # Close parent's connections
    if not conn1.closed:
        conn1.close()
        logger.info("✓ Connection 1 closed")

    if not conn2.closed:
        conn2.close()
        logger.info("✓ Connection 2 closed")

    logger.info("\nAll resources released\n")

    # =========================================================================
    # SECTION 6: Summary
    # =========================================================================
    log_section(logger, "Execution Summary")

    logger.info("Data Flow:")
    logger.info("  1. Generator creates invoice")
    logger.info("  2. conn1.send(invoice) - serializes and writes to pipe")
    logger.info("  3. Validator receives from conn2")
    logger.info("  4. conn2.recv() - reads and deserializes from pipe")
    logger.info("  5. Validator processes invoice")
    logger.info("  6. Repeat for each invoice")
    logger.info("  7. Generator closes conn1")
    logger.info("  8. Validator receives EOFError on conn2.recv()")
    logger.info("  9. Validator closes conn2")

    logger.info("\nKey Insights:")
    logger.info("  ✓ Pipe created by parent")
    logger.info("  ✓ Child processes started after pipe creation")
    logger.info("  ✓ Data serialized automatically on send")
    logger.info("  ✓ Data deserialized automatically on recv")
    logger.info("  ✓ recv() blocks until data available")
    logger.info("  ✓ Closing pipe signals end of data (EOFError)")
    logger.info("  ✓ Both processes work simultaneously")


def demonstrate_pipe_api() -> None:
    """
    Demonstrate pipe API methods and properties.
    """
    logger = get_logger(__name__)

    log_section(logger, "Pipe API Reference")

    conn1, conn2 = mp.Pipe()

    logger.info("\nConnection Methods:")
    logger.info("─" * 70)

    logger.info("\n1. send(obj)")
    logger.info("   Purpose: Send object through pipe")
    logger.info("   Args:    Object to send (must be picklable)")
    logger.info("   Blocks:  Usually no (buffer available)")
    logger.info("   Example:")
    logger.info("      conn.send({'id': 1, 'amount': 100.00})")

    logger.info("\n2. recv()")
    logger.info("   Purpose: Receive object from pipe")
    logger.info("   Args:    None")
    logger.info("   Blocks:  Yes (waits for data)")
    logger.info("   Returns: Deserialized object")
    logger.info("   Raises:  EOFError if pipe closed")
    logger.info("   Example:")
    logger.info("      data = conn.recv()  # Blocks until data available")

    logger.info("\n3. close()")
    logger.info("   Purpose: Close connection")
    logger.info("   Args:    None")
    logger.info("   Effect:  Send side: No more sends possible")
    logger.info("            Recv side: Gets EOFError after current data")
    logger.info("   Example:")
    logger.info("      conn.close()")

    logger.info("\n4. fileno()")
    logger.info("   Purpose: Get underlying file descriptor")
    logger.info("   Returns: Integer file descriptor")
    logger.info("   Use:     Advanced I/O (select, poll)")

    logger.info("\nConnection Properties:")
    logger.info("─" * 70)

    logger.info(f"\n1. conn.closed")
    logger.info(f"   Type:  Boolean")
    logger.info(f"   Value: {conn1.closed}")
    logger.info(f"   Use:   Check if connection closed before using")

    logger.info(f"\n2. conn.readable")
    logger.info(f"   Type:  Boolean")
    logger.info(f"   Value: {conn1.readable}")
    logger.info(f"   Use:   Check if can receive (not applicable for pipes)")

    logger.info(f"\n3. conn.writable")
    logger.info(f"   Type:  Boolean")
    logger.info(f"   Value: {conn1.writable}")
    logger.info(f"   Use:   Check if can send (not applicable for pipes)")

    conn1.close()
    conn2.close()


def demonstrate_data_types() -> None:
    """
    Demonstrate sending different data types through pipes.
    """
    logger = get_logger(__name__)

    log_section(logger, "Data Types Through Pipes")

    logger.info("\nPipes Support All Picklable Python Objects")
    logger.info("─" * 70)

    logger.info("\nSupported Types:")
    logger.info("  ✓ Basic types: int, float, str, bool, bytes")
    logger.info("  ✓ Collections: list, tuple, dict, set")
    logger.info("  ✓ Objects: dataclass instances, custom classes")
    logger.info("  ✓ Complex: nested structures, combinations")

    logger.info("\nExample Objects:")

    logger.info("\n1. Simple Dictionary:")
    logger.info("   {'invoice_id': 'INV-001', 'amount': 1000.00}")
    logger.info("   Size: ~80 bytes after pickling")

    logger.info("\n2. List of Dictionaries:")
    logger.info("   [{'id': 1}, {'id': 2}, {'id': 3}]")
    logger.info("   Size: ~60 bytes after pickling")

    logger.info("\n3. Dataclass Instance:")
    from dataclasses import dataclass

    @dataclass
    class Invoice:
        id: str
        amount: float
        status: str

    invoice = Invoice("INV-001", 1000.00, "pending")
    logger.info(f"   {invoice}")
    logger.info(f"   Size: ~90 bytes after pickling")

    logger.info("\nNot Supported:")
    logger.info("  ✗ File objects (open files)")
    logger.info("  ✗ Lock/Event objects")
    logger.info("  ✗ Lambda functions")
    logger.info("  ✗ Local functions (defined in __main__)")

    logger.info("\nSerialization Process:")
    logger.info("  1. Object → pickle.dumps() → bytes")
    logger.info("  2. bytes → write to pipe buffer")
    logger.info("  3. read from pipe buffer → bytes")
    logger.info("  4. bytes → pickle.loads() → Object")
    logger.info("\nNote: Automatic, no manual pickle calls needed")


def demonstrate_error_handling() -> None:
    """
    Demonstrate common pipe errors and handling.
    """
    logger = get_logger(__name__)

    log_section(logger, "Error Handling & Edge Cases")

    logger.info("\nCommon Pipe Errors:")
    logger.info("─" * 70)

    logger.info("\n1. EOFError: Pipe Closed")
    logger.info("   When: Calling recv() after other end closed")
    logger.info("   Cause: All data read, no more incoming")
    logger.info("   Handle: Check in try/except or count messages")

    logger.info("   Example:")
    logger.info("   try:")
    logger.info("       data = conn.recv()")
    logger.info("   except EOFError:")
    logger.info("       print('Pipe closed')")

    logger.info("\n2. BrokenPipeError: Other End Closed During Send")
    logger.info("   When: Calling send() after receiver closes")
    logger.info("   Cause: Receiver process crashed or exited")
    logger.info("   Handle: Check if receiver is alive")

    logger.info("   Example:")
    logger.info("   try:")
    logger.info("       conn.send(data)")
    logger.info("   except BrokenPipeError:")
    logger.info("       print('Receiver closed')")

    logger.info("\n3. Deadlock: Both Processes Blocked")
    logger.info("   When: Both waiting to recv() with no sender")
    logger.info("   Cause: Incorrect pipe end assignment")
    logger.info("   Prevent: Parent keeps write end, gives read to child")

    logger.info("\n4. Buffer Full: Send Blocks")
    logger.info("   When: Pipe buffer full (~64KB)")
    logger.info("   Cause: Receiver not reading fast enough")
    logger.info("   Prevent: Ensure receiver processes data")

    logger.info("\nBest Practices:")
    logger.info("  1. Always close unused connections")
    logger.info("  2. Handle EOFError explicitly")
    logger.info("  3. Verify parent/child pipe assignment")
    logger.info("  4. Use try/finally for guaranteed cleanup")
    logger.info("  5. Add timeouts for long waits")
    logger.info("  6. Log all pipe operations")
    logger.info("  7. Test with small amounts first")


def demonstrate_pipe_lifecycle() -> None:
    """
    Show complete pipe lifecycle.
    """
    logger = get_logger(__name__)

    log_section(logger, "Pipe Lifecycle")

    logger.info("\nComplete Pipe Lifetime:")
    logger.info("─" * 70)

    logger.info("""
CREATION:
    Parent: conn1, conn2 = mp.Pipe()
    State:  Both connections open, empty buffer

CHILD PROCESS SPAWN:
    Parent: Process(target=child_func, args=(conn2,)).start()
    State:  Parent has conn1, Child has conn2
    Note:   File descriptors duplicated to child

PARENT CLOSES UNUSED END:
    Parent: conn2.close()  (don't need read end)
    State:  Parent only has write end (conn1)
    Note:   Child still has read end (conn2)

CHILD CLOSES UNUSED END:
    Child:  conn1.close()   (don't need write end)
    State:  Child only has read end (conn2)
    Note:   Parent still has write end (conn1)

DATA TRANSFER:
    Parent: conn1.send(data)  → buffer
    Child:  conn2.recv()      → data
    State:  Data flows through pipe

PARENT CLOSES WRITE END:
    Parent: conn1.close()
    Child:  conn2.recv() → EOFError (after all data)
    State:  Child knows no more data coming

CHILD CLOSES READ END:
    Child:  conn2.close()
    State:  All resources released

VERIFICATION:
    Both:   conn.closed == True
    State:  Pipe fully closed, file descriptors released
    """)

    logger.info("Key Points:")
    logger.info("  • Pipe created by parent before forking")
    logger.info("  • Child inherits copy of pipe connections")
    logger.info("  • Each process closes its unused end")
    logger.info("  • Sender closes write end to signal EOF")
    logger.info("  • Receiver detects EOF via EOFError")
    logger.info("  • Both must close for full cleanup")


def main() -> None:
    """Entry point for demonstrations."""
    demonstrate_simple_pipe()
    demonstrate_pipe_api()
    demonstrate_data_types()
    demonstrate_error_handling()
    demonstrate_pipe_lifecycle()


# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
================================================================================
  Anonymous Pipe Demonstration
================================================================================

Scenario: Invoice Processing Pipeline
Generator Process ──Pipe──> Validator Process

STEP 1: Create Pipe
────────────────────────────────────────────────────────────────────────────
mp.Pipe() created successfully
  Connection 1 (parent): <Connection object>
  Connection 2 (child):  <Connection object>

[Generator and Validator processes run in parallel]

[GENERATOR] Starting - will generate 5 invoices
[VALIDATOR] Starting - will validate 5 invoices

[GENERATOR] Sending INV-2024-00001 - $1000.00
[VALIDATOR] Received INV-2024-00001
[VALIDATOR] ✓ Validated INV-2024-00001

[... more invoices processed ...]

[GENERATOR] Finished sending all invoices
[GENERATOR] Pipe closed, process complete

[VALIDATOR] Completed: 5 valid, 0 rejected
[VALIDATOR] Process complete

STEP 5: Cleanup
────────────────────────────────────────────────────────────────────────────
✓ Connection 1 closed
✓ Connection 2 closed

All resources released
"""

# ============================================================================
# EXECUTION FLOW
# ============================================================================
"""
1. Create anonymous pipe with mp.Pipe()
2. Spawn generator process (writes to conn1)
3. Spawn validator process (reads from conn2)
4. Generator sends invoices through pipe
5. Validator receives and validates each invoice
6. Generator closes conn1 (sends EOF signal)
7. Validator detects EOF, stops reading
8. Both processes terminate
9. Parent closes both connections
"""

# ============================================================================
# ARCHITECTURE EXPLANATION
# ============================================================================
"""
Parent Process (Main)
├─ Creates Pipe: conn1, conn2 = mp.Pipe()
├─ Spawns Generator Process (connected via conn1)
├─ Spawns Validator Process (connected via conn2)
├─ Waits for both to complete
└─ Closes both connections

Generator Process
├─ Receives conn1 from parent
├─ Closes conn2 (unused)
├─ Loops through invoice list
├─ Calls conn1.send(invoice)
├─ conn1.close() to signal EOF
└─ Exits

Validator Process
├─ Receives conn2 from parent
├─ Closes conn1 (unused)
├─ Loops calling conn2.recv()
├─ Processes returned invoice
├─ Catches EOFError when done
├─ conn2.close()
└─ Exits
"""

# ============================================================================
# ADVANTAGES
# ============================================================================
"""
1. Simple: Easy to understand and use
2. Efficient: Kernel-optimized IPC
3. Direct: Point-to-point communication
4. Automatic Serialization: No manual pickling
5. Ordered: FIFO delivery guaranteed
6. Blocking Support: Natural flow control
7. Lightweight: Minimal overhead
"""

# ============================================================================
# LIMITATIONS
# ============================================================================
"""
1. Two Endpoints: Only parent and child
2. Unidirectional: One-way by default
3. No Persistence: Lost if processes crash
4. No Queuing: No built-in buffering
5. Deadlock Risk: Both waiting to receive
6. Serialization: Slower than direct memory access
7. Not Persistent: No named variant (FIFO required)
"""

# ============================================================================
# PERFORMANCE CONSIDERATIONS
# ============================================================================
"""
Throughput: ~1M small objects/sec on modern system
Latency: Sub-millisecond round-trip
Buffer Size: Typically 64KB
Serialization: Adds ~10-50% overhead vs direct memory

Optimization:
- Batch small objects (send lists)
- Use simple data types
- Avoid large objects (>1MB)
- Profile before optimizing
"""

# ============================================================================
# BEST PRACTICES
# ============================================================================
"""
1. Create pipe before forking
2. Close unused connection ends
3. Handle EOFError explicitly
4. Verify pipe is picklable object
5. Use try/finally for cleanup
6. Add logging for debugging
7. Test with small datasets first
8. Handle process crashes gracefully
"""

# ============================================================================
# COMMON MISTAKES
# ============================================================================
"""
1. Not closing unused ends (resource leak)
2. Both processes trying to receive (deadlock)
3. Sending non-picklable objects (crashes child)
4. Not handling EOFError (exceptions)
5. Assuming order on multiple processes
6. Creating pipe after fork (doesn't work)
7. Mixing read/write ends (wrong direction)
8. Not joining child processes
"""

# ============================================================================
# DEBUGGING TIPS
# ============================================================================
"""
1. Add logging to both processes
2. Verify pipe created before fork
3. Check conn.closed property
4. Monitor process with ps/top
5. Use small test data first
6. Print on send/recv to trace flow
7. Verify objects are picklable
8. Test connection closing
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: How do you create an anonymous pipe?
   A: conn1, conn2 = multiprocessing.Pipe()
      Returns tuple of two connection objects

2. Q: What happens when you call recv() on empty pipe?
   A: Blocks until data available
      Or raises EOFError if other end closed

3. Q: How do you send data through pipe?
   A: conn.send(object)
      Object is pickled and written to pipe

4. Q: What's the difference between conn1 and conn2?
   A: Both are connection objects, used by different processes
      By convention: parent uses conn1, child uses conn2

5. Q: Why close unused connection ends?
   A: Releases file descriptors
      Allows EOFError detection when sender closes
      Prevents resource leaks
"""

# ============================================================================
# HANDS-ON EXERCISE
# ============================================================================
"""
Exercise 1: Modify the invoice example to send 10 invoices

Current code sends 5 invoices. Modify:
1. Change num_invoices to 10
2. Run and verify all 10 are processed
3. Measure how long it takes

Exercise 2: Add error handling

Modify the validator to:
1. Catch EOFError explicitly
2. Log when pipe closes
3. Print summary of processing

Exercise 3: Send different data

Instead of dictionaries, send dataclass instances:

from dataclasses import dataclass

@dataclass
class Invoice:
    id: str
    amount: float
    items: int

# Send through pipe
conn.send(Invoice("INV-001", 100.00, 5))
"""

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
"""
Challenge: Bidirectional Communication

Current setup: Generator → Validator (one-way)

Create bidirectional communication:
1. Generator sends invoice
2. Validator receives and validates
3. Validator sends back validation result
4. Generator receives result and logs

Requires:
- Two pipes (one each direction)
- Generator reads from validator pipe
- Validator writes to generator pipe
- Proper sequencing (send/recv alternating)

Expected output:
[GEN] Sending INV-001
[VAL] Received INV-001
[VAL] Sending validation result
[GEN] Received validation result
[GEN] Invoice INV-001: APPROVED
"""


if __name__ == "__main__":
    main()
