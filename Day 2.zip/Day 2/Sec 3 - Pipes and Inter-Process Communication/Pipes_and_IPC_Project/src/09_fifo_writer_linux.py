"""
###############################################################################
Python IPC – Linux FIFO (Named Pipe) Writer
###############################################################################

PROBLEM STATEMENT: Centralized logging system needs to write logs to a
named pipe that survives process termination and can be read by separate
monitoring process.

BUSINESS SCENARIO: Microservices Logging
Company: LogHub Monitoring
System: Persistent named pipe logging
"""

import os
import time
from pathlib import Path

# Linux only - FIFO requires Unix-like OS
if os.name != "posix":
    print("ERROR: This example requires Linux/macOS (FIFO not available on Windows)")
    print("Run this on Linux/macOS only")
    exit(1)

import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section
from common.configuration import FIFO_PATH


def write_logs_to_fifo() -> None:
    """Write logs to FIFO."""
    logger = get_logger(__name__)

    log_section(logger, "Linux FIFO Writer Demo")

    logger.info(f"\nFIFO Path: {FIFO_PATH}\n")

    # Clean up any existing FIFO
    if FIFO_PATH.exists():
        try:
            os.unlink(FIFO_PATH)
            logger.info("✓ Removed existing FIFO")
        except OSError:
            pass

    logger.info("Creating FIFO...")
    try:
        os.mkfifo(FIFO_PATH)
        logger.info(f"✓ FIFO created at {FIFO_PATH}\n")
    except OSError as e:
        logger.error(f"Failed to create FIFO: {e}")
        return

    logger.info("Opening FIFO for writing...")
    try:
        with open(FIFO_PATH, "w") as fifo:
            logger.info("✓ FIFO opened (waiting for reader)\n")

            messages = [
                "Log entry 1: System started",
                "Log entry 2: Processing order ORD-001",
                "Log entry 3: Processing order ORD-002",
                "Log entry 4: All orders complete",
            ]

            for msg in messages:
                logger.info(f"[WRITER] Sending: {msg}")
                fifo.write(msg + "\n")
                fifo.flush()
                logger.info(f"[WRITER] Sent")
                time.sleep(0.5)

            logger.info("\n[WRITER] All messages sent")

    except Exception as e:
        logger.error(f"Error writing to FIFO: {e}")
    finally:
        logger.info("[WRITER] Closing FIFO")

        # Clean up
        try:
            os.unlink(FIFO_PATH)
            logger.info("✓ FIFO removed")
        except OSError:
            pass


def explain_fifo() -> None:
    """Explain FIFO concept."""
    from common.logger import get_logger, log_section

    logger = get_logger(__name__)

    log_section(logger, "Named Pipes (FIFO) Explanation")

    logger.info("""
FIFO = First-In-First-Out (Named Pipe)

What:
- Filesystem entry that acts like a pipe
- Data flows through, not stored
- Removed when no longer needed

Characteristics:
- Survives process termination (while exists in filesystem)
- Any process can open it (if permissions allow)
- Blocking I/O: writer waits for reader, reader waits for writer
- FIFO ordering: first written = first read

Creating a FIFO:
    os.mkfifo('/tmp/myfifo.pipe')

Writing to FIFO:
    with open('/tmp/myfifo.pipe', 'w') as fifo:
        fifo.write("Hello")
        fifo.flush()

Reading from FIFO:
    with open('/tmp/myfifo.pipe', 'r') as fifo:
        data = fifo.read()

Key Difference vs Anonymous Pipes:
- Anonymous: Parent-child only
- FIFO: Any process on system

Linux/Unix Only:
- Works on Linux, macOS, BSD
- Does NOT work on Windows
- Windows uses named pipes (different API)
    """)


def main() -> None:
    """Entry point."""
    write_logs_to_fifo()
    explain_fifo()


if __name__ == "__main__":
    main()
