"""
Pipes and IPC Educational Modules

This package contains educational examples of Python Inter-Process Communication
using pipes, including:

- Anonymous pipes (multiprocessing.Pipe)
- Named pipes (FIFO on Unix/Linux)
- Windows named pipes (conceptual)
- Producer-consumer patterns
- Complex ETL pipelines
- Enterprise logging systems

Run examples directly:
    python3 01_intro_to_ipc.py
    python3 04_simple_pipe.py
    python3 14_ipc_architecture_demo.py

Recommended learning order:
1. 01_intro_to_ipc.py          - Understand IPC
2. 02_why_pipes.py             - Benefits of pipes
3. 03_pipe_architecture_demo.py - Producer-consumer
4. 04_simple_pipe.py           - First hands-on
5. 05_parent_child_pipe.py     - Parent-child patterns
6. 06_duplex_pipe.py           - Bidirectional
7. 07_object_transfer.py       - Complex objects
8. 08_pipe_connection_management.py - Resource cleanup
9. 09_fifo_writer_linux.py     - Linux FIFO (if on Linux)
10. 10_fifo_reader_linux.py    - Linux FIFO reader (if on Linux)
11. 11_windows_named_pipe_demo.py - Windows concepts
12. 12_fifo_blocking_behavior.py - Blocking semantics
13. 13_logging_system_pipe.py   - Enterprise logging
14. 14_ipc_architecture_demo.py - Complex ETL pipeline
"""
