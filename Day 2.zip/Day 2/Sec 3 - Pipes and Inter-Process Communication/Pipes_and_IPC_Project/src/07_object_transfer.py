"""
###############################################################################
Python IPC – Object Transfer: Sending Complex Python Objects
###############################################################################

PROBLEM STATEMENT: Insurance claim processing system needs to transfer
complex claim objects between processes. Objects include nested structures,
lists, and dataclass instances.

BUSINESS SCENARIO: Insurance Claims Processing
Company: SecureInsure
System: Claims validation pipeline
"""

import logging
import multiprocessing as mp
import time
from dataclasses import dataclass
from typing import List, Dict, Any

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section


@dataclass
class ClaimItem:
    """Individual claim item."""

    description: str
    amount: float
    category: str


@dataclass
class InsuranceClaim:
    """Insurance claim object."""

    claim_id: str
    policy_id: str
    claimant: str
    date: str
    items: List[ClaimItem]
    total_amount: float
    status: str = "submitted"


def claim_processor(conn_recv, conn_send) -> None:
    """Child process that processes claim objects."""
    logger = get_logger(__name__)
    logger.info("[PROCESSOR] Started")

    try:
        while True:
            # Receive claim object
            claim = conn_recv.recv()
            logger.info(f"[PROCESSOR] Received claim: {claim.claim_id}")

            # Process the claim
            claim.status = "processing"

            # Validate items
            total = 0
            for item in claim.items:
                total += item.amount
                logger.info(f"  ├─ {item.description}: ${item.amount:.2f}")

            # Update claim
            claim.total_amount = total
            claim.status = "validated"

            # Send processed claim back
            conn_send.send(claim)
            logger.info(f"[PROCESSOR] Processed: {claim.claim_id} - ${claim.total_amount:.2f}")

            time.sleep(0.1)

    except EOFError:
        logger.info("[PROCESSOR] Pipe closed")
    finally:
        conn_recv.close()
        conn_send.close()


def demonstrate_object_transfer() -> None:
    """Demonstrate transferring complex objects through pipes."""
    logger = get_logger(__name__)

    log_section(logger, "Object Transfer Through Pipes")

    logger.info("\nScenario: Insurance Claim Processing\n")

    # Create pipes
    conn1, conn2 = mp.Pipe()

    # Spawn processor
    processor = mp.Process(
        target=claim_processor,
        args=(conn2, conn1),
        name="ClaimProcessor",
    )
    processor.start()
    logger.info("✓ Processor started\n")

    # Create complex claim objects
    claims = [
        InsuranceClaim(
            claim_id="CLM-2024-001",
            policy_id="POL-555",
            claimant="John Doe",
            date="2024-01-15",
            items=[
                ClaimItem("Medical consultation", 200.0, "Medical"),
                ClaimItem("Prescription medication", 150.0, "Pharmacy"),
                ClaimItem("Hospital stay (3 nights)", 2000.0, "Hospital"),
            ],
            total_amount=0,  # Will be calculated
        ),
        InsuranceClaim(
            claim_id="CLM-2024-002",
            policy_id="POL-666",
            claimant="Jane Smith",
            date="2024-01-20",
            items=[
                ClaimItem("Car repair", 1500.0, "Auto"),
                ClaimItem("Rental car", 300.0, "Auto"),
            ],
            total_amount=0,
        ),
    ]

    logger.info("Sending claims for processing:")
    logger.info("─" * 70)

    # Send claims and receive processed results
    for claim in claims:
        logger.info(f"\n[PARENT] Sending claim: {claim.claim_id}")
        conn1.send(claim)

        # Receive processed claim
        processed = conn2.recv()
        logger.info(f"[PARENT] Received processed claim:")
        logger.info(f"         ID: {processed.claim_id}")
        logger.info(f"         Claimant: {processed.claimant}")
        logger.info(f"         Status: {processed.status}")
        logger.info(f"         Total: ${processed.total_amount:.2f}")

    conn1.close()
    processor.join()
    logger.info("\n✓ Processing complete")


def demonstrate_different_types() -> None:
    """Show different object types that can be transferred."""
    logger = get_logger(__name__)

    log_section(logger, "Object Types Supported")

    logger.info("\nTypes That Can Be Transferred Through Pipes:")
    logger.info("─" * 70)

    # Basic types
    logger.info("\n1. Basic Types:")
    logger.info("   • Integers: 42, -100, 1000000")
    logger.info("   • Floats: 3.14, 99.99")
    logger.info("   • Strings: 'hello', 'world'")
    logger.info("   • Booleans: True, False")
    logger.info("   • Bytes: b'data'")
    logger.info("   • None: None")

    # Collections
    logger.info("\n2. Collections:")
    logger.info("   • Lists: [1, 2, 3]")
    logger.info("   • Tuples: (1, 2, 3)")
    logger.info("   • Dictionaries: {'key': 'value'}")
    logger.info("   • Sets: {1, 2, 3}")

    # Nested structures
    logger.info("\n3. Nested Structures:")
    logger.info("   • List of dicts: [{'id': 1}, {'id': 2}]")
    logger.info("   • Dict with lists: {'items': [1, 2, 3]}")
    logger.info("   • Multi-level: {'a': {'b': {'c': 1}}}")

    # Custom objects
    logger.info("\n4. Custom Objects:")
    logger.info("   • Dataclass instances")
    logger.info("   • Class instances (if picklable)")
    logger.info("   • Named tuples")

    # Not supported
    logger.info("\n5. NOT Supported (not picklable):")
    logger.info("   ✗ File objects: open('file.txt')")
    logger.info("   ✗ Lambda functions: lambda x: x + 1")
    logger.info("   ✗ Local functions (defined in __main__)")
    logger.info("   ✗ Lock/Event objects")
    logger.info("   ✗ Running threads")

    logger.info("\nPickling Process:")
    logger.info("  send()  → pickle.dumps() → bytes → kernel buffer")
    logger.info("  recv()  ← pickle.loads() ← bytes ← kernel buffer")


def demonstrate_serialization() -> None:
    """Show serialization process and size implications."""
    logger = get_logger(__name__)

    log_section(logger, "Serialization & Size")

    import pickle

    logger.info("\nSerialization Example:\n")

    # Simple dictionary
    claim_dict = {
        "claim_id": "CLM-2024-001",
        "amount": 1000.00,
        "status": "pending",
    }

    serialized = pickle.dumps(claim_dict)
    logger.info(f"Dictionary: {claim_dict}")
    logger.info(f"Serialized size: {len(serialized)} bytes")
    logger.info(f"Serialized: {serialized[:50]}...\n")

    # Complex object
    claim = InsuranceClaim(
        claim_id="CLM-2024-001",
        policy_id="POL-555",
        claimant="John Doe",
        date="2024-01-15",
        items=[
            ClaimItem("Medical", 200.0, "Medical"),
            ClaimItem("Pharmacy", 150.0, "Pharmacy"),
        ],
        total_amount=350.0,
    )

    serialized = pickle.dumps(claim)
    logger.info(f"Dataclass instance: {claim}")
    logger.info(f"Serialized size: {len(serialized)} bytes\n")

    # List of objects
    claims = [claim, claim, claim]
    serialized = pickle.dumps(claims)
    logger.info(f"List of 3 claims:")
    logger.info(f"Serialized size: {len(serialized)} bytes\n")

    logger.info("Size Implications:")
    logger.info("  Small objects (< 1KB): Serialization ~5-10µs")
    logger.info("  Medium objects (1-100KB): Serialization ~100-500µs")
    logger.info("  Large objects (> 1MB): Serialization ~1-10ms")
    logger.info("\nOptimization:")
    logger.info("  • Batch small objects")
    logger.info("  • Avoid sending unchanged data")
    logger.info("  • Use simple types when possible")


def demonstrate_best_practices() -> None:
    """Show best practices for object transfer."""
    logger = get_logger(__name__)

    log_section(logger, "Object Transfer Best Practices")

    logger.info("\n1. Use Dataclasses for Clarity:")
    logger.info("""
    Good:
    @dataclass
    class Claim:
        id: str
        amount: float

    claim = Claim("CLM-001", 1000.0)
    conn.send(claim)

    Why: Type hints, clear structure, serializable
    """)

    logger.info("\n2. Avoid Mutable Default Arguments:")
    logger.info("""
    Good:
    def create_claim(items: List[ClaimItem] = None):
        if items is None:
            items = []

    Bad:
    def create_claim(items: List[ClaimItem] = []):  # Mutable default!
        pass
    """)

    logger.info("\n3. Keep Objects Serializable:")
    logger.info("""
    Good: Simple types, dataclasses, dicts, lists
    Bad:  File objects, lambdas, local functions
    """)

    logger.info("\n4. Batch Related Objects:")
    logger.info("""
    Good:
    claims_batch = [claim1, claim2, claim3]
    conn.send(claims_batch)

    Bad:
    conn.send(claim1)
    conn.send(claim2)
    conn.send(claim3)

    Why: One serialization vs three, better throughput
    """)

    logger.info("\n5. Validate Before Transfer:")
    logger.info("""
    # Check object is valid before sending
    if claim.total_amount > 0 and claim.status in VALID_STATUS:
        conn.send(claim)
    """)


def main() -> None:
    """Entry point for demonstrations."""
    demonstrate_object_transfer()
    demonstrate_different_types()
    demonstrate_serialization()
    demonstrate_best_practices()


# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
================================================================================
  Object Transfer Through Pipes
================================================================================

Scenario: Insurance Claim Processing

✓ Processor started

Sending claims for processing:
────────────────────────────────────────────────────────────────────────────

[PARENT] Sending claim: CLM-2024-001
[PROCESSOR] Started
[PROCESSOR] Received claim: CLM-2024-001
  ├─ Medical consultation: $200.00
  ├─ Prescription medication: $150.00
  ├─ Hospital stay (3 nights): $2000.00
[PROCESSOR] Processed: CLM-2024-001 - $2350.00
[PARENT] Received processed claim:
         ID: CLM-2024-001
         Claimant: John Doe
         Status: validated
         Total: $2350.00

✓ Processing complete
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: How does pickle work with multiprocessing?
   A: send() automatically pickles objects before transmission
      recv() automatically unpickles received bytes

2. Q: What objects cannot be pickled?
   A: File objects, lambdas, local functions, running threads

3. Q: Does object state survive transfer?
   A: Yes, all attributes are preserved through pickling

4. Q: Is there performance overhead?
   A: Yes, serialization adds CPU overhead (~10-20% typically)

5. Q: How large can objects be?
   A: Limited by pipe buffer (~64KB) but can send larger objects
      in chunks or as streams
"""

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
"""
Challenge: Build a Batch Processor

Create a system that:
1. Parent creates batch of claim objects
2. Sends entire batch via single pipe message
3. Child processes batch and returns results
4. Parent validates all results

Benefits:
- Single serialization per batch (not per item)
- Better throughput
- Simpler coordination

Expected:
- 100 claims, 100x faster than individual transfers
"""


if __name__ == "__main__":
    main()
