"""
###############################################################################
Python IPC – Enterprise Logging System: Multi-Process Log Aggregation
###############################################################################

PROBLEM STATEMENT: Microservices system generates logs from multiple
processes. Need centralized logging that's thread-safe and handles
high-volume log streams.

BUSINESS SCENARIO: Microservices Log Aggregation
Company: CloudOps Monitoring
System: Centralized logging for microservices
"""

import logging
import multiprocessing as mp
import time
from datetime import datetime
from typing import Optional

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section


def worker_process(log_pipe, worker_id: int, num_messages: int) -> None:
    """Worker process that generates log messages."""
    logger = get_logger(__name__)

    for i in range(1, num_messages + 1):
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "worker_id": worker_id,
            "message_id": i,
            "level": "INFO" if i % 3 != 0 else "WARNING",
            "message": f"Worker-{worker_id} processing task {i}",
        }

        log_pipe.send(log_entry)

        logger.info(f"[Worker-{worker_id}] Sent log #{i}")
        time.sleep(0.1)

    log_pipe.close()


def central_logger_process(log_pipes: list, output_file: str) -> None:
    """Central logger that collects and writes logs."""
    logger = get_logger(__name__)
    logger.info("[CENTRAL LOGGER] Started")

    logs_received = 0
    active_pipes = len(log_pipes)

    try:
        while active_pipes > 0:
            # Try to receive from each pipe
            for i, pipe in enumerate(log_pipes):
                if pipe.closed:
                    continue

                try:
                    # Non-blocking check if data available
                    if pipe.poll(timeout=0.5):
                        log_entry = pipe.recv()
                        logs_received += 1

                        # Log it
                        logger.info(
                            f"[LOGGER] Received: {log_entry['worker_id']}: "
                            f"{log_entry['message']}"
                        )

                except EOFError:
                    # This pipe is done
                    pipe.close()
                    active_pipes -= 1
                    logger.info(f"[LOGGER] Worker-{log_entry.get('worker_id', '?')} closed")

    except Exception as e:
        logger.error(f"[LOGGER] Error: {e}")

    logger.info(f"[LOGGER] Complete - received {logs_received} logs")


def demonstrate_logging_system() -> None:
    """Demonstrate centralized logging system."""
    logger = get_logger(__name__)

    log_section(logger, "Enterprise Logging System")

    logger.info("\nArchitecture:")
    logger.info("""
    Worker-1 ──┐
    Worker-2 ──┼──> [Central Logger] ──> Console & File
    Worker-3 ──┤
    Worker-4 ──┘

    Multiple writers, single reader
    """)

    logger.info("\nInitialization:")
    logger.info("─" * 70)

    # Create pipes for each worker
    num_workers = 3
    worker_processes = []
    log_pipes = []

    for i in range(num_workers):
        conn1, conn2 = mp.Pipe()
        log_pipes.append(conn1)

        # Create worker
        worker = mp.Process(
            target=worker_process,
            args=(conn2, i + 1, 3),
            name=f"Worker-{i+1}",
        )
        worker_processes.append(worker)
        worker.start()

        logger.info(f"✓ Worker-{i+1} started (has pipe {i})")

    logger.info(f"✓ {num_workers} workers created\n")

    logger.info("Log Aggregation:")
    logger.info("─" * 70)

    # Central logger receives from all workers
    central_logs = 0
    try:
        # Simple aggregation loop
        for _ in range(num_workers * 3 + 5):  # Expect 3 messages per worker
            for pipe in log_pipes:
                if pipe.closed:
                    continue

                try:
                    if pipe.poll(timeout=0.2):
                        log_entry = pipe.recv()
                        central_logs += 1
                        logger.info(
                            f"[AGGREGATOR] "
                            f"Worker-{log_entry['worker_id']}: "
                            f"{log_entry['message']} "
                            f"({log_entry['level']})"
                        )

                except EOFError:
                    pass

    except Exception as e:
        logger.error(f"Error in aggregation: {e}")

    logger.info(f"\nTotal logs aggregated: {central_logs}\n")

    # Cleanup
    logger.info("Cleanup:")
    logger.info("─" * 70)

    for pipe in log_pipes:
        if not pipe.closed:
            pipe.close()

    for worker in worker_processes:
        worker.join()
        logger.info(f"✓ {worker.name} joined")


def explain_logging_patterns() -> None:
    """Explain logging patterns."""
    logger = get_logger(__name__)

    log_section(logger, "Logging Patterns")

    logger.info("\nPattern 1: Dedicated Logger Process")
    logger.info("─" * 70)
    logger.info("""
    Pros:
    • Centralized control
    • Single file handle
    • Consistent formatting
    • Easy to monitor/debug

    Cons:
    • Logger process is bottleneck
    • Extra IPC overhead
    """)

    logger.info("\nPattern 2: Direct File Logging")
    logger.info("─" * 70)
    logger.info("""
    Pros:
    • No central bottleneck
    • No IPC overhead

    Cons:
    • Multiple writers to file
    • Need file locking
    • Interleaved output risk
    • Inconsistent formatting
    """)

    logger.info("\nPattern 3: Hybrid (Logger Threads per Process)")
    logger.info("─" * 70)
    logger.info("""
    Pros:
    • Local thread handles writes
    • Efficient IPC
    • Minimal overhead

    Cons:
    • More complex
    • Thread-process interaction
    """)

    logger.info("\nBest Practice:")
    logger.info("  Use dedicated logger process for:")
    logger.info("  • Production systems")
    logger.info("  • High-volume logs")
    logger.info("  • Complex formatting")
    logger.info("  • Multiple outputs")


def explain_poll_vs_recv() -> None:
    """Explain poll vs recv for non-blocking reads."""
    logger = get_logger(__name__)

    log_section(logger, "Poll vs Recv")

    logger.info("\nrecv() - Blocking Read")
    logger.info("─" * 70)
    logger.info("""
    data = pipe.recv()

    Behavior:
    • Blocks until data available
    • Returns immediately if data present
    • Raises EOFError if closed

    Use when:
    • Single pipe to wait on
    • Known data will come
    """)

    logger.info("\npoll(timeout) - Non-Blocking Check")
    logger.info("─" * 70)
    logger.info("""
    if pipe.poll(timeout=1.0):
        data = pipe.recv()

    Behavior:
    • Returns True if data available
    • Returns False if timeout
    • Safe to call recv() if poll() returned True

    Use when:
    • Multiple pipes (round-robin)
    • Want timeouts
    • Don't want to block
    """)

    logger.info("\nExample - Monitoring Multiple Pipes:")
    logger.info("""
    for pipe in pipes:
        if pipe.poll(timeout=0.1):
            data = pipe.recv()
            process(data)
    """)


def demonstrate_log_structure() -> None:
    """Show log entry structure."""
    logger = get_logger(__name__)

    log_section(logger, "Log Entry Structure")

    logger.info("\nRecommended Log Entry Structure:")
    logger.info("─" * 70)

    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "level": "INFO",
        "worker_id": 1,
        "message": "Processing order",
        "context": {
            "order_id": "ORD-123",
            "status": "validated",
        },
        "duration_ms": 45,
    }

    logger.info(f"Example entry: {log_entry}")

    logger.info("\nFields:")
    logger.info("  timestamp  - When log occurred (ISO format)")
    logger.info("  level      - Severity (INFO, WARNING, ERROR)")
    logger.info("  worker_id  - Source process identifier")
    logger.info("  message    - Human-readable message")
    logger.info("  context    - Additional structured data")
    logger.info("  duration   - Operation time")

    logger.info("\nFormatted Output:")
    logger.info("""
    2024-01-15T10:30:45.123 [INFO]   Worker-1: Processing order
    2024-01-15T10:30:45.234 [INFO]   Worker-2: Validating payment
    2024-01-15T10:30:45.345 [WARNING] Worker-3: Retrying connection
    2024-01-15T10:30:45.456 [ERROR]  Worker-1: Order failed
    """)


def main() -> None:
    """Entry point."""
    demonstrate_logging_system()
    explain_logging_patterns()
    explain_poll_vs_recv()
    demonstrate_log_structure()


# ============================================================================
# BEST PRACTICES
# ============================================================================
"""
1. Use dedicated logger process
2. Use poll() for multiple pipes
3. Handle EOFError for closed pipes
4. Structure log entries consistently
5. Include timestamp and worker ID
6. Use appropriate log levels
7. Rotate log files
8. Monitor logger performance
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: Why use a central logger process?
   A: Single point of control, consistent formatting,
      avoids interleaved output from multiple writers

2. Q: How to handle multiple log pipes?
   A: Use poll() to check all pipes, recv() when data ready

3. Q: What if logger process is slow?
   A: Pipe buffer fills, worker sends block, affects throughput
      Solution: Optimize logger or increase buffer

4. Q: How to prevent log loss?
   A: Use queue with persistence, or file-based fallback

5. Q: How to structure log entries?
   A: Use dicts with timestamp, level, worker_id, message, context
"""

if __name__ == "__main__":
    main()
