"""
###############################################################################
Python IPC – Why Pipes: Sequential vs Pipe Communication
###############################################################################

PROBLEM STATEMENT
─────────────────────────────────────────────────────────────────────────────
A background report generation system needs to:

1. Read data from a source (database query, API call)
2. Transform the data (calculations, aggregations)
3. Format the report (tables, summaries)
4. Write to file or display

Currently implemented with sequential processing:
    results = read_data()
    transformed = transform_data(results)
    formatted = format_report(transformed)
    write_output(formatted)

Problems with sequential approach:
- Main process blocks during transformation
- All data must fit in memory simultaneously
- No pipelining of work
- Waste of CPU resources while waiting for I/O


BUSINESS SCENARIO – Report Generation Pipeline
─────────────────────────────────────────────────────────────────────────────
Company: DataCorp Analytics
System: Nightly Report Generation

Current problem:
- 10 GB data file from data warehouse
- Need to transform, aggregate, and format
- Sequential processing takes 30 minutes
- Server resources idle during data reads

Solution needs:
- Parallel processing: Read data while transforming previous batch
- Pipeline stages: Data flows through transformation → formatting
- Better CPU utilization
- Finish in under 10 minutes


LEARNING OBJECTIVES
─────────────────────────────────────────────────────────────────────────────
1. Understand sequential vs pipeline processing
2. See performance benefits of pipes
3. Learn how data flows through a pipeline
4. Understand when pipes outperform sequential code
5. Grasp the pipe buffering concept
"""

import logging
import multiprocessing as mp
import time
from typing import Any

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section, log_separator
from common.timer import timer, PerformanceMetrics


def simulate_sequential_processing() -> None:
    """
    Demonstrate sequential data processing approach.

    In sequential processing, each stage waits for previous stage completion.
    """
    logger = get_logger(__name__)

    log_section(logger, "Sequential Processing Demo")

    logger.info("Scenario: Generate and Process 5 Reports\n")

    # Simulate data pipeline
    reports = ["Report-001", "Report-002", "Report-003", "Report-004", "Report-005"]

    metrics = PerformanceMetrics()
    metrics.start()

    # Stage 1: Generate data (simulate reading from DB)
    logger.info("STAGE 1: Reading Data from Database")
    logger.info("─" * 70)

    generated_data = []
    for report in reports:
        logger.info(f"  Reading {report}...")
        time.sleep(0.5)  # Simulate I/O wait
        generated_data.append(f"{report}-data")
        elapsed = 0.5
        metrics.record("read", elapsed)

    logger.info(f"✓ Read {len(generated_data)} reports\n")

    # Stage 2: Transform data (simulate processing)
    logger.info("STAGE 2: Transforming Data")
    logger.info("─" * 70)

    transformed_data = []
    for data in generated_data:
        logger.info(f"  Transforming {data}...")
        time.sleep(0.3)  # Simulate processing
        transformed_data.append(f"{data}-transformed")
        elapsed = 0.3
        metrics.record("transform", elapsed)

    logger.info(f"✓ Transformed {len(transformed_data)} reports\n")

    # Stage 3: Format report (simulate formatting)
    logger.info("STAGE 3: Formatting Report")
    logger.info("─" * 70)

    formatted_data = []
    for data in transformed_data:
        logger.info(f"  Formatting {data}...")
        time.sleep(0.2)  # Simulate formatting
        formatted_data.append(f"{data}-formatted")
        elapsed = 0.2
        metrics.record("format", elapsed)

    logger.info(f"✓ Formatted {len(formatted_data)} reports\n")

    logger.info("Sequential Timeline:")
    logger.info("  Reading:      ████████░░░░░░░░░░ (2.5s)")
    logger.info("  Transforming: ░░░░░░░░████░░░░░░ (1.5s)")
    logger.info("  Formatting:   ░░░░░░░░░░░░████░░ (1.0s)")
    logger.info("─" * 70)
    logger.info("  Total Time:   5.0 seconds")
    logger.info("  CPU Usage:    Sequential, one stage at a time\n")

    metrics.print_report(logger)

    logger.info("\nKey Insight:")
    logger.info("  While Stage 2 transforms, Stage 1 reader is IDLE")
    logger.info("  While Stage 3 formats, Stages 1-2 are IDLE")
    logger.info("  CPU cannot parallelize without IPC")


def simulate_pipe_processing() -> None:
    """
    Demonstrate pipeline processing with pipes.

    In pipeline processing, stages work in parallel using IPC (pipes).
    """
    logger = get_logger(__name__)

    log_section(logger, "Pipe-Based Pipeline Demo")

    logger.info("Scenario: Generate and Process 5 Reports (with pipes)\n")

    # Simulate pipelined processing
    reports = ["Report-001", "Report-002", "Report-003", "Report-004", "Report-005"]

    metrics = PerformanceMetrics()
    metrics.start()

    logger.info("PIPELINED EXECUTION (stages run in parallel via pipes)\n")

    logger.info("Timeline Visualization:")
    logger.info("  Stage 1 (Read):       ████████░░░░░░░░░░  [2.5s]")
    logger.info("  Stage 2 (Transform):  ░░░░░░░░████████░░  [2.0s] (starts earlier)")
    logger.info("  Stage 3 (Format):     ░░░░░░░░░░░░████░░  [1.5s] (starts earlier)")
    logger.info("─" * 70)

    # Simulate overlapping execution
    logger.info("\nConcrete Timeline:")

    # Start with first report to fill pipeline
    logger.info("  0.0s - Reader starts Report-001")
    time.sleep(0.5)
    logger.info("  0.5s - Reader finishes Report-001, passes to Transformer via Pipe")
    logger.info("       - Transformer starts processing Report-001")
    logger.info("       - Reader starts Report-002 (in parallel)")

    time.sleep(0.3)
    logger.info("  0.8s - Reader finishes Report-002, passes to Transformer")
    logger.info("       - Transformer finishes Report-001, passes to Formatter")
    logger.info("       - Formatter starts formatting Report-001")
    logger.info("       - Transformer starts Report-002")

    time.sleep(0.2)
    logger.info("  1.0s - Reader starts Report-003")
    logger.info("       - Transformer starts Report-003")
    logger.info("       - Formatter finishes Report-001 ✓")
    logger.info("       - All three stages working on different reports")

    time.sleep(2.0)  # Simulate remaining processing
    logger.info("  3.0s - All reports processed\n")

    logger.info("✓ Total Time: ~3.0 seconds (vs 5.0 sequential)")
    logger.info("✓ Speedup: 1.67x faster (2.5 seconds saved)")
    logger.info("✓ CPU Usage: All cores utilized")
    logger.info("✓ Memory: Buffered data in pipes (~64KB each)\n")


def explain_pipe_buffering() -> None:
    """
    Explain how pipe buffering enables parallel processing.
    """
    logger = get_logger(__name__)

    log_section(logger, "Pipe Buffering & Why It Matters")

    logger.info("\nWithout Pipes (Sequential):")
    logger.info("  Reader Process:")
    logger.info("    1. Read chunk 1 from disk → 0.5s")
    logger.info("    2. WAIT for transformer to finish (blocked)")
    logger.info("    3. Read chunk 2 from disk → 0.5s")
    logger.info("    4. WAIT again...")

    logger.info("\n  Result: Reader idles 60% of the time\n")

    logger.info("With Pipes:")
    logger.info("  Pipe Buffer: ┌─────────────────┐")
    logger.info("               │  Buffered Data  │  (typically 64KB)")
    logger.info("               └─────────────────┘")
    logger.info("       ↑                ↓")
    logger.info("     Reader          Transformer")

    logger.info("\n  Reader Process:")
    logger.info("    1. Read chunk 1 from disk → 0.5s")
    logger.info("    2. Write to pipe (fast, non-blocking)")
    logger.info("    3. Read chunk 2 from disk → 0.5s  (transformer working in parallel)")
    logger.info("    4. Write to pipe")
    logger.info("    5. Continue reading...")

    logger.info("\n  Transformer Process:")
    logger.info("    1. WAIT for data in pipe (blocked)")
    logger.info("    2. Receive chunk 1 from pipe (fast)")
    logger.info("    3. Transform chunk 1 → 0.3s  (reader can continue)")
    logger.info("    4. Write to next pipe")
    logger.info("    5. Continue transforming...")

    logger.info("\n  Key Benefit: Reader doesn't wait for transformer")
    logger.info("  Key Benefit: Transformer doesn't wait for reader (data buffered)")
    logger.info("  Result: Both working simultaneously\n")


def compare_architectures() -> None:
    """
    Compare sequential vs pipe architectures side-by-side.
    """
    logger = get_logger(__name__)

    log_section(logger, "Architecture Comparison")

    logger.info("\nSEQUENTIAL ARCHITECTURE:")
    logger.info("─" * 70)

    logger.info("""
    ┌─────────────────────────────────────────────────────────────┐
    │  Main Process                                               │
    │  ┌──────────────┐                                           │
    │  │ Read Data    │  (0.5s per item)                          │
    │  │ from Disk    │                                           │
    │  └──────────────┘                                           │
    │         ↓                                                   │
    │  ┌──────────────┐                                           │
    │  │ Transform    │  (0.3s per item) – WAITS for read        │
    │  │ Data         │                                           │
    │  └──────────────┘                                           │
    │         ↓                                                   │
    │  ┌──────────────┐                                           │
    │  │ Format       │  (0.2s per item) – WAITS for transform   │
    │  │ Report       │                                           │
    │  └──────────────┘                                           │
    │         ↓                                                   │
    │  ┌──────────────┐                                           │
    │  │ Write to     │  (output)                                 │
    │  │ Disk         │                                           │
    │  └──────────────┘                                           │
    └─────────────────────────────────────────────────────────────┘

    Problems:
    ✗ Sequential stages
    ✗ Each stage waits for previous
    ✗ CPU idle most of the time
    ✗ Total time: Sum of all stages
    """)

    logger.info("\nPIPE-BASED ARCHITECTURE:")
    logger.info("─" * 70)

    logger.info("""
    ┌──────────────┐        ┌──────────────┐        ┌──────────────┐
    │ Reader       │ ──┐    │ Transformer  │ ──┐    │ Formatter    │
    │ Process      │   │    │ Process      │   │    │ Process      │
    └──────────────┘   │    └──────────────┘   │    └──────────────┘
           │           │           │           │           │
           └─ Pipe 1 ──┴─ Buffer ──┴─ Pipe 2 ──┴─ Buffer ──┘
               (64KB)                (64KB)

    Advantages:
    ✓ Parallel execution
    ✓ Processes don't wait
    ✓ Data buffered between stages
    ✓ CPU fully utilized
    ✓ Total time: Longest single stage (with setup)
    """)

    logger.info("\nRESULT COMPARISON:")
    logger.info("─" * 70)

    logger.info("  Sequential: 5 items × (0.5 + 0.3 + 0.2) = 5.0 seconds")
    logger.info("  Pipeline:   Overlapping execution ≈ 3.0 seconds")
    logger.info("  Speedup:    1.67x faster")
    logger.info("  Efficiency: Reader never blocked (continues reading)")
    logger.info("              Transformer never blocked (data waiting in pipe)")
    logger.info("              Formatter never blocked (data waiting in pipe)\n")


def calculate_theoretical_speedup() -> None:
    """
    Calculate theoretical speedup for different pipeline configurations.
    """
    logger = get_logger(__name__)

    log_section(logger, "Theoretical Speedup Analysis")

    logger.info("\nFormula for Pipeline Speedup:")
    logger.info("  Without pipelining: T_total = N × (T1 + T2 + T3 + ...)")
    logger.info("  With pipelining:    T_total = T1 + max(T2, T3, ...) × (N-1)\n")

    logger.info("Example Calculation:")
    logger.info("  5 reports, 3 stages:")
    logger.info("  - Stage 1 (Read):      0.5s per report")
    logger.info("  - Stage 2 (Transform): 0.3s per report")
    logger.info("  - Stage 3 (Format):    0.2s per report")

    logger.info("\n  Sequential: 5 × (0.5 + 0.3 + 0.2) = 5.0 seconds")
    logger.info("  Pipeline:   0.5 + 0.3×4 + 0.2×4 = 0.5 + 1.2 + 0.8 = 2.5 seconds")
    logger.info("             (Or approximately: first report through + 4 more batches)")

    logger.info("\nFor Large Datasets (100 reports):")
    logger.info("  Sequential: 100 × 1.0 = 100 seconds")
    logger.info("  Pipeline:   0.5 + 0.3×99 + 0.2×99 ≈ 50 seconds")
    logger.info("  Speedup:    2x faster\n")

    logger.info("For Very Large Datasets (10,000 reports):")
    logger.info("  Sequential: 10,000 × 1.0 = 10,000 seconds (2.8 hours)")
    logger.info("  Pipeline:   0.5 + (0.3 + 0.2)×9,999 ≈ 5,000 seconds (1.4 hours)")
    logger.info("  Speedup:    2x faster")
    logger.info("  ⚠️ Note: Speedup limited by slowest stage (0.5s read)\n")


def identify_bottleneck() -> None:
    """
    Explain bottleneck identification and optimization.
    """
    logger = get_logger(__name__)

    log_section(logger, "Identifying & Optimizing Bottlenecks")

    logger.info("\nOriginal Pipeline Bottleneck:")
    logger.info("  Stage 1 (Read):      ████░░░░░░  0.5s  ← SLOWEST (bottleneck)")
    logger.info("  Stage 2 (Transform): ░░██░░░░░░  0.3s")
    logger.info("  Stage 3 (Format):    ░░░░██░░░░  0.2s")

    logger.info("\nBottleneck Analysis:")
    logger.info("  The read stage is the bottleneck.")
    logger.info("  It determines overall throughput (one item every 0.5s)")
    logger.info("  Other stages finish in time, waiting for next item")

    logger.info("\nOptimization Strategies:")

    logger.info("\n1. Optimize Bottleneck Stage:")
    logger.info("   Original Read Time: 0.5s")
    logger.info("   → Use better I/O (SSD): 0.3s")
    logger.info("   → Use buffered read: 0.25s")
    logger.info("   → Use parallel reads: 0.15s")
    logger.info("   ")
    logger.info("   Result: 5 items @ 0.5s = 2.5s")
    logger.info("   Result: 5 items @ 0.15s = 0.75s (3.3x faster)")

    logger.info("\n2. Add Parallel Readers (if I/O parallelizable):")
    logger.info("   Original:  1 reader @ 0.5s per item")
    logger.info("   Optimized: 3 parallel readers @ 0.17s per item")
    logger.info("   ")
    logger.info("   Result: Much faster data feed to transformer")

    logger.info("\n3. Move Non-Bottleneck Work:")
    logger.info("   If read stage slow due to processing:")
    logger.info("   → Move processing to read stage")
    logger.info("   → Balance work across stages")

    logger.info("\nKey Insight:")
    logger.info("  Pipes enable parallelization")
    logger.info("  Parallelization enables identification of bottleneck")
    logger.info("  Bottleneck stage determines overall throughput")
    logger.info("  Optimize bottleneck for maximum speedup\n")


def when_pipes_worth_it() -> None:
    """
    Explain when pipes provide real benefits.
    """
    logger = get_logger(__name__)

    log_section(logger, "When Pipes Provide Real Benefits")

    logger.info("\nPipes Worth It:")
    logger.info("─" * 70)

    logger.info("\n✓ Scenario 1: High-latency I/O bottleneck")
    logger.info("  Task: Read from slow source (network, disk)")
    logger.info("  Benefit: Process data while reading next batch")
    logger.info("  Speedup: 2-5x")
    logger.info("  Example: ETL pipeline, data migration, log processing")

    logger.info("\n✓ Scenario 2: Multi-stage transformation")
    logger.info("  Task: Data → Transform 1 → Transform 2 → Transform 3")
    logger.info("  Benefit: Three stages work on different data simultaneously")
    logger.info("  Speedup: Up to 3x (more stages = more parallelism)")
    logger.info("  Example: Video processing, image processing, analytics")

    logger.info("\n✓ Scenario 3: Unbalanced stages")
    logger.info("  Task: Read (0.5s) → Process (0.3s) → Write (0.8s)")
    logger.info("  Benefit: Reader, processor, and writer run in parallel")
    logger.info("  Speedup: Eliminates waiting for slow writer")
    logger.info("  Example: Streaming pipelines, publish/subscribe")

    logger.info("\n✓ Scenario 4: Large data volumes")
    logger.info("  Task: Process 1 TB of data")
    logger.info("  Benefit: Don't need all data in memory at once")
    logger.info("  Speedup: Handles data that doesn't fit in RAM")
    logger.info("  Example: Big data processing, data warehouse")

    logger.info("\nPipes NOT Worth It:")
    logger.info("─" * 70)

    logger.info("\n✗ Scenario 1: Single fast operation")
    logger.info("  Task: Simple calculation")
    logger.info("  Problem: Serialization overhead > benefit")
    logger.info("  Cost: No speedup, just overhead")
    logger.info("  Use: Single process is faster")

    logger.info("\n✗ Scenario 2: Shared memory access")
    logger.info("  Task: Frequent reads/writes to same data")
    logger.info("  Problem: Can't serialize during access")
    logger.info("  Cost: Locks required, negates parallelism")
    logger.info("  Use: Shared memory or locks preferred")

    logger.info("\n✗ Scenario 3: Very tight coupling")
    logger.info("  Task: Each stage depends on previous output")
    logger.info("  Problem: Can't parallelize if serial dependency")
    logger.info("  Cost: No speedup from parallelism")
    logger.info("  Use: Optimize algorithm instead")

    logger.info("\n✗ Scenario 4: Complex coordination")
    logger.info("  Task: Need to coordinate many processes dynamically")
    logger.info("  Problem: Simple pipes insufficient for complex control")
    logger.info("  Cost: Complexity outweighs benefits")
    logger.info("  Use: Queues or message brokers better")

    log_separator(logger)


def main() -> None:
    """Entry point for the demonstration."""
    logger = get_logger(__name__)

    simulate_sequential_processing()
    simulate_pipe_processing()
    explain_pipe_buffering()
    compare_architectures()
    calculate_theoretical_speedup()
    identify_bottleneck()
    when_pipes_worth_it()


# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
Demonstrates:
1. Sequential processing timeline (5 seconds)
2. Pipe-based pipelined execution (3 seconds)
3. Comparison showing 1.67x speedup
4. Buffering explanation
5. Architectural differences
6. Theoretical speedup calculations
7. Bottleneck identification
8. When pipes are worth the complexity
"""

# ============================================================================
# EXECUTION FLOW
# ============================================================================
"""
1. Simulate sequential processing (5 items through 3 stages)
2. Simulate pipelined processing (same items with pipes)
3. Compare execution times
4. Explain pipe buffering mechanism
5. Show architectural differences
6. Calculate theoretical speedup
7. Identify bottlenecks
8. List scenarios where pipes help vs hurt
"""

# ============================================================================
# ARCHITECTURE EXPLANATION
# ============================================================================
"""
Sequential: Each stage waits for previous
    Stage 1 → Stage 2 → Stage 3
    Total: T1 + T2 + T3

Pipelined: Stages work in parallel via pipes
    Stage 1 ──┐
    Stage 2 ──┼─ (running simultaneously)
    Stage 3 ──┘
    Total: T1 + max(T2, T3) + setup

Benefit: Reduces idle CPU time, increases throughput
Cost: IPC overhead, serialization cost, complexity
"""

# ============================================================================
# ADVANTAGES
# ============================================================================
"""
1. Parallelism: Multiple stages work simultaneously
2. Throughput: Handles more items per unit time
3. Memory Efficiency: No need to buffer all data in memory
4. Responsiveness: Results start flowing sooner
5. CPU Utilization: Better use of multi-core processors
6. Scalability: Can add more stages easily
"""

# ============================================================================
# LIMITATIONS
# ============================================================================
"""
1. Complexity: More moving parts to manage
2. Serialization Overhead: IPC adds CPU cost
3. Debugging: Harder to trace data flow
4. Buffering Limits: Pipe buffer is typically 64KB
5. Order Dependencies: Stages can't have circular dependencies
6. Error Handling: Errors in one stage affect pipeline
"""

# ============================================================================
# PERFORMANCE CONSIDERATIONS
# ============================================================================
"""
Speedup Formula:
    Sequential:  T_total = N × (T1 + T2 + T3)
    Pipeline:    T_total = T1 + (N-1) × max(T2, T3)

For 5 items with T1=0.5s, T2=0.3s, T3=0.2s:
    Sequential: 5 × 1.0 = 5.0s
    Pipeline:   0.5 + 4 × 0.5 = 2.5s
    Speedup:    2x

Diminishing returns with:
    - More stages (more overhead)
    - Unbalanced stages (faster stage waits)
    - Very small items (serialization cost > benefit)
"""

# ============================================================================
# BEST PRACTICES
# ============================================================================
"""
1. Identify real bottleneck (use timing profiling)
2. Ensure stages are independent
3. Balance work across stages for efficiency
4. Use appropriate buffer size for pipe
5. Monitor for deadlocks
6. Handle pipe closure gracefully
7. Measure before/after for real improvement
8. Use logging to trace data flow
"""

# ============================================================================
# COMMON MISTAKES
# ============================================================================
"""
1. Adding pipes without profiling (no real benefit)
2. Having dependent stages (can't parallelize)
3. Unbalanced stages (faster ones idle)
4. Not measuring actual speedup
5. Over-complicating simple sequences
6. Assuming serialization cost is free
7. Not handling errors in pipeline
8. Not closing pipes properly
"""

# ============================================================================
# DEBUGGING TIPS
# ============================================================================
"""
1. Add timestamps to log when data enters/exits each stage
2. Verify data integrity after serialization
3. Check pipe buffer not getting blocked
4. Monitor CPU usage (should be high if parallelized)
5. Test with small datasets first
6. Add assertions for expected data
7. Use profiling tools to measure actual speedup
8. Start with single item to verify correctness
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: When should you use pipes instead of sequential processing?
   A: When stages have different latencies and can work in parallel.
      Pipes allow earlier stages to continue while later stages process.

2. Q: What's the theoretical speedup limit?
   A: Limited by slowest stage. With N items and T stages:
      T_total ≈ T1 + (N-1) × max(T2, ..., Tt)
      Max speedup: T / max(T1, T2, ..., Tt)

3. Q: Why does pipe buffering matter?
   A: Buffer allows producer to continue writing while consumer processes.
      Without buffer, producer would block waiting for consumer.

4. Q: How do you identify which stage is the bottleneck?
   A: Measure execution time of each stage.
      Bottleneck is the one taking longest.
      Optimize bottleneck for maximum speedup.

5. Q: When are pipes NOT worth it?
   A: When items are small (serialization > speedup)
      When stages have dependencies
      When coordination cost exceeds benefit
"""

# ============================================================================
# HANDS-ON EXERCISE
# ============================================================================
"""
Exercise 1: Calculate Speedup

Given:
- 1000 items to process
- Stage 1: 10ms per item
- Stage 2: 8ms per item
- Stage 3: 5ms per item

Calculate:
1. Sequential time
2. Pipelined time (assuming continuous flow)
3. Theoretical speedup

Answer:
Sequential: 1000 × (10 + 8 + 5) = 23,000 ms
Pipeline:   10 + (1000-1) × max(8, 5) = 10 + 999 × 8 = 8,002 ms
Speedup:    23,000 / 8,002 ≈ 2.87x

Exercise 2: Identify Bottleneck

If Stage 2 takes 20ms instead:
Sequential: 1000 × (10 + 20 + 5) = 35,000 ms
Pipeline:   10 + 999 × max(20, 5) = 10 + 999 × 20 = 19,990 ms
Speedup:    35,000 / 19,990 ≈ 1.75x (less speedup)

Conclusion: Slower stage (Stage 2 now) is the bottleneck
"""

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
"""
Challenge: Optimize a Processing Pipeline

Given bottleneck stage taking 2s, other stages taking 0.5s each:

Current state:
    1000 items × (0.5 + 2.0 + 0.5) = 3000 seconds

Optimization strategies:
1. Parallelize bottleneck stage (use multiple workers)
2. Move work from bottleneck to other stages
3. Batch processing to reduce item count
4. Use faster algorithms in bottleneck
5. Pre-process data to reduce bottleneck work

Question: Which strategy gives best improvement?
"""


if __name__ == "__main__":
    main()
