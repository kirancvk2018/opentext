"""
###############################################################################
Python IPC – Duplex Pipes: Bidirectional Communication
###############################################################################

PROBLEM STATEMENT: Customer verification system needs bidirectional communication.
Parent sends customer data → Child validates → Child returns validation result.

BUSINESS SCENARIO: Real-time Customer Verification
Company: SafeBank Financial Services
Need: Validate customers before processing transactions
"""

import logging
import multiprocessing as mp
import time
from typing import Dict, Any

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section


def customer_validator_process(conn) -> None:
    """Child process that validates customers via duplex pipe."""
    logger = get_logger(__name__)
    logger.info("[VALIDATOR] Started")

    validation_rules = {
        "min_age": 18,
        "min_credit_score": 600,
        "max_debt": 50000,
    }

    try:
        while True:
            # Receive customer request
            customer = conn.recv()
            logger.info(f"[VALIDATOR] Received: {customer['name']}")

            # Validate
            is_valid = (
                customer.get("age", 0) >= validation_rules["min_age"]
                and customer.get("credit_score", 0) >= validation_rules["min_credit_score"]
                and customer.get("debt", 0) <= validation_rules["max_debt"]
            )

            result = {
                "customer_id": customer["id"],
                "name": customer["name"],
                "valid": is_valid,
                "reason": (
                    "Approved"
                    if is_valid
                    else "Does not meet verification requirements"
                ),
            }

            # Send validation result back
            conn.send(result)
            logger.info(f"[VALIDATOR] Sent result: {result['name']} - {result['reason']}")

            time.sleep(0.1)

    except EOFError:
        logger.info("[VALIDATOR] Pipe closed, exiting")
    finally:
        conn.close()


def demonstrate_duplex_pipe() -> None:
    """Demonstrate bidirectional pipe communication."""
    logger = get_logger(__name__)

    log_section(logger, "Duplex Pipe Communication")

    logger.info("\nScenario: Customer Verification (Bidirectional)\n")

    # Create duplex pipe (bidirectional)
    conn1, conn2 = mp.Pipe()

    logger.info("✓ Created duplex pipe")
    logger.info("  Parent uses conn1 (send request, recv result)")
    logger.info("  Child uses conn2 (recv request, send result)\n")

    # Spawn validator process
    validator = mp.Process(
        target=customer_validator_process,
        args=(conn2,),
        name="CustomerValidator",
    )
    validator.start()
    logger.info("✓ Validator process started\n")

    # Customer data
    customers = [
        {"id": "CUST-001", "name": "Alice Johnson", "age": 35, "credit_score": 750, "debt": 5000},
        {"id": "CUST-002", "name": "Bob Smith", "age": 25, "credit_score": 580, "debt": 8000},
        {"id": "CUST-003", "name": "Carol White", "age": 45, "credit_score": 820, "debt": 2000},
    ]

    # Send requests and receive results
    logger.info("Sending verification requests:")
    logger.info("─" * 70)

    for customer in customers:
        # Send verification request
        logger.info(f"\n[PARENT] Sending request: {customer['name']}")
        conn1.send(customer)

        # Receive validation result
        result = conn1.recv()
        logger.info(f"[PARENT] Received result: {result}")
        logger.info(f"         Status: {'✓ APPROVED' if result['valid'] else '✗ REJECTED'}")

    logger.info("\n" + "─" * 70)

    # Signal end
    conn1.close()
    logger.info("\n[PARENT] Closed pipe (no more requests)")

    # Wait for validator
    validator.join()
    logger.info("[PARENT] Validator process completed")


def explain_duplex_vs_simplex() -> None:
    """Explain differences between duplex and simplex pipes."""
    logger = get_logger(__name__)

    log_section(logger, "Duplex vs Simplex Pipes")

    logger.info("\nSIMPLEX (One-way):")
    logger.info("─" * 70)
    logger.info("""
    Process A          Process B
    ┌────────┐        ┌────────┐
    │ write  ├───────>│ read   │
    │        │  Data  │        │
    └────────┘        └────────┘

    - One-way communication only
    - conn1 for sending, conn2 for receiving
    - Separate pipes needed for reverse communication
    """)

    logger.info("\nDUPLEX (Two-way):")
    logger.info("─" * 70)
    logger.info("""
    Process A          Process B
    ┌────────┐        ┌────────┐
    │ send   ├───────>│ recv   │
    │ recv   │<───────┤ send   │
    │        │  Data  │        │
    └────────┘        └────────┘

    - Both processes can send and receive
    - Each process uses same connection for both
    - Single pipe handles both directions
    """)

    logger.info("\nWhen to use each:")
    logger.info("  Simplex: One-way communication (producer → consumer)")
    logger.info("  Duplex:  Request-response patterns (A → B → A)")


def explain_duplex_sequencing() -> None:
    """Explain sequencing issues in duplex communication."""
    logger = get_logger(__name__)

    log_section(logger, "Duplex Pipe Sequencing")

    logger.info("\nCorrect Sequence (Alternating Send/Recv):")
    logger.info("─" * 70)

    logger.info("""
    Process A (Parent)          Process B (Child)
    ──────────────────          ────────────────
    1. conn.send(request)  ─────>  1. conn.recv()  ← blocks
    2. conn.recv()  ← blocks    <────  2. conn.send(response)
    3. process result
    """)

    logger.info("\nCOMMON MISTAKE - Deadlock:")
    logger.info("─" * 70)

    logger.info("""
    Process A                       Process B
    ──────────                      ────────
    1. conn.recv()  ← blocks        1. conn.recv()  ← blocks
       (waiting for data)               (waiting for data)

    Result: DEADLOCK - both waiting forever!
    """)

    logger.info("\nHow to Avoid:")
    logger.info("  1. Carefully plan send/recv sequence")
    logger.info("  2. Parent usually sends first (takes initiative)")
    logger.info("  3. Child receives first (waits for work)")
    logger.info("  4. Alternate send/recv (request ↔ response)")
    logger.info("  5. Use timeouts for debugging")
    logger.info("  6. Add logging for flow tracing")


def demonstrate_duplex_patterns() -> None:
    """Show different communication patterns with duplex pipes."""
    logger = get_logger(__name__)

    log_section(logger, "Duplex Communication Patterns")

    logger.info("\nPattern 1: Simple Request-Response")
    logger.info("─" * 70)
    logger.info("""
    Parent                Child
    1. send(req)  ────→
    2. recv(res)  ←──── 1. recv(req)
                        2. send(res)

    Use: Customer validation, lookups, simple queries
    """)

    logger.info("\nPattern 2: Multiple Requests-Responses")
    logger.info("─" * 70)
    logger.info("""
    Parent                          Child
    ──────────────────              ────────────────
    1. send(req1)  ─────────────→   1. recv()  ← blocks
    2. recv(res1)  ←──────────────  2. send(res1)
    3. send(req2)  ─────────────→   3. recv()  (gets req2)
    4. recv(res2)  ←──────────────  4. send(res2)
    ...

    Use: Batch processing, multiple queries
    """)

    logger.info("\nPattern 3: Streaming with Duplex")
    logger.info("─" * 70)
    logger.info("""
    Parent                      Child
    ──────────────────          ────────────────
    1. send(data1)  ─────────→  1. recv()
    2. send(data2)  ─────────→  2. send(result1)
    3. recv(res1)   ←─────────  3. recv()  (gets data2)
    4. send(data3)  ─────────→  4. send(result2)
    5. recv(res2)   ←─────────  5. recv()  (gets data3)
    ...                         6. send(result3)
    ...

    Use: Pipelined processing with feedback
    """)


def main() -> None:
    """Entry point for demonstrations."""
    demonstrate_duplex_pipe()
    explain_duplex_vs_simplex()
    explain_duplex_sequencing()
    demonstrate_duplex_patterns()


# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
================================================================================
  Duplex Pipe Communication
================================================================================

Scenario: Customer Verification (Bidirectional)

✓ Created duplex pipe
  Parent uses conn1 (send request, recv result)
  Child uses conn2 (recv request, send result)

✓ Validator process started

Sending verification requests:
────────────────────────────────────────────────────────────────────────────

[PARENT] Sending request: Alice Johnson

[VALIDATOR] Started
[VALIDATOR] Received: Alice Johnson
[VALIDATOR] Sent result: Alice Johnson - Approved

[PARENT] Received result: {'customer_id': 'CUST-001', 'name': 'Alice Johnson', 'valid': True, 'reason': 'Approved'}
         Status: ✓ APPROVED
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: What's the main difference between duplex and simplex pipes?
   A: Duplex: Both processes send and receive (bidirectional)
      Simplex: Only one direction (one sends, other receives)

2. Q: How do you avoid deadlock in duplex pipes?
   A: Careful sequencing - parent sends first, child receives first
      Alternate send/recv (don't both recv or both send)

3. Q: When would you use duplex instead of two simplex pipes?
   A: Duplex: Simpler code, less overhead for request-response
      Two simplex: Better for one-way data flows

4. Q: What happens if both processes try to recv()?
   A: Deadlock - both block waiting for other to send

5. Q: Why is sequencing important in duplex?
   A: Prevents deadlock and ensures data flows correctly
"""

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
"""
Challenge: Implement Echo Server

Create bidirectional communication where:
1. Parent sends messages to child
2. Child echoes back with processing
3. Multiple messages exchanged
4. Graceful termination

Features:
- Parent sends: {"msg": "hello"}
- Child receives and echoes: {"echo": "hello", "processed": True}
- Handle multiple exchanges
- Signal end with special message

Expected output:
[PARENT] Sending: hello
[CHILD] Received: hello
[PARENT] Received echo: hello
...
"""


if __name__ == "__main__":
    main()
