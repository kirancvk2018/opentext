"""
###############################################################################
Python IPC – Pipe Connection Management & Resource Cleanup
###############################################################################

PROBLEM STATEMENT: Payment processing system must properly manage pipe
connections to avoid resource leaks and handle errors gracefully.

BUSINESS SCENARIO: Payment Gateway
Company: FastPay Financial
System: Transaction processing pipeline
"""

import logging
import multiprocessing as mp
import time
from typing import Optional

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section


def payment_processor(conn_recv, conn_send) -> None:
    """Child process that processes payments."""
    logger = get_logger(__name__)
    logger.info("[PROCESSOR] Started")

    try:
        processed = 0
        while True:
            try:
                # Receive payment
                payment = conn_recv.recv()
                logger.info(f"[PROCESSOR] Received: {payment['id']}")

                # Process
                result = {
                    "payment_id": payment["id"],
                    "amount": payment["amount"],
                    "status": "completed",
                }

                # Send result
                conn_send.send(result)
                processed += 1

                time.sleep(0.1)

            except EOFError:
                logger.info(f"[PROCESSOR] Pipe closed after {processed} payments")
                break
            except Exception as e:
                logger.error(f"[PROCESSOR] Error: {e}")
                break

    finally:
        # Always close connections
        try:
            if not conn_recv.closed:
                conn_recv.close()
                logger.info("[PROCESSOR] Closed receive connection")
        except Exception:
            pass

        try:
            if not conn_send.closed:
                conn_send.close()
                logger.info("[PROCESSOR] Closed send connection")
        except Exception:
            pass

        logger.info("[PROCESSOR] Exiting")


def demonstrate_connection_management() -> None:
    """Demonstrate proper connection management."""
    logger = get_logger(__name__)

    log_section(logger, "Pipe Connection Management")

    logger.info("\nBest Practice: Proper Connection Lifecycle\n")

    # Step 1: Create
    logger.info("STEP 1: Create Pipes")
    logger.info("─" * 70)
    conn1, conn2 = mp.Pipe()
    logger.info(f"✓ conn1 created: {conn1}")
    logger.info(f"✓ conn2 created: {conn2}\n")

    # Step 2: Spawn
    logger.info("STEP 2: Spawn Child Process")
    logger.info("─" * 70)
    processor = mp.Process(
        target=payment_processor,
        args=(conn2, conn1),
        name="PaymentProcessor",
    )
    processor.start()
    logger.info("✓ Child process started\n")

    # Step 3: Use
    logger.info("STEP 3: Communicate")
    logger.info("─" * 70)

    payments = [
        {"id": "PAY-001", "amount": 100.00},
        {"id": "PAY-002", "amount": 250.00},
        {"id": "PAY-003", "amount": 75.50},
    ]

    try:
        for payment in payments:
            logger.info(f"[PARENT] Sending: {payment['id']} - ${payment['amount']:.2f}")
            conn1.send(payment)

            result = conn2.recv()
            logger.info(f"[PARENT] Received: {result['payment_id']} - {result['status']}")

    except BrokenPipeError:
        logger.error("Pipe broken - child process may have crashed")
    except Exception as e:
        logger.error(f"Communication error: {e}")

    logger.info()

    # Step 4: Close
    logger.info("STEP 4: Close Connections")
    logger.info("─" * 70)

    # Close parent's unused ends
    if not conn1.closed:
        conn1.close()
        logger.info("✓ Closed parent write connection")

    if not conn2.closed:
        conn2.close()
        logger.info("✓ Closed parent read connection")

    logger.info()

    # Step 5: Wait
    logger.info("STEP 5: Wait for Child Process")
    logger.info("─" * 70)
    processor.join()
    logger.info("✓ Child process exited\n")

    logger.info("✓ All resources cleaned up")


def demonstrate_resource_leak() -> None:
    """Show what happens with improper connection management."""
    logger = get_logger(__name__)

    log_section(logger, "Resource Leaks & Prevention")

    logger.info("\n❌ PROBLEM 1: Not Closing Connections")
    logger.info("─" * 70)
    logger.info("""
    # Bad code - connections not closed
    def bad_pipe_example():
        conn1, conn2 = mp.Pipe()
        # ... use pipes ...
        # Forgot to close!

    Problems:
    • File descriptors not released
    • OS runs out of file descriptors
    • Process can't open more files/pipes
    • Resource leak
    """)

    logger.info("\n✓ SOLUTION: Always Close")
    logger.info("─" * 70)
    logger.info("""
    # Good code - connections closed
    try:
        conn1, conn2 = mp.Pipe()
        # ... use pipes ...
    finally:
        if not conn1.closed:
            conn1.close()
        if not conn2.closed:
            conn2.close()

    Benefits:
    • Guaranteed cleanup
    • Even if exception occurs
    • File descriptors released
    """)

    logger.info("\n❌ PROBLEM 2: Deadlock from Unclosed Ends")
    logger.info("─" * 70)
    logger.info("""
    # Bad code
    conn1, conn2 = mp.Pipe()
    proc = Process(target=worker, args=(conn2,))
    proc.start()

    # Forgot to close conn2 in parent!
    # Now: both parent and child have conn2 open
    # Parent sends EOF but child doesn't receive it
    # (because parent still has a copy)

    Result: Child never detects EOF
    """)

    logger.info("\n✓ SOLUTION: Close Unused Ends")
    logger.info("─" * 70)
    logger.info("""
    # Good code
    conn1, conn2 = mp.Pipe()
    proc = Process(target=worker, args=(conn2,))
    proc.start()

    # Parent closes read end (doesn't need it)
    # Now only child has read end
    conn2.close()

    # When parent closes write end:
    # Child receives EOFError on recv()
    """)

    logger.info("\n❌ PROBLEM 3: Using After Close")
    logger.info("─" * 70)
    logger.info("""
    conn1, conn2 = mp.Pipe()
    conn1.close()
    conn2.close()

    # Bad: trying to use after close
    conn1.send(data)  # Raises ValueError
    """)


def demonstrate_error_handling() -> None:
    """Show error handling with pipes."""
    logger = get_logger(__name__)

    log_section(logger, "Error Handling Strategies")

    logger.info("\n1. Handle EOFError (Normal Termination)")
    logger.info("─" * 70)
    logger.info("""
    try:
        while True:
            data = conn.recv()
            process(data)
    except EOFError:
        logger.info("No more data")
    """)

    logger.info("\n2. Handle BrokenPipeError (Child Crashed)")
    logger.info("─" * 70)
    logger.info("""
    try:
        conn.send(data)
    except BrokenPipeError:
        logger.error("Child process crashed")
        # Handle gracefully
    """)

    logger.info("\n3. Handle ValueError (Using After Close)")
    logger.info("─" * 70)
    logger.info("""
    try:
        conn.send(data)
    except ValueError as e:
        if "connection closed" in str(e):
            logger.error("Pipe was closed")
    """)

    logger.info("\n4. Complete Error Handling")
    logger.info("─" * 70)
    logger.info("""
    try:
        try:
            while True:
                data = conn.recv()
                process(data)
        except EOFError:
            logger.info("Normal completion")
        except BrokenPipeError:
            logger.error("Child crashed")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
    finally:
        if not conn.closed:
            conn.close()
    """)


def demonstrate_cleanup_patterns() -> None:
    """Show different cleanup patterns."""
    logger = get_logger(__name__)

    log_section(logger, "Cleanup Patterns")

    logger.info("\nPattern 1: Try-Finally (Simple)")
    logger.info("─" * 70)
    logger.info("""
    conn1, conn2 = mp.Pipe()
    try:
        # Use pipes
        pass
    finally:
        if not conn1.closed:
            conn1.close()
        if not conn2.closed:
            conn2.close()
    """)

    logger.info("\nPattern 2: Context Manager (Best)")
    logger.info("─" * 70)
    logger.info("""
    class PipeContext:
        def __init__(self):
            self.conn1, self.conn2 = mp.Pipe()

        def __enter__(self):
            return self.conn1, self.conn2

        def __exit__(self, *args):
            if not self.conn1.closed:
                self.conn1.close()
            if not self.conn2.closed:
                self.conn2.close()

    with PipeContext() as (conn1, conn2):
        # Use pipes - auto cleanup
        pass
    """)

    logger.info("\nPattern 3: Wrapper Function")
    logger.info("─" * 70)
    logger.info("""
    def use_pipe(target_func, args):
        conn1, conn2 = mp.Pipe()
        proc = mp.Process(target=target_func, args=args)
        proc.start()

        try:
            return process_with_pipes(conn1, conn2)
        finally:
            if not conn1.closed:
                conn1.close()
            if not conn2.closed:
                conn2.close()
            proc.join()
    """)


def demonstrate_connection_properties() -> None:
    """Show connection object properties."""
    logger = get_logger(__name__)

    log_section(logger, "Connection Properties & Methods")

    conn1, conn2 = mp.Pipe()

    logger.info("\nConnection Properties:")
    logger.info("─" * 70)

    logger.info(f"conn1.closed:     {conn1.closed}")
    logger.info(f"conn2.closed:     {conn2.closed}")

    logger.info(f"\nAfter closing conn1:")
    conn1.close()
    logger.info(f"conn1.closed:     {conn1.closed}")
    logger.info(f"conn2.closed:     {conn2.closed}")

    conn2.close()
    logger.info(f"\nAfter closing both:")
    logger.info(f"conn1.closed:     {conn1.closed}")
    logger.info(f"conn2.closed:     {conn2.closed}")

    logger.info("\nConnection Methods:")
    logger.info("─" * 70)
    logger.info("send(obj)       - Send object (serializes, blocks if buffer full)")
    logger.info("recv()          - Receive object (deserializes, blocks if empty)")
    logger.info("close()         - Close connection")
    logger.info("closed          - Check if closed (property)")
    logger.info("fileno()        - Get file descriptor")
    logger.info("poll(timeout)   - Check if data available")


def main() -> None:
    """Entry point."""
    demonstrate_connection_management()
    demonstrate_resource_leak()
    demonstrate_error_handling()
    demonstrate_cleanup_patterns()
    demonstrate_connection_properties()


# ============================================================================
# BEST PRACTICES SUMMARY
# ============================================================================
"""
1. Always close connections in finally or try/except
2. Close unused pipe ends to enable EOF detection
3. Handle EOFError for normal completion
4. Handle BrokenPipeError for child crash
5. Check conn.closed before using
6. Don't reuse closed connections
7. Clean up even if exception occurs
8. Use logging for debugging
9. Join child processes after closing pipes
10. Test edge cases (crash, timeout, errors)
"""

# ============================================================================
# COMMON MISTAKES
# ============================================================================
"""
1. Forgetting to close connections
2. Not closing unused ends in parent
3. Not handling EOFError
4. Using connection after close
5. Not joining child processes
6. Ignoring BrokenPipeError
7. Deadlock from unclosed ends
8. Not catching exceptions
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: Why must you close pipe connections?
   A: Release file descriptors, allow EOF detection, prevent leaks

2. Q: What happens if child doesn't close write end?
   A: Parent never gets EOFError when closing write end

3. Q: How to detect if connection closed?
   A: Check conn.closed property or catch exceptions

4. Q: Should you close unused pipe ends?
   A: Yes - allows EOF detection, frees resources

5. Q: How to handle child process crash?
   A: Catch BrokenPipeError on send, check process.is_alive()
"""

if __name__ == "__main__":
    main()
