"""
###############################################################################
Python IPC – Parent-Child Communication via Pipes
###############################################################################

PROBLEM STATEMENT
─────────────────────────────────────────────────────────────────────────────
A payroll processing system needs to calculate employee salaries in parallel:

1. Main process holds employee records
2. Child processes calculate individual salaries (CPU-intensive)
3. Child processes return calculated results
4. Main process collects and summarizes

Problem:
- Can't calculate all salaries in main thread (slow)
- Need to distribute work to multiple child processes
- Need to collect results from children
- Main process should wait for all results


BUSINESS SCENARIO – Payroll Processing
─────────────────────────────────────────────────────────────────────────────
Company: GlobalPay Payroll Services
System: Monthly Salary Calculation

Challenge:
- 50,000 employees to process
- Each salary calculation: 200ms (tax, benefits, deductions)
- Sequential: 50,000 × 0.2s = 2.8 hours
- Target: Complete in < 10 minutes

Solution:
- Create 4 child processes (on 4-core system)
- Distribute employees across children
- Each child calculates salaries independently
- Children return results via pipes
- Main process assembles final payroll

Expected:
- Sequential: 2.8 hours
- Parallel (4 cores): ~45 minutes
- Speedup: ~3.7x (approaching 4x due to overhead)


LEARNING OBJECTIVES
─────────────────────────────────────────────────────────────────────────────
1. Create parent-child communication pattern
2. Send data from parent to child
3. Receive results from child
4. Handle multiple parent-child pairs
5. Collect results from multiple children
6. Manage child process lifecycle
"""

import logging
import multiprocessing as mp
import time
from typing import List, Dict, Any, Tuple

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section, log_separator
from common.timer import timer, PerformanceMetrics


def calculate_salary(employee_id: str, base_salary: float) -> Dict[str, Any]:
    """
    Calculate employee salary with taxes and benefits.

    Simulates CPU-intensive calculation.

    Args:
        employee_id: Employee identifier
        base_salary: Base salary amount

    Returns:
        Dictionary with calculated salary details
    """
    # Simulate complex salary calculation
    # (In reality this might involve:
    #  - Tax bracket calculations
    #  - Benefits accrual
    #  - Deductions
    #  - Overtime calculations
    #  - Bonus calculations)

    # Simulate processing time
    time.sleep(0.2)

    # Calculate components
    federal_tax = base_salary * 0.15
    state_tax = base_salary * 0.05
    social_security = base_salary * 0.062
    health_insurance = 400
    retirement_contribution = base_salary * 0.05

    total_deductions = (
        federal_tax + state_tax + social_security + health_insurance + retirement_contribution
    )
    net_salary = base_salary - total_deductions

    return {
        "employee_id": employee_id,
        "base_salary": base_salary,
        "federal_tax": federal_tax,
        "state_tax": state_tax,
        "social_security": social_security,
        "health_insurance": health_insurance,
        "retirement_contribution": retirement_contribution,
        "total_deductions": total_deductions,
        "net_salary": net_salary,
    }


def salary_calculator_process(conn_recv, conn_send) -> None:
    """
    Child process that receives employee data and returns calculated salaries.

    Args:
        conn_recv: Connection to receive employee data
        conn_send: Connection to send calculated results
    """
    logger = get_logger(__name__)
    proc_name = mp.current_process().name

    logger.info(f"[{proc_name}] Started salary calculator")

    # Process employees until receiver closes
    processed = 0
    try:
        while True:
            # Receive employee data from parent
            try:
                employee = conn_recv.recv()
            except EOFError:
                logger.info(f"[{proc_name}] No more employees to process")
                break

            # Calculate salary
            result = calculate_salary(employee["id"], employee["base_salary"])

            # Send result back to parent
            conn_send.send(result)
            processed += 1

            logger.info(
                f"[{proc_name}] Calculated salary for {employee['id']}: "
                f"${result['net_salary']:.2f}"
            )

    finally:
        # Close connections
        conn_recv.close()
        conn_send.close()
        logger.info(f"[{proc_name}] Processed {processed} employees, exiting")


def demonstrate_parent_child_pipes() -> None:
    """
    Demonstrate parent-child communication pattern.

    Parent sends work, children calculate, return results.
    """
    logger = get_logger(__name__)

    log_section(logger, "Parent-Child Pipe Communication")

    logger.info("\nScenario: Parallel Salary Calculation")
    logger.info("─" * 70)
    logger.info("Parent: Main process with employee data")
    logger.info("Children: Salary calculator processes\n")

    # =========================================================================
    # SECTION 1: Create Employees
    # =========================================================================
    logger.info("STEP 1: Prepare Employee Data")
    logger.info("─" * 70)

    employees = [
        {"id": f"EMP-{i:05d}", "base_salary": 50000 + (i * 1000)}
        for i in range(1, 9)
    ]

    logger.info(f"Prepared {len(employees)} employees")
    for emp in employees[:3]:
        logger.info(f"  {emp['id']}: ${emp['base_salary']:.2f}")
    logger.info("  ...\n")

    # =========================================================================
    # SECTION 2: Create Pipes
    # =========================================================================
    logger.info("STEP 2: Create Pipes for Parent-Child Communication")
    logger.info("─" * 70)

    # Create multiple child processes
    num_children = 2
    pipes = []

    for i in range(num_children):
        # Each child needs two pipes:
        # - One to receive work from parent
        # - One to send results back
        parent_send, child_recv = mp.Pipe()
        child_send, parent_recv = mp.Pipe()

        pipes.append(
            {
                "parent_send": parent_send,
                "child_recv": child_recv,
                "child_send": child_send,
                "parent_recv": parent_recv,
                "id": i,
            }
        )

    logger.info(f"Created {num_children} pipe pairs")
    logger.info("  Pipe 1: Parent ─→ Child 1 (send work)")
    logger.info("  Pipe 2: Child 1 ─→ Parent (receive results)")
    logger.info("  ...\n")

    # =========================================================================
    # SECTION 3: Spawn Child Processes
    # =========================================================================
    logger.info("STEP 3: Spawn Child Processes")
    logger.info("─" * 70)

    processes = []
    for pipe_info in pipes:
        process = mp.Process(
            target=salary_calculator_process,
            args=(pipe_info["child_recv"], pipe_info["child_send"]),
            name=f"SalaryCalc-{pipe_info['id']}",
        )
        process.start()
        processes.append(process)
        logger.info(f"Started {process.name}")

    logger.info()

    # =========================================================================
    # SECTION 4: Distribute Work
    # =========================================================================
    logger.info("STEP 4: Distribute Work to Children")
    logger.info("─" * 70)

    # Round-robin distribute employees to children
    for idx, employee in enumerate(employees):
        child_idx = idx % num_children
        pipe_info = pipes[child_idx]

        logger.info(
            f"Sending {employee['id']} to "
            f"SalaryCalc-{child_idx}: ${employee['base_salary']:.2f}"
        )

        # Send employee to child
        pipe_info["parent_send"].send(employee)

    logger.info()

    # =========================================================================
    # SECTION 5: Close Work Pipes
    # =========================================================================
    logger.info("STEP 5: Signal End of Work")
    logger.info("─" * 70)

    # Close send pipes to signal children: no more work
    for pipe_info in pipes:
        pipe_info["parent_send"].close()
        logger.info(f"Closed work pipe for SalaryCalc-{pipe_info['id']}")

    logger.info()

    # =========================================================================
    # SECTION 6: Collect Results
    # =========================================================================
    logger.info("STEP 6: Collect Results from Children")
    logger.info("─" * 70)

    results = []
    total_net_salary = 0

    for pipe_info in pipes:
        try:
            while True:
                # Receive result from child
                result = pipe_info["parent_recv"].recv()
                results.append(result)
                total_net_salary += result["net_salary"]

                logger.info(
                    f"Received result from SalaryCalc-{pipe_info['id']}: "
                    f"{result['employee_id']} = ${result['net_salary']:.2f}"
                )

        except EOFError:
            # Child closed result pipe (all results sent)
            logger.info(f"Closed result pipe for SalaryCalc-{pipe_info['id']}")

    logger.info()

    # =========================================================================
    # SECTION 7: Wait for Completion
    # =========================================================================
    logger.info("STEP 7: Wait for Child Processes")
    logger.info("─" * 70)

    for process in processes:
        process.join()
        logger.info(f"✓ {process.name} completed")

    logger.info()

    # =========================================================================
    # SECTION 8: Summary
    # =========================================================================
    log_section(logger, "Payroll Summary")

    logger.info(f"\nTotal Employees Processed: {len(results)}")
    logger.info(f"Total Net Salary: ${total_net_salary:,.2f}")
    logger.info(f"Average Net Salary: ${total_net_salary / len(results):,.2f}\n")

    # Show details for first few employees
    logger.info("Sample Results:")
    logger.info("─" * 70)
    for result in results[:3]:
        logger.info(f"\n{result['employee_id']}:")
        logger.info(f"  Base Salary:          ${result['base_salary']:>10,.2f}")
        logger.info(f"  Federal Tax:          ${result['federal_tax']:>10,.2f}")
        logger.info(f"  State Tax:            ${result['state_tax']:>10,.2f}")
        logger.info(f"  Social Security:      ${result['social_security']:>10,.2f}")
        logger.info(f"  Health Insurance:     ${result['health_insurance']:>10,.2f}")
        logger.info(f"  Retirement:           ${result['retirement_contribution']:>10,.2f}")
        logger.info(f"  ─" * 35)
        logger.info(f"  Net Salary:           ${result['net_salary']:>10,.2f}")


def demonstrate_work_distribution() -> None:
    """
    Show different work distribution strategies.
    """
    logger = get_logger(__name__)

    log_section(logger, "Work Distribution Strategies")

    logger.info("\nStrategy 1: Round-Robin Distribution")
    logger.info("─" * 70)
    logger.info("Employee → Child Process (via modulo)")
    logger.info("  EMP-001 → Child 1")
    logger.info("  EMP-002 → Child 2")
    logger.info("  EMP-003 → Child 1 (wraps around)")
    logger.info("  EMP-004 → Child 2")
    logger.info("  ...")
    logger.info("\nAdvantages: Simple, balanced distribution")
    logger.info("Disadvantages: Assumes equal processing time per employee")

    logger.info("\nStrategy 2: Batch Distribution")
    logger.info("─" * 70)
    logger.info("Send batch of work to each child")
    logger.info("  Child 1: EMP-001 through EMP-125")
    logger.info("  Child 2: EMP-126 through EMP-250")
    logger.info("  ...")
    logger.info("\nAdvantages: Simpler code, less pipe communication")
    logger.info("Disadvantages: Load imbalance if processing time varies")

    logger.info("\nStrategy 3: Dynamic Distribution (Work Queue)")
    logger.info("─" * 70)
    logger.info("Children request work when available")
    logger.info("  Child 1: \"Ready for work\"")
    logger.info("  Parent: Send next task")
    logger.info("  Child 2: \"Ready for work\"")
    logger.info("  Parent: Send next task")
    logger.info("  ...")
    logger.info("\nAdvantages: Optimal load balancing")
    logger.info("Disadvantages: More complex, more pipe communication")

    logger.info("\nRecommendation:")
    logger.info("  • For similar-sized tasks: Round-robin or Batch")
    logger.info("  • For variable-sized tasks: Dynamic (Work Queue)")
    logger.info("  • Measure before optimizing")


def demonstrate_timing_comparison() -> None:
    """
    Show timing comparison between sequential and parallel.
    """
    logger = get_logger(__name__)

    log_section(logger, "Performance Comparison")

    logger.info("\nPayroll Calculation Performance")
    logger.info("─" * 70)

    logger.info("\nScenario: 50,000 employees, 200ms per calculation")

    logger.info("\nSequential (1 process):")
    logger.info("  Time = 50,000 × 0.2s = 10,000s")
    logger.info("  Time = ~2.8 hours")
    logger.info("  CPU Core Usage: 1 core @ 100%")

    logger.info("\nParallel (4 processes):")
    logger.info("  Time ≈ (50,000 / 4) × 0.2s + overhead")
    logger.info("  Time ≈ 2,500 × 0.2s = 500s")
    logger.info("  Time ≈ ~8.3 minutes")
    logger.info("  CPU Core Usage: 4 cores @ 100%")

    logger.info("\nParallel (8 processes):")
    logger.info("  Time ≈ (50,000 / 8) × 0.2s + overhead")
    logger.info("  Time ≈ 1,250 × 0.2s = 250s")
    logger.info("  Time ≈ ~4.2 minutes")
    logger.info("  CPU Core Usage: 8 cores @ 100%")

    logger.info("\nSpeedup Analysis:")
    logger.info("  Sequential: 1.0x baseline")
    logger.info("  4 cores:    3.7x faster (not 4x due to overhead)")
    logger.info("  8 cores:    6.0x faster (not 8x due to overhead)")

    logger.info("\nKey Insights:")
    logger.info("  • Parallelism gives near-linear speedup")
    logger.info("  • Communication overhead ≈ 10-20% of total time")
    logger.info("  • IPC cost well worth it for large datasets")
    logger.info("  • More processes ≠ Always faster")
    logger.info("  • Optimal: #processes ≈ #CPU cores")


def main() -> None:
    """Entry point for demonstrations."""
    demonstrate_parent_child_pipes()
    demonstrate_work_distribution()
    demonstrate_timing_comparison()


# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
================================================================================
  Parent-Child Pipe Communication
================================================================================

Scenario: Parallel Salary Calculation
Parent: Main process with employee data
Children: Salary calculator processes

STEP 1: Prepare Employee Data
────────────────────────────────────────────────────────────────────────────
Prepared 8 employees
  EMP-00001: $51000.00
  EMP-00002: $52000.00
  EMP-00003: $53000.00
  ...

STEP 2: Create Pipes for Parent-Child Communication
────────────────────────────────────────────────────────────────────────────
Created 2 pipe pairs
  Pipe 1: Parent ─→ Child 1 (send work)
  Pipe 2: Child 1 ─→ Parent (receive results)
  ...

STEP 3: Spawn Child Processes
────────────────────────────────────────────────────────────────────────────
Started SalaryCalc-0
Started SalaryCalc-1

STEP 4: Distribute Work to Children
────────────────────────────────────────────────────────────────────────────
Sending EMP-00001 to SalaryCalc-0: $51000.00
Sending EMP-00002 to SalaryCalc-1: $52000.00
...

[SalaryCalc-0] Calculated salary for EMP-00001: $36262.50

[... More results ...]

STEP 7: Wait for Child Processes
────────────────────────────────────────────────────────────────────────────
✓ SalaryCalc-0 completed
✓ SalaryCalc-1 completed

================================================================================
  Payroll Summary
================================================================================

Total Employees Processed: 8
Total Net Salary: $395,112.50
Average Net Salary: $49,389.06

Sample Results:
────────────────────────────────────────────────────────────────────────────

EMP-00001:
  Base Salary:          $51,000.00
  Federal Tax:          $ 7,650.00
  State Tax:            $ 2,550.00
  Social Security:      $ 3,162.00
  Health Insurance:     $   400.00
  Retirement:           $ 2,550.00
  ───────────────────────────────────────────────────────────────
  Net Salary:           $36,737.50
"""

# ============================================================================
# EXECUTION FLOW
# ============================================================================
"""
1. Parent creates employee data
2. Parent creates 2 pipe pairs (for 2 child processes)
3. Parent spawns 2 child processes
4. Parent distributes employees to children (round-robin)
5. Children receive employees via pipe
6. Children calculate salaries
7. Children send results back via second pipe
8. Parent collects results from both children
9. Parent closes work pipes (signals no more work)
10. Parent waits for results from both children
11. Child processes detect EOF and exit
12. Parent displays summary
"""

# ============================================================================
# ARCHITECTURE EXPLANATION
# ============================================================================
"""
Parent Process (Main)
├─ Create pipes for each child
├─ Spawn child processes
├─ Send work through parent_send pipes
├─ Receive results through parent_recv pipes
└─ Collect and summarize

Child Processes
├─ Receive work from parent via child_recv
├─ Process work (calculate salaries)
├─ Send results back via child_send
├─ Detect EOF on child_recv
└─ Exit

Pipe Architecture (per child):
    ┌──────────────────────────────┐
    │   Parent Process             │
    │ ┌──────────────────────────┐ │
    │ │ parent_send │ parent_recv│ │
    │ └──────┬────────────┬──────┘ │
    └────────┼────────────┼────────┘
             │            │
           Pipe 1       Pipe 2
             │            │
    ┌────────┼────────────┼────────┐
    │ ┌──────┴───────────┴──────┐ │
    │ │ child_recv   child_send │ │
    │ │                         │ │
    │ │   Child Process         │ │
    │ │ (SalaryCalc)            │ │
    │ └─────────────────────────┘ │
    │                             │
    │   Receive: Employee Data    │
    │   Send: Calculated Results  │
    └─────────────────────────────┘
"""

# ============================================================================
# ADVANTAGES
# ============================================================================
"""
1. Parallelism: Multiple children work simultaneously
2. Work Distribution: Parent easily distributes work
3. Result Collection: Easy to gather results
4. Scalability: Add more children easily
5. Isolation: Each child independent
6. Load Balancing: Can distribute work optimally
"""

# ============================================================================
# LIMITATIONS
# ============================================================================
"""
1. Complexity: Need to manage multiple pipes
2. Sequencing: Ensure parent/child coordination
3. Error Handling: Errors in child affect result
4. Load Imbalance: If work not distributed evenly
5. Overhead: IPC cost for many small tasks
"""

# ============================================================================
# PERFORMANCE CONSIDERATIONS
# ============================================================================
"""
Speedup = Sequential Time / Parallel Time

For N workers:
    Ideal speedup: N (linear)
    Actual speedup: N × (1 - overhead%)

Example:
    Sequential: 10,000s
    4 workers with 10% overhead: 10,000 / (4 × 0.9) = 2778s (3.6x)
    8 workers with 10% overhead: 10,000 / (8 × 0.9) = 1389s (7.2x)

Overhead includes:
    - Process creation
    - IPC latency
    - Context switching
    - Load imbalance
"""

# ============================================================================
# BEST PRACTICES
# ============================================================================
"""
1. Create pipes before forking
2. Close unused pipe ends
3. Distribute work evenly
4. Handle EOFError explicitly
5. Log process activity
6. Join child processes
7. Measure before/after
8. Use num_children = num_cpu_cores
"""

# ============================================================================
# COMMON MISTAKES
# ============================================================================
"""
1. Creating pipes after forking (doesn't work)
2. Not closing unused ends (deadlock/hangs)
3. Wrong pipe assignment (data flows wrong way)
4. Not joining children (zombies)
5. Deadlock in parent (waiting while children wait)
6. Uneven work distribution
7. Not handling child errors
8. Creating too many children (overhead > benefit)
"""

# ============================================================================
# DEBUGGING TIPS
# ============================================================================
"""
1. Add logging to both parent and children
2. Verify pipe connections before use
3. Check process.is_alive()
4. Monitor with ps/top
5. Use small test data first
6. Verify work is actually distributed
7. Check for deadlocks (timeout test)
8. Trace data flow (log send/recv)
"""

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
"""
1. Q: How do parent and child communicate?
   A: Parent creates pipes before forking.
      Child receives connection objects via process arguments.
      Parent and child exchange data through pipes.

2. Q: Why two pipes per child?
   A: One for parent to send work to child.
      One for child to send results back to parent.
      Allows bidirectional communication.

3. Q: How does parent signal end of work?
   A: Parent closes work pipe after sending all tasks.
      Child detects EOF when receiving.

4. Q: What's ideal number of child processes?
   A: Equal to number of CPU cores.
      More processes = more overhead, not faster.

5. Q: How to handle uneven work?
   A: Use dynamic work queue (child requests next task).
      Or pre-measure and distribute accordingly.
"""

# ============================================================================
# HANDS-ON EXERCISE
# ============================================================================
"""
Exercise 1: Modify to use 4 children

Current code uses 2 children. Modify to:
1. Create 4 child processes
2. Distribute 16 employees across 4 children
3. Run and measure execution time

Exercise 2: Collect timing statistics

Modify to record:
1. Time when each employee is sent
2. Time when result is received
3. Calculate latency per employee
4. Report average and max latency

Exercise 3: Add error handling

Modify validator to:
1. Catch exceptions in children
2. Log errors
3. Handle child process crash
"""

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
"""
Challenge: Implement Dynamic Work Queue

Instead of distributing all work upfront, implement:
1. Children send "ready" message to parent
2. Parent sends next task when ready message received
3. Continue until all work done
4. Automatically balances load

Requirements:
- Need one additional communication pipe (child → parent)
- Parent waits for "ready" before sending work
- More complex coordination
- Should handle load better

Expected result:
- Faster children don't wait for slow ones
- Better utilization of fast workers
- More complex code but better performance
"""


if __name__ == "__main__":
    main()
