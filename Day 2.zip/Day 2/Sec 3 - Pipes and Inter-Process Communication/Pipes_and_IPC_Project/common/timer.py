"""
Performance measurement utilities.

Provides timing utilities for measuring IPC performance and execution time.
"""

import time
from contextlib import contextmanager
from typing import Generator, Optional

import logging


@contextmanager
def timer(
    logger: logging.Logger, label: str, level: str = "info"
) -> Generator[None, None, None]:
    """
    Context manager for timing code blocks.

    Args:
        logger: Logger instance
        label: Description of what's being timed
        level: Logging level ('info', 'debug', 'warning')

    Example:
        logger = get_logger(__name__)
        with timer(logger, "Process execution"):
            do_something()
    """
    start_time = time.perf_counter()

    try:
        yield
    finally:
        elapsed = time.perf_counter() - start_time
        log_func = getattr(logger, level.lower())
        log_func(f"{label}: {elapsed:.4f}s")


class PerformanceMetrics:
    """
    Collects and reports performance metrics for IPC operations.

    Tracks timing for multiple operations and provides summary statistics.

    Example:
        metrics = PerformanceMetrics()
        metrics.record("send", 0.001)
        metrics.record("recv", 0.002)
        metrics.print_report(logger)
    """

    def __init__(self) -> None:
        """Initialize metrics collection."""
        self.measurements: dict[str, list[float]] = {}
        self.start_time: Optional[float] = None

    def start(self) -> None:
        """Start overall timing."""
        self.start_time = time.perf_counter()

    def record(self, operation: str, elapsed: float) -> None:
        """
        Record a measurement.

        Args:
            operation: Name of operation (e.g., 'send', 'recv')
            elapsed: Time elapsed in seconds
        """
        if operation not in self.measurements:
            self.measurements[operation] = []
        self.measurements[operation].append(elapsed)

    def get_stats(self, operation: str) -> dict:
        """
        Get statistics for an operation.

        Args:
            operation: Operation name

        Returns:
            Dictionary with count, total, avg, min, max
        """
        if operation not in self.measurements:
            return {}

        times = self.measurements[operation]
        return {
            "count": len(times),
            "total": sum(times),
            "avg": sum(times) / len(times) if times else 0,
            "min": min(times) if times else 0,
            "max": max(times) if times else 0,
        }

    def print_report(self, logger: logging.Logger) -> None:
        """
        Print performance report.

        Args:
            logger: Logger instance
        """
        if not self.measurements:
            logger.info("No metrics recorded")
            return

        logger.info("=" * 70)
        logger.info("Performance Report")
        logger.info("=" * 70)

        for operation in self.measurements:
            stats = self.get_stats(operation)
            logger.info(f"\n{operation.upper()}:")
            logger.info(f"  Count:   {stats['count']} operations")
            logger.info(f"  Total:   {stats['total']:.4f}s")
            logger.info(f"  Average: {stats['avg']:.6f}s per operation")
            logger.info(f"  Min:     {stats['min']:.6f}s")
            logger.info(f"  Max:     {stats['max']:.6f}s")

            # Calculate throughput
            if stats["total"] > 0:
                throughput = stats["count"] / stats["total"]
                logger.info(f"  Rate:    {throughput:.0f} ops/sec")

        if self.start_time:
            total_time = time.perf_counter() - self.start_time
            logger.info(f"\nTotal Execution Time: {total_time:.4f}s")

        logger.info("=" * 70)
