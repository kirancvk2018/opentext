"""
General utility functions for IPC examples.

Provides helper functions for common operations, data validation,
and formatting across the project.
"""

import os
from pathlib import Path
from typing import Any, Dict, List

from .configuration import VALID_CLAIM_STATUSES, VALID_ORDER_STATUSES


def clean_fifo(path: Path) -> None:
    """
    Remove FIFO file if it exists.

    FIFO files persist in the filesystem even after process termination.
    Must be explicitly deleted to recreate.

    Args:
        path: Path to FIFO file

    Example:
        from pathlib import Path
        clean_fifo(Path("/tmp/myfifo.pipe"))
    """
    if path.exists():
        try:
            path.unlink()
        except OSError as e:
            # FIFO might be in use by another process
            pass


def ensure_fifo(path: Path) -> bool:
    """
    Ensure FIFO file exists, creating if necessary.

    Args:
        path: Path to create FIFO at

    Returns:
        True if FIFO exists (newly created or already existed)

    Raises:
        OSError: If FIFO creation fails (not on Unix-like system)

    Example:
        if ensure_fifo(Path("/tmp/myfifo.pipe")):
            print("FIFO ready")
    """
    if path.exists():
        return True

    try:
        os.mkfifo(path)
        return True
    except OSError as e:
        # Likely because this is Windows, or path issue
        return False


def format_order_for_display(order: Dict[str, Any]) -> str:
    """
    Format an order dictionary for readable display.

    Args:
        order: Order dictionary with id, customer, amount, etc.

    Returns:
        Formatted string representation
    """
    return (
        f"Order {order.get('order_id', 'N/A')}: "
        f"{order.get('customer', 'N/A')} - "
        f"${order.get('amount', 0):.2f}"
    )


def format_transaction_for_display(transaction: Dict[str, Any]) -> str:
    """
    Format a transaction dictionary for readable display.

    Args:
        transaction: Transaction with id, type, amount

    Returns:
        Formatted string representation
    """
    return (
        f"TXN {transaction.get('id', 'N/A')}: "
        f"{transaction.get('type', 'N/A').upper()} - "
        f"${transaction.get('amount', 0):.2f}"
    )


def validate_order(order: Dict[str, Any]) -> tuple[bool, str]:
    """
    Validate order data structure.

    Args:
        order: Order dictionary to validate

    Returns:
        Tuple of (is_valid, error_message)

    Example:
        is_valid, error = validate_order(order)
        if not is_valid:
            print(f"Invalid: {error}")
    """
    # Check required fields
    required_fields = ["order_id", "customer", "amount"]
    for field in required_fields:
        if field not in order:
            return False, f"Missing required field: {field}"

    # Validate amount
    amount = order.get("amount", 0)
    if not isinstance(amount, (int, float)) or amount <= 0:
        return False, f"Invalid amount: {amount}"

    # Validate status if present
    if "status" in order:
        if order["status"] not in VALID_ORDER_STATUSES:
            return False, f"Invalid status: {order['status']}"

    return True, ""


def validate_transaction(transaction: Dict[str, Any]) -> tuple[bool, str]:
    """
    Validate transaction data structure.

    Args:
        transaction: Transaction dictionary to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    # Check required fields
    required_fields = ["id", "type", "amount"]
    for field in required_fields:
        if field not in transaction:
            return False, f"Missing required field: {field}"

    # Validate type
    if transaction["type"] not in ("debit", "credit"):
        return False, f"Invalid type: {transaction['type']}"

    # Validate amount
    amount = transaction.get("amount", 0)
    if not isinstance(amount, (int, float)) or amount <= 0:
        return False, f"Invalid amount: {amount}"

    return True, ""


def validate_claim(claim: Dict[str, Any]) -> tuple[bool, str]:
    """
    Validate insurance claim data structure.

    Args:
        claim: Claim dictionary to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    # Check required fields
    required_fields = ["claim_id", "policy_id", "amount"]
    for field in required_fields:
        if field not in claim:
            return False, f"Missing required field: {field}"

    # Validate amount
    amount = claim.get("amount", 0)
    if not isinstance(amount, (int, float)) or amount <= 0:
        return False, f"Invalid claim amount: {amount}"

    # Validate status if present
    if "status" in claim:
        if claim["status"] not in VALID_CLAIM_STATUSES:
            return False, f"Invalid status: {claim['status']}"

    return True, ""


def merge_dictionaries(dict_list: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge multiple dictionaries into one.

    Later dictionaries override earlier ones.

    Args:
        dict_list: List of dictionaries to merge

    Returns:
        Merged dictionary
    """
    result = {}
    for d in dict_list:
        result.update(d)
    return result


def safe_get(data: Dict[str, Any], key: str, default: Any = None) -> Any:
    """
    Safely get dictionary value with default fallback.

    Args:
        data: Dictionary to access
        key: Key to retrieve
        default: Default value if key not found

    Returns:
        Value from dictionary or default
    """
    return data.get(key, default)


def bytes_to_human_readable(bytes_count: int) -> str:
    """
    Convert byte count to human-readable format.

    Args:
        bytes_count: Number of bytes

    Returns:
        Human-readable string (e.g., "1.5 MB")
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if bytes_count < 1024:
            return f"{bytes_count:.2f} {unit}"
        bytes_count /= 1024
    return f"{bytes_count:.2f} PB"


def calculate_message_size(obj: Any) -> int:
    """
    Estimate size of object after pickling.

    This gives approximate size of object when sent through pipe.

    Args:
        obj: Object to estimate

    Returns:
        Approximate size in bytes
    """
    import pickle

    return len(pickle.dumps(obj))
