"""
Logging utilities for IPC examples.

Provides thread-safe and process-safe logging across the project.
Ensures consistent log formatting and output handling.
"""

import logging
import sys
from typing import Optional

from .configuration import LOG_DATE_FORMAT, LOG_FORMAT, LOG_LEVEL


class ProcessSafeHandler(logging.StreamHandler):
    """
    Custom logging handler that prevents interleaving of log messages
    from different processes.

    This handler uses Python's GIL and atomic writes to reduce
    the probability of interleaved output.
    """

    def emit(self, record: logging.LogRecord) -> None:
        """
        Emit a log record with minimal interleaving risk.

        Args:
            record: The log record to emit
        """
        try:
            msg = self.format(record)
            # Single write operation reduces interleaving
            self.stream.write(msg + "\n")
            self.stream.flush()
        except Exception:
            self.handleError(record)


def get_logger(name: str, level: Optional[str] = None) -> logging.Logger:
    """
    Get a process-safe logger configured for the project.

    Args:
        name: Logger name (typically __name__)
        level: Log level (e.g., 'INFO', 'DEBUG'). Defaults to LOG_LEVEL

    Returns:
        Configured logger instance

    Example:
        logger = get_logger(__name__)
        logger.info("Starting process: %s", multiprocessing.current_process().name)
    """
    # Use provided level or fall back to configuration
    log_level = level or LOG_LEVEL

    # Create or get logger
    logger = logging.getLogger(name)
    logger.setLevel(log_level)

    # Skip if handlers already configured (avoid duplicates)
    if logger.handlers:
        return logger

    # Create custom handler
    handler = ProcessSafeHandler(sys.stdout)
    handler.setLevel(log_level)

    # Apply format
    formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
    handler.setFormatter(formatter)

    # Add to logger
    logger.addHandler(handler)

    # Prevent propagation to avoid duplicate messages
    logger.propagate = False

    return logger


def setup_process_logging() -> logging.Logger:
    """
    Setup logging for a child process.

    Child processes inherit logger configuration but should
    explicitly call this to ensure proper setup.

    Returns:
        Configured logger instance
    """
    # Clear any inherited handlers
    logger = logging.getLogger()
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Get fresh logger
    return get_logger(__name__)


def log_separator(logger: logging.Logger, char: str = "=", length: int = 80) -> None:
    """
    Log a visual separator line.

    Useful for improving readability in console output.

    Args:
        logger: Logger instance
        char: Character to use for separator
        length: Length of separator line
    """
    logger.info(char * length)


def log_section(logger: logging.Logger, title: str) -> None:
    """
    Log a section header.

    Args:
        logger: Logger instance
        title: Section title
    """
    log_separator(logger)
    logger.info(f"  {title}")
    log_separator(logger)
