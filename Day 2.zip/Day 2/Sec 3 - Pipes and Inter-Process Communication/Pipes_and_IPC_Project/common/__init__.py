"""Common utilities for Pipes and IPC project."""

from .logger import get_logger, setup_process_logging, log_separator, log_section
from .configuration import (
    PROJECT_ROOT,
    FIFO_PATH,
    DEFAULT_TIMEOUT,
    SAMPLE_ORDERS,
)
from .utilities import (
    clean_fifo,
    ensure_fifo,
    validate_order,
    format_order_for_display,
)
from .timer import timer, PerformanceMetrics

__all__ = [
    "get_logger",
    "setup_process_logging",
    "log_separator",
    "log_section",
    "PROJECT_ROOT",
    "FIFO_PATH",
    "DEFAULT_TIMEOUT",
    "SAMPLE_ORDERS",
    "clean_fifo",
    "ensure_fifo",
    "validate_order",
    "format_order_for_display",
    "timer",
    "PerformanceMetrics",
]
