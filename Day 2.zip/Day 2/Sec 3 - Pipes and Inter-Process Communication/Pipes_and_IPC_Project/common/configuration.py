"""
Configuration and constants for IPC examples.

This module centralizes all configuration values used across the project.
Enables consistent behavior and easy testing/customization.
"""

import os
from pathlib import Path
from typing import Final

# ============================================================================
# PATHS
# ============================================================================

PROJECT_ROOT: Final[Path] = Path(__file__).parent.parent
TEMP_DIR: Final[Path] = Path(os.environ.get("TMPDIR", "/tmp"))
DATA_DIR: Final[Path] = PROJECT_ROOT / "data"

# ============================================================================
# FIFO CONFIGURATION
# ============================================================================

FIFO_BASE_NAME: Final[str] = "fifo_ipc"
FIFO_PATH: Final[Path] = TEMP_DIR / f"{FIFO_BASE_NAME}.pipe"
FIFO_WRITER_PATH: Final[Path] = TEMP_DIR / f"{FIFO_BASE_NAME}_writer.pipe"
FIFO_READER_PATH: Final[Path] = TEMP_DIR / f"{FIFO_BASE_NAME}_reader.pipe"

# ============================================================================
# COMMUNICATION CONFIGURATION
# ============================================================================

# Default timeout for blocking operations (seconds)
DEFAULT_TIMEOUT: Final[float] = 5.0

# Message buffer size for FIFO (bytes)
FIFO_BUFFER_SIZE: Final[int] = 4096

# Maximum wait time before considering process hung (seconds)
PROCESS_TIMEOUT: Final[float] = 10.0

# Number of test messages to send/receive
DEFAULT_MESSAGE_COUNT: Final[int] = 5

# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================

LOG_FORMAT: Final[str] = (
    "%(asctime)s | %(processName)-12s | %(levelname)-8s | %(message)s"
)

LOG_DATE_FORMAT: Final[str] = "%Y-%m-%d %H:%M:%S"

LOG_LEVEL: Final[str] = "INFO"

# ============================================================================
# DATA CONFIGURATION
# ============================================================================

# Sample order data for demonstrations
SAMPLE_ORDERS = [
    {
        "order_id": "ORD-2024-001",
        "customer": "Acme Corp",
        "amount": 15000.00,
        "items": ["Widget", "Gadget"],
        "status": "pending",
    },
    {
        "order_id": "ORD-2024-002",
        "customer": "TechStart Inc",
        "amount": 25500.50,
        "items": ["Server", "License"],
        "status": "pending",
    },
    {
        "order_id": "ORD-2024-003",
        "customer": "Global Services",
        "amount": 42000.00,
        "items": ["Consulting", "Support"],
        "status": "pending",
    },
]

# Sample transaction data for demonstrations
SAMPLE_TRANSACTIONS = [
    {"id": "TXN-001", "type": "debit", "amount": 1000.00},
    {"id": "TXN-002", "type": "credit", "amount": 2500.00},
    {"id": "TXN-003", "type": "debit", "amount": 500.00},
]

# ============================================================================
# PERFORMANCE CONFIGURATION
# ============================================================================

# Delay between messages (seconds) – simulates processing time
MESSAGE_DELAY: Final[float] = 0.1

# Delay to simulate work (seconds)
WORK_DELAY: Final[float] = 0.5

# ============================================================================
# SYSTEM INFORMATION
# ============================================================================

PLATFORM_INFO = {
    "supports_fifo": os.name == "posix",  # Unix-like systems
    "supports_windows_named_pipes": os.name == "nt",  # Windows
}

# ============================================================================
# VALIDATION RULES
# ============================================================================

# Minimum and maximum message sizes
MIN_MESSAGE_SIZE: Final[int] = 1
MAX_MESSAGE_SIZE: Final[int] = 10 * 1024 * 1024  # 10MB

# Valid order statuses
VALID_ORDER_STATUSES: Final[tuple] = (
    "pending",
    "validated",
    "processing",
    "completed",
    "failed",
)

# Valid claim statuses
VALID_CLAIM_STATUSES: Final[tuple] = (
    "submitted",
    "validated",
    "approved",
    "rejected",
    "paid",
)
