"""
###############################################################################
LAB 01 – Order Processing System with Multiprocessing Pipes
###############################################################################

OBJECTIVES:
1. Build a multi-process order processing system
2. Demonstrate parent-child communication
3. Implement producer-consumer pattern
4. Practice pipe lifecycle management
5. Create a real-world scenario

REQUIREMENTS:
• Order generator process
• Order validator process
• Order reporter process
• Pipe communication between stages
• Summary report generation
• Error handling

BUSINESS SCENARIO:
Company: OrderFlow Processing
System: Real-time order processing with parallel validation and reporting
"""

import logging
import multiprocessing as mp
import time
from datetime import datetime
from typing import Dict, Any, List
from dataclasses import dataclass

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section, log_separator
from common.configuration import SAMPLE_ORDERS


@dataclass
class Order:
    """Order object."""

    order_id: str
    customer: str
    amount: float
    items: int
    status: str = "pending"
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()


def order_generator(pipe_send, num_orders: int) -> None:
    """
    Generate orders and send to validator.

    Args:
        pipe_send: Send pipe to validator
        num_orders: Number of orders to generate
    """
    logger = get_logger(__name__)
    logger.info(f"[GENERATOR] Starting - will generate {num_orders} orders")

    for i in range(1, num_orders + 1):
        # Create order
        order = Order(
            order_id=f"ORD-{i:05d}",
            customer=f"Customer-{i % 10}",
            amount=100 * i + (i * 50),  # Varying amounts
            items=(i % 5) + 1,
            timestamp=datetime.now().isoformat(),
        )

        logger.info(f"[GENERATOR] Generated: {order.order_id} - ${order.amount:.2f}")

        # Send to validator
        pipe_send.send(order)
        time.sleep(0.2)  # Simulate generation time

    pipe_send.close()
    logger.info("[GENERATOR] Complete")


def order_validator(pipe_recv, pipe_send) -> None:
    """
    Validate orders and pass to reporter.

    Args:
        pipe_recv: Receive pipe from generator
        pipe_send: Send pipe to reporter
    """
    logger = get_logger(__name__)
    logger.info("[VALIDATOR] Started")

    validated = 0
    rejected = 0

    try:
        while True:
            # Receive order from generator
            order = pipe_recv.recv()

            # Validate
            is_valid = order.amount > 0 and order.items > 0

            if is_valid:
                order.status = "validated"
                validated += 1
                logger.info(f"[VALIDATOR] ✓ Validated {order.order_id}")
            else:
                order.status = "rejected"
                rejected += 1
                logger.info(f"[VALIDATOR] ✗ Rejected {order.order_id}")

            # Send to reporter
            pipe_send.send(order)
            time.sleep(0.15)  # Simulate validation time

    except EOFError:
        logger.info(f"[VALIDATOR] Complete: {validated} valid, {rejected} rejected")
    finally:
        pipe_recv.close()
        pipe_send.close()


def order_reporter(pipe_recv, results: List) -> None:
    """
    Receive orders and compile report.

    Args:
        pipe_recv: Receive pipe from validator
        results: Shared list to store results
    """
    logger = get_logger(__name__)
    logger.info("[REPORTER] Started")

    processed = 0
    total_revenue = 0

    try:
        while True:
            # Receive order from validator
            order = pipe_recv.recv()

            results.append(
                {
                    "order_id": order.order_id,
                    "customer": order.customer,
                    "amount": order.amount,
                    "status": order.status,
                }
            )

            if order.status == "validated":
                total_revenue += order.amount
                logger.info(f"[REPORTER] Reported: {order.order_id} - ${order.amount:.2f}")

            processed += 1
            time.sleep(0.1)  # Simulate reporting time

    except EOFError:
        logger.info(f"[REPORTER] Complete: Processed {processed}, Revenue ${total_revenue:.2f}")
    finally:
        pipe_recv.close()


def run_order_processing_system() -> None:
    """Main function to run the order processing system."""
    logger = get_logger(__name__)

    log_section(logger, "Order Processing System with Pipes")

    logger.info("\nArchitecture:")
    logger.info("""
    Generator ──Pipe1──> Validator ──Pipe2──> Reporter
    (create)              (validate)           (summary)
    """)

    logger.info("\nInitialization:")
    logger.info("─" * 70)

    # Create pipes
    gen_val_pipe_1, gen_val_pipe_2 = mp.Pipe()
    val_rep_pipe_1, val_rep_pipe_2 = mp.Pipe()

    logger.info("✓ Pipe 1: Generator → Validator")
    logger.info("✓ Pipe 2: Validator → Reporter\n")

    # Shared results list
    with mp.Manager() as manager:
        results = manager.list()

        # Create processes
        num_orders = 5

        generator = mp.Process(
            target=order_generator,
            args=(gen_val_pipe_1, num_orders),
            name="OrderGenerator",
        )

        validator = mp.Process(
            target=order_validator,
            args=(gen_val_pipe_2, val_rep_pipe_1),
            name="OrderValidator",
        )

        reporter = mp.Process(
            target=order_reporter,
            args=(val_rep_pipe_2, results),
            name="OrderReporter",
        )

        logger.info("Processes Created:")
        logger.info("─" * 70)
        logger.info("✓ OrderGenerator")
        logger.info("✓ OrderValidator")
        logger.info("✓ OrderReporter\n")

        # Start all processes
        logger.info("Starting Processes:")
        logger.info("─" * 70)

        generator.start()
        validator.start()
        reporter.start()

        logger.info("✓ All processes started")
        logger.info("✓ Execution running in parallel\n")

        # Wait for completion
        generator.join()
        validator.join()
        reporter.join()

        logger.info("\nProcesses Complete:")
        logger.info("─" * 70)
        logger.info("✓ Generator finished")
        logger.info("✓ Validator finished")
        logger.info("✓ Reporter finished\n")

        # Cleanup pipes
        if not gen_val_pipe_1.closed:
            gen_val_pipe_1.close()
        if not gen_val_pipe_2.closed:
            gen_val_pipe_2.close()
        if not val_rep_pipe_1.closed:
            val_rep_pipe_1.close()
        if not val_rep_pipe_2.closed:
            val_rep_pipe_2.close()

        # Generate summary report
        log_section(logger, "Order Processing Summary")

        results_list = list(results)
        validated = sum(1 for r in results_list if r["status"] == "validated")
        rejected = sum(1 for r in results_list if r["status"] == "rejected")
        total_revenue = sum(
            r["amount"] for r in results_list if r["status"] == "validated"
        )
        avg_order = total_revenue / validated if validated > 0 else 0

        logger.info(f"\nTotal Orders Processed: {len(results_list)}")
        logger.info(f"Validated Orders:      {validated}")
        logger.info(f"Rejected Orders:       {rejected}")
        logger.info(f"Total Revenue:         ${total_revenue:.2f}")
        logger.info(f"Average Order Value:   ${avg_order:.2f}\n")

        # Show details
        logger.info("Order Details:")
        logger.info("─" * 70)
        for result in results_list[:10]:  # Show first 10
            status_icon = "✓" if result["status"] == "validated" else "✗"
            logger.info(
                f"{status_icon} {result['order_id']}: {result['customer']} - "
                f"${result['amount']:.2f}"
            )

        logger.info("\n✓ Order processing complete")


def main() -> None:
    """Entry point."""
    run_order_processing_system()


# ============================================================================
# EXERCISE REQUIREMENTS
# ============================================================================
"""
1. BASIC (Provided - already working)
   ✓ Generator creates orders
   ✓ Validator validates
   ✓ Reporter collects results

2. ENHANCEMENT 1: Add discount logic
   - Orders over $500 get 10% discount
   - Validator applies discount before sending

3. ENHANCEMENT 2: Add error handling
   - Handle invalid orders gracefully
   - Log errors but continue processing
   - Count errors in summary

4. ENHANCEMENT 3: Add metrics
   - Track processing time per stage
   - Report average latency
   - Report throughput (orders/second)

5. CHALLENGE: Add a fourth stage
   - Add "Storage" process between Validator and Reporter
   - Storage "saves" orders to list
   - Add fourth pipe for communication
   - Update all process calls

HINTS:
- Use time.time() for metrics
- Use dataclass fields for tracking
- Add timing logging
- Use more processes = more parallelism
"""

# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
================================================================================
  Order Processing System with Pipes
================================================================================

Architecture:
Generator ──Pipe1──> Validator ──Pipe2──> Reporter
(create)              (validate)           (summary)

Initialization:
────────────────────────────────────────────────────────────────────────────
✓ Pipe 1: Generator → Validator
✓ Pipe 2: Validator → Reporter

Processes Created:
✓ OrderGenerator
✓ OrderValidator
✓ OrderReporter

Starting Processes:
✓ All processes started
✓ Execution running in parallel

[Process messages showing parallel execution]

================================================================================
  Order Processing Summary
================================================================================

Total Orders Processed: 5
Validated Orders:      5
Rejected Orders:       0
Total Revenue:         $3250.00
Average Order Value:   $650.00

Order Details:
✓ ORD-00001: Customer-1 - $150.00
✓ ORD-00002: Customer-2 - $300.00
✓ ORD-00003: Customer-3 - $450.00
✓ ORD-00004: Customer-4 - $600.00
✓ ORD-00005: Customer-5 - $750.00

✓ Order processing complete
"""

if __name__ == "__main__":
    main()
