"""
Hands-on Labs for Pipes and IPC

This package contains practical exercises that build complete systems:

Lab 01 - Order Processing System
  Demonstrates: Parent-child pipes, multi-stage pipeline, parallel processing
  Skills: Creating pipes, spawning processes, coordinating work
  Time: 30-45 minutes

Lab 02 - Pipe Chat Application
  Demonstrates: Bidirectional pipes, request-response, conversation logging
  Skills: Duplex communication, protocol design, graceful shutdown
  Time: 30-45 minutes

Lab 03 - FIFO Logger (Linux/macOS only)
  Demonstrates: Named pipes, continuous monitoring, log aggregation
  Skills: FIFO creation, blocking behavior, cleanup handling
  Time: 30-45 minutes

How to use these labs:

1. Read the requirements and scenario
2. Study the provided code
3. Run the example: python3 lab01_process_communication.py
4. Complete the enhancements (marked in code)
5. Try the challenges
6. Modify and experiment

Expected outcomes:
- Understand multi-process communication
- Build real systems with pipes
- Handle errors and edge cases
- Design protocols for IPC
- Apply patterns to your own code
"""
