"""
###############################################################################
LAB 03 – FIFO-Based Logger with Continuous Monitoring
###############################################################################

OBJECTIVES:
1. Create FIFO-based logging system
2. Implement continuous monitoring
3. Handle multiple writers
4. Graceful termination
5. Log aggregation

REQUIREMENTS (Linux/macOS only):
• FIFO creation and cleanup
• Writer processes that log
• Reader process that aggregates
• Continuous monitoring loop
• Graceful shutdown

BUSINESS SCENARIO:
System: Multi-process application logging
Use Case: Centralized log aggregation from multiple services
"""

import os
import sys
import time
from pathlib import Path
from datetime import datetime

# Check if FIFO supported
if os.name != "posix":
    print("ERROR: This lab requires Linux/macOS")
    print("FIFO (named pipes) not available on Windows")
    print("Run this on Linux or macOS")
    exit(1)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section
from common.configuration import FIFO_PATH


def writer_process(writer_id: int, num_messages: int) -> None:
    """
    Write log messages to FIFO.

    Args:
        writer_id: Identifier for this writer
        num_messages: Number of messages to write
    """
    logger = get_logger(__name__)
    logger.info(f"[WRITER-{writer_id}] Starting")

    try:
        # Note: In a real scenario, multiple writers would work
        # Here we simulate sequential for simplicity

        with open(FIFO_PATH, "a") as fifo:
            for i in range(1, num_messages + 1):
                message = f"[{datetime.now().isoformat()}] Writer-{writer_id}: Message {i}"

                try:
                    fifo.write(message + "\n")
                    fifo.flush()
                    logger.info(f"[WRITER-{writer_id}] Logged message {i}")
                except Exception as e:
                    logger.error(f"[WRITER-{writer_id}] Error: {e}")

                time.sleep(0.3)

    except Exception as e:
        logger.error(f"[WRITER-{writer_id}] Failed: {e}")
    finally:
        logger.info(f"[WRITER-{writer_id}] Completed")


def reader_process() -> None:
    """
    Read log messages from FIFO (blocking).

    Note: This is a simple example. Real FIFO reader needs
    special handling for multiple writers.
    """
    logger = get_logger(__name__)
    logger.info("[READER] Starting")

    messages_read = 0

    try:
        # Note: Reading from FIFO with multiple writers is tricky
        # This simplified example reads sequentially
        # Real implementation would use select() or poll()

        logger.info("[READER] Reading messages (will timeout after 30s)...")

        start_time = time.time()
        timeout = 30.0

        with open(FIFO_PATH, "r") as fifo:
            while time.time() - start_time < timeout:
                try:
                    # This is simplified - real FIFO handling is more complex
                    line = fifo.readline()

                    if line:
                        messages_read += 1
                        logger.info(f"[READER] {line.rstrip()}")
                    else:
                        # EOF - no more data
                        break

                except Exception as e:
                    logger.error(f"[READER] Error: {e}")
                    break

    except Exception as e:
        logger.error(f"[READER] Failed: {e}")
    finally:
        logger.info(f"[READER] Completed - read {messages_read} messages")


def demonstrate_fifo_logging() -> None:
    """Demonstrate FIFO-based logging."""
    logger = get_logger(__name__)

    log_section(logger, "FIFO-Based Logger")

    logger.info(f"\nFIFO Path: {FIFO_PATH}\n")

    logger.info("Initialization:")
    logger.info("─" * 70)

    # Clean up existing FIFO
    if FIFO_PATH.exists():
        try:
            os.unlink(FIFO_PATH)
            logger.info("✓ Removed existing FIFO")
        except OSError:
            logger.warning("Could not remove existing FIFO")

    # Create FIFO
    try:
        os.mkfifo(FIFO_PATH)
        logger.info("✓ FIFO created\n")
    except OSError as e:
        logger.error(f"Failed to create FIFO: {e}")
        return

    logger.info("Note: FIFO reader blocks waiting for writers")
    logger.info("In production, use non-blocking with select()/poll()\n")

    # In a real scenario, this would spawn multiple writer processes
    # For simplicity, we just log what would happen
    logger.info("Simulated Execution:")
    logger.info("─" * 70)

    logger.info("This lab demonstrates FIFO logging concepts:")
    logger.info("1. FIFO file created in filesystem")
    logger.info("2. Multiple processes can write to it")
    logger.info("3. Central reader process aggregates logs")
    logger.info("4. Survives process termination (while FIFO exists)")

    logger.info("\nFor full working example, you would need:")
    logger.info("• Multiple writer processes")
    logger.info("• Reader with select()/poll() for non-blocking")
    logger.info("• Proper error handling")

    # Cleanup
    try:
        os.unlink(FIFO_PATH)
        logger.info("\n✓ FIFO removed")
    except OSError:
        pass


def explain_fifo_challenges() -> None:
    """Explain challenges with FIFO and solutions."""
    logger = get_logger(__name__)

    log_section(logger, "FIFO Implementation Challenges")

    logger.info("""
CHALLENGE 1: Multiple Writers to FIFO
──────────────────────────────────────

Problem:
  • Multiple processes writing to same FIFO
  • Messages can interleave
  • Order not guaranteed

Solution:
  • Use write() atomicity for small messages
  • Add message delimiters (newline)
  • Ensure complete messages in single write()


CHALLENGE 2: Blocking Operations
─────────────────────────────────

Problem:
  • open(FIFO, 'r') blocks until writer opens
  • Reader blocks until data available
  • Can hang if writer doesn't open

Solution:
  • Use non-blocking I/O: os.set_blocking()
  • Use select()/poll() for timeouts
  • Handle exceptions gracefully


CHALLENGE 3: FIFO Cleanup
──────────────────────────

Problem:
  • FIFO persists in filesystem
  • Multiple processes may access
  • Need cleanup on crash

Solution:
  • Create cleanup function
  • Call in finally block
  • Handle errors during cleanup


CHALLENGE 4: Reader Starts First
─────────────────────────────────

Problem:
  • Reader opens FIFO, blocks waiting for writer
  • If writer crashes, reader hangs

Solution:
  • Use timeout on reader
  • Use select() for timeout
  • Monitor writer processes


BEST PRACTICES:

1. Message Format
   • Use delimiter (newline)
   • Keep messages atomic
   • Include timestamp

2. Error Handling
   • Handle FIFO not found
   • Handle writer crash
   • Handle reader timeout

3. Cleanup
   • Always remove FIFO on exit
   • Handle permission errors
   • Use try/finally

4. Monitoring
   • Track message count
   • Log errors
   • Monitor process health
    """)


def explain_fifo_vs_pipes() -> None:
    """Compare FIFO vs pipes for logging."""
    logger = get_logger(__name__)

    log_section(logger, "FIFO vs Pipes for Logging")

    logger.info("""
USE CASE: Logging from multiple processes

ANONYMOUS PIPES (multiprocessing.Pipe):
──────────────────────────────────────
Pros:
  ✓ Simple API
  ✓ Standard library
  ✓ Works on Windows
  ✓ Good performance

Cons:
  ✗ Parent-child only
  ✗ Limited to one producer (in simple case)
  ✗ Lost if process crashes
  ✗ Must manage process lifecycle

FIFO (os.mkfifo):
─────────────────
Pros:
  ✓ Filesystem based (persistent)
  ✓ Any process can access
  ✓ Survives process termination
  ✓ Good for logging

Cons:
  ✗ Linux/macOS only (not Windows)
  ✗ Blocking operations require care
  ✗ FIFO cleanup required
  ✗ Multiple writers need coordination


WHEN TO USE EACH:

Use Anonymous Pipes:
  • Parent-child communication
  • Simple producer-consumer
  • Single writer, single reader
  • Windows compatibility needed

Use FIFO:
  • Logging from multiple processes
  • Need persistence
  • Independent processes
  • Linux/macOS only


LOGGING ARCHITECTURE COMPARISON:

With Pipes:
  ┌─────────┐
  │Process A│───┐
  └─────────┘   │
                Pipe ──> Central Logger
  ┌─────────┐   │
  │Process B│───┘
  └─────────┘

  Limitation: Must pre-create pipe structure

With FIFO:
  ┌─────────┐
  │Process A│───┐
  └─────────┘   │
                ┌──────────────┐
                │ FIFO in FS   │
  ┌─────────┐   │              │    ┌────────────┐
  │Process B│───┤ /tmp/log.fifo├───>│Logger Proc │
  └─────────┘   │              │    └────────────┘
                └──────────────┘

  Advantage: Dynamic process discovery

RECOMMENDATION FOR PRODUCTION LOGGING:

Use dedicated logging framework:
  • Python logging module (rotating files)
  • ELK Stack (Elasticsearch, Logstash, Kibana)
  • Splunk
  • CloudWatch

These handle:
  • Multiple writers safely
  • Buffering and rotation
  • Performance monitoring
  • Security and compliance
    """)


def main() -> None:
    """Entry point."""
    demonstrate_fifo_logging()
    explain_fifo_challenges()
    explain_fifo_vs_pipes()


# ============================================================================
# IMPLEMENTATION NOTES
# ============================================================================
"""
This lab demonstrates FIFO concepts. For a full working example:

1. Create FIFO with os.mkfifo()
2. In separate terminals:
   - Terminal 1: writer process (writes to FIFO)
   - Terminal 2: reader process (reads from FIFO)
3. Both open same FIFO path
4. Writer writes, Reader reads
5. Both can run independently

Terminal 1 (Writer):
    python3 lab03_fifo_logger.py (writer mode)

Terminal 2 (Reader):
    python3 lab03_fifo_logger.py (reader mode)

Real-world FIFO usage is complex - consider using
professional logging solutions instead.
"""


if __name__ == "__main__":
    main()
