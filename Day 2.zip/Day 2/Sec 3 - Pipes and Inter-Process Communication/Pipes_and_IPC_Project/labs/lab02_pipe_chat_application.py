"""
###############################################################################
LAB 02 – Pipe-Based Chat Application
###############################################################################

OBJECTIVES:
1. Implement bidirectional pipe communication
2. Handle request-response patterns
3. Manage multiple exchanges between processes
4. Implement graceful shutdown
5. Log conversation history

REQUIREMENTS:
• Server process with receive and send
• Client process with send and receive
• Bidirectional communication
• Conversation logging
• Graceful termination
• Message formatting

BUSINESS SCENARIO:
System: Customer service chat simulation
Shows: Real-time bidirectional IPC communication
"""

import logging
import multiprocessing as mp
import time
from datetime import datetime
from typing import Dict, Any

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.logger import get_logger, log_section


def server_process(server_conn) -> None:
    """
    Server that receives messages and responds.

    Args:
        server_conn: Duplex pipe connection
    """
    logger = get_logger(__name__)
    logger.info("[SERVER] Started and listening")

    responses = {
        "hello": "Hello! How can I help you?",
        "status": "System is running normally",
        "help": "Type: hello, status, help, or quit",
        "quit": "Goodbye!",
    }

    message_count = 0

    try:
        while True:
            # Receive message from client
            message = server_conn.recv()
            message_count += 1

            logger.info(f"[SERVER] Received: {message}")

            # Prepare response
            command = message.lower().strip()

            if command == "quit":
                response = responses.get(command, "Unknown command")
                server_conn.send(response)
                logger.info("[SERVER] Closing connection")
                break

            response = responses.get(command, "I don't understand. Try 'help'")

            # Send response back
            server_conn.send(response)
            logger.info(f"[SERVER] Sent: {response}")

            time.sleep(0.1)

    except EOFError:
        logger.info("[SERVER] Connection closed by client")
    except Exception as e:
        logger.error(f"[SERVER] Error: {e}")
    finally:
        server_conn.close()
        logger.info(f"[SERVER] Closed after {message_count} messages")


def client_process(client_conn, messages: list) -> None:
    """
    Client that sends messages and receives responses.

    Args:
        client_conn: Duplex pipe connection
        messages: List of messages to send
    """
    logger = get_logger(__name__)
    logger.info("[CLIENT] Connected to server")

    try:
        for msg in messages:
            logger.info(f"[CLIENT] Sending: {msg}")
            client_conn.send(msg)

            # Receive response
            response = client_conn.recv()
            logger.info(f"[CLIENT] Received: {response}")

            time.sleep(0.2)

    except Exception as e:
        logger.error(f"[CLIENT] Error: {e}")
    finally:
        client_conn.close()
        logger.info("[CLIENT] Disconnected")


def run_chat_application() -> None:
    """Run the chat application."""
    logger = get_logger(__name__)

    log_section(logger, "Pipe-Based Chat Application")

    logger.info("\nArchitecture:")
    logger.info("""
    ┌──────────┐                ┌──────────┐
    │ CLIENT   │───────────────>│ SERVER   │
    │ Process  │<───────────────│ Process  │
    └──────────┘    Duplex Pipe └──────────┘

    Request-Response Communication
    """)

    logger.info("\nInitialization:")
    logger.info("─" * 70)

    # Create duplex pipe
    server_conn, client_conn = mp.Pipe()
    logger.info("✓ Duplex pipe created\n")

    # Messages for client to send
    client_messages = [
        "hello",
        "status",
        "hello again",
        "help",
        "quit",
    ]

    logger.info("Starting Communication:")
    logger.info("─" * 70)

    # Create and start processes
    server = mp.Process(
        target=server_process,
        args=(server_conn,),
        name="ChatServer",
    )

    client = mp.Process(
        target=client_process,
        args=(client_conn, client_messages),
        name="ChatClient",
    )

    server.start()
    client.start()

    logger.info("✓ Server started")
    logger.info("✓ Client started")
    logger.info("✓ Communication beginning\n")

    # Wait for completion
    client.join()
    server.join()

    logger.info("\nConversation Complete:")
    logger.info("─" * 70)
    logger.info("✓ Both processes finished")

    log_section(logger, "Conversation Summary")

    logger.info("\nMessages Exchanged:")
    logger.info("  CLIENT → SERVER → CLIENT")
    for i, msg in enumerate(client_messages, 1):
        logger.info(f"  {i}. '{msg}'")

    logger.info(f"\nTotal exchanges: {len(client_messages)}")
    logger.info("✓ Chat session complete")


def demonstrate_conversation_logging() -> None:
    """Show how to log conversations."""
    logger = get_logger(__name__)

    log_section(logger, "Conversation Logging Pattern")

    logger.info("""
LOGGING CONVERSATION BETWEEN PROCESSES:

1. Log on send:
   logger.info(f"[CLIENT] Sending: {message}")
   conn.send(message)

2. Log on receive:
   response = conn.recv()
   logger.info(f"[CLIENT] Received: {response}")

3. Store messages for later analysis:
   messages = []
   messages.append({
       "timestamp": datetime.now(),
       "sender": "client",
       "message": msg
   })

4. Format for display:
   for entry in messages:
       print(f"{entry['timestamp']} [{entry['sender']}]: {entry['message']}")

EXAMPLE OUTPUT:

2024-01-15 10:30:45 [CLIENT]: hello
2024-01-15 10:30:45 [SERVER]: Hello! How can I help you?
2024-01-15 10:30:46 [CLIENT]: status
2024-01-15 10:30:46 [SERVER]: System is running normally
2024-01-15 10:30:47 [CLIENT]: quit
2024-01-15 10:30:47 [SERVER]: Goodbye!

BENEFITS:
• Audit trail
• Debugging
• Performance analysis
• Compliance logging
    """)


def demonstrate_protocol_design() -> None:
    """Show protocol design for pipe communication."""
    logger = get_logger(__name__)

    log_section(logger, "Protocol Design for Pipe Communication")

    logger.info("""
SIMPLE REQUEST-RESPONSE PROTOCOL:

Format:
  Client sends: "COMMAND [args]"
  Server sends: "RESPONSE"

Example:
  GET_ORDER 123      → GET_ORDER_RESPONSE {data}
  CREATE_ORDER       → CREATED {id}
  ERROR              → ERROR_UNKNOWN_COMMAND

STRUCTURED PROTOCOL (Dict):

Format:
  Client sends: {"type": "request", "command": "...", "args": {...}}
  Server sends: {"type": "response", "status": "ok", "data": {...}}

Example:
  {"type": "request", "command": "get_order", "id": "ORD-123"}
  {"type": "response", "status": "ok", "data": {...}}

STREAMING PROTOCOL:

Format:
  Multiple exchanges before termination
  "START" → Setup
  "DATA ..." → Streaming
  "END" → Cleanup

Example:
  Client: "STREAM_ORDERS"
  Server: "ORDERS_STARTING"
  Server: "ORDER1_DATA"
  Server: "ORDER2_DATA"
  Server: "STREAM_END"

PROTOCOL DESIGN BEST PRACTICES:

1. Make it explicit
   • Clear message types
   • Defined fields
   • Version info

2. Handle errors
   • Error codes
   • Error messages
   • Recovery steps

3. Make it testable
   • Simple format (strings or JSON)
   • No binary data (if possible)
   • Timestamps for debugging

4. Document it
   • Message types
   • Field meanings
   • Examples
    """)


def main() -> None:
    """Entry point."""
    run_chat_application()
    demonstrate_conversation_logging()
    demonstrate_protocol_design()


# ============================================================================
# EXERCISE REQUIREMENTS
# ============================================================================
"""
1. BASIC (Provided - working)
   ✓ Duplex pipe created
   ✓ Client sends messages
   ✓ Server responds
   ✓ Graceful shutdown

2. ENHANCEMENT 1: Add commands
   - Add "time" command (server returns current time)
   - Add "echo WORD" command (echo back word)
   - Add "calc A+B" command (return result)

3. ENHANCEMENT 2: Structured messages
   - Use dictionaries instead of strings
   - Format: {"type": "request", "command": "..."}
   - Server responds: {"type": "response", "status": "ok", "data": "..."}

4. ENHANCEMENT 3: Conversation history
   - Track all messages
   - Log to file at end
   - Show summary

5. CHALLENGE: Multiple clients
   - Main process manages multiple client-server pairs
   - Each pair in separate processes
   - Aggregate responses

HINTS:
- Use dictionaries for structured messages
- Use datetime for timestamps
- Add message validation
- Store messages in list
"""

# ============================================================================
# KEY CONCEPTS DEMONSTRATED
# ============================================================================
"""
1. Bidirectional Communication
   - Both processes send and receive
   - Single pipe for both directions
   - Careful sequencing important

2. Request-Response Pattern
   - Client sends request
   - Server processes
   - Server sends response
   - Client receives

3. Graceful Termination
   - Special message to signal end
   - Process closes cleanly
   - No hanging processes

4. Logging Communication
   - Track send/receive
   - Timestamp messages
   - Store for analysis

5. Protocol Design
   - Define message format
   - Handle errors
   - Document clearly
"""


if __name__ == "__main__":
    main()
