# Quick Start Guide – Pipes & IPC Project

Get started in 5 minutes! 🚀

## Prerequisites

- Python 3.12 or higher installed
- Terminal/Command Prompt access
- 10 MB disk space

## Step 1: Verify Python Version

```bash
python3 --version
# Output should be: Python 3.12.0 or higher
```

If you need Python 3.12:
- **macOS**: `brew install python@3.12`
- **Linux**: `apt-get install python3.12` or `yum install python3.12`
- **Windows**: Download from python.org

## Step 2: Navigate to Project

```bash
cd Pipes_and_IPC_Project
ls -la  # Verify files exist
```

You should see:
- `README.md`
- `src/` directory
- `labs/` directory
- `common/` directory

## Step 3: Run Your First Example

### Option A: Introduction (Recommended for beginners)
```bash
python3 src/01_intro_to_ipc.py
```

**What you'll see**:
- Explanation of IPC concepts
- ASCII diagrams showing problem and solution
- Overview of different IPC methods
- Best practices summary

**Time**: 2 minutes

### Option B: Simple Pipe (Hands-on)
```bash
python3 src/04_simple_pipe.py
```

**What you'll see**:
- Two processes running in parallel
- Generator creating invoices
- Validator checking invoices
- Pipe communication between them
- Summary report

**Time**: 3 seconds

### Option C: Order Processing Lab (Full Example)
```bash
python3 labs/lab01_process_communication.py
```

**What you'll see**:
- Multi-stage pipeline (3 processes)
- Parallel order processing
- Final summary with statistics
- Real-world scenario

**Time**: 2 seconds

## Step 4: Explore More Examples

### Recommended Path (30 minutes)

1. **Understand Concepts** (5 min)
   ```bash
   python3 src/01_intro_to_ipc.py
   ```

2. **See Benefits** (5 min)
   ```bash
   python3 src/02_why_pipes.py
   ```

3. **Learn Architecture** (5 min)
   ```bash
   python3 src/03_pipe_architecture_demo.py
   ```

4. **First Hands-on** (5 min)
   ```bash
   python3 src/04_simple_pipe.py
   ```

5. **Do First Lab** (5 min)
   ```bash
   python3 labs/lab01_process_communication.py
   ```

## Step 5: Try Your First Modification

Edit `labs/lab01_process_communication.py`:

Find this line:
```python
num_orders = 5
```

Change to:
```python
num_orders = 10
```

Run again:
```bash
python3 labs/lab01_process_communication.py
```

**Observe**: Now processing 10 orders instead of 5!

## Step 6: Read the Documentation

For deeper understanding:

- **Full Guide**: `README.md` (comprehensive, 2000+ lines)
- **Project Map**: `PROJECT_SUMMARY.md` (curriculum and structure)
- **Each Module**: Read docstring at top of Python file

## Common Commands

### Run specific module
```bash
python3 src/05_parent_child_pipe.py
```

### Run all examples
```bash
for file in src/0*.py; do python3 $file; done
```

### Run a lab
```bash
python3 labs/lab02_pipe_chat_application.py
```

### Check file structure
```bash
tree -L 2 .
# or
find . -type f -name "*.py" | head -20
```

## Understanding the Output

Each module prints:

1. **Title & Separator**
   ```
   ================================================================================
     Module Name
   ================================================================================
   ```

2. **Section Headers**
   ```
   SECTION 1: Description
   ────────────────────────────────────────────────────────────────────────────
   ```

3. **Process Logs** (shown by process name)
   ```
   [GENERATOR] Starting
   [PROCESSOR] Started
   [GENERATOR] Generated REC-001
   ```

4. **Summary Report**
   ```
   Total: 5 records
   Processed: 5
   Average: $100.00
   ```

## Troubleshooting

### "Python not found"
```bash
# Try python instead of python3
python src/01_intro_to_ipc.py

# Or check your Python path
which python3
/usr/bin/python3  # Should find Python 3
```

### "Module not found" error
```bash
# Make sure you're in project root
cd Pipes_and_IPC_Project
pwd  # Should end in Pipes_and_IPC_Project

# Then run
python3 src/04_simple_pipe.py
```

### "Permission denied" error
```bash
# Give execute permission
chmod +x src/*.py
python3 src/04_simple_pipe.py
```

### FIFO examples not working (Windows)
```bash
# FIFO is Linux/macOS only
# Skip 09, 10, 12 and 03 on Windows
# All other examples work fine

python3 src/04_simple_pipe.py  # Works on Windows!
```

## Next Steps

After running the quick examples:

1. **Read README.md** – Get full context
2. **Study a Module** – Dive into one topic
3. **Do a Lab** – Build something real
4. **Modify Code** – Experiment and learn
5. **Interview Prep** – Read Q&A sections

## Learning Time Estimates

| Activity | Time | Effort |
|----------|------|--------|
| Run intro | 2 min | Minimal |
| Read README | 30 min | Easy |
| Run all examples | 45 min | Watching |
| Study 1 module | 60 min | Reading |
| Do 1 lab | 60 min | Coding |
| Complete all | 80 hours | Complete |

## Quick Concepts

**Pipe**: Direct connection between two processes for sending data

**Producer**: Process that generates data

**Consumer**: Process that receives and processes data

**Parent-Child**: One process creates another

**Duplex**: Two-way communication (can send and receive)

**Blocking**: Operation waits until complete (natural synchronization)

**Serialization**: Converting Python objects to bytes for transmission

## Key Takeaways

✓ Pipes enable parallel processing
✓ Producer-consumer is fundamental pattern
✓ Blocking provides natural flow control
✓ Always close pipes to prevent leaks
✓ Serialization handles complex objects
✓ Works on Windows, Linux, macOS (except FIFO)
✓ Standard library only (no pip install needed)
✓ Production-ready patterns

## Common Mistakes to Avoid

❌ Not closing pipes (resource leak)
❌ Both processes trying to recv() (deadlock)
❌ Forgetting to close unused ends (EOF not detected)
❌ Sending non-picklable objects (crash)
❌ Not handling exceptions (hangs)
❌ Creating pipe after fork (doesn't work)

✓ Always test with small data first
✓ Add logging to debug
✓ Close unused connections
✓ Handle errors explicitly
✓ Test edge cases

## Getting Help

1. **Read the full docstring** of the module
2. **Check the README** for explanations
3. **Look at the examples** - they demonstrate patterns
4. **Read interview questions** - they explain concepts
5. **Try modifying code** - learn by doing

## Performance Note

Don't worry about performance initially. Focus on:
1. Understanding concepts
2. Writing correct code
3. Handling errors
4. Then optimize

Production optimization comes after understanding!

## File Descriptions (Quick Reference)

| File | Purpose | Focus |
|------|---------|-------|
| 01_intro_to_ipc.py | Concepts | Why IPC matters |
| 02_why_pipes.py | Benefits | Sequential vs parallel |
| 03_pipe_architecture_demo.py | Patterns | Producer-consumer |
| 04_simple_pipe.py | Basics | First pipe usage |
| 05_parent_child_pipe.py | Patterns | Work distribution |
| 06_duplex_pipe.py | Advanced | Two-way communication |
| 07_object_transfer.py | Technical | Serialization |
| 08_pipe_connection_management.py | Best practices | Resource cleanup |
| 09, 10_fifo_*.py | Linux | Named pipes |
| 11_windows_named_pipe_demo.py | Cross-platform | Windows concepts |
| 12_fifo_blocking_behavior.py | Advanced | Blocking semantics |
| 13_logging_system_pipe.py | Enterprise | Multi-process logging |
| 14_ipc_architecture_demo.py | Architecture | Complex pipeline |
| lab01_*.py | Project | Order system |
| lab02_*.py | Project | Chat application |
| lab03_*.py | Project | FIFO logger |

## You're Ready! 🎉

You have everything needed to learn pipes and IPC!

1. Run an example
2. Read the documentation
3. Study the code
4. Modify and experiment
5. Complete the labs
6. You'll master IPC!

**Remember**: Every expert started as a beginner. Keep going!

---

**Questions?** Check README.md for detailed guidance.
**Stuck?** Read the module's docstring and comments.
**Want more?** Extend the examples and build your own projects!

**Happy learning!** 🚀
