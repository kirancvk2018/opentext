# Threading Fundamentals Project

## Project Overview

This project teaches Python threading fundamentals using realistic enterprise scenarios. Each script illustrates a single threading concept with professional-quality code, extensive comments, and clear business explanations.

## Folder Structure

- `README.md`
- `requirements.txt`
- `src/`
  - `01_sequential_execution.py`
  - `02_concurrency_intro.py`
  - `03_process_vs_thread_demo.py`
  - `04_thread_lifecycle.py`
  - `05_thread_module_intro.py`
  - `06_create_thread_using__thread.py`
  - `07_multiple_threads.py`
  - `08_thread_timing_comparison.py`
  - `09_basic_locking.py`
  - `10_three_worker_threads_lab.py`
  - `11_sequential_vs_threaded_lab.py`
  - `common/`
    - `timer.py`
    - `utilities.py`
    - `logger.py`

## Learning Objectives

- Understand blocking and sequential execution behavior.
- Learn how concurrency improves responsiveness in enterprise workflows.
- Compare processes and threads for background tasks.
- Track thread lifecycle stages in a production-style workflow.
- Review the legacy `_thread` module and its role.
- Create threads with `start_new_thread()` and manage basic workers.
- Execute multiple threads safely with shared resources.
- Measure and compare execution time between sequential and threaded work.
- Apply locking to prevent race conditions.
- Practice building threaded report generation and download pipelines.

## How to Run

1. Open this folder in Visual Studio Code.
2. Use a Python 3.12+ interpreter.
3. Run an example file directly from the terminal:

```bash
python src/01_sequential_execution.py
```

## Python Version

Python 3.12 or later.

## VS Code Instructions

- Open the folder in VS Code.
- Ensure Python extension is enabled.
- Select the interpreter: `Python 3.12+`.
- Run each script in the Terminal or Debug pane.

## Expected Outputs

Each script prints a business scenario explanation, execution steps, and a final result summary. The timed examples show performance differences between sequential and threaded execution.

## Concept Map

- Sequential execution
- Concurrency basics
- Process vs thread comparison
- Thread lifecycle
- Legacy `_thread` module
- Thread creation with `start_new_thread`
- Multiple worker coordination
- Timing comparison
- Locking and race conditions
- Regional report generation lab
- Download pipeline lab

## Execution Order

1. `01_sequential_execution.py`
2. `02_concurrency_intro.py`
3. `03_process_vs_thread_demo.py`
4. `04_thread_lifecycle.py`
5. `05_thread_module_intro.py`
6. `06_create_thread_using__thread.py`
7. `07_multiple_threads.py`
8. `08_thread_timing_comparison.py`
9. `09_basic_locking.py`
10. `10_three_worker_threads_lab.py`
11. `11_sequential_vs_threaded_lab.py`

## Prerequisites

- Python 3.12+ installed.
- No third-party dependencies required.
- Basic familiarity with Python functions, I/O, and modules.
