"""Python Threading Fundamentals

Problem Statement

A sales organization must generate three regional sales reports concurrently.
Sequential report generation delays the consolidated sales review.

Business Scenario

Large enterprises often combine regional summaries from Americas, EMEA,
and APAC to produce a single executive sales dashboard.

Learning Objectives

- Build multiple worker threads for independent report generation.
- Combine partial results from separate threads.
- Practice coordinating thread completion in a realistic lab.

Solution Overview

This lab uses three worker threads for regional sales reports.
Each thread generates a region-specific report, then main code
combines the results into a consolidated summary.

Source Code
"""

from __future__ import annotations

import threading
import time
from typing import Dict

from src.common.logger import log_info, log_step
from src.common.utilities import generate_report_content, simulate_io_wait


REGIONAL_REPORTS = [
    "Americas Sales Report",
    "EMEA Sales Report",
    "APAC Sales Report",
]
SIMULATED_REGION_DELAY = 1.0


def build_regional_report(region_name: str, results: Dict[str, str]) -> None:
    """Generate a regional report and store its results."""
    log_info(f"Start regional report: {region_name}")
    simulate_io_wait(SIMULATED_REGION_DELAY)
    results[region_name] = generate_report_content(region_name, rows=4)
    log_info(f"Complete regional report: {region_name}")


def run_regional_report_threads() -> Dict[str, str]:
    """Launch worker threads to generate each regional report."""
    results: Dict[str, str] = {}
    threads: list[threading.Thread] = []

    for region_name in REGIONAL_REPORTS:
        thread = threading.Thread(target=build_regional_report, args=(region_name, results), name=f"RegionalWorker-{region_name}")
        threads.append(thread)
        thread.start()
        log_info(f"Started thread for {region_name}")

    for thread in threads:
        thread.join()
        log_info(f"Joined thread: {thread.name}")

    return results


def aggregate_reports(reports: Dict[str, str]) -> str:
    """Combine regional report content into a consolidated summary."""
    sections = [f"--- {region} ---\n{content}" for region, content in reports.items()]
    return "\n\n".join(sections)


def main() -> None:
    """Execute the three worker threads lab."""
    log_step("Three Worker Threads Lab")
    log_info("Run three regional sales report generators in parallel.")

    start_time = time.perf_counter()
    regional_reports = run_regional_report_threads()
    consolidated_report = aggregate_reports(regional_reports)
    duration = time.perf_counter() - start_time

    print("\nExpected Output: Three regional reports generated concurrently.")
    print("Execution Flow: start regional threads -> wait for all -> aggregate results")
    print(f"Total Duration: {duration:.3f} seconds")
    print("Consolidated Sales Summary:\n")
    print(consolidated_report)
    print("Advantages: Faster generation and independent report production.")
    print("Limitations: Needs thread-safe result aggregation for shared containers.")
    print("When to use: Distributed report generation across regions.")
    print("When NOT to use: Sequential workflows requiring strict transaction order.")
    print("Performance Notes: The wall-clock time is close to the slowest regional task.")
    print("Best Practices: Use descriptive thread names and collect results safely.")
    print("Common Mistakes: Assuming dictionaries are always safe without locks in complex writes.")
    print("Interview Questions:")
    print("1. How do you combine partial results from multiple threads?")
    print("2. Why is the final duration close to the longest region task?")
    print("3. What shared state should you protect in this example?")
    print("4. How would you handle a failed regional report thread?")
    print("5. What changes if there are ten regions instead of three?")
    print("Hands-on Exercise: Add a supervisor thread that validates each regional report.")
    print("Challenge Exercise: Implement a thread-safe queue for result collection.")


if __name__ == "__main__":
    main()
