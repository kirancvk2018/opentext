"""Python Threading Fundamentals

Problem Statement

Legacy maintenance teams need to understand `_thread` module behavior.
Modern threading APIs abstract some of its low-level details.

Business Scenario

Older enterprise systems still use legacy modules for audit logging,
background cleanup, and compatibility layers. Understanding `_thread`
helps maintain and migrate these systems safely.

Learning Objectives

- Learn the history of the `_thread` module.
- Understand why it is considered low-level.
- Recognize when higher-level threading is recommended.

Solution Overview

This example shows how `_thread` creates a worker thread and why
`threading.Thread` is usually preferred in production code.

Source Code
"""

from __future__ import annotations

import _thread
import time

from src.common.logger import log_info, log_step
from src.common.utilities import simulate_io_wait


LOG_ENTRIES = [
    "Audit event received",
    "User permission validated",
    "Transaction record written",
]


def legacy_audit_logger(task_id: int) -> None:
    """Simulate an audit logging task using the low-level _thread module."""
    log_info(f"Legacy logger thread {task_id} started")
    for entry in LOG_ENTRIES:
        simulate_io_wait(0.4)
        log_info(f"Legacy logger recorded: {entry}")

    log_info(f"Legacy logger thread {task_id} completed")


def main() -> None:
    """Execute the _thread introduction example."""
    log_step("_thread Module Introduction")
    log_info("Start a legacy audit logger thread using _thread.start_new_thread.")

    _thread.start_new_thread(legacy_audit_logger, (1,))

    # Because _thread does not provide join, keep the main thread alive.
    time.sleep(1.6)

    print("\nExpected Output: Audit logger runs in a legacy worker thread.")
    print("Execution Flow: start -> legacy thread runs -> main waits -> complete")
    print("Advantages: Minimal dependency and fine-grained control.")
    print("Limitations: No thread join, fewer abstractions, harder error handling.")
    print("When to use: Legacy compatibility and simple background tasks.")
    print("When NOT to use: New code that needs readable, maintainable threading.")
    print("Performance Notes: Works for lightweight background helpers.")
    print("Best Practices: Use `threading.Thread` in modern enterprise applications.")
    print("Common Mistakes: Forgetting that `_thread` lacks join and exception propagation.")
    print("Interview Questions:")
    print("1. What is the `_thread` module used for?")
    print("2. Why does _thread require the main program to stay alive?")
    print("3. What makes `_thread` less suitable than `threading`?")
    print("4. How do you detect completion of a low-level thread?")
    print("5. When would legacy code still use `_thread`? ")
    print("Hands-on Exercise: Add another legacy thread instance.")
    print("Challenge Exercise: Replace `_thread` with `threading.Thread` and compare.")


if __name__ == "__main__":
    main()
