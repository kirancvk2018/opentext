"""Python Threading Fundamentals

Problem Statement

A background approval workflow moves a document through multiple stages.
Understanding thread lifecycle states helps engineers monitor and manage work.

Business Scenario

Approval workflows in procurement, insurance, and loan processing
use asynchronous steps for review, validation, and final authorization.
Tracking each thread state is vital for enterprise observability.

Learning Objectives

- Learn thread lifecycle states: new, runnable, running, waiting, terminated.
- Understand when state transitions occur in a running workflow.
- Apply lifecycle awareness to enterprise background tasks.

Solution Overview

This example creates a thread that represents an approval workflow.
Lifecycle checkpoints show transitions from thread creation to completion.

Source Code
"""

from __future__ import annotations

import threading
import time

from src.common.logger import log_info, log_step
from src.common.utilities import format_duration, simulate_io_wait


APPROVAL_STEPS = [
    "Receive request",
    "Validate documents",
    "Route to reviewer",
    "Collect approval",
    "Publish decision",
]


def approval_workflow() -> None:
    """Simulate an approval workflow run inside a worker thread."""
    log_info("Thread state: running")
    for step in APPROVAL_STEPS:
        log_info(f"Workflow task: {step}")
        simulate_io_wait(0.5)

    log_info("Approval workflow completed")


def main() -> None:
    """Execute the thread lifecycle demonstration."""
    log_step("Thread Lifecycle Example")
    log_info("Create a background thread for an approval workflow.")

    worker = threading.Thread(target=approval_workflow, name="ApprovalWorker")
    log_info("Thread state: new")

    worker.start()
    log_info("Thread state: runnable/running (scheduled)")

    while worker.is_alive():
        log_info("Thread state: running/waiting")
        time.sleep(0.3)

    log_info("Thread state: terminated")

    print("\nExpected Output: Lifecycle state changes during workflow execution.")
    print("Execution Flow: new -> start -> running/waiting -> terminated")
    print("Advantages: Observability of thread progress in workflows.")
    print("Limitations: Python does not expose state names directly; this is conceptual.")
    print("When to use: Background approval or asynchronous pipeline tasks.")
    print("When NOT to use: When you need real thread state introspection from Python runtime.")
    print("Performance Notes: State logging adds minimal overhead.")
    print("Best Practices: Track thread activity with logs for long-running operations.")
    print("Common Mistakes: Confusing thread lifecycle with process lifecycle.")
    print("Interview Questions:")
    print("1. What is the first thread state after construction?")
    print("2. How do you detect a thread is still alive?")
    print("3. Why is a thread waiting during I/O operations?")
    print("4. What does terminated mean for a Python thread?")
    print("5. How can lifecycle awareness improve troubleshooting?")
    print("Hands-on Exercise: Add additional workflow steps and log state transitions.")
    print("Challenge Exercise: Implement a supervisor thread that restarts failed workers.")


if __name__ == "__main__":
    main()
