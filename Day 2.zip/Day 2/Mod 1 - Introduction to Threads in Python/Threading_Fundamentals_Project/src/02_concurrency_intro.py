"""Python Threading Fundamentals

Problem Statement

A customer service API processes inbound requests.
Sequential handling delays responses and reduces user satisfaction.

Business Scenario

Retail and telecom systems receive many concurrent requests.
Faster request handling improves availability and customer experience.

Learning Objectives

- Understand concurrency in Python.
- Contrast sequential versus concurrent execution.
- Learn the benefits of concurrent request processing.

Solution Overview

This example processes simulated customer requests concurrently
using threads for the I/O-bound request handling stage.
The code shows how one request does not block another.

Source Code
"""

from __future__ import annotations

import threading
import time
from typing import Callable

from src.common.logger import log_info, log_step
from src.common.utilities import format_duration, simulate_io_wait


SIMULATED_REQUESTS = ["Request A", "Request B", "Request C"]
REQUEST_IO_SECONDS = 1.0


def handle_customer_request(request_id: str) -> None:
    """Simulate processing an inbound customer request.

    Args:
        request_id: Unique request identifier.
    """
    log_info(f"Begin processing {request_id}")
    simulate_io_wait(REQUEST_IO_SECONDS)
    log_info(f"Finished processing {request_id}")


def process_requests_concurrently(request_ids: list[str]) -> None:
    """Dispatch request handlers using threads."""
    threads: list[threading.Thread] = []

    for request_id in request_ids:
        thread = threading.Thread(
            target=handle_customer_request,
            args=(request_id,),
            name=f"Worker-{request_id}",
        )
        threads.append(thread)
        log_info(f"Scheduling thread for {request_id}")
        thread.start()

    for thread in threads:
        thread.join()
        log_info(f"Thread completed: {thread.name}")


def measure_concurrent_execution(action: Callable[[], None]) -> float:
    """Measure how long a concurrent workflow takes to complete."""
    start_time = time.perf_counter()
    action()
    return time.perf_counter() - start_time


def main() -> None:
    """Execute the concurrency introduction example."""
    log_step("Concurrency Introduction Example")
    log_info("A customer-facing service processes multiple requests concurrently.")

    duration = measure_concurrent_execution(lambda: process_requests_concurrently(SIMULATED_REQUESTS))

    print(f"\nExpected Output: All requests handled concurrently.")
    print(f"Execution Flow: start -> dispatch threads -> wait -> finish")
    print(f"Total Duration: {format_duration(duration)}")
    print("Advantages: Better utilization for I/O-bound workloads.")
    print("Limitations: Thread coordination and shared-state hazards.")
    print("When to use: Multiple network-bound tasks or request handlers.")
    print("When NOT to use: CPU-bound tasks with no blocking I/O.")
    print("Performance Notes: Concurrent I/O reduces overall latency.")
    print("Best Practices: Keep thread work small and avoid heavy shared state.")
    print("Common Mistakes: Starting threads without joining them.")
    print("Interview Questions:")
    print("1. What makes a workload suitable for threads?")
    print("2. How does concurrency differ from parallelism?")
    print("3. Why should threads be joined after starting?")
    print("4. What risk arises when threads share data without protection?")
    print("5. How can you measure thread-based response time improvements?")
    print("Hands-on Exercise: Add more simulated requests and compare timings.")
    print("Challenge Exercise: Introduce a shared counter and protect it with a lock.")


if __name__ == "__main__":
    main()
