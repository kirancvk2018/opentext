"""Python Threading Fundamentals

Problem Statement

A payroll system needs to run batch calculations and log status updates.
Understanding when to use processes versus threads is critical for reliability.

Business Scenario

Large enterprises process payroll in background tasks while keeping
front-end services responsive. Choosing thread or process models
affects memory use, isolation, and scaling.

Learning Objectives

- Understand the difference between processes and threads.
- Compare memory and performance characteristics.
- Learn when a background task should use a process or thread.

Solution Overview

This demo compares a thread-based workload and a process-based workload.
It highlights that threads share memory while processes provide isolation.

Source Code
"""

from __future__ import annotations

import multiprocessing
import threading
import time
from typing import Any

from src.common.logger import log_info, log_step
from src.common.utilities import simulate_io_wait


SIMULATED_BATCHES = ["Payroll A", "Payroll B"]
SIMULATED_BATCH_SECONDS = 1.1


def payroll_task(task_name: str, result_container: dict[str, int] | None = None) -> None:
    """Simulate a payroll batch calculation.

    Args:
        task_name: Name of the payroll batch.
        result_container: Shared container for threads or process-safe queue.
    """
    log_info(f"Starting payroll batch: {task_name}")
    simulate_io_wait(SIMULATED_BATCH_SECONDS)
    processed = 1000
    log_info(f"Completed payroll batch: {task_name}")
    if result_container is not None:
        result_container[task_name] = processed


def thread_based_payroll() -> dict[str, int]:
    """Run payroll work in threads sharing process memory."""
    results: dict[str, int] = {}
    threads: list[threading.Thread] = []

    for batch_name in SIMULATED_BATCHES:
        thread = threading.Thread(target=payroll_task, args=(batch_name, results), name=f"PayrollThread-{batch_name}")
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return results


def process_based_payroll() -> dict[str, int]:
    """Run payroll work in separate processes with explicit result passing."""
    with multiprocessing.Manager() as manager:
        results = manager.dict()
        processes: list[multiprocessing.Process] = []

        for batch_name in SIMULATED_BATCHES:
            process = multiprocessing.Process(target=payroll_task, args=(batch_name, results), name=f"PayrollProcess-{batch_name}")
            processes.append(process)
            process.start()

        for process in processes:
            process.join()

        return dict(results)


def record_summary(task_type: str, results: dict[str, int], duration: float) -> None:
    """Print a summary of payroll processing results."""
    print(f"\n{task_type} Summary")
    print(f"Execution Duration: {duration:.3f} seconds")
    for batch_name, processed in results.items():
        print(f"- {batch_name}: {processed} records")


def main() -> None:
    """Execute the process vs thread comparison."""
    log_step("Process vs Thread Demo")
    log_info("Comparing thread and process choices for payroll background work.")

    start_time = time.perf_counter()
    thread_results = thread_based_payroll()
    thread_duration = time.perf_counter() - start_time

    start_time = time.perf_counter()
    process_results = process_based_payroll()
    process_duration = time.perf_counter() - start_time

    record_summary("Thread", thread_results, thread_duration)
    record_summary("Process", process_results, process_duration)

    print("\nExpected Output: Thread workloads share memory; process workloads isolate state.")
    print("Execution Flow: choose model -> execute payroll batches -> compare results")
    print("Advantages: Threads are lightweight; processes isolate memory and crash domains.")
    print("Limitations: Threads can share state unsafely; processes require serialization.")
    print("When to use: Threads for I/O-bound background tasks; processes for CPU-bound isolation.")
    print("When NOT to use: Threads for truly CPU-bound heavy calculations in CPython.")
    print("Performance Notes: Process overhead is higher but provides safety.")
    print("Best Practices: Use multiprocessing for sandboxed batches, threads for service I/O.")
    print("Common Mistakes: Assuming process memory is shared without explicit managers.")
    print("Interview Questions:")
    print("1. What differences exist between thread and process memory models?")
    print("2. Why can processes be safer for payroll batch isolation?")
    print("3. When is a thread the better choice in Python?")
    print("4. How does `multiprocessing.Manager()` help share results?")
    print("5. What overhead does process creation introduce?")
    print("Hands-on Exercise: Add a shared queue for process results.")
    print("Challenge Exercise: Convert one payroll task to a CPU-bound computation and compare.")


if __name__ == "__main__":
    main()
