"""Python Threading Fundamentals

Problem Statement

An enterprise audit service needs to write log entries in the background.
A simple thread can allow logging to proceed without blocking business logic.

Business Scenario

In cybersecurity and financial services, audit logging must remain
reliable while the main application continues processing transactions.

Learning Objectives

- Learn how to create a thread using `_thread.start_new_thread()`.
- Understand the simplicity and limitations of low-level thread creation.
- See how background logging can be decoupled from request handling.

Solution Overview

This example starts a background audit logger with `_thread.start_new_thread()`.
The main workflow can continue while the background logger writes audit records.

Source Code
"""

from __future__ import annotations

import _thread
import time

from src.common.logger import log_info, log_step
from src.common.utilities import simulate_io_wait


AUDIT_RECORDS = [
    "User login received",
    "Permission scope validated",
    "Configuration snapshot stored",
]
LOGGING_DELAY_SECONDS = 0.5


def background_audit_logger(logger_id: int) -> None:
    """Run a background audit logging worker using low-level thread APIs."""
    log_info(f"Background logger {logger_id} started")
    for record in AUDIT_RECORDS:
        simulate_io_wait(LOGGING_DELAY_SECONDS)
        log_info(f"Audit log entry: {record}")
    log_info(f"Background logger {logger_id} completed")


def main() -> None:
    """Execute the low-level thread creation example."""
    log_step("Create Thread Using _thread.start_new_thread")
    log_info("Launch a legacy background audit logger thread.")

    _thread.start_new_thread(background_audit_logger, (42,))

    log_info("Main workflow continues while audit logger runs.")
    time.sleep(1.8)

    print("\nExpected Output: background logger runs while main thread remains responsive.")
    print("Execution Flow: start_new_thread -> continue main -> wait -> complete")
    print("Advantages: Simple background worker creation.")
    print("Limitations: No `join`, no easy exception handling.")
    print("When to use: Very lightweight, legacy compatibility tasks.")
    print("When NOT to use: Complex workflows or enterprise-level thread management.")
    print("Performance Notes: Low overhead but limited control.")
    print("Best Practices: Prefer `threading.Thread` in modern applications.")
    print("Common Mistakes: Assuming the low-level thread is automatically joined.")
    print("Interview Questions:")
    print("1. What does `_thread.start_new_thread()` return?")
    print("2. Why does `_thread` require the main thread to wait?")
    print("3. How would you track completion of a low-level thread?")
    print("4. What are the drawbacks of `_thread` compared to `threading`?")
    print("5. When is `_thread` still appropriate to use?")
    print("Hands-on Exercise: Start a second audit logger thread.")
    print("Challenge Exercise: Replace `_thread` with a `threading.Thread` implementation.")


if __name__ == "__main__":
    main()
