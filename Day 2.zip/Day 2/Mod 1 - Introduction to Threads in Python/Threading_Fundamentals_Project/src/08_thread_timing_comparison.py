"""Python Threading Fundamentals

Problem Statement

A bulk reporting engine must generate hundreds of summary documents.
Sequential generation takes too long for daily operational reporting.

Business Scenario

Manufacturing and logistics teams rely on timely bulk reports.
Comparing sequential and threaded execution helps teams choose the right design.

Learning Objectives

- Compare sequential versus threaded execution times.
- Learn how threading reduces elapsed time for I/O-bound work.
- Understand timing measurement in enterprise scripts.

Solution Overview

This demo generates reports sequentially and then in parallel with threads.
It prints both durations to illustrate the performance difference.

Source Code
"""

from __future__ import annotations

import threading
import time
from typing import Callable, Iterable

from src.common.logger import log_info, log_step
from src.common.utilities import format_duration, generate_report_content, simulate_io_wait


BULK_REPORT_IDENTIFIERS = [
    "Operations KPI", "Service Compliance", "Customer Feedback",
    "Inventory Audit", "Department Budget", "Market Analysis",
]
REPORT_DELAY_SECONDS = 0.8


def generate_report(report_id: str) -> str:
    """Simulate a report generation task."""
    log_info(f"Generating report: {report_id}")
    simulate_io_wait(REPORT_DELAY_SECONDS)
    return generate_report_content(report_id, rows=3)


def run_sequential(report_ids: Iterable[str]) -> list[str]:
    """Generate reports sequentially."""
    return [generate_report(report_id) for report_id in report_ids]


def run_threaded(report_ids: Iterable[str]) -> list[str]:
    """Generate reports using threads concurrently."""
    results: dict[str, str] = {}
    threads: list[threading.Thread] = []

    def worker(report_id: str) -> None:
        results[report_id] = generate_report(report_id)

    for report_id in report_ids:
        thread = threading.Thread(target=worker, args=(report_id,), name=f"ReportWorker-{report_id}")
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return [results[report_id] for report_id in report_ids]


def measure_time(action: Callable[[], list[str]]) -> tuple[list[str], float]:
    """Measure execution time for a report generation approach."""
    start_time = time.perf_counter()
    payload = action()
    duration = time.perf_counter() - start_time
    return payload, duration


def main() -> None:
    """Execute the timing comparison example."""
    log_step("Thread Timing Comparison Example")
    log_info("Compare sequential and threaded bulk report generation.")

    _, sequential_duration = measure_time(lambda: run_sequential(BULK_REPORT_IDENTIFIERS))
    _, threaded_duration = measure_time(lambda: run_threaded(BULK_REPORT_IDENTIFIERS))

    print(f"\nSequential Duration: {format_duration(sequential_duration)}")
    print(f"Threaded Duration: {format_duration(threaded_duration)}")
    print("Expected Output: Threaded execution completes faster for I/O-bound tasks.")
    print("Execution Flow: sequential run -> threaded run -> timing comparison")
    print("Advantages: Threads can reduce wall-clock time for blocking operations.")
    print("Limitations: Threads still share process memory and require careful design.")
    print("When to use: Bulk I/O-bound report generation and data retrieval.")
    print("When NOT to use: CPU-heavy workloads without external waits.")
    print("Performance Notes: Speedup depends on I/O latency and thread overhead.")
    print("Best Practices: Measure and compare before optimizing architecture.")
    print("Common Mistakes: Assuming threads always improve speed.")
    print("Interview Questions:")
    print("1. Why does threaded execution reduce time for I/O-bound tasks?")
    print("2. How do you measure wall-clock duration in Python?")
    print("3. What is the main overhead of using threads?")
    print("4. How does thread scheduling affect timing results?")
    print("5. When could threaded execution be slower than sequential?")
    print("Hands-on Exercise: Add a CPU-bound step and observe changes.")
    print("Challenge Exercise: Implement a thread pool and compare timing again.")


if __name__ == "__main__":
    main()
