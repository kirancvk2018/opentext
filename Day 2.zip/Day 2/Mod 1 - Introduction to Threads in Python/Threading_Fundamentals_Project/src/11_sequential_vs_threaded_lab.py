"""Python Threading Fundamentals

Problem Statement

A file distribution service downloads files from remote servers.
Sequential downloads can be slow and delay downstream processing.

Business Scenario

Enterprises synchronize data from external partners, cloud storage,
and remote endpoints. Faster downloads improve pipeline throughput.

Learning Objectives

- Compare sequential downloads with threaded downloads.
- Measure execution time and observe performance differences.
- Print observations on threaded versus sequential workflows.

Solution Overview

This lab downloads simulated files sequentially and then concurrently.
It compares durations and prints observations for enterprise decision-making.

Source Code
"""

from __future__ import annotations

import threading
import time
from typing import Callable, Iterable

from src.common.logger import log_info, log_step
from src.common.utilities import format_duration, simulate_io_wait


REMOTE_FILES = [
    "Server A dataset.csv",
    "Server B archive.zip",
    "Server C report.pdf",
]
DOWNLOAD_SECONDS = 1.2


def download_file(file_name: str) -> str:
    """Simulate downloading a file from a remote server."""
    log_info(f"Downloading: {file_name}")
    simulate_io_wait(DOWNLOAD_SECONDS)
    log_info(f"Downloaded: {file_name}")
    return file_name


def download_files_sequentially(file_names: Iterable[str]) -> list[str]:
    """Download files one after another."""
    return [download_file(name) for name in file_names]


def download_files_threaded(file_names: Iterable[str]) -> list[str]:
    """Download files in parallel using worker threads."""
    results: list[str] = []
    threads: list[threading.Thread] = []
    results_lock = threading.Lock()

    def worker(file_name: str) -> None:
        downloaded = download_file(file_name)
        with results_lock:
            results.append(downloaded)

    for file_name in file_names:
        thread = threading.Thread(target=worker, args=(file_name,), name=f"DownloadWorker-{file_name}")
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return results


def measure_execution(action: Callable[[], list[str]]) -> tuple[list[str], float]:
    """Measure the result list and elapsed duration of a download action."""
    start_time = time.perf_counter()
    payload = action()
    return payload, time.perf_counter() - start_time


def main() -> None:
    """Execute the sequential versus threaded download lab."""
    log_step("Sequential vs Threaded Lab")
    log_info("Compare sequential and threaded file download performance.")

    sequential_files, sequential_duration = measure_execution(lambda: download_files_sequentially(REMOTE_FILES))
    threaded_files, threaded_duration = measure_execution(lambda: download_files_threaded(REMOTE_FILES))

    print(f"\nSequential downloads: {sequential_files}")
    print(f"Threaded downloads: {threaded_files}")
    print(f"Sequential duration: {format_duration(sequential_duration)}")
    print(f"Threaded duration: {format_duration(threaded_duration)}")

    print("\nExpected Output: Threaded downloads finish faster than sequential.")
    print("Execution Flow: sequential download -> threaded download -> compare results")
    print("Observations:")
    print("- Sequential execution waits for each download to finish before starting the next.")
    print("- Threaded execution overlaps waiting time and improves throughput.")
    print("Advantages: Faster completion for network-bound file transfers.")
    print("Limitations: Requires thread-safe result collection and error handling.")
    print("When to use: Multiple independent remote downloads.")
    print("When NOT to use: Small downloads where threading overhead outweighs benefit.")
    print("Performance Notes: Time saved is roughly the difference between serial and overlapped I/O.")
    print("Best Practices: Use locks for shared results and preserve download order if needed.")
    print("Common Mistakes: Appending results from threads without synchronization.")
    print("Interview Questions:")
    print("1. Why is threaded downloading faster for remote files?")
    print("2. How did we protect access to the result list?")
    print("3. What would happen if the downloads were CPU-bound?")
    print("4. How can you preserve file order in threaded results?")
    print("5. What additional error handling is needed for real downloads?")
    print("Hands-on Exercise: Add a timeout or retry logic to each download.")
    print("Challenge Exercise: Implement a thread pool for the downloads.")


if __name__ == "__main__":
    main()
