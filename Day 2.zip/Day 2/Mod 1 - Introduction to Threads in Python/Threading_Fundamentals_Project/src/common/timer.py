"""Utility module for timing tasks in threading examples."""

from __future__ import annotations

import time
from typing import Callable, TypeVar

T = TypeVar("T")


def measure_execution_time(function: Callable[[], T]) -> tuple[T, float]:
    """Measure elapsed time for a zero-argument function.

    Args:
        function: Callable with no arguments.

    Returns:
        A tuple containing the function return value and elapsed time in seconds.
    """
    start_time = time.perf_counter()
    result = function()
    end_time = time.perf_counter()
    elapsed = end_time - start_time
    return result, elapsed
