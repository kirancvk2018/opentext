"""Shared utilities for enterprise threading training examples."""

from __future__ import annotations

import random
import time
from typing import Iterable


def simulate_io_wait(duration_seconds: float) -> None:
    """Simulate I/O latency for a business operation.

    Args:
        duration_seconds: Number of seconds to sleep.
    """
    time.sleep(duration_seconds)


def generate_report_content(report_id: str, rows: int = 5) -> str:
    """Produce sample report content for training output.

    Args:
        report_id: Unique report identifier.
        rows: Number of summary lines.

    Returns:
        A formatted report string.
    """
    lines = [f"{report_id}: row {index + 1} - status OK" for index in range(rows)]
    return "\n".join(lines)


def simulate_data_fetch() -> dict[str, object]:
    """Simulate a data fetch from an enterprise system."""
    return {
        "customer_id": random.randint(1000, 9999),
        "invoice_count": random.randint(1, 12),
        "severity": "normal",
    }


def format_duration(seconds: float) -> str:
    """Format duration for user-friendly output."""
    return f"{seconds:.3f} seconds"


def chunk_list(items: list[T], chunk_size: int) -> list[list[T]]:
    """Split a list into chunks of a specified size."""
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    return [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]
