"""Standardized console logger for threading demonstration scripts."""

from __future__ import annotations

import datetime


def log_info(message: str) -> None:
    """Write an informational message to the console with a timestamp."""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] INFO: {message}")


def log_step(step: str) -> None:
    """Mark a significant step in the execution flow."""
    print(f"\n--- {step} ---")
