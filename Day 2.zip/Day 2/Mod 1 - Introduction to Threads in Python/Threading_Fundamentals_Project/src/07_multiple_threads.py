"""Python Threading Fundamentals

Problem Statement

An invoicing system needs to process multiple invoice batches concurrently.
Processing them sequentially can delay payment reconciliation.

Business Scenario

Large retail, logistics, and SaaS providers generate invoices across
multiple departments. Parallel invoice processing accelerates financial close.

Learning Objectives

- Learn how to create and manage multiple worker threads.
- Understand concurrent execution of several tasks.
- Observe how one thread does not block the others in I/O-bound work.

Solution Overview

This example starts multiple worker threads to process invoice batches.
Each thread simulates invoice validation and recording independently.

Source Code
"""

from __future__ import annotations

import threading
import time
from typing import Iterable

from src.common.logger import log_info, log_step
from src.common.utilities import simulate_io_wait


INVOICE_BATCHES = [
    "North America Invoices",
    "EMEA Invoices",
    "APAC Invoices",
]
PROCESSING_DELAY_SECONDS = 0.9


def process_invoice_batch(batch_name: str) -> None:
    """Simulate a batch invoice processor running in a worker thread."""
    log_info(f"Thread start: processing {batch_name}")
    simulate_io_wait(PROCESSING_DELAY_SECONDS)
    log_info(f"Thread complete: {batch_name}")


def run_invoice_processors(batch_names: Iterable[str]) -> None:
    """Launch concurrent invoice processing threads."""
    threads: list[threading.Thread] = []

    for batch_name in batch_names:
        thread = threading.Thread(target=process_invoice_batch, args=(batch_name,), name=f"InvoiceWorker-{batch_name}")
        threads.append(thread)
        thread.start()
        log_info(f"Started worker thread for {batch_name}")

    for thread in threads:
        thread.join()
        log_info(f"Worker thread joined: {thread.name}")


def main() -> None:
    """Execute the multiple worker threads example."""
    log_step("Multiple Threads Example")
    log_info("Start multiple invoice processors concurrently.")

    start_time = time.perf_counter()
    run_invoice_processors(INVOICE_BATCHES)
    elapsed = time.perf_counter() - start_time

    print("\nExpected Output: All invoice batches processed concurrently.")
    print("Execution Flow: launch threads -> threads run -> join threads -> end")
    print(f"Total Duration: {elapsed:.3f} seconds")
    print("Advantages: Improved throughput for parallel batch processing.")
    print("Limitations: Need to manage thread lifecycle and shared resources.")
    print("When to use: Multiple independent workload handlers.")
    print("When NOT to use: Workloads that require strict sequential ordering.")
    print("Performance Notes: Ideal for I/O-bound batch tasks.")
    print("Best Practices: Give threads descriptive names and join them.")
    print("Common Mistakes: Forgetting to store thread references before starting.")
    print("Interview Questions:")
    print("1. How do you ensure all worker threads finish before continuing?")
    print("2. Why should threads have names in production code?")
    print("3. What is the effect of using too many threads?")
    print("4. How can you tell if work is I/O-bound or CPU-bound?")
    print("5. What changes when shared state is introduced?")
    print("Hands-on Exercise: Add a status report after each thread completes.")
    print("Challenge Exercise: Create a thread pool abstraction for this example.")


if __name__ == "__main__":
    main()
