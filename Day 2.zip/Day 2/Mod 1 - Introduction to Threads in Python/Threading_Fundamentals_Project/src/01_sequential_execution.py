"""Python Threading Fundamentals

Problem Statement

A financial reporting system prepares three monthly summaries.
Running each report sequentially delays business decision-making,
especially when each report requires I/O-bound processing.

Business Scenario

Enterprise finance teams in banking, insurance, and manufacturing
need fast monthly reporting for regulatory compliance and executive review.
Slow sequential report generation can delay closing cycles and stakeholder updates.

Learning Objectives

- Understand sequential execution.
- Recognize blocking operations in a business workflow.
- Identify why sequential processing becomes slow in enterprise systems.

Solution Overview

This example demonstrates sequential report generation for three
monthly summaries. Each report simulates I/O and CPU work. The code
highlights how one slow task blocks the next in a sequential flow.

Source Code
"""

from __future__ import annotations

import time
from typing import Iterable

from src.common.logger import log_info, log_step
from src.common.utilities import generate_report_content, simulate_io_wait


REPORT_IDENTIFIERS = ["Budget Report", "Revenue Dashboard", "Expense Summary"]
SIMULATED_IO_SECONDS = 1.2


def build_monthly_report(report_name: str) -> str:
    """Generate a single report in a sequential workflow.

    Args:
        report_name: A human-readable report name.

    Returns:
        The synthesized report content.
    """
    log_info(f"Start generating report: {report_name}")

    # Simulate waiting for report data from a database or analytics service.
    simulate_io_wait(SIMULATED_IO_SECONDS)

    # Compose the report content after I/O completes.
    content = generate_report_content(report_name, rows=6)
    log_info(f"Completed report: {report_name}")
    return content


def generate_reports_sequentially(report_names: Iterable[str]) -> list[str]:
    """Build reports one after another in a blocking sequence."""
    reports: list[str] = []
    for name in report_names:
        reports.append(build_monthly_report(name))
    return reports


def main() -> None:
    """Execute the sequential report generation example."""
    log_step("Sequential Execution Example")
    log_info("A finance department runs monthly reports one after another.")

    start_time = time.perf_counter()
    reports = generate_reports_sequentially(REPORT_IDENTIFIERS)
    duration = time.perf_counter() - start_time

    log_info("All reports generated sequentially.")
    for index, report in enumerate(reports, start=1):
        print(f"\nReport {index}:\n{report}")

    print(f"\nExpected Output: All reports completed with sequential delay.")
    print(f"Execution Flow: start -> report 1 -> report 2 -> report 3 -> end")
    print(f"Total Duration: {duration:.3f} seconds")
    print("Advantages: Simple and predictable execution order.")
    print("Limitations: Blocking, not suitable for many simultaneous report tasks.")
    print("When to use: Small batches, low concurrency requirements.")
    print("When NOT to use: High-throughput reporting or time-sensitive pipelines.")
    print("Performance Notes: Each report waits for I/O before the next begins.")
    print("Best Practices: Profile blocking operations before optimizing.")
    print("Common Mistakes: Assuming sequential code is fast enough at scale.")
    print("Interview Questions:")
    print("1. What makes sequential execution blocking?")
    print("2. Why can I/O-bound tasks degrade sequential workflows?")
    print("3. How would you identify long-running steps in a report generator?")
    print("4. When is sequential processing appropriate in enterprise systems?")
    print("5. What is the impact of one slow report on overall throughput?")
    print("Hands-on Exercise: Replace simulated I/O with a file read or database query.")
    print("Challenge Exercise: Convert this example to concurrent execution with threads.")


if __name__ == "__main__":
    main()
