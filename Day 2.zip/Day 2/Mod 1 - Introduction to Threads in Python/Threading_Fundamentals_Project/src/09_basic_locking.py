"""Python Threading Fundamentals

Problem Statement

An inventory management system updates stock quantities concurrently.
Without synchronization, multiple updates can corrupt the shared inventory state.

Business Scenario

Retail and warehouse systems must keep inventory accurate while
many terminals and services update stock simultaneously.
This example highlights race condition risks and lock-based correction.

Learning Objectives

- Understand `allocate_lock()` and basic thread locking.
- Observe race conditions on shared mutable state.
- Learn how locks enforce correct inventory updates.

Solution Overview

This demo runs multiple threads that update a shared inventory count.
Without a lock, the final inventory value is incorrect. Adding a lock
ensures each update is atomic and consistent.

Source Code
"""

from __future__ import annotations

import threading
import time
from typing import Callable

from src.common.logger import log_info, log_step
from src.common.utilities import format_duration


INVENTORY_INITIAL_QUANTITY = 100
UPDATE_EVENTS = [20, -15, 10, -25, 30]
SIMULATED_DELAY = 0.2


def update_inventory(shared_inventory: dict[str, int], change: int) -> None:
    """Simulate a stock quantity update without synchronization."""
    log_info(f"Inventory update start: {change}")
    current_quantity = shared_inventory["quantity"]
    time.sleep(SIMULATED_DELAY)
    shared_inventory["quantity"] = current_quantity + change
    log_info(f"Inventory update complete: {change}")


def update_inventory_with_lock(shared_inventory: dict[str, int], change: int, lock: threading.Lock) -> None:
    """Perform an inventory update while holding a lock."""
    log_info(f"Locked inventory update start: {change}")
    with lock:
        current_quantity = shared_inventory["quantity"]
        time.sleep(SIMULATED_DELAY)
        shared_inventory["quantity"] = current_quantity + change
    log_info(f"Locked inventory update complete: {change}")


def execute_updates(action: Callable[[dict[str, int], int], None]) -> int:
    """Run concurrent update events using the provided action."""
    shared_inventory = {"quantity": INVENTORY_INITIAL_QUANTITY}
    threads: list[threading.Thread] = []

    for change in UPDATE_EVENTS:
        thread = threading.Thread(target=action, args=(shared_inventory, change), name=f"Updater-{change}")
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return shared_inventory["quantity"]


def measure_action(action: Callable[[], int]) -> tuple[int, float]:
    """Measure the result and duration of the concurrent update action."""
    start_time = time.perf_counter()
    result = action()
    return result, time.perf_counter() - start_time


def main() -> None:
    """Execute the basic locking demonstration."""
    log_step("Basic Locking Example")
    log_info("Demonstrate the value of locks for concurrent inventory updates.")

    incorrect_result, incorrect_duration = measure_action(lambda: execute_updates(update_inventory))
    lock = threading.Lock()
    correct_result, correct_duration = measure_action(lambda: execute_updates(lambda inventory, change: update_inventory_with_lock(inventory, change, lock)))

    print(f"\nIncorrect final inventory: {incorrect_result} (expected 100)")
    print(f"Correct final inventory with lock: {correct_result}")
    print(f"Incorrect duration: {format_duration(incorrect_duration)}")
    print(f"Correct duration: {format_duration(correct_duration)}")
    print("Expected Output: The unlocked version may be wrong; the locked version is correct.")
    print("Execution Flow: run unlocked updates -> run locked updates -> compare results")
    print("Advantages: Locks provide atomic access to shared resources.")
    print("Limitations: Locks can introduce contention and deadlocks if misused.")
    print("When to use: Protect shared mutable state across threads.")
    print("When NOT to use: When data is immutable or expensive to serialize.")
    print("Performance Notes: Locks add overhead but guarantee correctness.")
    print("Best Practices: Keep locked sections small and predictable.")
    print("Common Mistakes: Locking too much code or forgetting to release the lock.")
    print("Interview Questions:")
    print("1. What is a race condition?")
    print("2. Why did the unlocked inventory result become incorrect?")
    print("3. How does `threading.Lock()` prevent inconsistent updates?")
    print("4. What should you avoid doing while holding a lock?")
    print("5. How do you choose between a lock and other synchronization primitives?")
    print("Hands-on Exercise: Add a second shared resource and protect it.")
    print("Challenge Exercise: Replace the lock with a `threading.RLock` and explain why.")


if __name__ == "__main__":
    main()
