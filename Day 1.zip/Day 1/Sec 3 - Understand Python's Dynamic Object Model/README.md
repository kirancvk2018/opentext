# Section 03: Python's Dynamic Object Model

> A comprehensive enterprise-focused guide to Python's dynamic object capabilities using realistic software engineering scenarios.

**Target Audience:** Python Developers, Backend Engineers, Solution Architects, Enterprise Application Developers, Computer Science Students

**Python Version:** 3.12+

---

## Module Overview

This repository explores how Python enables flexible, extensible object-oriented design through its dynamic nature. Rather than treating dynamics as edge cases, we demonstrate how runtime polymorphism, descriptors, decorators, callbacks, and factory patterns form the foundation of professional, enterprise-grade software.

Each example solves a real-world software engineering problem:
- Notification systems
- Payment gateway adapters
- Plugin frameworks
- Logging infrastructures
- API adapters
- Workflow engines
- Document processors

---

## Learning Objectives

By completing this module, you will understand:

✓ **Duck Typing** – How Python achieves polymorphism without inheritance hierarchies

✓ **Protocol-Based Design** – Building flexible interfaces through structural typing

✓ **Callbacks & Higher-Order Functions** – Composing behavior at runtime

✓ **Function Objects** – Treating functions as first-class citizens

✓ **Object Wrapping** – Proxies and decorators for behavior modification

✓ **Design Patterns** – Factory, Adapter, and Proxy patterns in dynamic contexts

✓ **Monkey Patching** – Safe runtime behavior modification

✓ **Descriptors** – Advanced attribute access control and lazy computation

✓ **Properties** – Computed attributes and validation

✓ **Dynamic Object Creation** – Factory-based instantiation and type creation

✓ **Plugin Architectures** – Building extensible systems

✓ **Enterprise Patterns** – Real-world notification, logging, and adapter frameworks

---

## Repository Structure

```
Section03_Python_Dynamic_Object_Model/

├── README.md                              # This file
├── requirements.txt                       # Python dependencies (stdlib only)
├── LICENSE                                # MIT License
├── .gitignore                             # Standard Python exclusions
│
├── .vscode/
│   ├── launch.json                        # Debugger configuration
│   └── settings.json                      # Editor configuration
│
├── assets/
│   ├── config.json                        # Example configuration
│   ├── plugins.json                       # Plugin definitions
│   ├── employees.csv                      # Sample employee data
│   └── application.log                    # Example log output
│
└── src/
    ├── 01_duck_typing_basics.py           # Duck typing fundamentals
    ├── 02_protocol_based_design.py        # Structural typing with protocols
    ├── 03_callback_functions.py           # Callback mechanisms
    ├── 04_higher_order_functions.py       # Functions that return functions
    ├── 05_function_objects.py             # Functions as objects
    ├── 06_object_wrapping.py              # Wrapping objects for behavior
    ├── 07_proxy_pattern.py                # Proxy pattern implementation
    ├── 08_adapter_pattern.py              # Adapter pattern for APIs
    ├── 09_monkey_patching_basics.py       # Safe runtime modification
    ├── 10_runtime_behavior_modification.py # Dynamic behavior changes
    ├── 11_descriptors_basics.py           # Descriptor protocol
    ├── 12_custom_descriptors.py           # Building custom descriptors
    ├── 13_property_vs_descriptor.py       # Choosing the right approach
    ├── 14_factory_pattern.py              # Factory design pattern
    ├── 15_factory_method_pattern.py       # Factory method pattern
    ├── 16_simple_plugin_framework.py      # Building plugin systems
    ├── 17_dynamic_object_creation.py      # Creating objects at runtime
    └── 18_enterprise_notification_framework.py # Real-world framework
```

---

## VS Code Setup

### 1. Install Python Extension
- Open VS Code Extensions
- Search for "Python" (Microsoft)
- Click Install

### 2. Launch Configuration
- Press `Ctrl+Shift+D` (or `Cmd+Shift+D` on macOS)
- Click "create a launch.json file"
- Select "Python"

This repository includes preconfigured `.vscode/launch.json` and `.vscode/settings.json`.

### 3. Running Examples

#### Option A: Run from VS Code
1. Open any Python file (e.g., `src/01_duck_typing_basics.py`)
2. Press `F5` or `Ctrl+F5` to debug

#### Option B: Run from Terminal
```bash
cd src
python 01_duck_typing_basics.py
python 02_protocol_based_design.py
# ... etc
```

#### Option C: Run All Examples
```bash
for file in src/*.py; do
    echo "=== Running $file ==="
    python "$file"
    echo ""
done
```

---

## Suggested Learning Order

### **Foundational Concepts** (understand Python's flexibility)
1. `01_duck_typing_basics.py` – Start here
2. `02_protocol_based_design.py` – Formalize duck typing
3. `05_function_objects.py` – Functions as first-class objects

### **Callbacks & Composition** (build behavior at runtime)
4. `03_callback_functions.py` – Async patterns and event handling
5. `04_higher_order_functions.py` – Functions that create functions
6. `06_object_wrapping.py` – Decorators and wrappers

### **Object Modification** (alter behavior safely)
7. `07_proxy_pattern.py` – Control access to objects
8. `08_adapter_pattern.py` – Adapt incompatible interfaces
9. `09_monkey_patching_basics.py` – Modify at runtime
10. `10_runtime_behavior_modification.py` – Advanced modifications

### **Advanced Attribute Access** (fine-grained control)
11. `11_descriptors_basics.py` – Descriptor protocol
12. `12_custom_descriptors.py` – Build your own descriptors
13. `13_property_vs_descriptor.py` – Choose the right tool

### **Object Creation** (build factories)
14. `14_factory_pattern.py` – Factory basics
15. `15_factory_method_pattern.py` – Method factories
16. `17_dynamic_object_creation.py` – Create classes at runtime

### **Real-World Systems** (apply everything)
17. `16_simple_plugin_framework.py` – Extensible architectures
18. `18_enterprise_notification_framework.py` – Production patterns

---

## Design Principles Covered

| Principle | Where Taught | Why It Matters |
|-----------|--------------|----------------|
| **SOLID: Single Responsibility** | All modules | Each class has one reason to change |
| **SOLID: Open/Closed** | Factory, Plugin, Adapter | Open for extension, closed for modification |
| **SOLID: Liskov Substitution** | Duck Typing, Protocol | Subtypes must be substitutable |
| **SOLID: Interface Segregation** | Protocol-Based Design | Clients depend on specific interfaces |
| **SOLID: Dependency Inversion** | Callbacks, Higher-Order | Depend on abstractions, not concretions |
| **DRY: Don't Repeat Yourself** | Decorators, Wrappers | Extract common patterns |
| **KISS: Keep It Simple** | All modules | Simple is better than clever |
| **YAGNI: You Aren't Gonna Need It** | Factory Pattern | Build for current needs |

---

## Running the Examples

### Quick Start
```bash
# Navigate to the src directory
cd src

# Run a specific example
python 01_duck_typing_basics.py

# View expected output
# Each file contains "EXPECTED OUTPUT:" comments
```

### Debug a File
```bash
# Using Python debugger
python -m pdb 01_duck_typing_basics.py

# Using VS Code debugger
# Open the file and press F5
```

### Run All Examples with Output
```bash
# Bash/zsh
for file in src/*.py; do
    echo "=========================================="
    echo "Running: $(basename $file)"
    echo "=========================================="
    python "$file"
    echo ""
done
```

---

## Key Concepts

### Duck Typing
```python
# If it walks like a duck and quacks like a duck...
# ...it's a duck (doesn't matter what type it is)

class Dog:
    def speak(self): return "Woof"

class Cat:
    def speak(self): return "Meow"

def make_sound(animal):
    print(animal.speak())  # Works with ANY object with speak()
```

### Callbacks
```python
# Pass behavior as a parameter
def on_user_login(user, callback):
    callback(user)  # Execute custom behavior

on_user_login(user, send_welcome_email)
on_user_login(user, create_audit_log)
```

### Descriptors
```python
# Fine-grained control over attribute access
class ValidatedInteger:
    def __set_name__(self, owner, name):
        self.name = name
    
    def __get__(self, obj, objtype=None):
        return obj.__dict__.get(self.name, 0)
    
    def __set__(self, obj, value):
        if not isinstance(value, int):
            raise TypeError(f"{self.name} must be int")
        obj.__dict__[self.name] = value
```

### Factory Pattern
```python
# Create objects without specifying exact classes
class PaymentGateway:
    @staticmethod
    def create(provider_type):
        if provider_type == "stripe":
            return StripeGateway()
        elif provider_type == "paypal":
            return PayPalGateway()
```

---

## Code Quality Standards

Every example follows:

✓ **PEP 8** – Consistent formatting and naming  
✓ **Type Hints** – Full type annotations  
✓ **Docstrings** – Google-style docstrings  
✓ **Error Handling** – Proper exception management  
✓ **Best Practices** – Production-quality patterns  
✓ **Comments** – Only when "why" isn't obvious  
✓ **Self-Documenting** – Clear variable and function names  

---

## File Structure Pattern

Every Python file includes:

```
1. Module header (name, topic, objectives)
2. Problem statement (real-world scenario)
3. Enterprise scenario (why this matters)
4. Prerequisites (what to know first)
5. Expected output (what to look for)
6. Imports (organized by type)
7. Constants (configuration values)
8. Sample data (example data structures)
9. Classes (implementation)
10. Functions (utilities and examples)
11. Main driver (execution)
12. Expected output (actual output shown)
13. Best practices (do's and don'ts)
14. Common mistakes (what goes wrong)
15. Interview questions (test your knowledge)
16. Challenge exercise (practice problem)
```

---

## Running in Production-Like Environments

### Docker (Optional)
```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY . .
CMD ["python", "src/01_duck_typing_basics.py"]
```

### Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/01_duck_typing_basics.py
```

---

## References & Further Reading

### Python Documentation
- [Duck Typing](https://docs.python.org/3/glossary.html#term-duck-typing)
- [Descriptors](https://docs.python.org/3/howto/descriptor.html)
- [Data Model](https://docs.python.org/3/reference/datamodel.html)
- [typing Module](https://docs.python.org/3/library/typing.html)

### Recommended Books
- *Fluent Python* – Luciano Ramalho
- *Python Cookbook* – David Beazley & Brian K. Jones
- *Expert Python Programming* – Michal Jaworski & Tarek Ziadé
- *Design Patterns: Elements of Reusable Object-Oriented Software* – Gang of Four

### Design Patterns
- [Refactoring.guru – Design Patterns](https://refactoring.guru/design-patterns)
- [Real Python – Design Patterns](https://realpython.com/design-patterns-python/)

### Advanced Topics
- [PEP 20 – The Zen of Python](https://www.python.org/dev/peps/pep-0020/)
- [PEP 484 – Type Hints](https://www.python.org/dev/peps/pep-0484/)
- [PEP 544 – Protocols](https://www.python.org/dev/peps/pep-0544/)

---

## Frequently Asked Questions

### Q: Do I need external libraries?
**A:** No. All examples use only Python's Standard Library. This maximizes portability and demonstrates core language concepts.

### Q: Can I run these on Windows/Mac/Linux?
**A:** Yes. All examples are platform-independent and require only Python 3.12+.

### Q: How should I progress through the examples?
**A:** Follow the "Suggested Learning Order" section. Each example builds on previous concepts.

### Q: Are these examples used in production?
**A:** Yes. The patterns taught here are used daily in enterprise systems at major tech companies.

### Q: How long should each example take?
**A:** 20-45 minutes, depending on your Python experience and depth of study.

---

## Contributing

Found an issue? Have a suggestion? Contributions are welcome!

1. Open an issue describing the problem
2. Fork the repository
3. Create a feature branch
4. Submit a pull request

---

## License

This project is licensed under the MIT License – see the [LICENSE](LICENSE) file for details.

---

## Acknowledgments

This training material draws from decades of enterprise software development, design pattern literature, and the collective knowledge of the Python community.

---

**Last Updated:** July 2025  
**Python Version:** 3.12+  
**Status:** Production Ready
