"""
================================================================================
Module:           04_higher_order_functions.py
Topic:            Higher-Order Functions and Functional Composition
Problem:          Building flexible data processing pipelines where functions
                  return functions to create specialized behavior.
Enterprise:       A data transformation framework needs to compose multiple
                  transformations (filter, map, validate, aggregate) without
                  creating separate classes for each operation.
Objectives:       - Understand higher-order functions
                  - Build function factories
                  - Compose functions
                  - Use closures effectively
Prerequisites:    - Functions as objects (Module 05)
                  - Duck typing (Module 01)
================================================================================
"""

from typing import Callable, Any, TypeVar
from functools import wraps, reduce
import json
from datetime import datetime

T = TypeVar('T')
U = TypeVar('U')


# ============================================================================
# SAMPLE DATA
# ============================================================================

SALES_DATA = [
    {"id": 1, "product": "Laptop", "amount": 1200, "region": "US", "date": "2024-01-15"},
    {"id": 2, "product": "Mouse", "amount": 25, "region": "EU", "date": "2024-01-16"},
    {"id": 3, "product": "Keyboard", "amount": 85, "region": "US", "date": "2024-01-17"},
    {"id": 4, "product": "Monitor", "amount": 350, "region": "APAC", "date": "2024-01-18"},
    {"id": 5, "product": "Laptop", "amount": 1200, "region": "EU", "date": "2024-01-19"},
]


# ============================================================================
# FUNCTION FACTORIES: Functions That Return Functions
# ============================================================================

def create_filter(field: str, value: Any) -> Callable[[dict[str, Any]], bool]:
    """
    Factory function that creates a filter function.
    Returns a function that filters based on a field value.
    """
    def filter_fn(record: dict[str, Any]) -> bool:
        return record.get(field) == value
    return filter_fn


def create_threshold_filter(field: str, min_value: float) -> Callable[[dict[str, Any]], bool]:
    """Create a filter for minimum threshold."""
    def filter_fn(record: dict[str, Any]) -> bool:
        return record.get(field, 0) >= min_value
    return filter_fn


def create_mapper(transformation: Callable[[Any], Any]) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Factory that creates a mapping function."""
    def mapper(record: dict[str, Any]) -> dict[str, Any]:
        return {key: transformation(value) for key, value in record.items()}
    return mapper


def create_field_extractor(*fields: str) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Create a function that extracts specific fields from a record."""
    def extractor(record: dict[str, Any]) -> dict[str, Any]:
        return {field: record.get(field) for field in fields}
    return extractor


def create_aggregator(field: str, operation: str) -> Callable[[list[Any]], Any]:
    """Create an aggregation function."""
    def aggregator(records: list[dict[str, Any]]) -> Any:
        values = [r.get(field, 0) for r in records]
        if operation == "sum":
            return sum(values)
        elif operation == "avg":
            return sum(values) / len(values) if values else 0
        elif operation == "max":
            return max(values) if values else 0
        elif operation == "min":
            return min(values) if values else 0
        elif operation == "count":
            return len(values)
        return None
    return aggregator


# ============================================================================
# FUNCTION COMPOSITION
# ============================================================================

def compose(*functions: Callable[[Any], Any]) -> Callable[[Any], Any]:
    """
    Compose multiple functions into one.
    compose(f, g, h)(x) = f(g(h(x)))
    """
    def composed(x: Any) -> Any:
        for fn in reversed(functions):
            x = fn(x)
        return x
    return composed


def pipe(*functions: Callable[[Any], Any]) -> Callable[[Any], Any]:
    """
    Pipe multiple functions (opposite of compose).
    pipe(f, g, h)(x) = h(g(f(x)))
    """
    def piped(x: Any) -> Any:
        for fn in functions:
            x = fn(x)
        return x
    return piped


# ============================================================================
# PARTIAL APPLICATION & CURRYING
# ============================================================================

def create_discount_calculator(discount_percent: float) -> Callable[[float], float]:
    """Factory for discount calculation."""
    def calculate_discount(amount: float) -> float:
        return amount * (1 - discount_percent / 100)
    return calculate_discount


def create_tax_calculator(tax_rate: float) -> Callable[[float], float]:
    """Factory for tax calculation."""
    def calculate_tax(amount: float) -> float:
        return amount * (1 + tax_rate / 100)
    return calculate_tax


def curry(fn: Callable[[Any, Any], Any]) -> Callable[[Any], Callable[[Any], Any]]:
    """Convert a 2-argument function to curried form."""
    def curried(a: Any) -> Callable[[Any], Any]:
        def inner(b: Any) -> Any:
            return fn(a, b)
        return inner
    return curried


# ============================================================================
# DECORATORS (Functions That Modify Functions)
# ============================================================================

def timing_decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Measure function execution time."""
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = datetime.now()
        result = fn(*args, **kwargs)
        elapsed = (datetime.now() - start).total_seconds()
        print(f"  [{fn.__name__}] executed in {elapsed:.4f}s")
        return result
    return wrapper


def retry_decorator(max_attempts: int = 3) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that retries a function."""
    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            for attempt in range(1, max_attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts:
                        raise
                    print(f"  Attempt {attempt} failed: {e}. Retrying...")
            return None
        return wrapper
    return decorator


def logging_decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Log function calls and results."""
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        print(f"  Calling {fn.__name__}({args}, {kwargs})")
        result = fn(*args, **kwargs)
        print(f"  {fn.__name__} returned {type(result).__name__}")
        return result
    return wrapper


def cache_decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Simple caching decorator."""
    cache: dict[tuple[Any, ...], Any] = {}
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        key = (args, tuple(sorted(kwargs.items())))
        if key not in cache:
            cache[key] = fn(*args, **kwargs)
        else:
            print(f"  [{fn.__name__}] cache hit")
        return cache[key]
    return wrapper


# ============================================================================
# PIPELINE BUILDER
# ============================================================================

class Pipeline:
    """Build processing pipelines with fluent API."""

    def __init__(self, data: list[Any]) -> None:
        self.data = data
        self.operations: list[Callable[[Any], Any]] = []

    def filter(self, predicate: Callable[[Any], bool]) -> "Pipeline":
        """Add a filter operation."""
        self.operations.append(lambda data: [item for item in data if predicate(item)])
        return self

    def map(self, transformation: Callable[[Any], Any]) -> "Pipeline":
        """Add a map operation."""
        self.operations.append(lambda data: [transformation(item) for item in data])
        return self

    def reduce(self, fn: Callable[[Any, Any], Any], initial: Any = None) -> Any:
        """Apply reduce operation and return result."""
        result = self.data
        for operation in self.operations:
            result = operation(result)
        return reduce(fn, result) if result else initial

    def aggregate(self, fn: Callable[[list[Any]], Any]) -> Any:
        """Apply aggregation operation and return result."""
        result = self.data
        for operation in self.operations:
            result = operation(result)
        return fn(result)

    def execute(self) -> list[Any]:
        """Execute pipeline and return results."""
        result = self.data
        for operation in self.operations:
            result = operation(result)
        return result


# ============================================================================
# MAIN: DEMONSTRATION
# ============================================================================

def main() -> None:
    """Execute higher-order functions demonstration."""

    print("\n" + "=" * 80)
    print("HIGHER-ORDER FUNCTIONS: Function Composition and Factories")
    print("=" * 80)

    print("\n[1] FUNCTION FACTORIES")
    print("-" * 80)

    # Create filter functions
    us_filter = create_filter("region", "US")
    eu_filter = create_filter("region", "EU")
    high_value_filter = create_threshold_filter("amount", 100)

    print("\nFiltering sales data:")
    us_sales = [r for r in SALES_DATA if us_filter(r)]
    print(f"US sales: {len(us_sales)} records")
    for sale in us_sales:
        print(f"  - {sale['product']}: ${sale['amount']}")

    high_value_sales = [r for r in SALES_DATA if high_value_filter(r)]
    print(f"\nHigh-value sales (>=100): {len(high_value_sales)} records")

    print("\n[2] FIELD EXTRACTION")
    print("-" * 80)

    extract_summary = create_field_extractor("product", "amount", "region")
    summaries = [extract_summary(record) for record in SALES_DATA]
    print(f"Extracted {len(summaries)} summaries:")
    for summary in summaries[:3]:
        print(f"  {json.dumps(summary)}")

    print("\n[3] AGGREGATION FUNCTIONS")
    print("-" * 80)

    total_sales = create_aggregator("amount", "sum")
    avg_sales = create_aggregator("amount", "avg")
    max_sale = create_aggregator("amount", "max")

    print(f"Total sales: ${total_sales(SALES_DATA)}")
    print(f"Average sale: ${avg_sales(SALES_DATA):.2f}")
    print(f"Largest sale: ${max_sale(SALES_DATA)}")

    print("\n[4] PRICE CALCULATION PIPELINE")
    print("-" * 80)

    # Create calculation functions
    apply_10_percent_discount = create_discount_calculator(10)
    apply_sales_tax = create_tax_calculator(8)

    print("\nApplying discount and tax to a $1000 item:")
    price = 1000
    print(f"  Original price: ${price}")

    discounted = apply_10_percent_discount(price)
    print(f"  After 10% discount: ${discounted}")

    final = apply_sales_tax(discounted)
    print(f"  After 8% tax: ${final:.2f}")

    # Using composition
    process_price = compose(apply_sales_tax, apply_10_percent_discount)
    print(f"\n  Using compose: ${process_price(price):.2f}")

    # Using pipe (clearer for left-to-right reading)
    calculate_final_price = pipe(apply_10_percent_discount, apply_sales_tax)
    print(f"  Using pipe: ${calculate_final_price(price):.2f}")

    print("\n[5] DECORATED FUNCTIONS")
    print("-" * 80)

    @timing_decorator
    def slow_calculation() -> int:
        """Simulate slow operation."""
        total = 0
        for i in range(1000000):
            total += i
        return total

    @cache_decorator
    def expensive_computation(n: int) -> int:
        """Expensive computation with caching."""
        return sum(range(n))

    print("\nTiming decorator:")
    result = slow_calculation()

    print("\nCaching decorator:")
    print("  First call:")
    result1 = expensive_computation(1000)
    print("  Second call (cached):")
    result2 = expensive_computation(1000)

    print("\n[6] DATA PROCESSING PIPELINE")
    print("-" * 80)

    # Build a complex pipeline
    pipeline = Pipeline(SALES_DATA)
    high_us_sales = pipeline.filter(lambda r: r["region"] == "US").filter(
        lambda r: r["amount"] >= 100
    ).execute()

    print(f"\nHigh-value US sales (pipeline):")
    for sale in high_us_sales:
        print(f"  - {sale['product']}: ${sale['amount']}")

    # Aggregation pipeline
    total_pipeline = Pipeline(SALES_DATA).filter(lambda r: r["region"] == "US")
    total_us_sales = total_pipeline.aggregate(create_aggregator("amount", "sum"))
    print(f"\nTotal US sales: ${total_us_sales}")

    print("\n[7] CURRYING")
    print("-" * 80)

    def multiply(a: int, b: int) -> int:
        return a * b

    curried_multiply = curry(multiply)
    double = curried_multiply(2)
    triple = curried_multiply(3)

    print(f"Curried multiplication:")
    print(f"  double(5) = {double(5)}")
    print(f"  triple(5) = {triple(5)}")

    print("\n" + "=" * 80)
    print("HIGHER-ORDER FUNCTION PATTERNS")
    print("=" * 80)
    print("""
PATTERN 1: Function Factory
  - Factory function returns a configured function
  + Reusable, parameterized behavior
  - Closure captures parameters

PATTERN 2: Composition
  - Combine multiple functions
  + Clean, mathematical
  - Order can be confusing

PATTERN 3: Pipeline
  - Chain operations in sequence
  + Left-to-right readability
  - Can be slower than direct composition

PATTERN 4: Decorators
  - Wrap function to add behavior
  + Separation of concerns
  - Can make debugging harder

PATTERN 5: Currying
  - Multi-argument function becomes chain of single-argument functions
  + Enables partial application
  - Less pythonic (use functools.partial instead)
    """)

    print("\n" + "=" * 80)
    print("BEST PRACTICES")
    print("=" * 80)
    print("""
[DO] Use higher-order functions for reusable operations.

[DO] Name factory functions descriptively (create_*).

[DO] Use type hints with higher-order functions.

[DO] Compose simple functions into complex behaviors.

[DO] Use functools.wraps() when creating decorators.

[DO] Document what functions expect and return.

[DONT] Nest higher-order functions too deeply.

[DONT] Mix pipes and composition in same codebase.

[DONT] Create factories when a simple function suffices.

[DONT] Use lambdas for complex logic.
    """)

    print("\n" + "=" * 80)
    print("COMMON MISTAKES")
    print("=" * 80)
    print("""
MISTAKE 1: Confusing compose vs pipe order
    BAD:  compose(f, g, h)(x)  # Applies h, g, f (right-to-left)
          # Hard to remember
    GOOD: pipe(f, g, h)(x)     # Applies f, g, h (left-to-right)
          # More intuitive

MISTAKE 2: Not using functools.wraps in decorators
    BAD:  def decorator(fn):
              def wrapper(*args):
                  return fn(*args)
              return wrapper  # Loses fn's metadata
    GOOD: @wraps(fn)
          def wrapper(*args):
              return fn(*args)

MISTAKE 3: Closure variable capture issues
    BAD:  functions = []
          for i in range(3):
              functions.append(lambda x: x + i)
          # All functions use final value of i
    GOOD: functions = [lambda x, i=i: x + i for i in range(3)]

MISTAKE 4: Over-generalizing factory functions
    BAD:  factory that tries to handle every possible case
    GOOD: Simple factory for common case

MISTAKE 5: Performance impact of decorators
    BAD:  Multiple nested decorators without considering cost
    GOOD: Profile and optimize decorator chains
    """)

    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS")
    print("=" * 80)
    print("""
Q1: What is a higher-order function?
A1: A function that takes another function as argument or returns a function.
    Examples: map(), filter(), decorators, function factories.

Q2: What's the difference between compose and pipe?
A2: compose(f,g)(x) = f(g(x)) (right-to-left, mathematical notation).
    pipe(f,g)(x) = g(f(x)) (left-to-right, more readable).

Q3: How do closures work in Python?
A3: Inner functions can access variables from enclosing scopes.
    The closure "captures" these variables even after the outer function
    returns. Use nonlocal to modify captured variables.

Q4: What are the performance implications of higher-order functions?
A4: Each function call adds overhead. Nested higher-order functions
    can be slower than direct implementation. Profile before optimizing.

Q5: When should you use decorators vs composition?
A5: Use decorators to modify function behavior transparently.
    Use composition when behavior is application-specific.
    Decorators are for cross-cutting concerns.
    """)

    print("\n" + "=" * 80)
    print("CHALLENGE EXERCISE")
    print("=" * 80)
    print("""
Build a QueryBuilder that uses higher-order functions to:

1. Create chainable filter methods
2. Support complex predicates (AND, OR)
3. Support sorting
4. Support grouping
5. Support aggregation

Requirements:
    - Fluent API (builder pattern)
    - Lazy evaluation (execute() runs all operations)
    - Support combining filters with AND/OR
    - Return results or aggregates

Example usage:
    result = QueryBuilder(SALES_DATA)
        .filter(lambda r: r['amount'] > 100)
        .filter(lambda r: r['region'] in ['US', 'EU'])
        .sort_by('amount', reverse=True)
        .aggregate('amount', 'sum')
    """)


if __name__ == "__main__":
    main()
