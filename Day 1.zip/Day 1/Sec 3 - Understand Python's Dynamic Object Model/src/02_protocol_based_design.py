"""
================================================================================
Module:           02_protocol_based_design.py
Topic:            Protocol-Based Design and Structural Typing
Problem:          Formalizing duck typing contracts using typing.Protocol
                  to enable static type checking while maintaining flexibility.
Enterprise:       An enterprise API adapter framework needs to support multiple
                  data sources (SQL, NoSQL, REST APIs) with type safety and
                  compile-time verification using mypy/pyright.
Objectives:       - Understand Protocol as a typing construct
                  - Implement structural typing with @runtime_checkable
                  - Build flexible type-safe systems
                  - Verify implementations against contracts
Prerequisites:    - Duck typing (Module 01)
                  - Type hints (PEP 484)
                  - Python 3.8+ (Protocol introduced in 3.8)
================================================================================
"""

from typing import Protocol, runtime_checkable, Any, Iterator
from abc import ABC, abstractmethod
import json
from datetime import datetime
from dataclasses import dataclass


# ============================================================================
# PROBLEM STATEMENT
# ============================================================================
# Different data sources have different APIs:
# - SQL databases: query(), fetch_one(), fetch_all()
# - NoSQL databases: find(), find_one(), aggregate()
# - REST APIs: get(), post(), list()
#
# We need a way to:
# 1. Define a contract (Protocol)
# 2. Verify implementations match the contract
# 3. Enable static type checking
# 4. Maintain runtime flexibility


# ============================================================================
# SAMPLE DATA
# ============================================================================

SAMPLE_RECORDS = [
    {"id": 1, "name": "Alice", "email": "alice@company.com", "department": "Engineering"},
    {"id": 2, "name": "Bob", "email": "bob@company.com", "department": "Sales"},
    {"id": 3, "name": "Carol", "email": "carol@company.com", "department": "Engineering"},
]


# ============================================================================
# PROTOCOLS: Defining the Contract
# ============================================================================

@runtime_checkable
class DataSource(Protocol):
    """
    Protocol defining what a data source must do.
    This is a STRUCTURAL typing contract—not an ABC.
    Any class with these methods satisfies this protocol.
    """

    def query(self, sql: str) -> list[dict[str, Any]]:
        """Execute a query and return results."""
        ...

    def count(self) -> int:
        """Return total record count."""
        ...

    def close(self) -> None:
        """Close the connection."""
        ...


@runtime_checkable
class Repository(Protocol):
    """Repository pattern protocol."""

    def get_by_id(self, id: int) -> dict[str, Any] | None:
        """Get a record by ID."""
        ...

    def get_all(self) -> list[dict[str, Any]]:
        """Get all records."""
        ...

    def save(self, record: dict[str, Any]) -> int:
        """Save a record. Return the ID."""
        ...

    def delete(self, id: int) -> bool:
        """Delete a record. Return success status."""
        ...


@runtime_checkable
class Logger(Protocol):
    """Logger protocol."""

    def info(self, message: str) -> None:
        """Log info message."""
        ...

    def error(self, message: str) -> None:
        """Log error message."""
        ...

    def debug(self, message: str) -> None:
        """Log debug message."""
        ...


@runtime_checkable
class Validator(Protocol):
    """Validator protocol."""

    def validate(self, data: dict[str, Any]) -> bool:
        """Return True if data is valid."""
        ...

    def get_errors(self) -> list[str]:
        """Return list of validation errors."""
        ...


# ============================================================================
# IMPLEMENTATIONS: Different Data Sources (No Inheritance!)
# ============================================================================

class SQLiteRepository:
    """
    SQLite repository implementation.
    Note: Doesn't inherit from anything—just implements the protocol.
    """

    def __init__(self, name: str = "employees") -> None:
        self.name = name
        self.records: list[dict[str, Any]] = SAMPLE_RECORDS.copy()
        self.logger: SimpleLogger | None = None

    def get_by_id(self, id: int) -> dict[str, Any] | None:
        """Get record by ID."""
        for record in self.records:
            if record["id"] == id:
                return record.copy()
        return None

    def get_all(self) -> list[dict[str, Any]]:
        """Get all records."""
        return [r.copy() for r in self.records]

    def save(self, record: dict[str, Any]) -> int:
        """Save a record."""
        if "id" not in record:
            record["id"] = max((r["id"] for r in self.records), default=0) + 1
        existing_idx = next(
            (i for i, r in enumerate(self.records) if r["id"] == record["id"]), -1
        )
        if existing_idx >= 0:
            self.records[existing_idx] = record.copy()
        else:
            self.records.append(record.copy())
        return record["id"]

    def delete(self, id: int) -> bool:
        """Delete a record."""
        initial_len = len(self.records)
        self.records = [r for r in self.records if r["id"] != id]
        return len(self.records) < initial_len

    def query(self, sql: str) -> list[dict[str, Any]]:
        """Execute a query (simplified)."""
        return self.get_all()

    def count(self) -> int:
        """Return record count."""
        return len(self.records)

    def close(self) -> None:
        """Close connection."""
        pass


class MongoDBRepository:
    """
    MongoDB repository implementation.
    Different method names but same intent.
    """

    def __init__(self, collection_name: str = "employees") -> None:
        self.collection = collection_name
        self.documents: list[dict[str, Any]] = SAMPLE_RECORDS.copy()

    def get_by_id(self, id: int) -> dict[str, Any] | None:
        """Get document by ID."""
        result = next((d for d in self.documents if d["id"] == id), None)
        return result.copy() if result else None

    def get_all(self) -> list[dict[str, Any]]:
        """Get all documents."""
        return [d.copy() for d in self.documents]

    def save(self, record: dict[str, Any]) -> int:
        """Save a document."""
        if "id" not in record:
            record["id"] = max((d["id"] for d in self.documents), default=0) + 1
        existing_idx = next(
            (i for i, d in enumerate(self.documents) if d["id"] == record["id"]), -1
        )
        if existing_idx >= 0:
            self.documents[existing_idx] = record.copy()
        else:
            self.documents.append(record.copy())
        return record["id"]

    def delete(self, id: int) -> bool:
        """Delete a document."""
        initial_len = len(self.documents)
        self.documents = [d for d in self.documents if d["id"] != id]
        return len(self.documents) < initial_len

    def find(self, query: dict[str, Any]) -> list[dict[str, Any]]:
        """Find documents (MongoDB style)."""
        return self.get_all()

    def find_one(self, query: dict[str, Any]) -> dict[str, Any] | None:
        """Find one document."""
        return self.get_all()[0] if self.documents else None


class RESTAPIRepository:
    """
    REST API repository implementation.
    Yet another different interface, same protocol.
    """

    def __init__(self, base_url: str = "https://api.company.com") -> None:
        self.base_url = base_url
        self.cache: list[dict[str, Any]] = SAMPLE_RECORDS.copy()

    def get_by_id(self, id: int) -> dict[str, Any] | None:
        """GET /resource/{id}"""
        for item in self.cache:
            if item["id"] == id:
                return item.copy()
        return None

    def get_all(self) -> list[dict[str, Any]]:
        """GET /resources"""
        return [item.copy() for item in self.cache]

    def save(self, record: dict[str, Any]) -> int:
        """POST /resources or PUT /resources/{id}"""
        if "id" not in record:
            record["id"] = max((r["id"] for r in self.cache), default=0) + 1
        existing_idx = next(
            (i for i, r in enumerate(self.cache) if r["id"] == record["id"]), -1
        )
        if existing_idx >= 0:
            self.cache[existing_idx] = record.copy()
        else:
            self.cache.append(record.copy())
        return record["id"]

    def delete(self, id: int) -> bool:
        """DELETE /resources/{id}"""
        initial_len = len(self.cache)
        self.cache = [r for r in self.cache if r["id"] != id]
        return len(self.cache) < initial_len

    def get(self, endpoint: str) -> dict[str, Any]:
        """GET endpoint."""
        return self.get_all()[0] if self.cache else {}

    def post(self, endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
        """POST endpoint."""
        id = self.save(data)
        return {"id": id, "status": "created"}


class SimpleLogger:
    """
    Simple logger implementation.
    Satisfies the Logger protocol without explicit declaration.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self.messages: list[dict[str, str]] = []

    def info(self, message: str) -> None:
        """Log info."""
        self.messages.append({"level": "INFO", "message": message})

    def error(self, message: str) -> None:
        """Log error."""
        self.messages.append({"level": "ERROR", "message": message})

    def debug(self, message: str) -> None:
        """Log debug."""
        self.messages.append({"level": "DEBUG", "message": message})

    def get_logs(self) -> list[dict[str, str]]:
        """Get all logged messages."""
        return self.messages


class EmailValidator:
    """Email validation implementation satisfying Validator protocol."""

    def __init__(self) -> None:
        self.errors: list[str] = []

    def validate(self, data: dict[str, Any]) -> bool:
        """Validate email format."""
        self.errors = []
        if "email" not in data:
            self.errors.append("Email field is required")
            return False
        email = data["email"]
        if "@" not in email or "." not in email:
            self.errors.append("Invalid email format")
            return False
        return True

    def get_errors(self) -> list[str]:
        """Get validation errors."""
        return self.errors


# ============================================================================
# GENERIC FUNCTIONS: Work with Any Protocol Implementation
# ============================================================================

def process_repository(repo: Repository, logger: Logger) -> None:
    """
    Process any repository using the Repository protocol.
    Type checker knows repo has get_all(), save(), etc.
    """
    logger.info(f"Processing repository with {repo.count() if hasattr(repo, 'count') else '?'} records")

    records = repo.get_all()
    logger.info(f"Found {len(records)} records")

    for record in records:
        logger.debug(f"Processing record: {record.get('name', 'Unknown')}")

    new_record = {"name": "David", "email": "david@company.com", "department": "HR"}
    id = repo.save(new_record)
    logger.info(f"Saved new record with ID {id}")


def validate_and_save(
    repo: Repository, validator: Validator, record: dict[str, Any], logger: Logger
) -> bool:
    """Validate before saving to any repository."""
    if not validator.validate(record):
        logger.error(f"Validation failed: {', '.join(validator.get_errors())}")
        return False

    repo.save(record)
    logger.info(f"Record saved successfully: {record}")
    return True


def count_records_in_any_source(source: DataSource) -> int:
    """Count records from any DataSource."""
    return source.count()


# ============================================================================
# RUNTIME CHECKING: isinstance() with Protocols
# ============================================================================

def demonstrate_protocol_checking(obj: Any) -> None:
    """
    Check if an object satisfies a protocol at runtime.
    Only works with @runtime_checkable protocols.
    """
    print(f"\nChecking {type(obj).__name__}:")

    if isinstance(obj, Repository):
        print(f"  [PASS] Satisfies Repository protocol")
        records = obj.get_all()
        print(f"    - Has {len(records)} records")

    if isinstance(obj, DataSource):
        print(f"  [PASS] Satisfies DataSource protocol")
        count = obj.count()
        print(f"    - Total count: {count}")

    if isinstance(obj, Logger):
        print(f"  [PASS] Satisfies Logger protocol")

    if isinstance(obj, Validator):
        print(f"  [PASS] Satisfies Validator protocol")


# ============================================================================
# MULTI-PROTOCOL USAGE
# ============================================================================

def create_data_pipeline(repo: Repository, logger: Logger, validator: Validator) -> None:
    """
    Create a data pipeline using multiple protocols.
    Each parameter can be ANY implementation of its protocol.
    """
    logger.info("Starting data pipeline")

    # Fetch data
    records = repo.get_all()
    logger.info(f"Loaded {len(records)} records from repository")

    # Validate and save
    for record in records:
        if validator.validate(record):
            repo.save(record)
            logger.debug(f"Validated and saved: {record.get('name')}")
        else:
            logger.error(f"Validation failed for {record}: {validator.get_errors()}")

    logger.info("Pipeline complete")


# ============================================================================
# MAIN: DEMONSTRATION
# ============================================================================

def main() -> None:
    """Execute protocol-based design demonstration."""

    print("\n" + "=" * 80)
    print("PROTOCOL-BASED DESIGN: Structural Typing with Contracts")
    print("=" * 80)

    # Initialize implementations
    sqlite_repo = SQLiteRepository()
    mongo_repo = MongoDBRepository()
    rest_repo = RESTAPIRepository()
    logger = SimpleLogger("app")
    validator = EmailValidator()

    print("\n[1] PROTOCOLS IN ACTION")
    print("-" * 80)
    print("All three repositories satisfy the Repository protocol,")
    print("but they have completely different internal implementations.")

    for repo in [sqlite_repo, mongo_repo, rest_repo]:
        demonstrate_protocol_checking(repo)

    print("\n[2] GENERIC FUNCTIONS WITH PROTOCOLS")
    print("-" * 80)

    print("\nUsing SQLite Repository:")
    process_repository(sqlite_repo, logger)

    print("\nUsing MongoDB Repository:")
    process_repository(mongo_repo, logger)

    print("\nUsing REST API Repository:")
    process_repository(rest_repo, logger)

    print("\n[3] VALIDATION WITH PROTOCOLS")
    print("-" * 80)

    valid_record = {"name": "Emma", "email": "emma@company.com", "department": "Product"}
    invalid_record = {"name": "Frank", "email": "invalid-email", "department": "Sales"}

    print("\nValidating and saving valid record:")
    validate_and_save(sqlite_repo, validator, valid_record, logger)

    print("\nValidating and saving invalid record:")
    validate_and_save(sqlite_repo, validator, invalid_record, logger)

    print("\n[4] DATA PIPELINE WITH MULTIPLE PROTOCOLS")
    print("-" * 80)
    print("\nRunning pipeline with SQLite + EmailValidator:")
    create_data_pipeline(sqlite_repo, logger, validator)

    print("\n[5] LOGGER OUTPUT")
    print("-" * 80)
    for entry in logger.get_logs():
        print(f"  [{entry['level']}] {entry['message']}")

    print("\n" + "=" * 80)
    print("PROTOCOLS VS ABSTRACT BASE CLASSES")
    print("=" * 80)
    print("""
PROTOCOLS (Structural Typing)
  + No inheritance required
  + Type checking without ABC
  + More flexible
  + Pythonic
  - No implementation sharing
  - Runtime checking needs @runtime_checkable

ABSTRACT BASE CLASSES (Nominal Typing)
  + Can share implementation via mixins
  + Guaranteed interface conformance
  + Can have abstract methods and properties
  - Requires explicit inheritance
  - Tighter coupling
  - Less flexible
    """)

    print("\n" + "=" * 80)
    print("BEST PRACTICES")
    print("=" * 80)
    print("""
[DO] Use Protocol for defining contracts.

[DO] Use @runtime_checkable for isinstance() checks.

[DO] Document the methods each protocol requires.

[DO] Use type hints with protocols for static checking.

[DO] Combine multiple protocols for complex requirements.

[DO] Test implementations against the protocol.

[DONT] Mix Protocol and ABC without good reason.

[DONT] Assume implementation just because isinstance() passes.

[DONT] Create protocols for every single interface.

[DONT] Forget that @runtime_checkable requires structural matching.
    """)

    print("\n" + "=" * 80)
    print("COMMON MISTAKES")
    print("=" * 80)
    print("""
MISTAKE 1: Forgetting @runtime_checkable
    BAD:  if isinstance(obj, MyProtocol):  # TypeError at runtime
    GOOD: @runtime_checkable
          class MyProtocol(Protocol):
              def method(self): ...

MISTAKE 2: Assuming protocol inheritance without it
    BAD:  class MyClass(DataSource):  # Does NOT work
    GOOD: class MyClass:  # Satisfies protocol structurally
              def query(self, sql): ...

MISTAKE 3: Type checking with non-@runtime_checkable protocol
    BAD:  @runtime_checkable not used
    GOOD: @runtime_checkable
          class MyProtocol(Protocol):
              pass

MISTAKE 4: Mixing nominal and structural typing
    BAD:  class Config(ABC): ...
          class MyClass(Config, Protocol): ...
    GOOD: Use one or the other consistently

MISTAKE 5: Not documenting protocol expectations
    BAD:  class MyProtocol(Protocol):
              def process(self):  # What should this return?
    GOOD: class MyProtocol(Protocol):
              def process(self) -> list[dict]:
                  # Process and return list of records
                  ...
    """)

    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS")
    print("=" * 80)
    print("""
Q1: What is a Protocol and how does it differ from ABC?
A1: Protocol enables STRUCTURAL typing (duck typing formalized).
    ABC uses NOMINAL typing (inheritance-based).
    Protocols don't require inheritance—if it has the methods, it works.

Q2: Why use @runtime_checkable?
A2: It allows isinstance() checks at runtime. Without it, you can only
    use protocols for static type checking with mypy/pyright.

Q3: Can protocols inherit from other protocols?
A3: Yes. Protocol(OtherProtocol) creates a protocol that requires all
    methods from both protocols.

Q4: What happens if a class doesn't fully satisfy a protocol?
A4: With @runtime_checkable, isinstance() still returns True if the
    required methods exist. Without it, type checkers flag the error.

Q5: Should I use Protocol or ABC?
A5: Use Protocol for defining flexible contracts and integration points.
    Use ABC for base classes with shared implementation or abstract methods.
    Many projects use both strategically.
    """)

    print("\n" + "=" * 80)
    print("CHALLENGE EXERCISE")
    print("=" * 80)
    print("""
Create a CacheRepository that:

1. Wraps any Repository implementation
2. Caches get_by_id() results
3. Invalidates cache on save() or delete()
4. Satisfies the Repository protocol
5. Works with any repository type (SQLite, MongoDB, REST)

Requirements:
    - Accept a Repository in __init__()
    - Implement all Repository protocol methods
    - Cache get_by_id() results
    - Invalidate cache on modifications
    - Measure cache hit/miss ratio

Example usage:
    sqlite = SQLiteRepository()
    cached = CacheRepository(sqlite)
    # cached.get_by_id(1) - hits sqlite
    # cached.get_by_id(1) - hits cache
    # cached.save({...}) - clears cache
    """)


if __name__ == "__main__":
    main()
