"""Factory Method Pattern: Subclass-Based Object Creation"""
from typing import Any
from abc import ABC, abstractmethod

class Document(ABC):
    """Abstract document class."""

    @abstractmethod
    def save(self) -> str:
        pass

class PDFDocument(Document):
    def save(self) -> str:
        return "[PDF] Document saved as PDF"

class WordDocument(Document):
    def save(self) -> str:
        return "[WORD] Document saved as DOCX"

class ExcelDocument(Document):
    def save(self) -> str:
        return "[EXCEL] Document saved as XLSX"

class DocumentCreator(ABC):
    """Abstract creator with factory method."""

    @abstractmethod
    def create_document(self) -> Document:
        """Factory method - subclasses implement this."""
        pass

    def process_document(self) -> str:
        """Uses the factory method."""
        doc = self.create_document()
        return doc.save()

class PDFCreator(DocumentCreator):
    def create_document(self) -> Document:
        print("[FACTORY] Creating PDF document")
        return PDFDocument()

class WordCreator(DocumentCreator):
    def create_document(self) -> Document:
        print("[FACTORY] Creating Word document")
        return WordDocument()

class ExcelCreator(DocumentCreator):
    def create_document(self) -> Document:
        print("[FACTORY] Creating Excel document")
        return ExcelDocument()

def main() -> None:
    print("\n" + "="*80)
    print("FACTORY METHOD PATTERN: Subclass-Based Creation")
    print("="*80)

    print("\n[1] FACTORY METHOD PATTERN")
    print("-"*80)

    creators = [PDFCreator(), WordCreator(), ExcelCreator()]

    for creator in creators:
        result = creator.process_document()
        print(f"  {result}")

    print("\n" + "="*80)
    print("FACTORY METHOD vs FACTORY PATTERN")
    print("="*80)
    print("""
FACTORY PATTERN:
  - Separate factory class
  - Single responsibility (creation)
  - Often uses static methods or registries

FACTORY METHOD PATTERN:
  - Abstract class with factory method
  - Subclasses override factory method
  - Integrates creation with processing
  - Uses inheritance

WHEN TO USE FACTORY METHOD:
  - Framework design
  - When subclasses need to choose what to create
  - Template method pattern variation

WHEN TO USE FACTORY PATTERN:
  - Simple object creation
  - Plugin registration
  - Configuration-driven creation
    """)

if __name__ == "__main__":
    main()
