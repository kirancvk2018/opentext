"""
================================================================================
Module:           06_object_wrapping.py
Topic:            Object Wrapping and Decorator Pattern
Problem:          Modifying object behavior by wrapping objects without
                  changing their class or inheritance structure.
Enterprise:       A logging framework needs to wrap database connections,
                  API clients, and cache objects to track operations
                  without modifying their implementations.
Objectives:       - Understand object wrapping
                  - Implement decorator pattern
                  - Use wrappers for cross-cutting concerns
                  - Maintain interface transparency
Prerequisites:    - Object-oriented programming basics
                  - Duck typing (Module 01)
================================================================================
"""

from typing import Any, Callable
from datetime import datetime
from functools import wraps
import json

# ============================================================================
# SAMPLE: Original Objects (No Modification)
# ============================================================================

class DatabaseConnection:
    """Original database connection (unchanged)."""

    def execute(self, query: str) -> list[dict[str, Any]]:
        """Execute a database query."""
        return [{"id": 1, "name": "Record1"}, {"id": 2, "name": "Record2"}]

    def close(self) -> None:
        """Close the connection."""
        pass


class APIClient:
    """Original API client (unchanged)."""

    def get(self, endpoint: str) -> dict[str, Any]:
        """GET request."""
        return {"status": "success", "data": {"message": "OK"}}

    def post(self, endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
        """POST request."""
        return {"status": "created", "id": 123}


class CacheStore:
    """Original cache (unchanged)."""

    def __init__(self) -> None:
        self.data: dict[str, Any] = {}

    def get(self, key: str) -> Any:
        """Get from cache."""
        return self.data.get(key)

    def set(self, key: str, value: Any) -> None:
        """Set in cache."""
        self.data[key] = value


# ============================================================================
# WRAPPER CLASSES: Add Behavior Without Modification
# ============================================================================

class LoggingDatabaseWrapper:
    """Wraps a database connection to add logging."""

    def __init__(self, db: DatabaseConnection) -> None:
        self.db = db
        self.log: list[dict[str, Any]] = []

    def execute(self, query: str) -> list[dict[str, Any]]:
        """Execute query with logging."""
        start = datetime.now()
        result = self.db.execute(query)
        elapsed = (datetime.now() - start).total_seconds()

        log_entry = {
            "timestamp": start.isoformat(),
            "query": query,
            "rows_returned": len(result),
            "duration_ms": elapsed * 1000,
        }
        self.log.append(log_entry)

        print(f"[DB] Query executed in {elapsed*1000:.2f}ms: {query[:50]}...")
        return result

    def close(self) -> None:
        """Close with logging."""
        print(f"[DB] Closed connection. Executed {len(self.log)} queries.")
        self.db.close()

    def get_log(self) -> list[dict[str, Any]]:
        """Get execution log."""
        return self.log


class TimingAPIWrapper:
    """Wraps an API client to measure request times."""

    def __init__(self, client: APIClient) -> None:
        self.client = client
        self.requests: list[dict[str, Any]] = []

    def get(self, endpoint: str) -> dict[str, Any]:
        """GET with timing."""
        start = datetime.now()
        result = self.client.get(endpoint)
        elapsed = (datetime.now() - start).total_seconds()

        self.requests.append({
            "method": "GET",
            "endpoint": endpoint,
            "duration_ms": elapsed * 1000,
            "status": result.get("status"),
        })

        print(f"[API] GET {endpoint} in {elapsed*1000:.2f}ms")
        return result

    def post(self, endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
        """POST with timing."""
        start = datetime.now()
        result = self.client.post(endpoint, data)
        elapsed = (datetime.now() - start).total_seconds()

        self.requests.append({
            "method": "POST",
            "endpoint": endpoint,
            "duration_ms": elapsed * 1000,
            "status": result.get("status"),
        })

        print(f"[API] POST {endpoint} in {elapsed*1000:.2f}ms")
        return result

    def get_statistics(self) -> dict[str, Any]:
        """Get request statistics."""
        if not self.requests:
            return {}
        durations = [r["duration_ms"] for r in self.requests]
        return {
            "total_requests": len(self.requests),
            "avg_duration_ms": sum(durations) / len(durations),
            "max_duration_ms": max(durations),
            "min_duration_ms": min(durations),
        }


class CachingAPIWrapper:
    """Wraps an API client to add caching."""

    def __init__(self, client: APIClient, cache: CacheStore) -> None:
        self.client = client
        self.cache = cache
        self.hits = 0
        self.misses = 0

    def get(self, endpoint: str) -> dict[str, Any]:
        """GET with caching."""
        cache_key = f"get_{endpoint}"
        cached = self.cache.get(cache_key)

        if cached:
            print(f"[CACHE] HIT for {endpoint}")
            self.hits += 1
            return cached

        print(f"[CACHE] MISS for {endpoint}")
        result = self.client.get(endpoint)
        self.cache.set(cache_key, result)
        self.misses += 1
        return result

    def get_stats(self) -> dict[str, int]:
        """Get cache statistics."""
        total = self.hits + self.misses
        return {
            "hits": self.hits,
            "misses": self.misses,
            "total": total,
            "hit_rate": self.hits / total if total > 0 else 0,
        }


class CacheWithTTLWrapper:
    """Wraps a cache with TTL (time-to-live) support."""

    def __init__(self, cache: CacheStore, ttl_seconds: int = 60) -> None:
        self.cache = cache
        self.ttl_seconds = ttl_seconds
        self.timestamps: dict[str, float] = {}

    def get(self, key: str) -> Any:
        """Get with TTL check."""
        if key not in self.cache.data:
            return None

        timestamp = self.timestamps.get(key, 0)
        elapsed = datetime.now().timestamp() - timestamp

        if elapsed > self.ttl_seconds:
            print(f"[TTL] Expired: {key}")
            del self.cache.data[key]
            del self.timestamps[key]
            return None

        print(f"[TTL] Valid: {key} ({elapsed:.1f}s old)")
        return self.cache.get(key)

    def set(self, key: str, value: Any) -> None:
        """Set with timestamp."""
        self.cache.set(key, value)
        self.timestamps[key] = datetime.now().timestamp()
        print(f"[TTL] Set: {key}")


# ============================================================================
# FUNCTION WRAPPING DECORATOR
# ============================================================================

def timing_wrapper(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that times function execution."""
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = datetime.now()
        result = fn(*args, **kwargs)
        elapsed = (datetime.now() - start).total_seconds()
        print(f"[TIMING] {fn.__name__} took {elapsed*1000:.2f}ms")
        return result
    return wrapper


def validation_wrapper(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that validates arguments."""
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        print(f"[VALIDATE] Calling {fn.__name__} with {len(args)} args, {len(kwargs)} kwargs")
        result = fn(*args, **kwargs)
        print(f"[VALIDATE] Returned {type(result).__name__}")
        return result
    return wrapper


def error_handling_wrapper(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that handles errors gracefully."""
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            print(f"[ERROR] {fn.__name__} raised {type(e).__name__}: {e}")
            return None
    return wrapper


# ============================================================================
# COMPOSABLE WRAPPERS
# ============================================================================

def compose_wrappers(*wrapper_classes: type) -> Callable[[Any], Any]:
    """Create a function that wraps objects with multiple wrappers."""
    def composite_wrapper(obj: Any) -> Any:
        result = obj
        for wrapper_class in wrapper_classes:
            result = wrapper_class(result)
        return result
    return composite_wrapper


# ============================================================================
# MAIN: DEMONSTRATION
# ============================================================================

def main() -> None:
    """Execute object wrapping demonstration."""

    print("\n" + "=" * 80)
    print("OBJECT WRAPPING: Decorator Pattern")
    print("=" * 80)

    print("\n[1] BASIC OBJECT WRAPPING")
    print("-" * 80)

    # Original object
    db = DatabaseConnection()
    result1 = db.execute("SELECT * FROM users")
    print(f"Direct call result: {result1}")

    # Wrapped object
    print("\nWith logging wrapper:")
    wrapped_db = LoggingDatabaseWrapper(db)
    result2 = wrapped_db.execute("SELECT * FROM users")
    result3 = wrapped_db.execute("SELECT * FROM orders")
    wrapped_db.close()

    print(f"\nExecution log:")
    for entry in wrapped_db.get_log():
        print(f"  {entry}")

    print("\n[2] TIMING WRAPPER FOR API CLIENT")
    print("-" * 80)

    client = APIClient()
    wrapped_client = TimingAPIWrapper(client)

    wrapped_client.get("/users")
    wrapped_client.post("/users", {"name": "Alice"})
    wrapped_client.get("/orders")

    stats = wrapped_client.get_statistics()
    print(f"\nAPI Statistics: {json.dumps(stats, indent=2)}")

    print("\n[3] CACHING WRAPPER")
    print("-" * 80)

    cache = CacheStore()
    cached_client = CachingAPIWrapper(client, cache)

    print("First call (cache miss):")
    cached_client.get("/data")

    print("\nSecond call (cache hit):")
    cached_client.get("/data")

    print("\nThird call (cache hit):")
    cached_client.get("/data")

    cache_stats = cached_client.get_stats()
    print(f"Cache stats: {json.dumps(cache_stats, indent=2)}")

    print("\n[4] TTL WRAPPER")
    print("-" * 80)

    cache2 = CacheStore()
    ttl_cache = CacheWithTTLWrapper(cache2, ttl_seconds=2)

    ttl_cache.set("key1", "value1")
    print("Getting valid key:")
    ttl_cache.get("key1")

    print("\nGetting expired key (simulated):")
    ttl_cache.ttl_seconds = 0
    ttl_cache.get("key1")

    print("\n[5] FUNCTION DECORATORS")
    print("-" * 80)

    @timing_wrapper
    @validation_wrapper
    def process_data(data: list[int]) -> int:
        """Process data and return sum."""
        return sum(data)

    print("Calling decorated function:")
    result = process_data([1, 2, 3, 4, 5])
    print(f"Result: {result}")

    print("\n[6] MULTI-LAYER WRAPPING")
    print("-" * 80)

    client2 = APIClient()
    cache3 = CacheStore()

    print("Applying multiple wrappers:")
    wrapped = TimingAPIWrapper(CachingAPIWrapper(client2, cache3))

    print("\nFirst request (cache miss, timer):")
    wrapped.get("/api/data")

    print("\nSecond request (cache hit, still timer):")
    wrapped.get("/api/data")

    print("\n[7] WRAPPER TRANSPARENCY")
    print("-" * 80)

    print("Original method works the same through wrapper:")
    db_original = DatabaseConnection()
    db_wrapped = LoggingDatabaseWrapper(db_original)

    # Both have the same interface
    print(f"Original has 'execute': {hasattr(db_original, 'execute')}")
    print(f"Wrapped has 'execute': {hasattr(db_wrapped, 'execute')}")

    print("\n" + "=" * 80)
    print("WRAPPING PATTERNS")
    print("=" * 80)
    print("""
PATTERN 1: Logging Wrapper
  - Track method calls and results
  + Easy to implement
  - Adds memory overhead

PATTERN 2: Timing Wrapper
  - Measure performance
  + Identify bottlenecks
  - Small overhead

PATTERN 3: Caching Wrapper
  - Cache results
  + Improves performance
  - Invalidation complexity

PATTERN 4: Validation Wrapper
  - Validate inputs/outputs
  + Fail fast
  - Adds overhead

PATTERN 5: Function Decorator
  - Modify function behavior
  + Uses functools.wraps
  - Can hide stack traces
    """)

    print("\n" + "=" * 80)
    print("BEST PRACTICES")
    print("=" * 80)
    print("""
[DO] Keep wrapper interface compatible with wrapped object.

[DO] Use functools.wraps for function decorators.

[DO] Document what the wrapper adds.

[DO] Make wrappers composable (can wrap a wrapper).

[DO] Provide access to wrapped object if needed.

[DO] Test wrappers independently.

[DONT] Wrap too many layers (becomes complex).

[DONT] Hide the wrapper from the developer.

[DONT] Break the original interface.

[DONT] Store state in wrappers that belongs in wrapped object.
    """)

    print("\n" + "=" * 80)
    print("COMMON MISTAKES")
    print("=" * 80)
    print("""
MISTAKE 1: Not using functools.wraps
    BAD:  def decorator(fn):
              def wrapper(*args):
                  return fn(*args)
              return wrapper  # Loses fn.__name__, __doc__, etc.
    GOOD: @wraps(fn)
          def wrapper(*args):
              return fn(*args)

MISTAKE 2: Changing the interface
    BAD:  wrapper.new_method()  # Wrapped object doesn't have this
    GOOD: Keep same interface as wrapped object

MISTAKE 3: Hiding the wrapped object
    BAD:  wrapper.data = wrapped_obj
    GOOD: wrapper.__wrapped__ = wrapped_obj  # Standard convention

MISTAKE 4: Not handling all methods
    BAD:  Wrap only some methods
    GOOD: Proxy all methods (use __getattr__)

MISTAKE 5: Performance overhead from wrapping
    BAD:  Wrap everything (10 layers deep)
    GOOD: Be selective about what you wrap
    """)

    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS")
    print("=" * 80)
    print("""
Q1: What is the decorator pattern?
A1: A structural pattern that wraps objects to add behavior
    without modifying the original class.

Q2: How does wrapping differ from inheritance?
A2: Wrapping uses composition (has-a) while inheritance uses (is-a).
    Wrapping is more flexible; inheritance is simpler.

Q3: What's the difference between a wrapper and a decorator?
A3: Decorators modify function behavior; wrappers modify object behavior.
    Conceptually similar, different contexts.

Q4: How do you handle methods not defined in the wrapper?
A4: Use __getattr__ to forward unknown attributes to the wrapped object.

Q5: What's the performance cost of wrapping?
A5: Each wrapper adds a method call. Multiple wrappers can add up.
    Profile to measure the actual impact.
    """)

    print("\n" + "=" * 80)
    print("CHALLENGE EXERCISE")
    print("=" * 80)
    print("""
Build a RateLimitingWrapper that:

1. Wraps any API client
2. Enforces rate limits (e.g., 10 requests per minute)
3. Queues requests that exceed the limit
4. Provides retry logic
5. Tracks statistics

Requirements:
    - Accept max_requests and time_window_seconds
    - Block or queue requests that exceed limit
    - Provide get_stats() method
    - Work with any object (duck typing)

Example usage:
    client = APIClient()
    rate_limited = RateLimitingWrapper(client, max_requests=10, time_window_seconds=60)
    # First 10 requests execute immediately
    # Request 11 waits until 1 minute has passed
    """)


if __name__ == "__main__":
    main()
