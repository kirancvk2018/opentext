"""Descriptors: Attribute Access Control via __get__, __set__, __delete__"""
from typing import Any, Optional

class Descriptor:
    """Basic descriptor protocol example."""

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> Any:
        print("[DESCRIPTOR] __get__ called")
        if obj is None:
            return self
        return getattr(obj, "_value", None)

    def __set__(self, obj: Any, value: Any) -> None:
        print(f"[DESCRIPTOR] __set__ called with {value}")
        obj._value = value

    def __delete__(self, obj: Any) -> None:
        print("[DESCRIPTOR] __delete__ called")
        del obj._value

class Validated:
    """Descriptor that validates values."""

    def __init__(self, validator: callable) -> None:
        self.validator = validator

    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> Any:
        if obj is None:
            return self
        return obj.__dict__.get(self.name, None)

    def __set__(self, obj: Any, value: Any) -> None:
        if not self.validator(value):
            raise ValueError(f"Invalid value for {self.name}: {value}")
        obj.__dict__[self.name] = value

class User:
    """Class using descriptors."""

    age = Validated(lambda x: 0 < x < 150)
    email = Validated(lambda x: "@" in x and "." in x)

    def __init__(self, name: str, age: int, email: str) -> None:
        self.name = name
        self.age = age
        self.email = email

class Document:
    """Descriptor example with caching."""

    def __init__(self, default: str = "") -> None:
        self.default = default
        self.cache: dict[int, str] = {}

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> Any:
        if obj is None:
            return self
        obj_id = id(obj)
        if obj_id not in self.cache:
            print(f"[CACHE] MISS for document")
            self.cache[obj_id] = self.default
        else:
            print(f"[CACHE] HIT for document")
        return self.cache[obj_id]

    def __set__(self, obj: Any, value: str) -> None:
        self.cache[id(obj)] = value

class Note:
    content = Document("Empty note")

def main() -> None:
    print("\n" + "="*80)
    print("DESCRIPTORS: Fine-Grained Attribute Control")
    print("="*80)

    print("\n[1] BASIC DESCRIPTOR")
    print("-"*80)

    class Example:
        attr = Descriptor()

    ex = Example()
    print("Setting value:")
    ex.attr = "Hello"
    print("Getting value:")
    value = ex.attr

    print("\n[2] VALIDATION DESCRIPTOR")
    print("-"*80)

    try:
        user = User("Alice", 30, "alice@company.com")
        print(f"User created: {user.name}, {user.age}, {user.email}")
    except ValueError as e:
        print(f"Error: {e}")

    try:
        print("Trying invalid age:")
        user.age = 200
    except ValueError as e:
        print(f"Error: {e}")

    print("\n[3] CACHING DESCRIPTOR")
    print("-"*80)

    note = Note()
    print("First access:")
    content1 = note.content
    print("Second access:")
    content2 = note.content

    print("\n[4] DESCRIPTOR AS CLASS ATTRIBUTE")
    print("-"*80)

    print(f"Accessing descriptor from class: {User.age}")
    print(f"Type: {type(User.age)}")

    print("\n" + "="*80)
    print("DESCRIPTOR PROTOCOL")
    print("="*80)
    print("""
__get__(self, obj, objtype=None)
  - Called when attribute is accessed
  - obj is instance (None when accessed from class)
  - Return the value

__set__(self, obj, value)
  - Called when attribute is assigned
  - Validate or transform value
  - Store in obj.__dict__ or elsewhere

__set_name__(self, owner, name)
  - Called when descriptor is assigned to class
  - Store the attribute name for later use

__delete__(self, obj)
  - Called when attribute is deleted
  - Clean up resources

Use Cases:
  - Lazy evaluation
  - Validation
  - Computed properties
  - Type conversion
  - Access logging
  - Caching
  - Permission control
    """)

if __name__ == "__main__":
    main()
