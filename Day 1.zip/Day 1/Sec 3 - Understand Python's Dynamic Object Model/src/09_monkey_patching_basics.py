"""Monkey Patching: Runtime Modification of Code"""
from typing import Any

class Logger:
    def log(self, message: str) -> None:
        print(f"[LOG] {message}")

def add_timestamp(self: Logger, message: str) -> None:
    """Enhanced logging with timestamps."""
    from datetime import datetime
    timestamp = datetime.now().isoformat()
    print(f"[LOG] {timestamp} - {message}")

class Calculator:
    def add(self, a: int, b: int) -> int:
        return a + b

def bugged_add(self: Calculator, a: int, b: int) -> int:
    """Intentionally broken add."""
    return a + b + 1  # Off by one

def safe_add(self: Calculator, a: int, b: int) -> int:
    """Fixed add."""
    return a + b

def main() -> None:
    print("\n" + "="*80)
    print("MONKEY PATCHING: Modifying Code at Runtime")
    print("="*80)

    print("\n[1] BASIC MONKEY PATCHING")
    print("-"*80)

    logger = Logger()
    print("Before patching:")
    logger.log("Test message")

    print("\nMonkey patching the log method:")
    Logger.log = add_timestamp
    logger.log("Test message after patching")

    print("\n[2] FUNCTION REPLACEMENT (Hotfix)")
    print("-"*80)

    calc = Calculator()
    print(f"Before patching: 5 + 3 = {calc.add(5, 3)}")

    print("\nMonkey patching with buggy version:")
    original_add = Calculator.add
    Calculator.add = bugged_add
    print(f"After patching: 5 + 3 = {calc.add(5, 3)}")

    print("\nMonkey patching with fixed version:")
    Calculator.add = safe_add
    print(f"After fixing: 5 + 3 = {calc.add(5, 3)}")

    print("\n[3] ADDING NEW METHODS")
    print("-"*80)

    def multiply(self: Calculator, a: int, b: int) -> int:
        return a * b

    print("Adding multiply method to Calculator:")
    Calculator.multiply = multiply
    print(f"5 * 3 = {calc.multiply(5, 3)}")

    print("\n[4] MONKEY PATCHING THIRD-PARTY MODULES")
    print("-"*80)

    import json
    original_dumps = json.dumps

    def enhanced_dumps(obj: Any, indent: int = 2, **kwargs: Any) -> str:
        print(f"[PATCH] Dumping object of type {type(obj).__name__}")
        return original_dumps(obj, indent=indent, **kwargs)

    json.dumps = enhanced_dumps
    result = json.dumps({"name": "Alice", "age": 30})
    print(f"Result: {result}")

    print("\n" + "="*80)
    print("MONKEY PATCHING GUIDELINES")
    print("="*80)
    print("""
WHEN TO USE:
  + Hotfixes in production
  + Testing (mocking)
  + Temporary behavior override
  + Backward compatibility shims

WHEN NOT TO USE:
  - Regular code (use inheritance/composition)
  - Permanent changes (modify source)
  - Complex behavior (use decorators)

RISKS:
  - Code becomes hard to understand
  - Stack traces become confusing
  - Conflicts with other patches
  - Breaks IDE analysis

BEST PRACTICES:
  [DO] Document monkey patches clearly
  [DO] Make patches reversible
  [DO] Use for testing/debugging only
  [DO] Name patches descriptively
  [DONT] Patch third-party code in production
  [DONT] Patch multiple related methods
  [DONT] Make unpredictable changes
    """)

if __name__ == "__main__":
    main()
