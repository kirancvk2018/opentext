"""Adapter Pattern: Integrate Incompatible Interfaces"""
from typing import Any, Dict
import json

class LegacyPaymentAPI:
    """Old payment system with incompatible interface."""
    def charge_account(self, account_id: str, amount_cents: int) -> bool:
        print(f"[LEGACY] Charging account {account_id} for {amount_cents} cents")
        return True

class ModernPaymentInterface:
    """Modern interface we want to use."""
    def process_payment(self, card_token: str, amount_dollars: float) -> Dict[str, Any]:
        pass

class PaymentAdapter(ModernPaymentInterface):
    """Adapt legacy API to modern interface."""
    def __init__(self, legacy_api: LegacyPaymentAPI):
        self.legacy = legacy_api

    def process_payment(self, card_token: str, amount_dollars: float) -> Dict[str, Any]:
        cents = int(amount_dollars * 100)
        success = self.legacy.charge_account(card_token, cents)
        return {"success": success, "amount": amount_dollars}

# XML to JSON Adapter
class XMLDataSource:
    """Returns XML data."""
    def get_data(self) -> str:
        return "<root><user><name>Alice</name></user></root>"

class JSONDataSource:
    """Expected JSON interface."""
    def get_data(self) -> Dict[str, Any]:
        pass

class XMLtoJSONAdapter(JSONDataSource):
    """Adapt XML to JSON."""
    def __init__(self, xml_source: XMLDataSource):
        self.xml_source = xml_source

    def get_data(self) -> Dict[str, Any]:
        xml_str = self.xml_source.get_data()
        return {"data": xml_str, "format": "json"}

def main() -> None:
    print("\n" + "="*80)
    print("ADAPTER PATTERN: Integrating Incompatible Interfaces")
    print("="*80)

    print("\n[1] PAYMENT API ADAPTER")
    print("-"*80)
    legacy = LegacyPaymentAPI()
    adapter = PaymentAdapter(legacy)
    result = adapter.process_payment("tok_visa_4242", 99.99)
    print(f"Result: {json.dumps(result, indent=2)}")

    print("\n[2] DATA FORMAT ADAPTER")
    print("-"*80)
    xml_source = XMLDataSource()
    json_adapter = XMLtoJSONAdapter(xml_source)
    data = json_adapter.get_data()
    print(f"JSON data: {json.dumps(data, indent=2)}")

    print("\n" + "="*80)
    print("KEY CONCEPTS")
    print("="*80)
    print("""
ADAPTER converts incompatible interface to compatible one:
  - Wraps incompatible object
  - Implements target interface
  - Translates calls between interfaces

When to use:
  - Integrating legacy systems
  - Third-party library incompatibility
  - Different data formats

vs Decorator:
  - Decorator adds behavior
  - Adapter changes interface
    """)

if __name__ == "__main__":
    main()
