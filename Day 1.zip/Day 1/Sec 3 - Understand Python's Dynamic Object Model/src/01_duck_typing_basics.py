"""
================================================================================
Module:           01_duck_typing_basics.py
Topic:            Duck Typing and Polymorphism Without Inheritance
Problem:          Implementing flexible payment processing across multiple
                  providers without rigid class hierarchies.
Enterprise:       A SaaS platform needs to support Stripe, PayPal, Square, and
                  custom payment gateways. Each provider has different APIs,
                  but the platform should treat them uniformly.
Objectives:       - Understand duck typing principles
                  - Implement polymorphism without inheritance
                  - Build flexible, extensible systems
                  - Use composition over inheritance
Prerequisites:    - Basic Python classes and methods
                  - Understanding of interfaces (conceptual)
                  - OOP fundamentals
================================================================================
"""

from typing import Any, Callable
from abc import ABC
import json
from datetime import datetime


# ============================================================================
# PROBLEM STATEMENT
# ============================================================================
# Different payment providers have incompatible APIs:
# - Stripe uses: transaction.process(amount, card_token)
# - PayPal uses: payment.execute(amount, payer_id)
# - Square uses: client.charge(amount, source_id)
#
# We need a unified interface without forcing inheritance.
# This is where duck typing shines!


# ============================================================================
# SAMPLE DATA
# ============================================================================

SAMPLE_TRANSACTIONS = [
    {"id": "txn_001", "amount": 99.99, "currency": "USD", "customer": "acme_corp"},
    {"id": "txn_002", "amount": 1500.00, "currency": "USD", "customer": "tech_startup"},
    {"id": "txn_003", "amount": 45.50, "currency": "USD", "customer": "small_biz"},
]

SAMPLE_CUSTOMER = {
    "id": "cust_12345",
    "name": "Acme Corporation",
    "email": "billing@acme.com",
    "country": "US",
}


# ============================================================================
# IMPLEMENTATION: MULTIPLE PAYMENT PROVIDERS
# ============================================================================

class StripeGateway:
    """
    Stripe payment gateway implementation.
    Note: No inheritance. This class exists on its own.
    """

    def __init__(self, api_key: str) -> None:
        self.api_key = api_key
        self.name = "Stripe"
        self.transactions: list[dict[str, Any]] = []

    def process(self, amount: float, token: str) -> dict[str, Any]:
        """
        Process payment using Stripe's method signature.

        Args:
            amount: Payment amount in USD
            token: Tokenized card from Stripe.js

        Returns:
            Transaction result dictionary
        """
        transaction = {
            "provider": self.name,
            "amount": amount,
            "token": token,
            "status": "success",
            "timestamp": datetime.now().isoformat(),
            "charge_id": f"ch_{len(self.transactions) + 1}",
        }
        self.transactions.append(transaction)
        return transaction

    def refund(self, charge_id: str) -> dict[str, Any]:
        """Refund a Stripe charge."""
        return {
            "provider": self.name,
            "charge_id": charge_id,
            "status": "refunded",
            "timestamp": datetime.now().isoformat(),
        }


class PayPalGateway:
    """
    PayPal payment gateway implementation.
    Different method signature, same intent.
    """

    def __init__(self, client_id: str, client_secret: str) -> None:
        self.client_id = client_id
        self.client_secret = client_secret
        self.name = "PayPal"
        self.payments: list[dict[str, Any]] = []

    def execute(self, amount: float, payer_id: str) -> dict[str, Any]:
        """
        Execute payment using PayPal's method signature.

        Args:
            amount: Payment amount
            payer_id: PayPal payer ID

        Returns:
            Payment result dictionary
        """
        payment = {
            "provider": self.name,
            "amount": amount,
            "payer_id": payer_id,
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "sale_id": f"SALE-{len(self.payments) + 1}",
        }
        self.payments.append(payment)
        return payment

    def get_payment_details(self, sale_id: str) -> dict[str, Any]:
        """Get details of a PayPal sale."""
        return {"provider": self.name, "sale_id": sale_id, "status": "completed"}


class SquareGateway:
    """
    Square payment gateway implementation.
    Yet another different API style.
    """

    def __init__(self, access_token: str) -> None:
        self.access_token = access_token
        self.name = "Square"
        self.charges: list[dict[str, Any]] = []

    def charge(self, amount: float, source_id: str, idempotency_key: str = "") -> dict[str, Any]:
        """
        Charge using Square's method signature.

        Args:
            amount: Amount in cents
            source_id: Square source identifier
            idempotency_key: Unique key for idempotency

        Returns:
            Charge result dictionary
        """
        charge = {
            "provider": self.name,
            "amount": amount / 100,  # Square uses cents
            "source_id": source_id,
            "status": "succeeded",
            "timestamp": datetime.now().isoformat(),
            "transaction_id": f"txn_{len(self.charges) + 1}",
        }
        self.charges.append(charge)
        return charge

    def retrieve_charge(self, transaction_id: str) -> dict[str, Any]:
        """Retrieve a Square charge."""
        return {"provider": self.name, "transaction_id": transaction_id, "status": "succeeded"}


# ============================================================================
# UNIFIED PROCESSOR (Duck Typing in Action)
# ============================================================================

class PaymentProcessor:
    """
    Process payments using ANY gateway that "quacks like a payment gateway."
    No inheritance required—duck typing handles this elegantly.
    """

    def __init__(self, gateway: Any) -> None:
        """
        Initialize with any payment gateway.

        Args:
            gateway: Any object that has methods for payment processing.
                     The specific type doesn't matter!
        """
        self.gateway = gateway
        self.audit_log: list[dict[str, Any]] = []

    def process_payment(self, amount: float, payment_detail: str) -> dict[str, Any]:
        """
        Process a payment using the underlying gateway's methods.
        This method DOESN'T KNOW which gateway it's using—it just
        tries different methods until one works.

        Args:
            amount: Payment amount
            payment_detail: Gateway-specific payment identifier

        Returns:
            Transaction result
        """

        # Try Stripe's method
        if hasattr(self.gateway, "process") and callable(self.gateway.process):
            result = self.gateway.process(amount, payment_detail)
        # Try PayPal's method
        elif hasattr(self.gateway, "execute") and callable(self.gateway.execute):
            result = self.gateway.execute(amount, payment_detail)
        # Try Square's method
        elif hasattr(self.gateway, "charge") and callable(self.gateway.charge):
            result = self.gateway.charge(int(amount * 100), payment_detail)
        else:
            raise ValueError(
                f"Gateway {type(self.gateway).__name__} does not support "
                "process(), execute(), or charge() methods"
            )

        # Log the transaction
        self.audit_log.append(
            {
                "gateway": self.gateway.name,
                "amount": amount,
                "status": result.get("status"),
                "timestamp": datetime.now().isoformat(),
            }
        )

        return result

    def get_audit_log(self) -> list[dict[str, Any]]:
        """Return the audit log of all transactions."""
        return self.audit_log


# ============================================================================
# ADVANCED APPROACH: Strategy Pattern (More Elegant)
# ============================================================================

class PaymentStrategy:
    """
    Base class showing the duck typing contract.
    This is documentation—not a requirement for subclassing.
    """

    def process_payment(self, amount: float, payment_detail: str) -> dict[str, Any]:
        """Process a payment. Subclasses implement this."""
        raise NotImplementedError


class StripeStrategy:
    """Strategy for Stripe."""

    def __init__(self, gateway: StripeGateway) -> None:
        self.gateway = gateway

    def process_payment(self, amount: float, payment_detail: str) -> dict[str, Any]:
        """Adapt Stripe's process() to our standard interface."""
        return self.gateway.process(amount, payment_detail)


class PayPalStrategy:
    """Strategy for PayPal."""

    def __init__(self, gateway: PayPalGateway) -> None:
        self.gateway = gateway

    def process_payment(self, amount: float, payment_detail: str) -> dict[str, Any]:
        """Adapt PayPal's execute() to our standard interface."""
        return self.gateway.execute(amount, payment_detail)


class SquareStrategy:
    """Strategy for Square."""

    def __init__(self, gateway: SquareGateway) -> None:
        self.gateway = gateway

    def process_payment(self, amount: float, payment_detail: str) -> dict[str, Any]:
        """Adapt Square's charge() to our standard interface."""
        return self.gateway.charge(int(amount * 100), payment_detail)


class UnifiedPaymentProcessor:
    """
    More elegant processor using strategies.
    Requires the strategy to implement process_payment().
    """

    def __init__(self, strategy: Any) -> None:
        self.strategy = strategy
        self.transactions: list[dict[str, Any]] = []

    def pay(self, amount: float, payment_detail: str) -> dict[str, Any]:
        """
        Process payment through the strategy.
        Duck typing: we just call process_payment(), trust it exists.
        """
        result = self.strategy.process_payment(amount, payment_detail)
        self.transactions.append(result)
        return result

    def get_transaction_count(self) -> int:
        """Get number of transactions processed."""
        return len(self.transactions)


# ============================================================================
# DUCK TYPING WITH CALLBACKS
# ============================================================================

def process_with_callback(
    amount: float,
    payment_detail: str,
    gateway: Any,
    on_success: Callable[[dict[str, Any]], None] | None = None,
    on_failure: Callable[[Exception], None] | None = None,
) -> dict[str, Any]:
    """
    Process a payment with callbacks for success/failure.
    The gateway can be ANY object as long as it "quacks like" a payment processor.

    Args:
        amount: Payment amount
        payment_detail: Payment identifier
        gateway: Any payment gateway
        on_success: Callback on success
        on_failure: Callback on failure

    Returns:
        Transaction result
    """
    try:
        # Try different method names—duck typing in action
        if hasattr(gateway, "process"):
            result = gateway.process(amount, payment_detail)
        elif hasattr(gateway, "execute"):
            result = gateway.execute(amount, payment_detail)
        elif hasattr(gateway, "charge"):
            result = gateway.charge(int(amount * 100), payment_detail)
        else:
            raise AttributeError(f"No payment method found on {type(gateway).__name__}")

        if on_success:
            on_success(result)
        return result

    except Exception as e:
        if on_failure:
            on_failure(e)
        raise


# ============================================================================
# MAIN: DEMONSTRATION
# ============================================================================

def main() -> None:
    """Execute duck typing demonstration."""

    print("\n" + "=" * 80)
    print("DUCK TYPING BASICS: Polymorphism Without Inheritance")
    print("=" * 80)

    # Initialize gateways
    stripe = StripeGateway("sk_live_abc123")
    paypal = PayPalGateway("client_id", "client_secret")
    square = SquareGateway("sq_access_token_xyz")

    print("\n[1] BASIC DUCK TYPING: PaymentProcessor")
    print("-" * 80)

    # Process with Stripe
    processor_stripe = PaymentProcessor(stripe)
    result1 = processor_stripe.process_payment(99.99, "tok_visa_4242")
    print(f"Stripe: {json.dumps(result1, indent=2)}")

    # Process with PayPal (same processor, different gateway!)
    processor_paypal = PaymentProcessor(paypal)
    result2 = processor_paypal.process_payment(150.00, "payer_12345")
    print(f"PayPal: {json.dumps(result2, indent=2)}")

    # Process with Square
    processor_square = PaymentProcessor(square)
    result3 = processor_square.process_payment(75.50, "cnon_cbsq_5_6uZbvvvvvvvvvv")
    print(f"Square: {json.dumps(result3, indent=2)}")

    print("\n[2] STRATEGY PATTERN: Unified Interface")
    print("-" * 80)

    # Create strategies
    stripe_strategy = StripeStrategy(stripe)
    paypal_strategy = PayPalStrategy(paypal)
    square_strategy = SquareStrategy(square)

    # Use unified processor
    unified = UnifiedPaymentProcessor(stripe_strategy)
    unified.pay(100.00, "tok_visa_5555")
    unified.pay(200.00, "tok_visa_6666")
    print(f"Stripe transactions: {unified.get_transaction_count()}")

    unified_paypal = UnifiedPaymentProcessor(paypal_strategy)
    unified_paypal.pay(500.00, "payer_67890")
    print(f"PayPal transactions: {unified_paypal.get_transaction_count()}")

    print("\n[3] CALLBACKS WITH DUCK TYPING")
    print("-" * 80)

    def success_handler(result: dict[str, Any]) -> None:
        """Handle successful payment."""
        print(f"[SUCCESS] Payment succeeded: {result.get('amount')} USD")

    def failure_handler(error: Exception) -> None:
        """Handle payment failure."""
        print(f"[FAILED] Payment failed: {str(error)}")

    # Process with callbacks
    print("Processing with Stripe:")
    process_with_callback(250.00, "tok_visa_9999", stripe, success_handler, failure_handler)

    print("\nProcessing with PayPal:")
    process_with_callback(300.00, "payer_11111", paypal, success_handler, failure_handler)

    print("\n[4] AUDIT TRAIL")
    print("-" * 80)
    audit = processor_stripe.get_audit_log()
    for entry in audit:
        print(f"  {entry['gateway']}: ${entry['amount']} - {entry['status']}")

    print("\n" + "=" * 80)
    print("WHY DUCK TYPING MATTERS")
    print("=" * 80)
    print("""
1. FLEXIBILITY: Add new payment providers without modifying existing code.

2. SIMPLICITY: No complex inheritance hierarchies or abstract base classes.

3. TESTABILITY: Easy to create mock gateways for testing.

4. PYTHONIC: "If it walks like a duck and quacks like a duck, it's a duck."

5. DECOUPLING: The processor doesn't care about gateway implementation.

6. EXTENSIBILITY: Users can provide their own gateway implementations.

7. DYNAMIC: The type system doesn't get in your way.
    """)

    print("\n" + "=" * 80)
    print("BEST PRACTICES")
    print("=" * 80)
    print("""
[DO] Use duck typing for flexible, plugin-based architectures.

[DO] Document the expected "contract" (methods and signatures).

[DO] Use hasattr() and callable() to check for method existence.

[DO] Prefer composition over inheritance.

[DO] Provide callbacks for extensibility.

[DO] Use type hints to clarify expectations (even with duck typing).

[DO] Test with multiple implementations to ensure flexibility.

[DONT] Assume method existence without checking.

[DONT] Create overly complex inheritance hierarchies.

[DONT] Use duck typing to hide poor design.

[DONT] Forget to document the expected interface.
    """)

    print("\n" + "=" * 80)
    print("COMMON MISTAKES")
    print("=" * 80)
    print("""
MISTAKE 1: Not checking for method existence
    BAD:  result = gateway.process(amount, token)  # Crashes if no method
    GOOD: if hasattr(gateway, 'process'): result = gateway.process(amount, token)

MISTAKE 2: Mixing different payment methods in the same code
    BAD:  processor.process(amount, 'token')  # Works Stripe, fails PayPal
    GOOD: Use strategy pattern or adapter to normalize interfaces

MISTAKE 3: Assuming all gateways behave the same way
    BAD:  for gw in [stripe, paypal, square]:
            gw.process(amount, token)  # Fails for PayPal and Square
    GOOD: Adapt each gateway to a common interface

MISTAKE 4: Not documenting the expected interface
    BAD:  class PaymentProcessor:
             def __init__(self, gateway):  # What methods should gateway have?
    GOOD: Document or use Protocol (see 02_protocol_based_design.py)

MISTAKE 5: Ignoring exceptions
    BAD:  result = process_with_callback(100, 'token', gateway)
    GOOD: Provide error handlers and catch exceptions
    """)

    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS")
    print("=" * 80)
    print("""
Q1: What is duck typing and why is it important in Python?
A1: Duck typing means if an object has the required methods and attributes,
    you can use it as if it were of a certain type. It enables polymorphism
    without inheritance, making code more flexible and loosely coupled.

Q2: When should you use duck typing vs inheritance?
A2: Use duck typing when you want flexibility and loose coupling.
    Use inheritance when you have a clear "is-a" relationship and shared
    implementation. Prefer composition + duck typing in most cases.

Q3: How do you handle different method signatures in duck typing?
A3: Use adapters, strategies, or higher-order functions to normalize
    different interfaces into a common contract.

Q4: What are the risks of duck typing?
A4: Less static safety. Runtime errors if methods don't exist.
    Mitigate with: type hints, hasattr() checks, good tests, documentation.

Q5: How does duck typing relate to the Liskov Substitution Principle?
A5: Both emphasize substitutability—if X can be used where Y is expected,
    then X is duck-type compatible with Y. LSP formalizes this for inheritance.
    """)

    print("\n" + "=" * 80)
    print("CHALLENGE EXERCISE")
    print("=" * 80)
    print("""
Implement a "RetryablePaymentGateway" that wraps any payment gateway
and retries up to 3 times on failure.

Requirements:
1. Accept any payment gateway in __init__()
2. Implement retry logic with exponential backoff
3. Log each retry attempt
4. Raise an exception after 3 failed attempts

Example usage:
    stripe = StripeGateway("sk_live_abc123")
    retryable = RetryablePaymentGateway(stripe, max_retries=3)
    result = retryable.process_payment(100.00, "tok_visa")
    """)


# ============================================================================
# EXPECTED OUTPUT
# ============================================================================
"""
Output should show:

1. Three payment providers (Stripe, PayPal, Square) processing payments
   with different method signatures but same effect.

2. Strategy pattern adapting each gateway to a unified interface.

3. Callback-based payment processing.

4. Audit trail showing all transactions.

5. Best practices and common mistakes.

6. Interview questions and a challenge exercise.

Key takeaway: Python's duck typing allows us to write flexible code that
works with any object that "quacks like" a payment gateway, without complex
inheritance hierarchies. This is the essence of polymorphism done Pythonic ally.
"""


if __name__ == "__main__":
    main()
