"""Dynamic Object Creation: Creating Classes at Runtime"""
from typing import Any, Dict

def create_dataclass(name: str, fields: Dict[str, type]) -> type:
    """Create a data class dynamically."""

    def __init__(self: Any, **kwargs: Any) -> None:
        for field, field_type in fields.items():
            value = kwargs.get(field)
            if value is not None and not isinstance(value, field_type):
                raise TypeError(f"{field} must be {field_type.__name__}")
            setattr(self, field, value)

    def __repr__(self: Any) -> str:
        field_strs = [f"{f}={getattr(self, f)!r}" for f in fields.keys()]
        return f"{name}({', '.join(field_strs)})"

    attrs = {
        "__init__": __init__,
        "__repr__": __repr__,
        "_fields": fields,
    }

    return type(name, (), attrs)

def create_enum(name: str, values: list[str]) -> type:
    """Create an enum-like class dynamically."""

    attrs = {value: value for value in values}
    attrs["_values"] = values

    def __init__(self: Any, value: str) -> None:
        if value not in self._values:
            raise ValueError(f"Invalid enum value: {value}")
        self.value = value

    attrs["__init__"] = __init__
    attrs["__repr__"] = lambda self: f"{name}.{self.value}"

    return type(name, (), attrs)

def main() -> None:
    print("\n" + "="*80)
    print("DYNAMIC OBJECT CREATION")
    print("="*80)

    print("\n[1] DYNAMIC DATA CLASS")
    print("-"*80)

    # Create a User class dynamically
    User = create_dataclass("User", {
        "name": str,
        "age": int,
        "email": str,
    })

    print("Creating User instances:")
    user1 = User(name="Alice", age=30, email="alice@company.com")
    print(f"  {user1}")

    user2 = User(name="Bob", age=25, email="bob@company.com")
    print(f"  {user2}")

    # Create a Product class dynamically
    Product = create_dataclass("Product", {
        "id": int,
        "name": str,
        "price": float,
    })

    print("\nCreating Product instances:")
    product = Product(id=1, name="Laptop", price=999.99)
    print(f"  {product}")

    print("\n[2] DYNAMIC ENUM")
    print("-"*80)

    Status = create_enum("Status", ["PENDING", "ACTIVE", "COMPLETED"])

    print("Creating enum values:")
    status1 = Status("PENDING")
    print(f"  {status1}")

    status2 = Status("ACTIVE")
    print(f"  {status2}")

    try:
        invalid = Status("INVALID")
    except ValueError as e:
        print(f"  Error: {e}")

    print("\n[3] DYNAMIC CLASS WITH METHODS")
    print("-"*80)

    def create_service(name: str, methods: Dict[str, callable]) -> type:
        """Create a service class with dynamic methods."""
        attrs = {"name": name}
        attrs.update(methods)
        return type(name, (), attrs)

    def get_data(self: Any) -> str:
        return "[SERVICE] Fetching data..."

    def save_data(self: Any, data: str) -> None:
        print(f"[SERVICE] Saving data: {data}")

    DataService = create_service("DataService", {
        "get_data": get_data,
        "save_data": save_data,
    })

    service = DataService()
    print(f"Service name: {service.name}")
    print(service.get_data())
    service.save_data("Important data")

    print("\n[4] DYNAMIC INHERITANCE")
    print("-"*80)

    class Animal:
        def speak(self) -> None:
            print("Making a sound")

    def create_animal_subclass(animal_type: str, sound: str) -> type:
        """Create animal subclass dynamically."""

        def speak(self: Any) -> None:
            print(f"[{animal_type.upper()}] {sound}")

        return type(f"{animal_type}Class", (Animal,), {"speak": speak})

    Dog = create_animal_subclass("dog", "Woof!")
    Cat = create_animal_subclass("cat", "Meow!")

    dog = Dog()
    dog.speak()

    cat = Cat()
    cat.speak()

    print("\n" + "="*80)
    print("DYNAMIC OBJECT CREATION")
    print("="*80)
    print("""
TECHNIQUES:
  1. type(name, bases, dict) - Create class at runtime
  2. __init__ dynamically - Custom initialization
  3. __repr__ dynamically - Custom string representation
  4. Inheritance - Create subclasses dynamically

USE CASES:
  - Data class generation
  - Enum creation
  - ORM (Object-Relational Mapping)
  - Code generation
  - Configuration-driven classes
  - Testing (dynamic test classes)

BENEFITS:
  + Reduced boilerplate
  + Configuration-driven design
  + Flexible architecture

RISKS:
  - Harder to debug
  - IDE support limited
  - Performance overhead
  - Testing complexity

BEST PRACTICES:
  [DO] Document what's being created dynamically
  [DO] Use descriptive names for dynamic classes
  [DO] Keep dynamic creation logic separate
  [DONT] Overuse - prefer regular classes when possible
  [DONT] Create dynamic classes in hot paths
    """)

if __name__ == "__main__":
    main()
