"""Custom Descriptors: Building Complex Attribute Behavior"""
from typing import Any, Optional, Callable
from datetime import datetime

class Lazy:
    """Descriptor for lazy initialization of expensive computations."""

    def __init__(self, fn: Callable) -> None:
        self.fn = fn
        self.name = fn.__name__

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> Any:
        if obj is None:
            return self
        print(f"[LAZY] Computing {self.name}")
        value = self.fn(obj)
        setattr(obj, self.name, value)  # Replace descriptor with value
        return value

class Typed:
    """Descriptor that enforces type checking."""

    def __init__(self, name: str, expected_type: type) -> None:
        self.name = name
        self.expected_type = expected_type
        self.private_name = f"_{name}"

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> Any:
        if obj is None:
            return self
        return getattr(obj, self.private_name, None)

    def __set__(self, obj: Any, value: Any) -> None:
        if not isinstance(value, self.expected_type):
            raise TypeError(
                f"{self.name} must be {self.expected_type.__name__}, "
                f"got {type(value).__name__}"
            )
        setattr(obj, self.private_name, value)

class Bounded:
    """Descriptor that enforces min/max bounds."""

    def __init__(self, name: str, min_val: float, max_val: float) -> None:
        self.name = name
        self.min_val = min_val
        self.max_val = max_val
        self.private_name = f"_{name}"

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> Any:
        if obj is None:
            return self
        return getattr(obj, self.private_name, 0)

    def __set__(self, obj: Any, value: float) -> None:
        if not (self.min_val <= value <= self.max_val):
            raise ValueError(
                f"{self.name} must be between {self.min_val} and {self.max_val}, "
                f"got {value}"
            )
        setattr(obj, self.private_name, value)

class Cached:
    """Descriptor that caches computed values with timeout."""

    def __init__(self, fn: Callable, cache_time: int = 60) -> None:
        self.fn = fn
        self.cache_time = cache_time
        self.cache: dict[int, tuple[Any, float]] = {}

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> Any:
        if obj is None:
            return self
        obj_id = id(obj)
        now = datetime.now().timestamp()

        if obj_id in self.cache:
            value, timestamp = self.cache[obj_id]
            if now - timestamp < self.cache_time:
                print(f"[CACHE] HIT for {self.fn.__name__}")
                return value
            else:
                print(f"[CACHE] EXPIRED for {self.fn.__name__}")

        print(f"[CACHE] MISS for {self.fn.__name__}")
        value = self.fn(obj)
        self.cache[obj_id] = (value, now)
        return value

class Document:
    """Example class using custom descriptors."""

    title = Typed("title", str)
    priority = Bounded("priority", 1, 10)

    def __init__(self, title: str, priority: int) -> None:
        self.title = title
        self.priority = priority
        self._word_count = 0

    @property
    def word_count(self) -> int:
        print("[COMPUTE] Computing word count")
        return 42

class ExpensiveComputation:
    """Class with lazy evaluation."""

    def __init__(self, data: list[int]) -> None:
        self.data = data

    @Lazy
    def sum_of_squares(self) -> int:
        """Expensive computation."""
        print("  [Computing sum of squares...]")
        return sum(x**2 for x in self.data)

def main() -> None:
    print("\n" + "="*80)
    print("CUSTOM DESCRIPTORS: Advanced Attribute Control")
    print("="*80)

    print("\n[1] TYPED DESCRIPTOR (Type Checking)")
    print("-"*80)

    try:
        doc = Document("My Document", 5)
        print(f"Document created: {doc.title}, priority {doc.priority}")
    except (TypeError, ValueError) as e:
        print(f"Error: {e}")

    try:
        print("Setting invalid title type:")
        doc.title = 123
    except TypeError as e:
        print(f"Error: {e}")

    print("\n[2] BOUNDED DESCRIPTOR (Range Validation)")
    print("-"*80)

    try:
        print("Setting priority to 7 (valid):")
        doc.priority = 7
        print(f"Priority: {doc.priority}")
    except ValueError as e:
        print(f"Error: {e}")

    try:
        print("Setting priority to 15 (invalid):")
        doc.priority = 15
    except ValueError as e:
        print(f"Error: {e}")

    print("\n[3] LAZY DESCRIPTOR (On-Demand Computation)")
    print("-"*80)

    comp = ExpensiveComputation([1, 2, 3, 4, 5])
    print("Creating object (computation not done yet)")
    print("Accessing sum_of_squares (first time):")
    result1 = comp.sum_of_squares
    print(f"Result: {result1}")
    print("Accessing sum_of_squares (second time - direct value):")
    result2 = comp.sum_of_squares
    print(f"Result: {result2}")

    print("\n[4] CACHED DESCRIPTOR (With Expiration)")
    print("-"*80)

    class DataFetcher:
        def __init__(self):
            self.fetch_count = 0

        @Cached
        def expensive_data(self) -> str:
            self.fetch_count += 1
            return f"Data (fetch #{self.fetch_count})"

    fetcher = DataFetcher()
    print("First access:")
    print(fetcher.expensive_data)
    print("Second access (cached):")
    print(fetcher.expensive_data)

    print("\n" + "="*80)
    print("CUSTOM DESCRIPTOR PATTERNS")
    print("="*80)
    print("""
PATTERN 1: Lazy Evaluation
  - Compute expensive values on first access
  + Saves computation if never accessed
  - Cache invalidation needed

PATTERN 2: Type Checking
  - Validate type on assignment
  + Fail fast
  - Runtime overhead

PATTERN 3: Bounds Checking
  - Enforce min/max values
  + Data integrity
  - Adds validation cost

PATTERN 4: Caching with TTL
  - Cache results with timeout
  + Performance improvement
  - Stale data possible

PATTERN 5: Logging Access
  - Track all reads/writes
  + Debugging
  - Performance overhead
    """)

if __name__ == "__main__":
    main()
