"""Property vs Descriptor: Choosing the Right Tool"""
from typing import Any, Optional

# ============================================================================
# EXAMPLE 1: Property (Simple)
# ============================================================================

class Circle:
    """Using @property for simple getter/setter."""

    def __init__(self, radius: float) -> None:
        self._radius = radius

    @property
    def radius(self) -> float:
        """Get radius."""
        print("[PROPERTY] Getting radius")
        return self._radius

    @radius.setter
    def radius(self, value: float) -> None:
        """Set radius with validation."""
        if value <= 0:
            raise ValueError("Radius must be positive")
        print(f"[PROPERTY] Setting radius to {value}")
        self._radius = value

    @property
    def area(self) -> float:
        """Computed property."""
        print("[PROPERTY] Computing area")
        return 3.14159 * self._radius ** 2

# ============================================================================
# EXAMPLE 2: Descriptor (Reusable)
# ============================================================================

class Positive:
    """Reusable descriptor for positive values."""

    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name
        self.private_name = f"_{name}"

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> float:
        if obj is None:
            return self
        return getattr(obj, self.private_name, 0)

    def __set__(self, obj: Any, value: float) -> None:
        if value <= 0:
            raise ValueError(f"{self.name} must be positive")
        print(f"[DESCRIPTOR] Setting {self.name} to {value}")
        setattr(obj, self.private_name, value)

class Sphere:
    """Using descriptor for reusable validation."""

    radius = Positive()
    height = Positive()

    def __init__(self, radius: float, height: float) -> None:
        self.radius = radius
        self.height = height

# ============================================================================
# COMPARISON
# ============================================================================

class PropertyExample:
    """Multiple properties with individual logic."""

    def __init__(self, x: float, y: float, z: float) -> None:
        self._x = x
        self._y = y
        self._z = z

    @property
    def x(self) -> float:
        print("[PROPERTY] Getting x")
        return self._x

    @x.setter
    def x(self, value: float) -> None:
        if not isinstance(value, (int, float)):
            raise TypeError("x must be numeric")
        self._x = value

    @property
    def y(self) -> float:
        print("[PROPERTY] Getting y")
        return self._y

    @y.setter
    def y(self, value: float) -> None:
        if not isinstance(value, (int, float)):
            raise TypeError("y must be numeric")
        self._y = value

    @property
    def z(self) -> float:
        print("[PROPERTY] Getting z")
        return self._z

    @z.setter
    def z(self, value: float) -> None:
        if not isinstance(value, (int, float)):
            raise TypeError("z must be numeric")
        self._z = value

class Numeric:
    """Descriptor for numeric values (reusable)."""

    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name
        self.private_name = f"_{name}"

    def __get__(self, obj: Any, objtype: Optional[type] = None) -> float:
        if obj is None:
            return self
        return getattr(obj, self.private_name, 0)

    def __set__(self, obj: Any, value: float) -> None:
        if not isinstance(value, (int, float)):
            raise TypeError(f"{self.name} must be numeric")
        setattr(obj, self.private_name, value)

class DescriptorExample:
    """Cleaner with descriptors."""

    x = Numeric()
    y = Numeric()
    z = Numeric()

    def __init__(self, x: float, y: float, z: float) -> None:
        self.x = x
        self.y = y
        self.z = z

def main() -> None:
    print("\n" + "="*80)
    print("PROPERTY vs DESCRIPTOR: When to Use Each")
    print("="*80)

    print("\n[1] PROPERTY EXAMPLE")
    print("-"*80)

    circle = Circle(5)
    print(f"Radius: {circle.radius}")
    print(f"Area: {circle.area}")

    circle.radius = 10
    print(f"New radius: {circle.radius}")

    try:
        circle.radius = -5
    except ValueError as e:
        print(f"Error: {e}")

    print("\n[2] DESCRIPTOR EXAMPLE")
    print("-"*80)

    sphere = Sphere(5, 10)
    print(f"Radius: {sphere.radius}, Height: {sphere.height}")

    sphere.radius = 7
    print(f"New radius: {sphere.radius}")

    print("\n[3] PROPERTY CODE (With Duplication)")
    print("-"*80)

    prop_example = PropertyExample(1, 2, 3)
    print(f"x={prop_example.x}, y={prop_example.y}, z={prop_example.z}")

    print("\n[4] DESCRIPTOR CODE (DRY)")
    print("-"*80)

    desc_example = DescriptorExample(1, 2, 3)
    print(f"x={desc_example.x}, y={desc_example.y}, z={desc_example.z}")

    print("\n" + "="*80)
    print("PROPERTY vs DESCRIPTOR COMPARISON")
    print("="*80)
    print("""
PROPERTY:
  + Simple, readable for single use case
  + Intuitive method decoration syntax
  + Easy to write for one-off logic
  - Code duplication when reused
  - Tied to single class
  - Less flexible

DESCRIPTOR:
  + Reusable across multiple classes
  + DRY (Don't Repeat Yourself)
  + More powerful
  - More complex to implement
  - Less intuitive syntax
  - Overkill for simple cases

WHEN TO USE PROPERTY:
  - Single attribute with specific logic
  - Computed properties (area from radius)
  - Simple validation
  - Class-specific behavior

WHEN TO USE DESCRIPTOR:
  - Same validation/logic across many attributes
  - Multiple classes need same behavior
  - Plugin systems
  - Framework code
  - Complex attribute access patterns

EXAMPLE: Validation
  Property: One validation logic per property
  Descriptor: One class enforces validation on all attributes
    """)

if __name__ == "__main__":
    main()
