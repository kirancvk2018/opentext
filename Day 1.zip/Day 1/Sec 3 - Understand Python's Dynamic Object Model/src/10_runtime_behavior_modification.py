"""Runtime Behavior Modification: Dynamic Class and Method Creation"""
from typing import Any, Callable, Dict

def create_logger_class(prefix: str) -> type:
    """Dynamically create a logger class."""
    class DynamicLogger:
        def log(self, message: str) -> None:
            print(f"[{prefix}] {message}")
    DynamicLogger.__name__ = f"Logger_{prefix}"
    return DynamicLogger

def add_validation(cls: type, field: str, validator: Callable[[Any], bool]) -> None:
    """Add validation to class methods dynamically."""
    original_init = cls.__init__

    def validated_init(self: Any, **kwargs: Any) -> None:
        if field in kwargs:
            if not validator(kwargs[field]):
                raise ValueError(f"Validation failed for {field}")
        original_init(self, **kwargs)

    cls.__init__ = validated_init

class User:
    def __init__(self, name: str = "", age: int = 0) -> None:
        self.name = name
        self.age = age

def create_api_client(base_url: str) -> type:
    """Factory creating API client classes at runtime."""
    class APIClient:
        def __init__(self) -> None:
            self.base_url = base_url

        def get(self, endpoint: str) -> Dict[str, Any]:
            return {"url": f"{self.base_url}{endpoint}"}

        def post(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
            return {"url": f"{self.base_url}{endpoint}", "data": data}

    APIClient.__name__ = f"APIClient_{base_url.replace('/', '_')}"
    return APIClient

def main() -> None:
    print("\n" + "="*80)
    print("RUNTIME BEHAVIOR MODIFICATION")
    print("="*80)

    print("\n[1] DYNAMIC CLASS CREATION")
    print("-"*80)

    LoggerDev = create_logger_class("DEV")
    LoggerProd = create_logger_class("PROD")

    dev_logger = LoggerDev()
    prod_logger = LoggerProd()

    dev_logger.log("Development message")
    prod_logger.log("Production message")

    print(f"Class name: {LoggerDev.__name__}")
    print(f"Class name: {LoggerProd.__name__}")

    print("\n[2] DYNAMIC METHOD INJECTION")
    print("-"*80)

    class Reporter:
        pass

    def generate_report(self: Reporter) -> str:
        return "[REPORT] Data compiled successfully"

    Reporter.generate_report = generate_report
    reporter = Reporter()
    print(reporter.generate_report())

    print("\n[3] DYNAMIC VALIDATION")
    print("-"*80)

    def is_valid_age(age: int) -> bool:
        return 0 < age < 150

    add_validation(User, "age", is_valid_age)

    try:
        print("Creating user with valid age:")
        user1 = User(name="Alice", age=30)
        print(f"  Success: {user1.name}, {user1.age}")
    except ValueError as e:
        print(f"  Failed: {e}")

    try:
        print("Creating user with invalid age:")
        user2 = User(name="Bob", age=200)
    except ValueError as e:
        print(f"  Failed: {e}")

    print("\n[4] DYNAMIC API CLIENT FACTORY")
    print("-"*80)

    StripeClient = create_api_client("https://api.stripe.com")
    PayPalClient = create_api_client("https://api.paypal.com")

    stripe = StripeClient()
    paypal = PayPalClient()

    print(f"Stripe: {stripe.get('/charges')}")
    print(f"PayPal: {paypal.get('/payments')}")

    print("\n[5] ADDING PROPERTIES DYNAMICALLY")
    print("-"*80)

    class Product:
        def __init__(self, price: float) -> None:
            self._price = price

    def get_price_with_tax(self: Product) -> float:
        return self._price * 1.08

    Product.price_with_tax = property(lambda self: get_price_with_tax(self))
    product = Product(100)
    print(f"Original price: ${product._price}")
    print(f"Price with tax: ${product.price_with_tax}")

    print("\n" + "="*80)
    print("DYNAMIC MODIFICATION PATTERNS")
    print("="*80)
    print("""
PATTERN 1: Dynamic Class Creation
  - Create classes at runtime based on configuration
  + Flexibility
  - Debugging complexity

PATTERN 2: Method Injection
  - Add methods to existing classes dynamically
  + Runtime flexibility
  - Violates encapsulation

PATTERN 3: Validation Middleware
  - Wrap __init__ to add validation
  + Cross-cutting concern
  - Can hide original logic

PATTERN 4: Property Factory
  - Create properties from functions
  + Lazy evaluation
  - Less predictable

PATTERN 5: Mixin Injection
  - Add behavior via inheritance at runtime
  + MRO (method resolution order) aware
  - Complex to debug
    """)

if __name__ == "__main__":
    main()
