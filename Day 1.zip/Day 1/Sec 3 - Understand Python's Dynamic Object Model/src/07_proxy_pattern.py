"""
================================================================================
Module:           07_proxy_pattern.py
Topic:            Proxy Pattern and Access Control
Problem:          Control access to objects—delay initialization, log access,
                  enforce permissions, or protect expensive resources.
Enterprise:       A database pool needs proxy objects that:
                  - Delay connection creation until first use (lazy loading)
                  - Log all SQL queries
                  - Check permissions before allowing access
                  - Count access frequency
Objectives:       - Understand proxy pattern
                  - Implement lazy initialization
                  - Control access with __getattr__
                  - Maintain interface compatibility
Prerequisites:    - Object wrapping (Module 06)
                  - Python dunder methods
================================================================================
"""

from typing import Any, Optional, Callable
from datetime import datetime
import json
import time

# ============================================================================
# ORIGINAL EXPENSIVE OBJECT
# ============================================================================

class DatabaseConnection:
    """Expensive-to-create database connection."""

    def __init__(self) -> None:
        print("[DB] Connecting... (simulating slow connection)")
        time.sleep(0.1)  # Simulate connection delay
        self.connected = True
        self.queries: list[str] = []

    def execute(self, query: str) -> list[dict[str, Any]]:
        """Execute a query."""
        if not self.connected:
            raise RuntimeError("Not connected")
        self.queries.append(query)
        return [{"id": 1, "data": "result"}]

    def get_stats(self) -> dict[str, Any]:
        """Get connection statistics."""
        return {"connected": self.connected, "queries_executed": len(self.queries)}


# ============================================================================
# LAZY LOADING PROXY
# ============================================================================

class LazyDatabaseProxy:
    """Proxy that delays database connection until first use."""

    def __init__(self) -> None:
        self._real_object: Optional[DatabaseConnection] = None
        print("[PROXY] LazyDatabaseProxy created (no real connection yet)")

    def _ensure_initialized(self) -> None:
        """Create the real object on first access."""
        if self._real_object is None:
            print("[PROXY] First access detected - creating real connection")
            self._real_object = DatabaseConnection()

    def __getattr__(self, name: str) -> Any:
        """Forward attribute access to real object."""
        self._ensure_initialized()
        return getattr(self._real_object, name)

    def __repr__(self) -> str:
        return f"LazyDatabaseProxy(initialized={self._real_object is not None})"


# ============================================================================
# ACCESS CONTROL PROXY
# ============================================================================

class AccessControlProxy:
    """Proxy that enforces permissions."""

    def __init__(self, obj: Any, allowed_methods: list[str]) -> None:
        self._obj = obj
        self._allowed_methods = allowed_methods
        self._access_log: list[dict[str, Any]] = []

    def _check_access(self, method_name: str) -> bool:
        """Check if method access is allowed."""
        allowed = method_name in self._allowed_methods
        self._access_log.append({
            "timestamp": datetime.now().isoformat(),
            "method": method_name,
            "allowed": allowed,
        })
        return allowed

    def __getattr__(self, name: str) -> Any:
        """Forward with access control."""
        if not self._check_access(name):
            raise PermissionError(f"Access to '{name}' denied")
        return getattr(self._obj, name)

    def get_access_log(self) -> list[dict[str, Any]]:
        """Get access log."""
        return self._access_log


# ============================================================================
# LOGGING PROXY
# ============================================================================

class LoggingProxy:
    """Proxy that logs all method calls."""

    def __init__(self, obj: Any) -> None:
        self._obj = obj
        self._log: list[dict[str, Any]] = []

    def __getattr__(self, name: str) -> Any:
        """Log attribute access."""
        attr = getattr(self._obj, name)

        # If it's a method, wrap it with logging
        if callable(attr):
            def logged_method(*args: Any, **kwargs: Any) -> Any:
                start = datetime.now()
                print(f"[LOG] Calling {name}({args}, {kwargs})")
                result = attr(*args, **kwargs)
                elapsed = (datetime.now() - start).total_seconds()
                self._log.append({
                    "timestamp": start.isoformat(),
                    "method": name,
                    "args": str(args),
                    "duration_ms": elapsed * 1000,
                })
                print(f"[LOG] {name} completed in {elapsed*1000:.2f}ms")
                return result
            return logged_method

        return attr

    def get_logs(self) -> list[dict[str, Any]]:
        """Get execution logs."""
        return self._log


# ============================================================================
# STATISTICS PROXY
# ============================================================================

class StatisticsProxy:
    """Proxy that collects statistics about usage."""

    def __init__(self, obj: Any) -> None:
        self._obj = obj
        self._call_stats: dict[str, int] = {}
        self._call_times: dict[str, list[float]] = {}

    def __getattr__(self, name: str) -> Any:
        """Track method calls."""
        attr = getattr(self._obj, name)

        if callable(attr):
            def tracked_method(*args: Any, **kwargs: Any) -> Any:
                # Update call count
                if name not in self._call_stats:
                    self._call_stats[name] = 0
                    self._call_times[name] = []
                self._call_stats[name] += 1

                # Time the call
                start = datetime.now()
                result = attr(*args, **kwargs)
                elapsed = (datetime.now() - start).total_seconds()
                self._call_times[name].append(elapsed)

                return result
            return tracked_method

        return attr

    def get_statistics(self) -> dict[str, Any]:
        """Get usage statistics."""
        stats = {}
        for method, count in self._call_stats.items():
            times = self._call_times[method]
            stats[method] = {
                "calls": count,
                "avg_time_ms": (sum(times) / len(times) * 1000) if times else 0,
                "max_time_ms": max(times) * 1000 if times else 0,
                "min_time_ms": min(times) * 1000 if times else 0,
            }
        return stats


# ============================================================================
# CACHING PROXY
# ============================================================================

class CachingProxy:
    """Proxy that caches method results."""

    def __init__(self, obj: Any) -> None:
        self._obj = obj
        self._cache: dict[tuple[str, tuple[Any, ...]], Any] = {}
        self._cache_hits = 0
        self._cache_misses = 0

    def __getattr__(self, name: str) -> Any:
        """Cache method results."""
        attr = getattr(self._obj, name)

        if callable(attr):
            def cached_method(*args: Any, **kwargs: Any) -> Any:
                cache_key = (name, args)  # Simplified caching

                if cache_key in self._cache:
                    print(f"[CACHE] HIT for {name}{args}")
                    self._cache_hits += 1
                    return self._cache[cache_key]

                print(f"[CACHE] MISS for {name}{args}")
                result = attr(*args, **kwargs)
                self._cache[cache_key] = result
                self._cache_misses += 1
                return result
            return cached_method

        return attr

    def get_cache_stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        total = self._cache_hits + self._cache_misses
        return {
            "hits": self._cache_hits,
            "misses": self._cache_misses,
            "hit_rate": self._cache_hits / total if total > 0 else 0,
            "cache_size": len(self._cache),
        }


# ============================================================================
# COMPOSITE PROXY: Multiple Proxies
# ============================================================================

def compose_proxies(*proxies: type) -> Callable[[Any], Any]:
    """Compose multiple proxy types."""
    def composite(obj: Any) -> Any:
        for proxy_class in proxies:
            obj = proxy_class(obj)
        return obj
    return composite


# ============================================================================
# MAIN: DEMONSTRATION
# ============================================================================

def main() -> None:
    """Execute proxy pattern demonstration."""

    print("\n" + "=" * 80)
    print("PROXY PATTERN: Access Control and Lazy Loading")
    print("=" * 80)

    print("\n[1] LAZY LOADING PROXY")
    print("-" * 80)

    # Create proxy (no connection yet)
    db_lazy = LazyDatabaseProxy()
    print(f"Proxy status: {db_lazy}")

    print("\nFirst method call triggers initialization:")
    db_lazy.execute("SELECT * FROM users")

    print("\nSecond method call uses existing connection:")
    db_lazy.execute("SELECT * FROM orders")

    print("\n[2] ACCESS CONTROL PROXY")
    print("-" * 80)

    db_real = DatabaseConnection()
    db_restricted = AccessControlProxy(
        db_real,
        allowed_methods=["execute", "get_stats"]  # Allow only these
    )

    print("\nAllowed method (execute):")
    db_restricted.execute("SELECT *...")

    print("\nAllowed method (get_stats):")
    db_restricted.get_stats()

    print("\nDenied method (non_existent):")
    try:
        db_restricted.non_existent_method()
    except PermissionError as e:
        print(f"  Access denied: {e}")

    print("\nAccess log:")
    for entry in db_restricted.get_access_log():
        print(f"  {entry['method']}: {'ALLOWED' if entry['allowed'] else 'DENIED'}")

    print("\n[3] LOGGING PROXY")
    print("-" * 80)

    db_real2 = DatabaseConnection()
    db_logged = LoggingProxy(db_real2)

    print("\nExecuting through logging proxy:")
    db_logged.execute("SELECT * FROM products")
    db_logged.get_stats()

    print("\nExecution logs:")
    for log in db_logged.get_logs()[:2]:
        print(f"  {log['method']}: {log['duration_ms']:.2f}ms")

    print("\n[4] STATISTICS PROXY")
    print("-" * 80)

    db_real3 = DatabaseConnection()
    db_stats = StatisticsProxy(db_real3)

    print("\nCalling methods multiple times:")
    db_stats.execute("Query 1")
    db_stats.execute("Query 2")
    db_stats.execute("Query 3")
    db_stats.get_stats()
    db_stats.get_stats()

    print("\nUsage statistics:")
    stats = db_stats.get_statistics()
    for method, data in stats.items():
        print(f"  {method}: {data['calls']} calls, avg {data['avg_time_ms']:.2f}ms")

    print("\n[5] CACHING PROXY")
    print("-" * 80)

    db_real4 = DatabaseConnection()
    db_cached = CachingProxy(db_real4)

    print("\nCalling same method multiple times:")
    db_cached.execute("SELECT * FROM users")
    db_cached.execute("SELECT * FROM users")
    db_cached.execute("SELECT * FROM users")
    db_cached.execute("SELECT * FROM orders")

    cache_stats = db_cached.get_cache_stats()
    print(f"\nCache statistics: {json.dumps(cache_stats, indent=2)}")

    print("\n[6] COMPOSITE PROXY")
    print("-" * 80)

    db_real5 = DatabaseConnection()
    # Apply multiple proxies in order
    db_multi = LoggingProxy(StatisticsProxy(AccessControlProxy(
        db_real5,
        allowed_methods=["execute", "get_stats"]
    )))

    print("\nUsing multi-proxy (Logging + Statistics + Access Control):")
    db_multi.execute("SELECT * FROM users")

    print("\n" + "=" * 80)
    print("PROXY PATTERN USE CASES")
    print("=" * 80)
    print("""
USE CASE 1: Lazy Initialization
  - Delay expensive object creation
  + Faster startup
  - First access is slower

USE CASE 2: Access Control
  - Enforce permissions
  + Security
  - Adds overhead

USE CASE 3: Logging/Monitoring
  - Track all accesses
  + Debugging and auditing
  - Performance impact

USE CASE 4: Caching
  - Cache expensive operations
  + Improves performance
  - Memory usage

USE CASE 5: Validation
  - Validate inputs before forwarding
  + Fail fast
  - Overhead

USE CASE 6: Protocol Translation
  - Adapt one interface to another
  + Compatibility
  - Complexity
    """)

    print("\n" + "=" * 80)
    print("BEST PRACTICES")
    print("=" * 80)
    print("""
[DO] Use __getattr__ to forward unknown attributes.

[DO] Maintain the same interface as the wrapped object.

[DO] Document what the proxy adds.

[DO] Combine multiple proxies for complex behavior.

[DO] Test proxies independently and with the wrapped object.

[DO] Use proxies for cross-cutting concerns (logging, security).

[DONT] Use proxies for simple cases.

[DONT] Create too many layers of proxies.

[DONT] Hide the proxying from the developer.

[DONT] Break the Liskov substitution principle.
    """)

    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS")
    print("=" * 80)
    print("""
Q1: What is the proxy pattern?
A1: A structural pattern that provides a surrogate or placeholder
    for another object to control access to it.

Q2: How does a proxy differ from a wrapper?
A2: Proxy controls access to the real object; wrappers add behavior.
    Both use composition but for different purposes.

Q3: When should you use lazy initialization proxies?
A3: When object creation is expensive (database connections,
    file I/O) and you want to delay it until actually needed.

Q4: What's the performance cost of proxies?
A4: Each __getattr__ call adds overhead. Multiple proxies multiply
    this cost. Profile to measure impact.

Q5: How do you handle special methods like __str__ in proxies?
A5: Override them explicitly in the proxy class, or use
    __getattribute__ instead of __getattr__ for complete control.
    """)

    print("\n" + "=" * 80)
    print("CHALLENGE EXERCISE")
    print("=" * 80)
    print("""
Build a ConnectionPoolProxy that:

1. Manages a pool of database connections
2. Reuses connections (get free connection on access)
3. Limits concurrent connections
4. Queues requests when pool is exhausted
5. Tracks pool statistics

Requirements:
    - Accept pool_size parameter
    - Reuse connections
    - Queue excess requests
    - Provide get_stats() method
    - Implement timeout handling

Example usage:
    pool = ConnectionPoolProxy(pool_size=5)
    # Requests 1-5 get direct connections
    # Request 6 waits in queue
    # When request 1 completes, request 6 gets its connection
    """)


if __name__ == "__main__":
    main()
