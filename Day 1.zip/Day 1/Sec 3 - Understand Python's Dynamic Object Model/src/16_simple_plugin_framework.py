"""Simple Plugin Framework: Extensible Architecture"""
from typing import Any, Dict, Type, Protocol
import json

class Plugin(Protocol):
    """Protocol for plugins."""
    def execute(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute plugin."""
        ...

class PluginRegistry:
    """Registry for managing plugins."""

    def __init__(self) -> None:
        self.plugins: Dict[str, Type] = {}

    def register(self, name: str, plugin_class: Type) -> None:
        """Register a plugin."""
        self.plugins[name] = plugin_class
        print(f"[PLUGIN] Registered: {name}")

    def execute(self, name: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a plugin."""
        plugin_class = self.plugins.get(name)
        if not plugin_class:
            raise ValueError(f"Plugin '{name}' not found")
        plugin = plugin_class()
        return plugin.execute(data)

    def list_plugins(self) -> list[str]:
        """List all registered plugins."""
        return list(self.plugins.keys())

# Built-in plugins
class UppercasePlugin:
    def execute(self, data: Dict[str, Any]) -> Dict[str, Any]:
        print("[PLUGIN] Executing UppercasePlugin")
        if "text" in data:
            data["text"] = data["text"].upper()
        return data

class ReversePlugin:
    def execute(self, data: Dict[str, Any]) -> Dict[str, Any]:
        print("[PLUGIN] Executing ReversePlugin")
        if "text" in data:
            data["text"] = data["text"][::-1]
        return data

class JsonPlugin:
    def execute(self, data: Dict[str, Any]) -> Dict[str, Any]:
        print("[PLUGIN] Executing JsonPlugin")
        return {"json": json.dumps(data)}

def main() -> None:
    print("\n" + "="*80)
    print("SIMPLE PLUGIN FRAMEWORK")
    print("="*80)

    print("\n[1] PLUGIN FRAMEWORK")
    print("-"*80)

    registry = PluginRegistry()

    # Register plugins
    registry.register("uppercase", UppercasePlugin)
    registry.register("reverse", ReversePlugin)
    registry.register("json", JsonPlugin)

    print(f"\nAvailable plugins: {registry.list_plugins()}")

    # Execute plugins
    data = {"text": "Hello World"}

    print("\nExecuting uppercase plugin:")
    result1 = registry.execute("uppercase", data.copy())
    print(f"  Result: {result1}")

    print("\nExecuting reverse plugin:")
    result2 = registry.execute("reverse", data.copy())
    print(f"  Result: {result2}")

    print("\nExecuting json plugin:")
    result3 = registry.execute("json", data.copy())
    print(f"  Result: {result3}")

    print("\n[2] PLUGIN CHAIN")
    print("-"*80)

    print("Chaining plugins:")
    result = data.copy()
    for plugin_name in ["uppercase", "reverse"]:
        result = registry.execute(plugin_name, result)
        print(f"  After {plugin_name}: {result}")

    print("\n" + "="*80)
    print("PLUGIN FRAMEWORK PATTERN")
    print("="*80)
    print("""
COMPONENTS:
  1. Plugin Interface (Protocol or ABC)
  2. Plugin Registry (stores and manages plugins)
  3. Plugin Host (loads and executes plugins)
  4. Concrete Plugins (implement interface)

BENEFITS:
  + Extensible without modifying core code
  + Decoupled architecture
  + Easy to add/remove features
  + Third-party plugin support

IMPLEMENTATION:
  - Use registry.register(name, plugin_class)
  - Use registry.execute(name, data) to run
  - Return result to pass to next plugin

USE CASES:
  - Data processing pipelines
  - Extensible applications
  - Middleware systems
  - Event handlers
    """)

if __name__ == "__main__":
    main()
