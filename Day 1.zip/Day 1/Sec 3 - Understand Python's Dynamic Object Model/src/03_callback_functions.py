"""
================================================================================
Module:           03_callback_functions.py
Topic:            Callback Functions and Event-Driven Programming
Problem:          Processing asynchronous events (user actions, API responses,
                  database updates) with custom behavior injected at runtime.
Enterprise:       A notification system needs to handle multiple event types
                  (user_signup, order_shipped, payment_received) with different
                  notification strategies (email, SMS, webhooks) without
                  modifying core event processing logic.
Objectives:       - Understand callback functions
                  - Implement event-driven patterns
                  - Use callbacks for extensibility
                  - Build observer-like systems
Prerequisites:    - Duck typing (Module 01)
                  - Functions as objects (Module 05)
                  - Higher-order functions (Module 04)
================================================================================
"""

from typing import Callable, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json


# ============================================================================
# PROBLEM STATEMENT
# ============================================================================
# Different events need different handlers:
# - user_signup -> send welcome email, create audit log
# - order_shipped -> send SMS, update dashboard
# - payment_received -> send receipt email, update accounting
#
# Core event processing shouldn't know about specific handlers.
# Handlers should be pluggable.


# ============================================================================
# SAMPLE DATA
# ============================================================================

@dataclass
class Event:
    """Represents an event with metadata."""
    event_type: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    data: dict[str, Any] = field(default_factory=dict)
    handlers_executed: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "type": self.event_type,
            "timestamp": self.timestamp,
            "data": self.data,
            "handlers": self.handlers_executed,
        }


@dataclass
class User:
    """User entity."""
    id: int
    name: str
    email: str
    signup_date: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Order:
    """Order entity."""
    id: int
    customer_name: str
    customer_email: str
    amount: float
    status: str = "pending"


# ============================================================================
# CALLBACKS: Simple Functions
# ============================================================================

def on_user_signup_email(event: Event) -> None:
    """Send welcome email on signup."""
    user_data = event.data
    print(f"[EMAIL] Sending welcome email to {user_data.get('email')}")
    event.handlers_executed.append("on_user_signup_email")


def on_user_signup_audit(event: Event) -> None:
    """Create audit log on signup."""
    user_data = event.data
    print(f"[AUDIT] User signup logged: {user_data.get('name')} ({user_data.get('email')})")
    event.handlers_executed.append("on_user_signup_audit")


def on_user_signup_welcome_message(event: Event) -> None:
    """Send welcome message on signup."""
    user_data = event.data
    print(f"[WELCOME] Welcoming {user_data.get('name')} to the platform")
    event.handlers_executed.append("on_user_signup_welcome_message")


def on_order_shipped_sms(event: Event) -> None:
    """Send SMS notification when order ships."""
    order_data = event.data
    print(f"[SMS] Sending shipment notification to {order_data.get('phone')}")
    event.handlers_executed.append("on_order_shipped_sms")


def on_order_shipped_email(event: Event) -> None:
    """Send email when order ships."""
    order_data = event.data
    print(f"[EMAIL] Sending shipment email to {order_data.get('email')}")
    event.handlers_executed.append("on_order_shipped_email")


def on_payment_received_receipt(event: Event) -> None:
    """Send receipt on payment."""
    payment_data = event.data
    print(f"[RECEIPT] Sending receipt for ${payment_data.get('amount')} to {payment_data.get('email')}")
    event.handlers_executed.append("on_payment_received_receipt")


def on_payment_received_accounting(event: Event) -> None:
    """Update accounting on payment."""
    payment_data = event.data
    print(f"[ACCOUNTING] Recording payment of ${payment_data.get('amount')}")
    event.handlers_executed.append("on_payment_received_accounting")


# ============================================================================
# EVENT DISPATCHER: Core Processing
# ============================================================================

class EventDispatcher:
    """
    Dispatches events to registered callbacks.
    The dispatcher doesn't know what handlers will do—it just calls them.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self.handlers: dict[str, list[Callable[[Event], None]]] = {}
        self.event_log: list[Event] = []

    def subscribe(self, event_type: str, callback: Callable[[Event], None]) -> None:
        """
        Register a callback for an event type.

        Args:
            event_type: The event type to listen for
            callback: Function to call when event occurs
        """
        if event_type not in self.handlers:
            self.handlers[event_type] = []
        self.handlers[event_type].append(callback)
        callback_name = getattr(callback, "__name__", str(type(callback).__name__))
        print(f"Subscribed {callback_name} to '{event_type}'")

    def unsubscribe(self, event_type: str, callback: Callable[[Event], None]) -> None:
        """Unregister a callback."""
        if event_type in self.handlers:
            self.handlers[event_type] = [
                h for h in self.handlers[event_type] if h != callback
            ]

    def emit(self, event: Event) -> Event:
        """
        Emit an event to all registered callbacks.

        Args:
            event: The event to dispatch

        Returns:
            The event (may be modified by handlers)
        """
        print(f"\n[EVENT] {event.event_type} emitted at {event.timestamp}")

        callbacks = self.handlers.get(event.event_type, [])
        if not callbacks:
            print(f"  (No handlers registered)")
            return event

        print(f"  Executing {len(callbacks)} handler(s):")
        for callback in callbacks:
            try:
                callback(event)
            except Exception as e:
                print(f"  [ERROR] {callback.__name__} failed: {e}")

        self.event_log.append(event)
        return event

    def get_handler_count(self, event_type: str) -> int:
        """Get number of handlers for an event type."""
        return len(self.handlers.get(event_type, []))

    def get_event_log(self) -> list[Event]:
        """Get log of all emitted events."""
        return self.event_log


# ============================================================================
# ADVANCED CALLBACKS: Conditional Callbacks
# ============================================================================

class ConditionalCallback:
    """
    Wrapper that executes a callback only if a condition is met.
    This is a callback that decides whether to call another callback.
    """

    def __init__(
        self,
        callback: Callable[[Event], None],
        predicate: Callable[[Event], bool],
    ) -> None:
        self.callback = callback
        self.predicate = predicate

    def __call__(self, event: Event) -> None:
        """Execute callback if predicate returns True."""
        if self.predicate(event):
            self.callback(event)
        else:
            print(f"  Skipped {self.callback.__name__} (condition not met)")


def create_amount_threshold_callback(
    callback: Callable[[Event], None], min_amount: float
) -> ConditionalCallback:
    """Create a callback that only executes for amounts >= threshold."""

    def check_amount(event: Event) -> bool:
        return event.data.get("amount", 0) >= min_amount

    return ConditionalCallback(callback, check_amount)


# ============================================================================
# CALLBACK CHAINS: Multiple Operations
# ============================================================================

class CallbackChain:
    """
    Execute multiple callbacks in sequence.
    Stop on first error if configured to do so.
    """

    def __init__(self, stop_on_error: bool = False) -> None:
        self.callbacks: list[Callable[[Event], None]] = []
        self.stop_on_error = stop_on_error

    def add(self, callback: Callable[[Event], None]) -> "CallbackChain":
        """Add a callback to the chain."""
        self.callbacks.append(callback)
        return self  # Enable fluent API

    def execute(self, event: Event) -> Event:
        """Execute all callbacks in sequence."""
        for callback in self.callbacks:
            try:
                callback(event)
            except Exception as e:
                print(f"Error in {callback.__name__}: {e}")
                if self.stop_on_error:
                    break

        return event


# ============================================================================
# CALLBACK WITH STATE: Maintaining Context
# ============================================================================

class StatefulCallback:
    """
    Callback that maintains state across invocations.
    Useful for metrics, aggregation, or rate limiting.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self.call_count = 0
        self.errors = 0
        self.last_event: Event | None = None

    def __call__(self, event: Event) -> None:
        """Execute callback and update state."""
        self.call_count += 1
        self.last_event = event
        print(
            f"[{self.name}] Handler called {self.call_count} times | "
            f"Event: {event.event_type}"
        )

    def get_stats(self) -> dict[str, Any]:
        """Get callback statistics."""
        return {
            "name": self.name,
            "calls": self.call_count,
            "errors": self.errors,
            "last_event": self.last_event.event_type if self.last_event else None,
        }


# ============================================================================
# ERROR HANDLING CALLBACKS
# ============================================================================

def safe_callback(
    callback: Callable[[Event], None], fallback: Callable[[Event, Exception], None] | None = None
) -> Callable[[Event], None]:
    """
    Wrap a callback with error handling.
    Returns a new callback that catches exceptions.
    """

    def wrapper(event: Event) -> None:
        try:
            callback(event)
        except Exception as e:
            print(f"[CALLBACK ERROR] {callback.__name__} raised {type(e).__name__}: {e}")
            if fallback:
                fallback(event, e)

    wrapper.__name__ = f"safe_{callback.__name__}"
    return wrapper


# ============================================================================
# ASYNC-LIKE CALLBACKS (Simulated)
# ============================================================================

class AsyncCallback:
    """Simulates async callback behavior."""

    def __init__(self, callback: Callable[[Event], None], delay_ms: int = 0) -> None:
        self.callback = callback
        self.delay_ms = delay_ms

    def __call__(self, event: Event) -> None:
        """Execute callback (with simulated delay)."""
        if self.delay_ms > 0:
            print(f"  [ASYNC] Scheduling {self.callback.__name__} with {self.delay_ms}ms delay")
        self.callback(event)


# ============================================================================
# MAIN: DEMONSTRATION
# ============================================================================

def main() -> None:
    """Execute callback functions demonstration."""

    print("\n" + "=" * 80)
    print("CALLBACK FUNCTIONS: Event-Driven Programming")
    print("=" * 80)

    print("\n[1] BASIC CALLBACKS")
    print("-" * 80)

    dispatcher = EventDispatcher("app")

    # Subscribe to user_signup events
    dispatcher.subscribe("user_signup", on_user_signup_email)
    dispatcher.subscribe("user_signup", on_user_signup_audit)
    dispatcher.subscribe("user_signup", on_user_signup_welcome_message)

    # Subscribe to order_shipped events
    dispatcher.subscribe("order_shipped", on_order_shipped_sms)
    dispatcher.subscribe("order_shipped", on_order_shipped_email)

    # Subscribe to payment_received events
    dispatcher.subscribe("payment_received", on_payment_received_receipt)
    dispatcher.subscribe("payment_received", on_payment_received_accounting)

    # Emit events
    user_event = Event("user_signup", data={"name": "Alice", "email": "alice@company.com"})
    dispatcher.emit(user_event)

    order_event = Event(
        "order_shipped",
        data={"order_id": "ORD-001", "email": "alice@company.com", "phone": "555-1234"},
    )
    dispatcher.emit(order_event)

    payment_event = Event(
        "payment_received", data={"amount": 99.99, "email": "alice@company.com"}
    )
    dispatcher.emit(payment_event)

    print("\n[2] CONDITIONAL CALLBACKS")
    print("-" * 80)

    dispatcher2 = EventDispatcher("app2")

    # Only send high-value payment receipts
    high_value_receipt = create_amount_threshold_callback(
        on_payment_received_receipt, min_amount=100.0
    )

    dispatcher2.subscribe("payment_received", high_value_receipt)

    print("\nLow-value payment (should skip receipt):")
    low_payment = Event("payment_received", data={"amount": 25.00, "email": "bob@company.com"})
    dispatcher2.emit(low_payment)

    print("\nHigh-value payment (should send receipt):")
    high_payment = Event(
        "payment_received", data={"amount": 500.00, "email": "carol@company.com"}
    )
    dispatcher2.emit(high_payment)

    print("\n[3] CALLBACK CHAINS")
    print("-" * 80)

    chain = CallbackChain()
    chain.add(on_user_signup_email).add(on_user_signup_audit).add(
        on_user_signup_welcome_message
    )

    user_event2 = Event("user_signup", data={"name": "Bob", "email": "bob@company.com"})
    print("\nExecuting callback chain:")
    chain.execute(user_event2)

    print("\n[4] STATEFUL CALLBACKS")
    print("-" * 80)

    stats_tracker = StatefulCallback("event_tracker")
    dispatcher3 = EventDispatcher("app3")
    dispatcher3.subscribe("user_signup", stats_tracker)
    dispatcher3.subscribe("order_shipped", stats_tracker)

    dispatcher3.emit(Event("user_signup", data={"name": "David"}))
    dispatcher3.emit(Event("order_shipped", data={"order_id": "123"}))
    dispatcher3.emit(Event("user_signup", data={"name": "Emma"}))

    print(f"\nTracker statistics: {json.dumps(stats_tracker.get_stats(), indent=2)}")

    print("\n[5] SAFE CALLBACKS (Error Handling)")
    print("-" * 80)

    def buggy_callback(event: Event) -> None:
        """This callback will fail."""
        raise ValueError("Intentional error in callback")

    def error_fallback(event: Event, error: Exception) -> None:
        """Fallback handler for errors."""
        print(f"Fallback: Event {event.event_type} failed with {type(error).__name__}")

    safe_buggy = safe_callback(buggy_callback, error_fallback)

    dispatcher4 = EventDispatcher("app4")
    dispatcher4.subscribe("test_event", safe_buggy)
    dispatcher4.emit(Event("test_event", data={"test": True}))

    print("\n[6] EVENT LOG")
    print("-" * 80)
    print(f"\nTotal events emitted: {len(dispatcher.get_event_log())}")
    for event in dispatcher.get_event_log():
        print(f"  - {event.event_type} ({len(event.handlers_executed)} handlers executed)")

    print("\n" + "=" * 80)
    print("CALLBACK PATTERNS COMPARISON")
    print("=" * 80)
    print("""
PATTERN 1: Simple Callback
  - Function passed to another function
  - Executed when event occurs
  - Stateless
  + Simple, easy to understand
  - No context sharing

PATTERN 2: Conditional Callback
  - Execute only if predicate matches
  - Filter events before handling
  + Flexible event routing
  - Adds complexity

PATTERN 3: Callback Chain
  - Execute multiple callbacks in sequence
  + Cleaner than nested callbacks
  - Order dependency (if A depends on B)

PATTERN 4: Stateful Callback
  - Callback maintains state
  + Useful for metrics, aggregation
  - Can be harder to test

PATTERN 5: Event Dispatcher
  - Central hub for all events
  + Decouples event producers from consumers
  - Can become bottleneck
    """)

    print("\n" + "=" * 80)
    print("BEST PRACTICES")
    print("=" * 80)
    print("""
[DO] Use callbacks for event handling and extensibility.

[DO] Name callbacks descriptively (on_event_action).

[DO] Document what data is in the event.

[DO] Handle errors in callbacks gracefully.

[DO] Provide a way to unsubscribe from events.

[DO] Use type hints for callback signatures.

[DO] Consider using Event objects instead of multiple parameters.

[DONT] Pass too many parameters to callbacks—use Event objects.

[DONT] Make callbacks do too much—single responsibility.

[DONT] Forget to handle exceptions in callback execution.

[DONT] Create callback chains that depend on execution order.

[DONT] Use callbacks for simple cases when direct calls suffice.
    """)

    print("\n" + "=" * 80)
    print("COMMON MISTAKES")
    print("=" * 80)
    print("""
MISTAKE 1: Circular callback dependencies
    BAD:  callback_a subscribes to event that callback_b emits
          callback_b subscribes to event that callback_a emits
    GOOD: Design event flow as a DAG (directed acyclic graph)

MISTAKE 2: Blocking callbacks
    BAD:  def callback(event):
              time.sleep(10)  # Blocks event processing
    GOOD: Use async callbacks or offload to background jobs

MISTAKE 3: Modifying callback list during iteration
    BAD:  for callback in self.callbacks:
              callback()
              self.callbacks.remove(callback)  # Modifying while iterating
    GOOD: Create a copy: for callback in list(self.callbacks):

MISTAKE 4: Forgetting to pass event data
    BAD:  def callback():  # Needs event data!
              pass
    GOOD: def callback(event):
              data = event.data

MISTAKE 5: Silent failures in callbacks
    BAD:  def callback(event):
              try:
                  something()
              except:
                  pass  # Silent failure
    GOOD: Log or report errors for debugging
    """)

    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS")
    print("=" * 80)
    print("""
Q1: What is a callback and when should you use it?
A1: A callback is a function passed as an argument to be executed later.
    Use callbacks for event handling, async operations, and when you need
    custom behavior without modifying core code.

Q2: How do you prevent callback hell (deeply nested callbacks)?
A2: Use named functions instead of lambdas, use Promise/async-await (in
    async code), or use event dispatchers for multiple sequential callbacks.

Q3: What's the difference between a callback and an observer?
A3: Observer is a design pattern that typically uses callbacks. Observer
    usually has subscribe/unsubscribe methods, while callbacks are simpler.

Q4: How do you handle errors in callbacks?
A4: Wrap callback execution in try/except, provide error callbacks,
    or use a wrapper function that catches exceptions.

Q5: What are the performance implications of many callbacks?
A5: Each callback adds overhead. Too many callbacks can slow event
    processing. Consider batching or filtering events.
    """)

    print("\n" + "=" * 80)
    print("CHALLENGE EXERCISE")
    print("=" * 80)
    print("""
Build an EventDeduplicator that:

1. Wraps an EventDispatcher
2. Prevents duplicate events within a time window
3. Coalesces multiple identical events into one
4. Maintains a dedupe cache with TTL
5. Provides metrics on deduplicated events

Requirements:
    - Accept events and check if they're duplicates
    - Only emit if event is not recent duplicate
    - Clear old cache entries (TTL)
    - Track dedup statistics

Example usage:
    deduplicator = EventDeduplicator(dispatcher, time_window_ms=1000)
    deduplicator.emit(event1)  # Emitted
    deduplicator.emit(event1)  # Deduped (skipped)
    sleep(1.1)
    deduplicator.emit(event1)  # Emitted (TTL expired)
    """)


if __name__ == "__main__":
    main()
