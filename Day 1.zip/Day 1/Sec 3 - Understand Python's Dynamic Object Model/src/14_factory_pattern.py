"""Factory Pattern: Centralized Object Creation"""
from typing import Any, Dict
import json

class DatabaseConnection:
    def connect(self) -> str:
        return "Connected to database"

class CacheConnection:
    def connect(self) -> str:
        return "Connected to cache"

class APIConnection:
    def connect(self) -> str:
        return "Connected to API"

class ConnectionFactory:
    """Factory for creating connections."""

    _connections: Dict[str, type] = {
        "database": DatabaseConnection,
        "cache": CacheConnection,
        "api": APIConnection,
    }

    @staticmethod
    def create(connection_type: str) -> Any:
        """Create a connection of the specified type."""
        cls = ConnectionFactory._connections.get(connection_type)
        if not cls:
            raise ValueError(f"Unknown connection type: {connection_type}")
        print(f"[FACTORY] Creating {connection_type} connection")
        return cls()

    @classmethod
    def register(cls, name: str, connection_class: type) -> None:
        """Register a new connection type."""
        cls._connections[name] = connection_class
        print(f"[FACTORY] Registered {name}")

    @classmethod
    def list_types(cls) -> list[str]:
        """List available connection types."""
        return list(cls._connections.keys())

def main() -> None:
    print("\n" + "="*80)
    print("FACTORY PATTERN: Centralized Object Creation")
    print("="*80)

    print("\n[1] BASIC FACTORY")
    print("-"*80)

    print("Creating connections via factory:")
    db = ConnectionFactory.create("database")
    print(f"  {db.connect()}")

    cache = ConnectionFactory.create("cache")
    print(f"  {cache.connect()}")

    api = ConnectionFactory.create("api")
    print(f"  {api.connect()}")

    print(f"\nAvailable types: {ConnectionFactory.list_types()}")

    print("\n[2] REGISTERING NEW TYPES")
    print("-"*80)

    class WebSocketConnection:
        def connect(self) -> str:
            return "Connected via WebSocket"

    ConnectionFactory.register("websocket", WebSocketConnection)
    print(f"Available types: {ConnectionFactory.list_types()}")

    ws = ConnectionFactory.create("websocket")
    print(f"  {ws.connect()}")

    print("\n" + "="*80)
    print("FACTORY PATTERN BENEFITS")
    print("="*80)
    print("""
BENEFITS:
  + Centralized object creation
  + Easy to add new types
  + Decouples client from concrete classes
  + Can apply common initialization
  + Simplifies testing (mock factory)

WHEN TO USE:
  - Multiple similar objects with different types
  - Plugin systems
  - Configuration-driven creation
  - Complex initialization logic

WHEN NOT TO USE:
  - Simple object creation (just use constructor)
  - Single type being created
  - No variation in creation logic
    """)

if __name__ == "__main__":
    main()
