"""
================================================================================
Module:           05_function_objects.py
Topic:            Functions as First-Class Objects
Problem:          Treating functions as data—storing, passing, and returning
                  them like any other object for flexible behavior composition.
Enterprise:       A workflow engine needs to dynamically load and execute
                  processing steps stored as function objects in a registry.
Objectives:       - Understand functions as objects
                  - Build function registries
                  - Use function objects for plugins
                  - Implement dynamic dispatch
Prerequisites:    - Higher-order functions (Module 04)
================================================================================
"""

from typing import Callable, Any, Dict, get_type_hints
from functools import wraps
import json
import inspect

# ============================================================================
# SAMPLE DATA
# ============================================================================

ORDER_DATA = {
    "order_id": "ORD-001",
    "customer": "Alice",
    "amount": 500,
    "items": ["Laptop", "Mouse"],
    "status": "pending"
}

# ============================================================================
# FUNCTION REGISTRY
# ============================================================================

class FunctionRegistry:
    """Store and retrieve functions by name."""

    def __init__(self) -> None:
        self.functions: Dict[str, Callable[..., Any]] = {}

    def register(self, name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator to register a function."""
        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            self.functions[name] = fn
            print(f"  Registered function: {name}")
            return fn
        return decorator

    def get(self, name: str) -> Callable[..., Any] | None:
        """Get a registered function."""
        return self.functions.get(name)

    def call(self, name: str, *args: Any, **kwargs: Any) -> Any:
        """Call a registered function by name."""
        fn = self.get(name)
        if not fn:
            raise ValueError(f"Function '{name}' not registered")
        return fn(*args, **kwargs)

    def list_functions(self) -> list[str]:
        """List all registered functions."""
        return list(self.functions.keys())

    def get_info(self, name: str) -> Dict[str, Any]:
        """Get information about a registered function."""
        fn = self.functions.get(name)
        if not fn:
            return {}
        return {
            "name": name,
            "docstring": inspect.getdoc(fn),
            "signature": str(inspect.signature(fn)),
            "module": inspect.getmodule(fn).__name__ if inspect.getmodule(fn) else None,
        }


# ============================================================================
# WORKFLOW PROCESSING
# ============================================================================

registry = FunctionRegistry()

@registry.register("validate_order")
def validate_order(order: Dict[str, Any]) -> Dict[str, Any]:
    """Validate order structure."""
    required_fields = ["order_id", "customer", "amount", "items"]
    is_valid = all(field in order for field in required_fields)
    if is_valid:
        print("[VALIDATE] Order is valid")
    else:
        print("[VALIDATE] Order is invalid")
    return order

@registry.register("check_inventory")
def check_inventory(order: Dict[str, Any]) -> Dict[str, Any]:
    """Check if items are in stock."""
    print(f"[INVENTORY] Checking {len(order.get('items', []))} items in stock")
    return order

@registry.register("calculate_shipping")
def calculate_shipping(order: Dict[str, Any]) -> Dict[str, Any]:
    """Calculate shipping cost."""
    shipping_cost = 10 + (len(order.get("items", [])) * 5)
    order["shipping"] = shipping_cost
    print(f"[SHIPPING] Calculated shipping: ${shipping_cost}")
    return order

@registry.register("process_payment")
def process_payment(order: Dict[str, Any]) -> Dict[str, Any]:
    """Process payment."""
    total = order.get("amount", 0) + order.get("shipping", 0)
    order["total"] = total
    print(f"[PAYMENT] Processing payment of ${total}")
    return order

@registry.register("send_confirmation")
def send_confirmation(order: Dict[str, Any]) -> None:
    """Send order confirmation email."""
    print(f"[EMAIL] Sending confirmation to {order.get('customer')}")

# ============================================================================
# WORKFLOW EXECUTOR
# ============================================================================

class Workflow:
    """Execute a sequence of function objects."""

    def __init__(self, name: str, functions: list[Callable[..., Any]]) -> None:
        self.name = name
        self.steps = functions
        self.results: list[tuple[str, Any]] = []

    def execute(self, data: Any) -> Any:
        """Execute all functions in sequence."""
        print(f"\n[WORKFLOW] Executing '{self.name}' with {len(self.steps)} steps")
        result = data
        for i, fn in enumerate(self.steps, 1):
            fn_name = fn.__name__
            print(f"  [{i}] {fn_name}")
            try:
                result = fn(result)
                self.results.append((fn_name, "success"))
            except Exception as e:
                print(f"      ERROR: {e}")
                self.results.append((fn_name, f"failed: {e}"))
                break
        return result

    def get_results(self) -> list[tuple[str, Any]]:
        """Get execution results."""
        return self.results

# ============================================================================
# FUNCTION COMPOSITION
# ============================================================================

def compose_functions(*functions: Callable[..., Any]) -> Callable[[Any], Any]:
    """Compose function objects into one."""
    def composed(data: Any) -> Any:
        for fn in reversed(functions):
            data = fn(data)
        return data
    return composed

def chain_functions(*functions: Callable[..., Any]) -> Callable[[Any], Any]:
    """Chain function objects (pipe)."""
    def chained(data: Any) -> Any:
        for fn in functions:
            data = fn(data)
        return data
    return chained

# ============================================================================
# FUNCTION METADATA
# ============================================================================

def get_function_info(fn: Callable[..., Any]) -> Dict[str, Any]:
    """Extract metadata about a function."""
    return {
        "name": fn.__name__,
        "docstring": fn.__doc__,
        "signature": str(inspect.signature(fn)),
        "is_builtin": inspect.isbuiltin(fn),
        "is_method": inspect.ismethod(fn),
        "is_function": inspect.isfunction(fn),
        "module": fn.__module__,
        "source_file": inspect.getfile(fn) if not inspect.isbuiltin(fn) else "builtin",
    }

# ============================================================================
# MAIN: DEMONSTRATION
# ============================================================================

def main() -> None:
    """Execute function objects demonstration."""

    print("\n" + "=" * 80)
    print("FUNCTION OBJECTS: First-Class Citizens")
    print("=" * 80)

    print("\n[1] FUNCTIONS AS DATA")
    print("-" * 80)

    # Store functions in a list
    operations = [
        lambda x: x * 2,
        lambda x: x + 10,
        lambda x: x ** 2,
    ]

    print("Applying list of functions to value 5:")
    value = 5
    for op in operations:
        value = op(value)
        print(f"  After {op.__name__}: {value}")

    print("\n[2] FUNCTION REGISTRY")
    print("-" * 80)

    print(f"\nRegistered functions: {registry.list_functions()}")

    print("\n[3] DYNAMIC DISPATCH")
    print("-" * 80)

    # Call functions by name
    print("\nCalling functions dynamically:")
    order_copy = ORDER_DATA.copy()
    registry.call("validate_order", order_copy)
    registry.call("check_inventory", order_copy)
    order_copy = registry.call("calculate_shipping", order_copy)
    order_copy = registry.call("process_payment", order_copy)
    registry.call("send_confirmation", order_copy)

    print("\n[4] WORKFLOW EXECUTION")
    print("-" * 80)

    # Create workflows using function objects
    order_processing = Workflow(
        "Order Processing",
        [
            registry.get("validate_order"),
            registry.get("check_inventory"),
            registry.get("calculate_shipping"),
            registry.get("process_payment"),
            registry.get("send_confirmation"),
        ]
    )

    final_order = order_processing.execute(ORDER_DATA.copy())
    print(f"\nFinal order state: {json.dumps(final_order, indent=2)}")

    print("\n[5] FUNCTION COMPOSITION")
    print("-" * 80)

    def add_tax(order: Dict[str, Any]) -> Dict[str, Any]:
        """Add tax to order."""
        order["tax"] = order.get("total", 0) * 0.08
        return order

    def apply_discount(order: Dict[str, Any]) -> Dict[str, Any]:
        """Apply discount to order."""
        order["discount"] = order.get("total", 0) * 0.1
        return order

    # Compose functions
    pipeline = chain_functions(
        validate_order,
        calculate_shipping,
        process_payment,
        add_tax,
        apply_discount
    )

    test_order = ORDER_DATA.copy()
    print("\nExecuting composed pipeline:")
    result = pipeline(test_order)
    print(f"Result: {json.dumps(result, indent=2)}")

    print("\n[6] FUNCTION INTROSPECTION")
    print("-" * 80)

    print("\nFunction metadata:")
    info = get_function_info(validate_order)
    for key, value in info.items():
        print(f"  {key}: {value}")

    print("\nRegistry function information:")
    for fn_name in registry.list_functions()[:2]:
        reg_info = registry.get_info(fn_name)
        print(f"  {fn_name}: {reg_info['signature']}")

    print("\n[7] STORING FUNCTIONS IN DATA STRUCTURES")
    print("-" * 80)

    handlers = {
        "success": lambda result: print(f"  [SUCCESS] {result}"),
        "error": lambda error: print(f"  [ERROR] {error}"),
        "retry": lambda attempt: print(f"  [RETRY] Attempt {attempt}"),
    }

    print("\nEvent handlers (functions in dict):")
    handlers["success"]("Order processed")
    handlers["error"]("Payment failed")
    handlers["retry"](3)

    print("\n" + "=" * 80)
    print("FUNCTION OBJECT PATTERNS")
    print("=" * 80)
    print("""
PATTERN 1: Function Registry
  - Store and retrieve functions by name
  + Plugin architecture
  + Dynamic dispatch
  - Need to manage lifecycle

PATTERN 2: Workflow/Pipeline
  - Execute sequence of function objects
  + Declarative execution order
  + Easy to trace execution
  - Order dependency

PATTERN 3: Handler Maps
  - Map events/states to function handlers
  + Decouples event producer from handler
  + Easy to add new handlers
  - State management can be complex

PATTERN 4: Function Composition
  - Combine functions into new functions
  + Reusable components
  - Can be hard to debug

PATTERN 5: Strategy Pattern (via functions)
  - Store function objects as strategy implementations
  + Flexibility
  - Less type safety
    """)

    print("\n" + "=" * 80)
    print("BEST PRACTICES")
    print("=" * 80)
    print("""
[DO] Use descriptive function names.

[DO] Document function parameters and return types.

[DO] Use function registries for plugin systems.

[DO] Type hint function objects.

[DO] Keep functions pure when possible.

[DO] Test function objects independently.

[DONT] Store too many functions—consider classes.

[DONT] Mix function and class patterns arbitrarily.

[DONT] Rely on function names being stable.

[DONT] Create deeply nested function compositions.
    """)

    print("\n" + "=" * 80)
    print("COMMON MISTAKES")
    print("=" * 80)
    print("""
MISTAKE 1: Not distinguishing between functions and methods
    BAD:  handler_map[event] = instance.method
          # Breaks when instance is garbage collected
    GOOD: handler_map[event] = lambda e: instance.method(e)

MISTAKE 2: Function registration without lifecycle management
    BAD:  global_registry.register("fn", my_function)
          # Hard to clean up or replace
    GOOD: Use scoped registries or context managers

MISTAKE 3: Assuming function attributes are preserved
    BAD:  store fn.custom_attr = value
    GOOD: Store metadata separately in registry

MISTAKE 4: Deep function nesting
    BAD:  compose(f1, compose(f2, compose(f3, f4)))
    GOOD: Use pipeline or list of functions

MISTAKE 5: Ignoring function introspection
    BAD:  Call functions without checking signature
    GOOD: Use inspect module to validate arguments
    """)

    print("\n" + "=" * 80)
    print("INTERVIEW QUESTIONS")
    print("=" * 80)
    print("""
Q1: What does it mean that functions are first-class objects in Python?
A1: Functions can be stored in variables, passed as arguments, returned
    from functions, and stored in data structures like any other object.

Q2: What are the benefits of treating functions as objects?
A2: Flexibility, composability, dynamic dispatch, plugin systems,
    and cleaner separation of concerns.

Q3: How would you implement a plugin system using function objects?
A3: Create a registry that stores functions by name, then dynamically
    load and call them based on configuration.

Q4: What's the difference between storing methods vs functions?
A4: Methods need an instance; functions don't. Store methods as
    lambdas or partial functions to avoid reference issues.

Q5: How do you introspect function objects?
A5: Use inspect module: inspect.signature(), inspect.getdoc(),
    inspect.isfunction(), inspect.signature().parameters.
    """)

    print("\n" + "=" * 80)
    print("CHALLENGE EXERCISE")
    print("=" * 80)
    print("""
Build a TaskScheduler that:

1. Accepts function objects to execute
2. Supports different execution strategies (sync, async, delayed)
3. Maintains task history and results
4. Supports task dependencies
5. Provides rollback on failure

Requirements:
    - register_task(name, fn) - register a task
    - schedule(task_name, depends_on=[]) - schedule with dependencies
    - execute() - run all tasks in dependency order
    - get_history() - return execution history

Example usage:
    scheduler = TaskScheduler()
    scheduler.register_task("fetch_data", fetch_fn)
    scheduler.register_task("process_data", process_fn)
    scheduler.schedule("fetch_data")
    scheduler.schedule("process_data", depends_on=["fetch_data"])
    scheduler.execute()
    """)


if __name__ == "__main__":
    main()
