# Section 01 - Master Advanced Python Programming Concepts

This repository is a practical, instructor-friendly training module for advanced Python concepts. Each script is designed to be run independently with standard Python 3.12+ and uses only the Python Standard Library.

## Module Overview

The repository covers:
- List, dictionary, and set comprehensions
- Generator expressions and generator pipelines
- Iterators and custom iterators
- Decorators, parameterized decorators, and class decorators
- Descriptors and custom descriptors
- Context managers and the contextlib module
- An enterprise log processing example

## Repository Structure

```text
Section01_Advanced_Python_Concepts/
├── README.md
├── requirements.txt
├── LICENSE
├── .gitignore
├── .vscode/
│   ├── launch.json
│   └── settings.json
├── assets/
│   ├── employees.csv
│   ├── transactions.csv
│   └── sample.log
└── src/
    ├── 01_list_comprehensions.py
    ├── 02_dictionary_comprehensions.py
    ├── 03_set_comprehensions.py
    ├── 04_generator_expressions.py
    ├── 05_iterators_basics.py
    ├── 06_custom_iterator.py
    ├── 07_generators_basics.py
    ├── 08_yield_statement.py
    ├── 09_generator_pipeline.py
    ├── 10_decorators_basics.py
    ├── 11_parameterized_decorators.py
    ├── 12_class_decorators.py
    ├── 13_descriptors_basics.py
    ├── 14_custom_descriptors.py
    ├── 15_context_manager_basics.py
    ├── 16_custom_context_manager.py
    ├── 17_contextlib_examples.py
    └── 18_enterprise_log_processor.py
```

## How to Run

From the repository root:

```bash
python src/01_list_comprehensions.py
```

You can run any module in the same way:

```bash
python src/02_dictionary_comprehensions.py
```

## Learning Path

1. Start with list comprehensions and dictionary comprehensions.
2. Move to generators and iterator patterns.
3. Learn decorators and descriptors.
4. Finish with context managers and enterprise log processing.

## Recommended Execution Order

1. 01_list_comprehensions.py
2. 02_dictionary_comprehensions.py
3. 03_set_comprehensions.py
4. 04_generator_expressions.py
5. 05_iterators_basics.py
6. 06_custom_iterator.py
7. 07_generators_basics.py
8. 08_yield_statement.py
9. 09_generator_pipeline.py
10. 10_decorators_basics.py
11. 11_parameterized_decorators.py
12. 12_class_decorators.py
13. 13_descriptors_basics.py
14. 14_custom_descriptors.py
15. 15_context_manager_basics.py
16. 16_custom_context_manager.py
17. 17_contextlib_examples.py
18. 18_enterprise_log_processor.py

## Prerequisites

- Python 3.12+
- VS Code with the Python extension

## Learning Outcomes

By the end of this module, learners should be able to:
- Write compact comprehensions for transformation and filtering
- Understand iterator and generator behavior
- Apply decorators and descriptors in real systems
- Manage resources safely with context managers
- Process logs in an enterprise-style workflow

## References

- Python Documentation: https://docs.python.org/3/
- PEP 8: https://peps.python.org/pep-0008/
- Real Python: https://realpython.com/
