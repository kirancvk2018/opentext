"""Module Name: 14_custom_descriptors
Topic: Custom Descriptors
Problem Statement: A data governance team needs descriptors to enforce read-only and uppercase-only fields.
Enterprise Scenario: The enterprise model must prevent invalid field values from entering critical records.
Learning Objectives:
- Implement custom descriptors for domain-specific validation.
- Support read-only and transformation behavior.
- Apply descriptors to multiple class attributes.
Prerequisites:
- Descriptors basics
Expected Output:
- Descriptors that enforce uppercase and read-only rules.
Concepts Covered:
- Custom descriptor logic
- Validation and transformation
- Encapsulation
"""


class UpperCaseDescriptor:
    """Store values in uppercase and enforce string types."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._value = ""

    def __get__(self, instance: object, owner: type | None = None) -> str:
        return self._value

    def __set__(self, instance: object, value: str) -> None:
        if not isinstance(value, str):
            raise TypeError("Value must be a string")
        self._value = value.upper()


class ReadOnlyDescriptor:
    """Prevent reassignment after initial assignment."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._value = None

    def __get__(self, instance: object, owner: type | None = None) -> object:
        return self._value

    def __set__(self, instance: object, value: object) -> None:
        if self._value is not None:
            raise AttributeError("This field is read-only")
        self._value = value


class Record:
    region = UpperCaseDescriptor("region")
    id_number = ReadOnlyDescriptor("id_number")


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - CUSTOM DESCRIPTORS")
    print("=" * 72)
    print("\nEnterprise scenario: Governing record values.")

    record = Record()
    record.region = "north-america"
    record.id_number = "R-100"
    print(f"Region: {record.region}")
    print(f"ID: {record.id_number}")


if __name__ == "__main__":
    main()
