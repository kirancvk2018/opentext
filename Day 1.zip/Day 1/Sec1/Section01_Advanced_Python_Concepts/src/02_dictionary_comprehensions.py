"""Module Name: 02_dictionary_comprehensions
Topic: Dictionary Comprehensions
Problem Statement: A security operations team needs to transform employee records into a lookup table for rapid authentication and access review.
Enterprise Scenario: The identity management team must map employee IDs to department and salary bands for a daily compliance report.
Learning Objectives:
- Create dictionaries using comprehensions.
- Combine mapping and filtering to build lookup structures.
- Handle exceptions and missing values safely.
Prerequisites:
- Basic Python dictionaries
- List comprehensions
Expected Output:
- A dictionary mapping employee IDs to salary bands and department names.
Concepts Covered:
- Dictionary comprehension syntax
- Conditional logic in dictionary comprehension
- Key-value transformations
"""

from typing import Any, Dict, List

SAMPLE_EMPLOYEES: List[Dict[str, Any]] = [
    {"employee_id": "E-1001", "department": "Finance", "salary": 72000},
    {"employee_id": "E-1002", "department": "Engineering", "salary": 98000},
    {"employee_id": "E-1003", "department": "Finance", "salary": 64000},
    {"employee_id": "E-1004", "department": "Operations", "salary": 86000},
]


def create_salary_band_lookup(records: List[Dict[str, Any]]) -> Dict[str, str]:
    """Map employee IDs to a salary band string."""
    return {
        record["employee_id"]: (
            "High" if record.get("salary", 0) >= 90000 else "Medium" if record.get("salary", 0) >= 70000 else "Low"
        )
        for record in records
        if isinstance(record.get("salary"), int)
    }


def create_department_lookup(records: List[Dict[str, Any]]) -> Dict[str, str]:
    """Map employee IDs to department."""
    return {record["employee_id"]: record.get("department", "Unknown") for record in records if "employee_id" in record}


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - DICTIONARY COMPREHENSIONS")
    print("=" * 72)
    print("\nEnterprise scenario: Building access review lookup tables.")

    print("\nSalary band lookup:")
    print(create_salary_band_lookup(SAMPLE_EMPLOYEES))

    print("\nDepartment lookup:")
    print(create_department_lookup(SAMPLE_EMPLOYEES))


if __name__ == "__main__":
    main()
