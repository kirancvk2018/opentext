"""Module Name: 09_generator_pipeline
Topic: Generator Pipelines
Problem Statement: A financial reporting system needs to process incoming transactions through multiple stages without materializing all intermediate data.
Enterprise Scenario: A banking application filters, transforms, and aggregates transaction data in a pipeline.
Learning Objectives:
- Build generator pipelines using multiple yield stages.
- Connect producers and consumers efficiently.
- Understand flow control in data pipelines.
Prerequisites:
- Generators and yield
Expected Output:
- A pipeline that emits cleaned and summarized transaction values.
Concepts Covered:
- Generator pipelines
- Data transformation stages
- Lazy processing
"""

from typing import Generator, List

TRANSACTIONS = [100, -10, 25, 50, -5, 75]


def remove_negative(values: List[int]) -> Generator[int, None, None]:
    """Yield only non-negative values."""
    for value in values:
        if value >= 0:
            yield value


def double_values(values: Generator[int, None, None]) -> Generator[int, None, None]:
    """Yield doubled values from an upstream generator."""
    for value in values:
        yield value * 2


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - GENERATOR PIPELINES")
    print("=" * 72)
    print("\nEnterprise scenario: Processing financial transactions in stages.")

    pipeline = double_values(remove_negative(TRANSACTIONS))
    print(list(pipeline))


if __name__ == "__main__":
    main()
