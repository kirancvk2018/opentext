"""Module Name: 01_list_comprehensions
Topic: List Comprehensions
Problem Statement: A multinational company needs a fast way to audit high-value employees and summarize departmental staffing without writing verbose loops.
Enterprise Scenario: The finance and HR operations teams are preparing a quarterly compensation review. They need to identify top-paid employees, classify departments, and flag employees with exceptional performance across hundreds of records.
Learning Objectives:
- Understand the syntax and purpose of list comprehensions.
- Use conditional logic inside comprehensions.
- Apply comprehensions to realistic business data.
- Recognize when comprehensions are appropriate and when they should be avoided.
Prerequisites:
- Basic Python syntax
- Python built-in data structures
- Functions and loops
Expected Output:
- A console report showing high-value employees, department summary, and safe handling of invalid records.
Concepts Covered:
- List comprehension syntax
- Filtering and transformation
- Nested comprehension basics
- Error handling with invalid data
"""

import json
from typing import Any, Dict, List

# Constants
SAMPLE_RECORDS: List[Dict[str, Any]] = [
    {"employee_id": "E-1001", "department": "Finance", "salary": 72000, "performance": "A"},
    {"employee_id": "E-1002", "department": "Engineering", "salary": 98000, "performance": "A"},
    {"employee_id": "E-1003", "department": "Finance", "salary": 64000, "performance": "B"},
    {"employee_id": "E-1004", "department": "Operations", "salary": 86000, "performance": "A"},
    {"employee_id": "E-1005", "department": "Engineering", "salary": 91000, "performance": "C"},
    {"employee_id": "E-1006", "department": "HR", "salary": 67000, "performance": "B"},
    {"employee_id": "E-1007", "department": "Operations", "salary": 78000, "performance": "A"},
    {"employee_id": "E-1008", "department": "Finance", "salary": 102000, "performance": "A"},
]

INVALID_RECORDS: List[Dict[str, Any]] = [
    {"employee_id": "E-2001", "department": "Sales", "salary": "not-a-number", "performance": "A"},
    {"employee_id": "E-2002", "department": "Marketing", "salary": 54000},
    {"employee_id": "E-2003", "department": "Legal", "salary": 65000, "performance": "B"},
]


# -----------------------------
# Functions
# -----------------------------
def build_high_value_employee_ids(records: List[Dict[str, Any]], salary_threshold: int = 80000) -> List[str]:
    """Return employee IDs whose salary meets or exceeds the threshold."""
    return [record["employee_id"] for record in records if record.get("salary", 0) >= salary_threshold]


def build_department_names(records: List[Dict[str, Any]]) -> List[str]:
    """Return a normalized list of department names while safely skipping missing values."""
    return [
        str(department).strip().title()
        for department in (record.get("department") for record in records)
        if department is not None
    ]


def build_department_summary(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Summarize each department with employee IDs and average salary."""
    departments = sorted({record["department"] for record in records if "department" in record})

    return [
        {
            "department": department,
            "employee_ids": [record["employee_id"] for record in records if record.get("department") == department],
            "average_salary": round(
                sum(record.get("salary", 0) for record in records if record.get("department") == department) / max(1, sum(1 for record in records if record.get("department") == department)),
                2,
            ),
        }
        for department in departments
    ]


def safe_salary_values(records: List[Dict[str, Any]]) -> List[int]:
    """Collect valid numeric salaries while ignoring invalid or missing values."""
    return [record["salary"] for record in records if isinstance(record.get("salary"), int)]


def format_summary(summary: List[Dict[str, Any]]) -> str:
    """Render a readable summary for console output."""
    return json.dumps(summary, indent=2)


# -----------------------------
# Main Driver
# -----------------------------
def main() -> None:
    """Run the enterprise examples for list comprehensions."""
    print("=" * 72)
    print("SECTION 01 - LIST COMPREHENSIONS")
    print("=" * 72)
    print("\nEnterprise scenario: Quarterly compensation review for global operations.")

    print("\n1. High-value employee IDs:")
    high_value_ids = build_high_value_employee_ids(SAMPLE_RECORDS)
    print(high_value_ids)

    print("\n2. Department names:")
    department_names = build_department_names(SAMPLE_RECORDS)
    print(department_names)

    print("\n3. Department summary:")
    department_summary = build_department_summary(SAMPLE_RECORDS)
    print(format_summary(department_summary))

    print("\n4. Safe salary values from mixed-quality data:")
    try:
        safe_salaries = safe_salary_values(INVALID_RECORDS)
        print(safe_salaries)
    except TypeError as exc:
        print(f"Error while processing invalid records: {exc}")

    print("\n5. Edge case: empty records")
    empty_summary = build_department_summary([])
    print(empty_summary)

    print("\n6. Edge case: records with missing keys")
    missing_key_records = [{"employee_id": "E-3001"}, {"employee_id": "E-3002", "department": "IT"}]
    print(build_department_names(missing_key_records))


if __name__ == "__main__":
    main()


# -----------------------------
# Expected Output
# -----------------------------
# Example output will include:
# - A list of high-value employee IDs such as ['E-1002', 'E-1004', 'E-1008']
# - A normalized list of department names
# - A JSON-style department summary
# - An empty list for invalid salary data after filtering

# -----------------------------
# Best Practices
# -----------------------------
# - Use list comprehensions for concise, readable transformations.
# - Keep expressions simple and avoid nesting too deeply.
# - Prefer comprehensions for data filtering and mapping over large, homogeneous datasets.
# - Use explicit loops for complex business logic that needs multiple steps.

# -----------------------------
# Common Mistakes
# -----------------------------
# - Using a comprehension when a loop would be clearer.
# - Forgetting to handle missing keys or mixed data types.
# - Writing overly complex expressions that are hard to debug.

# -----------------------------
# Interview Questions
# -----------------------------
# - What is the difference between a list comprehension and a generator expression?
# - When would you choose a loop over a list comprehension?
# - How do you filter invalid values inside a comprehension?

# -----------------------------
# Challenge Exercise
# -----------------------------
# - Extend this module to produce a list of employee IDs that belong to departments with average salaries above 75,000.
