"""Module Name: 06_custom_iterator
Topic: Custom Iterators
Problem Statement: An operations team needs a custom iterator to walk through service tickets in pages.
Enterprise Scenario: The ticketing system exposes records in fixed-size batches for a dashboard view.
Learning Objectives:
- Create a class that implements __iter__ and __next__.
- Control iteration state manually.
- Raise StopIteration at the correct time.
Prerequisites:
- Iterators basics
Expected Output:
- A custom iterator that yields ticket batches.
Concepts Covered:
- Custom iterator classes
- Stateful iteration
- StopIteration handling
"""

from typing import Iterator, List


class TicketBatchIterator:
    """Iterate through a list of tickets in fixed-size batches."""

    def __init__(self, tickets: List[str], batch_size: int) -> None:
        self._tickets = tickets
        self._batch_size = batch_size
        self._index = 0

    def __iter__(self) -> "TicketBatchIterator":
        return self

    def __next__(self) -> List[str]:
        if self._index >= len(self._tickets):
            raise StopIteration

        batch = self._tickets[self._index : self._index + self._batch_size]
        self._index += self._batch_size
        return batch


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - CUSTOM ITERATORS")
    print("=" * 72)
    print("\nEnterprise scenario: Paging through support tickets.")

    tickets = ["T-100", "T-101", "T-102", "T-103", "T-104"]
    iterator = TicketBatchIterator(tickets, 2)

    for batch in iterator:
        print(batch)


if __name__ == "__main__":
    main()
