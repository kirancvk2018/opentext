"""Module Name: 16_custom_context_manager
Topic: Custom Context Managers
Problem Statement: A monitoring platform needs a custom context manager to track the lifecycle of an audit session.
Enterprise Scenario: The platform opens an audit session, performs work, and logs the start and end events.
Learning Objectives:
- Implement a context manager class with __enter__ and __exit__.
- Ensure cleanup in all scenarios.
- Use context managers for domain-specific workflows.
Prerequisites:
- Context managers basics
Expected Output:
- A custom context manager that logs session lifecycle events.
Concepts Covered:
- __enter__ and __exit__
- Custom resource lifecycle management
- Exception propagation
"""

from typing import Any


class AuditSession:
    """Context manager that tracks audit lifecycle events."""

    def __enter__(self) -> "AuditSession":
        print("Audit session started")
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: Any) -> bool | None:
        print("Audit session ended")
        return None


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - CUSTOM CONTEXT MANAGERS")
    print("=" * 72)
    print("\nEnterprise scenario: Logging audit lifecycle for support cases.")

    with AuditSession():
        print("Executing audit work")


if __name__ == "__main__":
    main()
