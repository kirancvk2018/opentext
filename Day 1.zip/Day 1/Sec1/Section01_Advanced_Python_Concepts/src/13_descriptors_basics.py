"""Module Name: 13_descriptors_basics
Topic: Descriptors
Problem Statement: A configuration service needs to enforce value validation when settings are assigned.
Enterprise Scenario: The system must ensure that only valid port numbers are stored in configuration objects.
Learning Objectives:
- Understand the descriptor protocol.
- Implement __get__ and __set__.
- Use descriptors for validation and encapsulation.
Prerequisites:
- Classes and properties
Expected Output:
- A descriptor that validates a configuration value.
Concepts Covered:
- Descriptor protocol
- Attribute access interception
- Validation logic
"""


class PortDescriptor:
    """Validate that a port number is between 1 and 65535."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._value = None

    def __get__(self, instance: object, owner: type | None = None) -> object:
        return self._value

    def __set__(self, instance: object, value: int) -> None:
        if not isinstance(value, int) or not 1 <= value <= 65535:
            raise ValueError("Port must be an integer between 1 and 65535")
        self._value = value


class ServiceConfig:
    port = PortDescriptor("port")


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - DESCRIPTORS")
    print("=" * 72)
    print("\nEnterprise scenario: Validating service configuration.")

    config = ServiceConfig()
    config.port = 8080
    print(f"Configured port: {config.port}")


if __name__ == "__main__":
    main()
