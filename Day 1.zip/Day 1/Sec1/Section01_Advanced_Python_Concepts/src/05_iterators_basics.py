"""Module Name: 05_iterators_basics
Topic: Iterators
Problem Statement: A support team needs to inspect user sessions one-by-one without loading all records into memory.
Enterprise Scenario: The enterprise support platform streams session logs and must process them incrementally.
Learning Objectives:
- Understand the iterator protocol.
- Use iter() and next() on iterables.
- Recognize the difference between iterables and iterators.
Prerequisites:
- Loops and collections
Expected Output:
- Iteration through a sequence of session IDs using the iterator protocol.
Concepts Covered:
- Iterable and iterator objects
- iter() and next()
- StopIteration
"""

from typing import Iterator

SESSIONS = ["S-101", "S-102", "S-103"]


def build_iterator(items: list[str]) -> Iterator[str]:
    """Return an iterator for the provided items."""
    return iter(items)


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - ITERATORS")
    print("=" * 72)
    print("\nEnterprise scenario: Streaming support sessions.")

    iterator = build_iterator(SESSIONS)
    print("\nIterator created successfully.")

    try:
        while True:
            print(next(iterator))
    except StopIteration:
        print("\nAll sessions processed.")


if __name__ == "__main__":
    main()
