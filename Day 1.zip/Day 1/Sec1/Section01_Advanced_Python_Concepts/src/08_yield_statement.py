"""Module Name: 08_yield_statement
Topic: Yield Statement
Problem Statement: A manufacturing control system needs to pause and resume data processing between stages.
Enterprise Scenario: Production data flows through a pipeline where each stage can yield intermediate results for monitoring.
Learning Objectives:
- Use yield to pause execution.
- Understand how generators preserve state.
- Demonstrate suspend-and-resume behavior.
Prerequisites:
- Generators basics
Expected Output:
- A generator that yields progress updates and final values.
Concepts Covered:
- yield semantics
- generator state
- pause and resume
"""

from typing import Generator


def production_steps() -> Generator[str, None, None]:
    """Yield process updates for a manufacturing pipeline."""
    yield "Starting intake"
    yield "Validating quality checks"
    yield "Publishing report"


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - YIELD STATEMENT")
    print("=" * 72)
    print("\nEnterprise scenario: Monitoring manufacturing throughput.")

    generator = production_steps()
    print(next(generator))
    print(next(generator))
    print(next(generator))


if __name__ == "__main__":
    main()
