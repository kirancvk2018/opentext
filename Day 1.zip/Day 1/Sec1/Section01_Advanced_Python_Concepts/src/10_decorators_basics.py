"""Module Name: 10_decorators_basics
Topic: Decorators
Problem Statement: A DevOps team wants a reusable way to time critical automation scripts without modifying each function.
Enterprise Scenario: A deployment pipeline must log execution time for multiple automation routines.
Learning Objectives:
- Understand how decorators wrap functions.
- Use functools.wraps for preserving metadata.
- Apply decorators to existing functions.
Prerequisites:
- Functions and closures
Expected Output:
- A timing decorator that reports execution duration.
Concepts Covered:
- Decorator syntax
- Wrapping functions
- functools.wraps
"""

import time
from functools import wraps
from typing import Callable, TypeVar

F = TypeVar("F", bound=Callable[..., object])


def timing_decorator(func: F) -> F:
    """Measure the execution time of a function."""

    @wraps(func)
    def wrapper(*args: object, **kwargs: object) -> object:
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        print(f"{func.__name__} completed in {elapsed:.4f} seconds")
        return result

    return wrapper


@timing_decorator
def deploy_service() -> str:
    """Simulate a deployment step."""
    time.sleep(0.01)
    return "Deployment complete"


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - DECORATORS")
    print("=" * 72)
    print("\nEnterprise scenario: Measuring automation runtime.")
    print(deploy_service())


if __name__ == "__main__":
    main()
