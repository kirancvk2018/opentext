"""Module Name: 03_set_comprehensions
Topic: Set Comprehensions
Problem Statement: A retail analytics team needs to identify unique product categories and detect duplicate vendor entries from a large incoming feed.
Enterprise Scenario: The procurement and analytics division must maintain a distinct set of categories and flag repeated suppliers for review.
Learning Objectives:
- Build sets using comprehensions.
- Remove duplicates and inspect unique values.
- Apply conditions to create targeted subsets.
Prerequisites:
- Basic Python sets
- List comprehensions
Expected Output:
- A unique set of categories and a filtered set of high-priority suppliers.
Concepts Covered:
- Set comprehension syntax
- Uniqueness and deduplication
- Filtering values
"""

from typing import List

RAW_CATEGORIES: List[str] = ["Hardware", "Software", "Hardware", "Cloud", "Software", "Security"]
RAW_SUPPLIERS: List[str] = ["Contoso", "Fabrikam", "Litware", "Contoso", "Northwind", "Fabrikam"]


def unique_categories(items: List[str]) -> set[str]:
    """Return the unique categories from the input list."""
    return {category for category in items}


def high_priority_suppliers(items: List[str], minimum_length: int = 8) -> set[str]:
    """Return suppliers whose names meet the minimum length threshold."""
    return {supplier for supplier in items if len(supplier) >= minimum_length}


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - SET COMPREHENSIONS")
    print("=" * 72)
    print("\nEnterprise scenario: Maintaining clean procurement data.")

    print("\nUnique categories:")
    print(unique_categories(RAW_CATEGORIES))

    print("\nHigh-priority suppliers:")
    print(high_priority_suppliers(RAW_SUPPLIERS))


if __name__ == "__main__":
    main()
