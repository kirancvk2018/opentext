"""Module Name: 07_generators_basics
Topic: Generators
Problem Statement: A monitoring tool needs to stream health-check metrics without storing them all in memory.
Enterprise Scenario: The platform observes dozens of systems and wants a lightweight streaming approach.
Learning Objectives:
- Understand generator functions and yield.
- Compare generators with list creation.
- Use generator state across iterations.
Prerequisites:
- Functions and loops
Expected Output:
- A generator that yields health-check values for discovered services.
Concepts Covered:
- Generator functions
- yield vs return
- Stateful iteration
"""

from typing import Generator


def service_statuses() -> Generator[str, None, None]:
    """Yield service health states."""
    services = ["API", "Database", "Queue", "Cache"]
    for service in services:
        yield f"{service}: OK"


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - GENERATORS")
    print("=" * 72)
    print("\nEnterprise scenario: Streaming infrastructure health states.")

    for status in service_statuses():
        print(status)


if __name__ == "__main__":
    main()
