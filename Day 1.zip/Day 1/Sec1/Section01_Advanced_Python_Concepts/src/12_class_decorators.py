"""Module Name: 12_class_decorators
Topic: Class Decorators
Problem Statement: A platform team wants to add audit metadata to classes without editing each class directly.
Enterprise Scenario: Several service classes need an audit tag added at class definition time.
Learning Objectives:
- Apply decorators to classes.
- Modify class behavior through wrapping.
- Understand how decorators interact with class objects.
Prerequisites:
- Decorators basics
Expected Output:
- A class decorator that adds a registry entry.
Concepts Covered:
- Class decorators
- Class metadata
- Runtime class modification
"""

from typing import Any, Callable, Dict, Type

REGISTRY: Dict[str, str] = {}


def register_service(service_name: str) -> Callable[[Type[Any]], Type[Any]]:
    """Return a class decorator that registers the class name."""

    def decorator(cls: Type[Any]) -> Type[Any]:
        REGISTRY[service_name] = cls.__name__
        return cls

    return decorator


@register_service("billing")
class BillingService:
    pass


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - CLASS DECORATORS")
    print("=" * 72)
    print("\nEnterprise scenario: Registering service classes.")
    print(REGISTRY)


if __name__ == "__main__":
    main()
