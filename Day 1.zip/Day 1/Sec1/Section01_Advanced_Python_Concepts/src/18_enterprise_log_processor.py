"""Module Name: 18_enterprise_log_processor
Topic: Enterprise Integration Example
Problem Statement: A DevOps team needs to analyze server logs from a production environment and identify critical errors.
Enterprise Scenario: The operations department processes application logs to detect failures, count warning events, and summarize activity.
Learning Objectives:
- Parse structured log lines from a text file.
- Count severity levels and extract errors.
- Build a small enterprise-style reporting workflow.
Prerequisites:
- File I/O
- Basic string processing
Expected Output:
- A concise summary report of log severity counts and critical messages.
Concepts Covered:
- File parsing
- Data extraction
- Enterprise reporting patterns
"""

from pathlib import Path
from typing import Dict, List, Tuple

LOG_PATH = Path(__file__).resolve().parent.parent / "assets" / "sample.log"


def parse_log_lines(path: Path) -> List[Tuple[str, str]]:
    """Parse severity and message from each log line."""
    parsed: List[Tuple[str, str]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            parts = line.split(" ", 2)
            if len(parts) >= 3:
                severity = parts[0]
                message = parts[2]
                parsed.append((severity, message))
    return parsed


def summarize_logs(entries: List[Tuple[str, str]]) -> Dict[str, int]:
    """Count log entries by severity."""
    summary: Dict[str, int] = {}
    for severity, _ in entries:
        summary[severity] = summary.get(severity, 0) + 1
    return summary


def critical_messages(entries: List[Tuple[str, str]]) -> List[str]:
    """Return all ERROR messages."""
    return [message for severity, message in entries if severity == "ERROR"]


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - ENTERPRISE LOG PROCESSOR")
    print("=" * 72)
    print("\nEnterprise scenario: Processing application logs for incident review.")

    entries = parse_log_lines(LOG_PATH)
    print("\nLog summary:")
    print(summarize_logs(entries))

    print("\nCritical messages:")
    print(critical_messages(entries))


if __name__ == "__main__":
    main()
