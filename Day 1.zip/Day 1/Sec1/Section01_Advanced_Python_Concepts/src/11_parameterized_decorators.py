"""Module Name: 11_parameterized_decorators
Topic: Parameterized Decorators
Problem Statement: A compliance team needs decorators that can be configured with a custom message prefix for logging different systems.
Enterprise Scenario: Different departments need logging wrappers with varying severity labels.
Learning Objectives:
- Create decorators that accept parameters.
- Build reusable wrappers around functions.
- Preserve function behavior and metadata.
Prerequisites:
- Decorators basics
Expected Output:
- A parameterized decorator that prefixes log output.
Concepts Covered:
- Decorator factories
- Function wrapping
- Metadata preservation
"""

from functools import wraps
from typing import Callable, TypeVar

F = TypeVar("F", bound=Callable[..., object])


def log_with_prefix(prefix: str) -> Callable[[F], F]:
    """Return a decorator that prefixes log output."""

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: object, **kwargs: object) -> object:
            print(f"[{prefix}] Calling {func.__name__}")
            return func(*args, **kwargs)

        return wrapper

    return decorator


@log_with_prefix("SECURITY")
def review_access() -> str:
    return "Access review completed"


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - PARAMETERIZED DECORATORS")
    print("=" * 72)
    print("\nEnterprise scenario: Formatting compliance logs.")
    print(review_access())


if __name__ == "__main__":
    main()
