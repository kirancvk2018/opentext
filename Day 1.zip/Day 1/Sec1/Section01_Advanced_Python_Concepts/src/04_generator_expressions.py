"""Module Name: 04_generator_expressions
Topic: Generator Expressions
Problem Statement: A data engineering team needs to stream transaction amounts without creating large intermediate lists.
Enterprise Scenario: A payments platform processes millions of transaction records and wants memory-efficient transformations.
Learning Objectives:
- Understand generator expressions and their syntax.
- Compare generator expressions with list comprehensions.
- Use generators for streaming data.
Prerequisites:
- List comprehensions
- Iterables and loops
Expected Output:
- A streamed set of values from a generator expression.
Concepts Covered:
- Generator expression syntax
- Lazy evaluation
- Memory efficiency
"""

from typing import Iterator

TRANSACTION_AMOUNTS = [10, 25, 50, 100, 250, 500]


def doubled_values(values: list[int]) -> Iterator[int]:
    """Yield doubled values lazily."""
    return (value * 2 for value in values)


def filtered_values(values: list[int], threshold: int) -> Iterator[int]:
    """Yield values above a threshold."""
    return (value for value in values if value > threshold)


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - GENERATOR EXPRESSIONS")
    print("=" * 72)
    print("\nEnterprise scenario: Streaming payment data efficiently.")

    print("\nDoubled values:")
    print(list(doubled_values(TRANSACTION_AMOUNTS)))

    print("\nFiltered values above 60:")
    print(list(filtered_values(TRANSACTION_AMOUNTS, 60)))


if __name__ == "__main__":
    main()
