"""Module Name: 17_contextlib_examples
Topic: contextlib
Problem Statement: A logging service needs to suppress temporary warnings during automated runs while still preserving normal output.
Enterprise Scenario: An enterprise automation job should ignore known non-critical warnings without crashing the process.
Learning Objectives:
- Use contextlib.suppress to ignore expected exceptions.
- Understand context manager composition.
- Apply contextlib in practical automation scenarios.
Prerequisites:
- Context managers basics
Expected Output:
- A script that suppresses expected errors and continues processing.
Concepts Covered:
- contextlib.suppress
- Exception handling within context managers
"""

from contextlib import suppress


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - CONTEXTLIB")
    print("=" * 72)
    print("\nEnterprise scenario: Suppressing known automation warnings.")

    with suppress(FileNotFoundError):
        open("missing_file.txt", "r", encoding="utf-8")

    print("Automation continued without interruption")


if __name__ == "__main__":
    main()
