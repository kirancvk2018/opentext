"""Module Name: 15_context_manager_basics
Topic: Context Managers
Problem Statement: A file-processing job needs to ensure that temporary files are cleaned up even if an error occurs.
Enterprise Scenario: The operations team uses temporary files during data staging and must guarantee cleanup.
Learning Objectives:
- Use the with statement for resource management.
- Understand context manager behavior.
- Handle setup and teardown reliably.
Prerequisites:
- File handling basics
Expected Output:
- A file created and cleaned up safely using a context manager.
Concepts Covered:
- with statement
- resource setup and teardown
- exception safety
"""

from pathlib import Path

TEMP_FILE = Path("temp_demo.txt")


def main() -> None:
    print("=" * 72)
    print("SECTION 01 - CONTEXT MANAGERS")
    print("=" * 72)
    print("\nEnterprise scenario: Safely managing temporary data files.")

    with TEMP_FILE.open("w", encoding="utf-8") as handle:
        handle.write("temporary payload")

    print(f"Created and closed {TEMP_FILE}")

    if TEMP_FILE.exists():
        TEMP_FILE.unlink()
        print("Temporary file removed")


if __name__ == "__main__":
    main()
