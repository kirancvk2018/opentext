@echo off
echo ==================================
echo Compressing Reports Folder
echo ==================================
powershell Compress-Archive -Path Reports -DestinationPath Reports.zip -Force
echo Archive Created Successfully.
