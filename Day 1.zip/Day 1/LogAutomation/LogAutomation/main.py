import sys
import os
from pathlib import Path
from multiprocessing import Pool, current_process
import subprocess
import time

def analyze_log(log_file):
    info = warning = error = total = 0
    with open(log_file, "r") as file:
        for line in file:
            total += 1
            if "INFO" in line:
                info += 1
            elif "WARNING" in line:
                warning += 1
            elif "ERROR" in line:
                error += 1
    return {
        "process": current_process().name,
        "file": Path(log_file).name,
        "total": total,
        "info": info,
        "warning": warning,
        "error": error
    }

def main():
    start = time.time()
    if len(sys.argv) < 2:
        print("Usage: python main.py logs")
        sys.exit()
    log_folder = Path(sys.argv[1])
    print("="*60)
    print("AUTOMATED LOG ANALYZER")
    print("="*60)
    print("Python Version:", sys.version)
    print("Platform:", sys.platform)
    print("Working Folder:", os.getcwd())
    report_folder = Path("Reports")
    report_folder.mkdir(exist_ok=True)
    log_files = list(log_folder.glob("*.log"))
    with Pool() as pool:
        results = pool.map(analyze_log, log_files)
    report = report_folder/"report.txt"
    with open(report,"w") as f:
        f.write("LOG ANALYSIS REPORT\n\n")
        for r in results:
            f.write(f"Process: {r['process']}\nFile: {r['file']}\nLines: {r['total']}\nINFO: {r['info']}\nWARNING: {r['warning']}\nERROR: {r['error']}\n")
            f.write("-"*40+"\n")
    subprocess.run(["cmd","/c","archive.bat"])
    print("Automation Completed Successfully.")
    print(f"Execution Time: {time.time()-start:.2f} seconds")

if __name__ == "__main__":
    main()
