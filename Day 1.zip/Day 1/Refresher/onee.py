import subprocess

print("=" * 60)
print("Executing External Windows Script")
print("=" * 60)

result = subprocess.run(
    ["cmd", "/c", "system_task.bat"],
    capture_output=True,
    text=True
)

print("\nOUTPUT FROM BATCH FILE")
print("-" * 60)
print(result.stdout)

print("\nERRORS")
print("-" * 60)
print(result.stderr)

print("\nReturn Code:", result.returncode)
