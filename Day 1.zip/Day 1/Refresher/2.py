import subprocess,os
commands=[['python','--version'],['echo','Diagnostics']]
for cmd in commands:
    result=subprocess.run(cmd,capture_output=True,text=True,shell=False)
    print('='*40)
    print('Command:',cmd)
    print('Return Code:',result.returncode)
    print(result.stdout or result.stderr)
print('PID:',os.getpid())


