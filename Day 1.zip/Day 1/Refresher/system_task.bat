@echo off

echo ====================================
echo      WINDOWS SYSTEM INFORMATION
echo ====================================

echo.
echo Current User:
whoami

echo.
echo Computer Name:
hostname

echo.
echo Current Directory:
cd

echo.
echo Current Date and Time:
date /t
time /t

echo.
echo Listing Current Folder:
dir

echo.
echo Script Execution Completed