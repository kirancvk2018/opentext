"""Module Name: Standard Input
Topic: Reading data from standard input
Problem Statement: Enterprise pipelines often receive incident reports or data streams through stdin.
Enterprise Scenario: An on-call engineer wants to process text from a log collector or pipeline without creating temporary files.
Learning Objectives:
- Read from sys.stdin
- Handle empty input gracefully
- Transform incoming data into structured output
Prerequisites: Basic Python file handling and strings
Expected Output: A cleaned summary of the received input.
Concepts Covered: sys.stdin, input normalization, stream processing
"""

from __future__ import annotations

import sys
from pathlib import Path


MODULE_NAME = "03_standard_input"
SAMPLE_INPUT = Path("assets/sample.txt")


def read_input() -> str:
    """Read input from stdin if provided; otherwise fall back to a sample file."""
    if not sys.stdin.isatty():
        return sys.stdin.read().strip()

    if SAMPLE_INPUT.exists():
        return SAMPLE_INPUT.read_text(encoding="utf-8").strip()

    return "No input provided"


def summarize_text(text: str) -> str:
    """Produce a concise summary of raw text."""
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    return (
        f"Received {len(lines)} non-empty lines.\n"
        f"First line: {lines[0] if lines else 'N/A'}"
    )


def main() -> None:
    """Process streamed or file-based input."""
    text = read_input()
    print("[INFO] Processing inbound text")
    print(summarize_text(text))


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Processing inbound text
# Received N non-empty lines.
# First line: ...

# Best Practices:
# - Check whether stdin is interactive before reading.
# - Normalize input before processing.

# Common Mistakes:
# - Blocking indefinitely on input when no data is present.
# - Forgetting to strip whitespace.

# Interview Questions:
# - How do you distinguish interactive input from piped input?
# - Why is normalization important for stream processing?

# Challenge Exercise:
# - Extend the script to count the number of words in the incoming text.
