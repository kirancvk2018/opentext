"""Module Name: subprocess.Popen
Topic: Managing long-running processes with subprocess.Popen
Problem Statement: Enterprise systems sometimes need to start background tasks and monitor their output over time.
Enterprise Scenario: An operations team wants to launch a monitoring helper process and capture its output without blocking the main script.
Learning Objectives:
- Launch a process with subprocess.Popen
- Read output incrementally
- Manage process lifecycle safely
Prerequisites: Basic subprocess knowledge and process concepts
Expected Output: A process identifier and captured output.
Concepts Covered: subprocess.Popen, communicate, stdout pipe, process management
"""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path


MODULE_NAME = "12_subprocess_popen"
WORKDIR = Path(__file__).resolve().parent.parent


def launch_process(command: list[str]) -> None:
    """Launch a process and collect output without blocking indefinitely."""
    process = subprocess.Popen(
        command,
        cwd=WORKDIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    try:
        output, _ = process.communicate(timeout=3)
    except subprocess.TimeoutExpired:
        process.terminate()
        output, _ = process.communicate(timeout=5)
        print("[WARN] Process exceeded the expected runtime and was terminated")

    print(f"[INFO] Process ID: {process.pid}")
    print(output.strip())


def main() -> None:
    """Demonstrate process launch and output capture."""
    launch_process([sys.executable, "-c", "import time; print('monitoring worker started'); time.sleep(2)"])


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Process ID: <pid>
# monitoring worker started

# Best Practices:
# - Use Popen when you need more control than subprocess.run offers.
# - Always terminate or wait for processes when done.

# Common Mistakes:
# - Leaving child processes running after the script exits.
# - Blocking indefinitely on reads.

# Interview Questions:
# - How does Popen differ from run?
# - When would you choose Popen for process orchestration?

# Challenge Exercise:
# - Add a timeout and print a warning if the process does not complete in time.
