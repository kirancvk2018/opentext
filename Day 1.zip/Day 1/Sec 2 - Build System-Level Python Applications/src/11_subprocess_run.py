"""Module Name: subprocess.run()
Topic: Running external commands with subprocess.run
Problem Statement: Enterprise automation often needs to invoke system tools and capture their output.
Enterprise Scenario: A support engineer wants to inspect the Python version and list files in a project directory using a standard command.
Learning Objectives:
- Use subprocess.run to execute commands
- Capture stdout and stderr
- Handle command failures safely
Prerequisites: Basic understanding of command-line tools
Expected Output: Output from the executed system command.
Concepts Covered: subprocess.run, capture_output, check, text
"""

from __future__ import annotations

import subprocess
from pathlib import Path


MODULE_NAME = "11_subprocess_run"
WORKDIR = Path(__file__).resolve().parent.parent


def run_command(command: list[str]) -> None:
    """Run a shell-style command and print its output."""
    try:
        completed = subprocess.run(
            command,
            cwd=WORKDIR,
            text=True,
            capture_output=True,
            check=True,
        )
        print("[INFO] Command completed successfully")
        if completed.stdout:
            print(completed.stdout)
        if completed.stderr:
            print(completed.stderr)
    except FileNotFoundError:
        print("[ERROR] Command not found")
    except subprocess.CalledProcessError as error:
        print(f"[ERROR] Command failed with exit code {error.returncode}")
        if error.stdout:
            print(error.stdout)
        if error.stderr:
            print(error.stderr)


def main() -> None:
    """Execute a simple command using subprocess.run."""
    run_command(["python", "--version"])


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Command completed successfully
# Python 3.x.x

# Best Practices:
# - Prefer subprocess.run for simple command execution.
# - Use check=True for fail-fast behavior.

# Common Mistakes:
# - Using shell=True without understanding the security implications.
# - Ignoring exit codes.

# Interview Questions:
# - Why is subprocess.run preferred over os.system?
# - What is the purpose of capture_output?

# Challenge Exercise:
# - Run a directory listing command and print the result.
