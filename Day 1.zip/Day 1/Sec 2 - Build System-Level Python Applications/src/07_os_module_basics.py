"""Module Name: os Module Basics
Topic: Working with the os module for system tasks
Problem Statement: Enterprise scripts often need to inspect and alter the runtime environment.
Enterprise Scenario: A support engineer needs to verify the current working directory, environment variables, and whether a temp directory exists.
Learning Objectives:
- Use os.path and os.environ
- Inspect file system metadata
- Build portable system utilities
Prerequisites: Basic understanding of file paths and environment variables
Expected Output: A summary of the current environment and file system state.
Concepts Covered: os, os.path, os.environ, path inspection
"""

from __future__ import annotations

import os
from pathlib import Path


MODULE_NAME = "07_os_module_basics"
TEMP_DIR = Path("assets/logs")


def inspect_environment() -> None:
    """Print key environment and path information."""
    print("[INFO] Environment Summary")
    print(f"- Current working directory: {os.getcwd()}")
    print(f"- User home: {os.path.expanduser('~')}")
    print(f"- PATH available: {'PATH' in os.environ}")


def inspect_directory(path: Path) -> None:
    """Show whether a directory exists and list its contents."""
    if not path.exists():
        print(f"[WARN] Directory missing: {path}")
        return

    print(f"[INFO] Directory exists: {path}")
    for child in sorted(path.iterdir()):
        print(f"  - {child.name}")


def main() -> None:
    """Execute the os-based example."""
    inspect_environment()
    inspect_directory(TEMP_DIR)


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Environment Summary
# - Current working directory: ...
# - User home: ...
# - PATH available: True

# Best Practices:
# - Prefer os.path or pathlib for cross-platform path handling.
# - Avoid hard-coding separators.

# Common Mistakes:
# - Assuming Linux-style paths on Windows.
# - Using environment variables without checking their presence.

# Interview Questions:
# - How does os.path differ from pathlib?
# - Why is environment inspection important in automation?

# Challenge Exercise:
# - Print the size of each child entry in the target directory.
