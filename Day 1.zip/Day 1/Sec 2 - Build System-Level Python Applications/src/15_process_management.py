"""Module Name: Process Management
Topic: Managing processes and their lifecycle
Problem Statement: Enterprise systems need to monitor and control background services or child processes.
Enterprise Scenario: A service controller wants to start a helper process, inspect its status, and terminate it cleanly.
Learning Objectives:
- Start and stop child processes
- Check process status
- Handle process exit codes
Prerequisites: Basic understanding of subprocess and OS processes
Expected Output: A managed process lifecycle with a final status report.
Concepts Covered: subprocess.Popen, poll(), terminate(), wait()
"""

from __future__ import annotations

import subprocess
import sys
import time


MODULE_NAME = "15_process_management"


def manage_process() -> None:
    """Start a child process, inspect it, and terminate it."""
    process = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(10)"],
    )

    print(f"[INFO] Started process with PID {process.pid}")
    time.sleep(1)
    print(f"[INFO] Poll result before terminate: {process.poll()}")

    process.terminate()
    process.wait(timeout=5)
    print(f"[INFO] Final exit code: {process.returncode}")


def main() -> None:
    """Run the process management example."""
    manage_process()


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Started process with PID <pid>
# [INFO] Poll result before terminate: None
# [INFO] Final exit code: -15 or 0 depending on platform

# Best Practices:
# - Always wait for a process after termination.
# - Use poll() to inspect state without blocking.

# Common Mistakes:
# - Forgetting to clean up child processes.
# - Assuming a process has already exited.

# Interview Questions:
# - What is the difference between poll() and wait()?
# - Why is graceful termination important?

# Challenge Exercise:
# - Add a timeout handler to terminate the process if it does not stop within a few seconds.
