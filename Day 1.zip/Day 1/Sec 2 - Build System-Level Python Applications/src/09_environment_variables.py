"""Module Name: Environment Variables
Topic: Reading and setting environment variables
Problem Statement: Enterprise applications frequently rely on environment-specific configuration values.
Enterprise Scenario: A deployment process needs to read secrets and environment names at runtime without hard-coding them.
Learning Objectives:
- Access os.environ values safely
- Provide default values for missing settings
- Show enterprise-safe configuration patterns
Prerequisites: Basic understanding of environment variables
Expected Output: A configuration summary based on runtime environment values.
Concepts Covered: os.environ, defaults, configuration management
"""

from __future__ import annotations

import os


MODULE_NAME = "09_environment_variables"


def get_setting(name: str, default: str = "") -> str:
    """Return an environment variable value or a fallback default."""
    return os.environ.get(name, default)


def main() -> None:
    """Print an environment-based configuration summary."""
    service_name = get_setting("SERVICE_NAME", "inventory-service")
    environment = get_setting("ENVIRONMENT", "development")
    log_level = get_setting("LOG_LEVEL", "INFO")

    print("[INFO] Runtime Configuration")
    print(f"- Service Name: {service_name}")
    print(f"- Environment: {environment}")
    print(f"- Log Level: {log_level}")


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Runtime Configuration
# - Service Name: inventory-service
# - Environment: development
# - Log Level: INFO

# Best Practices:
# - Use environment variables for deployment-specific values.
# - Avoid storing secrets directly in source code.

# Common Mistakes:
# - Assuming variables always exist.
# - Exposing secrets in logs.

# Interview Questions:
# - Why are environment variables useful in CI/CD pipelines?
# - What is the difference between configuration files and environment variables?

# Challenge Exercise:
# - Add support for a custom timeout value from the environment.
