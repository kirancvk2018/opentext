"""Module Name: Enterprise Backup Utility
Topic: Building an enterprise-grade backup automation script
Problem Statement: Businesses need reliable backup procedures for important data and reports.
Enterprise Scenario: A company wants a backup utility that copies key files to an archive folder and keeps a manifest of created backups.
Learning Objectives:
- Create a reusable backup workflow
- Preserve file metadata and maintain a manifest
- Handle backup errors and edge cases
Prerequisites: Basic file handling, paths, and timestamps
Expected Output: A backup folder containing copied files and a manifest file.
Concepts Covered: shutil, datetime, pathlib, manifest generation
"""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from typing import Iterable


MODULE_NAME = "18_enterprise_backup_utility"
SOURCE_DIR = Path("assets")
BACKUP_ROOT = Path("assets/reports/backup_archive")
MANIFEST_PATH = BACKUP_ROOT / "backup_manifest.txt"


def gather_files(root: Path) -> Iterable[Path]:
    """Yield files that should be included in the backup."""
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix in {".txt", ".csv", ".json"}:
            yield path


def create_backup() -> None:
    """Create timestamped backup copies of selected files and write a manifest."""
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamped_dir = BACKUP_ROOT / timestamp
    timestamped_dir.mkdir(parents=True, exist_ok=True)

    manifest_lines = [f"Backup created: {timestamp}", ""]
    for source_path in gather_files(SOURCE_DIR):
        relative_path = source_path.relative_to(SOURCE_DIR)
        destination_path = timestamped_dir / relative_path
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, destination_path)
        manifest_lines.append(f"- {relative_path}")

    MANIFEST_PATH.write_text("\n".join(manifest_lines), encoding="utf-8")
    print(f"[INFO] Backup completed at {timestamped_dir}")
    print(f"[INFO] Manifest written to {MANIFEST_PATH}")


def main() -> None:
    """Run the backup utility example."""
    create_backup()


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Backup completed at assets/reports/backup_archive/YYYYMMDD_HHMMSS
# [INFO] Manifest written to assets/reports/backup_archive/backup_manifest.txt

# Best Practices:
# - Use timestamped backup folders for recoverability.
# - Maintain a manifest for auditability.

# Common Mistakes:
# - Overwriting previous backups without versioning.
# - Not documenting what was backed up.

# Interview Questions:
# - Why are backup manifests important?
# - How does timestamping improve backup reliability?

# Challenge Exercise:
# - Add retention logic to remove backups older than 10 days.
