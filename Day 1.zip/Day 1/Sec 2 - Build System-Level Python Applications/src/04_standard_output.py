"""Module Name: Standard Output
Topic: Writing clear and structured output to stdout
Problem Statement: Enterprise scripts must provide readable status updates for operators and monitoring systems.
Enterprise Scenario: A report generator needs to print a concise summary of user activity from a CSV file.
Learning Objectives:
- Write formatted output to stdout
- Use string formatting for clarity
- Produce machine-readable and human-readable output
Prerequisites: CSV handling and basic string formatting
Expected Output: A formatted console report.
Concepts Covered: print(), formatting, CSV parsing, reporting
"""

from __future__ import annotations

import csv
from pathlib import Path


MODULE_NAME = "04_standard_output"
CSV_PATH = Path("assets/sample.csv")


def load_users(path: Path) -> list[dict[str, str]]:
    """Load user records from a CSV file."""
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def build_report(records: list[dict[str, str]]) -> str:
    """Create a human-friendly summary report."""
    active_count = sum(1 for row in records if row.get("status", "").lower() == "active")
    pending_count = sum(1 for row in records if row.get("status", "").lower() == "pending")

    lines = [
        "User Activity Report",
        "=" * 22,
        f"Total Records: {len(records)}",
        f"Active Users: {active_count}",
        f"Pending Users: {pending_count}",
    ]
    return "\n".join(lines)


def main() -> None:
    """Print the report to standard output."""
    records = load_users(CSV_PATH)
    print(build_report(records))


if __name__ == "__main__":
    main()


# Expected Output:
# User Activity Report
# =====================
# Total Records: 3
# Active Users: 2
# Pending Users: 1

# Best Practices:
# - Format output for readability.
# - Separate data preparation from presentation.

# Common Mistakes:
# - Printing unstructured or inconsistent text.
# - Mixing report generation with file I/O logic.

# Interview Questions:
# - Why is stdout important in automation scripts?
# - How do you keep output clear for operators and logs?

# Challenge Exercise:
# - Add a section showing the department breakdown.
