"""Module Name: System Administration Tool
Topic: Building a practical admin utility with Python
Problem Statement: System administrators often need a CLI tool to inspect disk usage, available space, and environment health.
Enterprise Scenario: An infrastructure team wants a lightweight admin helper to summarize the current workspace and available storage.
Learning Objectives:
- Combine standard library modules into a usable tool
- Present actionable system information
- Handle missing resources gracefully
Prerequisites: Basic file system and OS concepts
Expected Output: A concise admin status report.
Concepts Covered: shutil.disk_usage, os.getcwd, pathlib, reporting
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path


MODULE_NAME = "17_system_administration_tool"
ROOT = Path(__file__).resolve().parent.parent


def summarize_disk_usage(path: Path) -> str:
    """Return a portable summary of disk usage for the given path."""
    total, used, free = shutil.disk_usage(path)
    return (
        f"Disk usage for {path}:\n"
        f"- Total: {total // (1024 * 1024)} MB\n"
        f"- Used: {used // (1024 * 1024)} MB\n"
        f"- Free: {free // (1024 * 1024)} MB"
    )


def main() -> None:
    """Print a lightweight administration summary."""
    print("[INFO] System Administration Summary")
    print(f"- Working directory: {os.getcwd()}")
    print(f"- Repository root: {ROOT}")
    print(summarize_disk_usage(ROOT))


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] System Administration Summary
# - Working directory: ...
# - Repository root: ...
# Disk usage for ...
# - Total: ... MB
# - Used: ... MB
# - Free: ... MB

# Best Practices:
# - Keep admin scripts focused on actionable information.
# - Report disk usage in a human-readable format.

# Common Mistakes:
# - Hard-coding paths instead of using runtime values.
# - Ignoring very large or very small values.

# Interview Questions:
# - How can Python help with infrastructure monitoring?
# - Why is disk usage information important for administrators?

# Challenge Exercise:
# - Extend the script to report the largest file under the repository.
