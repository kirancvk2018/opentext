"""Module Name: argparse Basics
Topic: Building command-line tools with argparse
Problem Statement: Enterprise automation tools need structured command-line interfaces that are self-documenting and robust.
Enterprise Scenario: A deployment engineer needs a script to validate, deploy, or roll back application releases with clear options.
Learning Objectives:
- Parse command-line arguments with argparse
- Define subcommands and options
- Validate enterprise input before execution
Prerequisites: Basic Python functions and command-line usage
Expected Output: A deployment summary for the selected action.
Concepts Covered: argparse, subcommands, validation, CLI design
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


MODULE_NAME = "02_argparse_basics"
CONFIG_PATH = Path("assets/config.json")


def load_config(path: Path) -> dict[str, Any]:
    """Load a JSON configuration file used for deployment metadata."""
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def build_parser() -> argparse.ArgumentParser:
    """Create an argparse parser for deployment workflows."""
    parser = argparse.ArgumentParser(description="Enterprise deployment utility")
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser("validate", help="Validate deployment settings")
    validate_parser.add_argument("--environment", default="production")

    deploy_parser = subparsers.add_parser("deploy", help="Deploy application configuration")
    deploy_parser.add_argument("--environment", default="production")
    deploy_parser.add_argument("--version", required=True)

    rollback_parser = subparsers.add_parser("rollback", help="Rollback the last deployment")
    rollback_parser.add_argument("--environment", default="production")

    return parser


def handle_validate(config: dict[str, Any], environment: str) -> None:
    """Validate the configuration for a specific environment."""
    print(f"[INFO] Validating configuration for {environment}")
    print(f"[INFO] Service: {config.get('service', 'unknown')}")
    print(f"[INFO] Log Level: {config.get('log_level', 'INFO')}")


def handle_deploy(config: dict[str, Any], environment: str, version: str) -> None:
    """Simulate a deployment action using the provided configuration."""
    print(f"[INFO] Deploying version {version} to {environment}")
    print(f"[INFO] Retention policy: {config.get('retention_days', 0)} days")


def handle_rollback(environment: str) -> None:
    """Simulate a rollback operation."""
    print(f"[INFO] Rolling back {environment} to the previous known-good release")


def main() -> None:
    """Execute the CLI workflow."""
    parser = build_parser()
    args = parser.parse_args()

    try:
        config = load_config(CONFIG_PATH)
    except FileNotFoundError:
        print("[ERROR] Configuration file not found. Expected assets/config.json")
        return

    if args.command == "validate":
        handle_validate(config, args.environment)
    elif args.command == "deploy":
        handle_deploy(config, args.environment, args.version)
    elif args.command == "rollback":
        handle_rollback(args.environment)


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Validating configuration for production
# [INFO] Service: inventory
# [INFO] Log Level: INFO

# Best Practices:
# - Use subcommands for distinct workflows.
# - Provide helpful help text and defaults.

# Common Mistakes:
# - Using positional arguments where options would be clearer.
# - Forgetting to make subcommands required.

# Interview Questions:
# - Why is argparse preferred over manual parsing for enterprise CLI tools?
# - How do you add subcommands to a parser?

# Challenge Exercise:
# - Add a --dry-run option to the deploy subcommand.
