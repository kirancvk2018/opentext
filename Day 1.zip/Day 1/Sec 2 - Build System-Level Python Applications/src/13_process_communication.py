"""Module Name: Process Communication
Topic: Communicating with child processes
Problem Statement: Enterprise utilities often need to exchange data with a subprocess rather than just launch it.
Enterprise Scenario: A monitoring service wants to send a request to a helper process and receive a response.
Learning Objectives:
- Use subprocess.PIPE for input and output
- Send data to a child process
- Receive and parse child process responses
Prerequisites: Basic subprocess and pipe concepts
Expected Output: A response received from the child process.
Concepts Covered: subprocess.PIPE, stdin/stdout communication, input/output handling
"""

from __future__ import annotations

import subprocess
import sys


MODULE_NAME = "13_process_communication"


def communicate_with_child() -> None:
    """Send a message to a Python subprocess and print the reply."""
    script = "import sys; data = sys.stdin.read().strip(); print(data.upper())"
    process = subprocess.Popen(
        [sys.executable, "-c", script],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    stdout, stderr = process.communicate("deploy-now")
    print("[INFO] Child process response:")
    print(stdout.strip())
    if stderr:
        print(f"[WARN] Child stderr: {stderr}")


def main() -> None:
    """Run the inter-process communication example."""
    communicate_with_child()


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Child process response:
# DEPLOY-NOW

# Best Practices:
# - Use pipes for structured command-line communication.
# - Handle stderr separately from stdout.

# Common Mistakes:
# - Treating stdout as the only communication channel.
# - Forgetting to close or drain pipes.

# Interview Questions:
# - What is the role of stdin and stdout in process communication?
# - How can you avoid deadlocks with pipes?

# Challenge Exercise:
# - Send multiple lines to the child process and return the count of lines.
