"""Module Name: exec() and eval()
Topic: Executing dynamic Python code safely and responsibly
Problem Statement: Some automation systems need to evaluate dynamic expressions or execute generated code snippets.
Enterprise Scenario: A configuration engine wants to evaluate business rules from a trusted source, but developers must understand the security implications.
Learning Objectives:
- Demonstrate the effect of exec() and eval()
- Explain the security concerns of dynamic execution
- Promote safe alternatives for enterprise code
Prerequisites: Basic Python expressions and functions
Expected Output: A computed result and a short security discussion.
Concepts Covered: exec, eval, dynamic execution, security considerations
"""

from __future__ import annotations


MODULE_NAME = "14_exec_functions"


def demonstrate_eval() -> None:
    """Evaluate a simple arithmetic expression."""
    expression = "3 * 7 + 2"
    result = eval(expression, {"__builtins__": {}}, {})
    print(f"[INFO] eval result: {result}")


def demonstrate_exec() -> None:
    """Execute a small Python statement block."""
    code = "value = 10\nvalue += 5"
    namespace: dict[str, int] = {}
    exec(code, {"__builtins__": {}}, namespace)
    print(f"[INFO] exec result: {namespace['value']}")


def main() -> None:
    """Show dynamic execution examples and explain the security risk."""
    demonstrate_eval()
    demonstrate_exec()
    print("[WARN] Avoid using eval/exec on untrusted input.")


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] eval result: 23
# [INFO] exec result: 15
# [WARN] Avoid using eval/exec on untrusted input.

# Best Practices:
# - Never execute untrusted strings.
# - Prefer explicit code paths over dynamic evaluation.

# Common Mistakes:
# - Using eval to parse user input without validation.
# - Overlooking the builtins exposure in the namespace.

# Interview Questions:
# - Why is eval considered risky?
# - What safer alternatives exist for dynamic logic?

# Challenge Exercise:
# - Rewrite the example to use a dictionary of allowed operations instead of eval.
