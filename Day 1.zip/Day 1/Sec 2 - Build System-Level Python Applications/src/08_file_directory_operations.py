"""Module Name: File and Directory Operations
Topic: Managing files and directories with Python
Problem Statement: Enterprise workflows often need to create, move, copy, and archive files as part of daily operations.
Enterprise Scenario: A systems engineer wants to organize reports into dated folders and preserve a backup copy.
Learning Objectives:
- Create directories and files
- Move and copy files safely
- Handle common file system errors
Prerequisites: Basic file handling and path concepts
Expected Output: A date-stamped directory structure and copied report files.
Concepts Covered: shutil, Path, file operations, safe copying
"""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path


MODULE_NAME = "08_file_directory_operations"
SOURCE_FILE = Path("assets/sample.txt")
TARGET_DIR = Path("assets/reports/processed")
BACKUP_DIR = Path("assets/reports/backup")


def prepare_directories() -> None:
    """Create the target and backup directories if needed."""
    TARGET_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def copy_and_archive() -> None:
    """Copy the sample file into a processed folder and preserve a backup copy."""
    prepare_directories()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    destination = TARGET_DIR / f"sample_{timestamp}.txt"
    backup_destination = BACKUP_DIR / f"sample_{timestamp}.txt"

    shutil.copy2(SOURCE_FILE, destination)
    shutil.copy2(SOURCE_FILE, backup_destination)

    print(f"[INFO] Copied sample file to {destination}")
    print(f"[INFO] Backup saved to {backup_destination}")


def main() -> None:
    """Run the file and directory operation example."""
    copy_and_archive()


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Copied sample file to assets/reports/processed/sample_YYYYMMDD_HHMMSS.txt
# [INFO] Backup saved to assets/reports/backup/sample_YYYYMMDD_HHMMSS.txt

# Best Practices:
# - Use shutil for robust file copying.
# - Preserve metadata with copy2 when appropriate.

# Common Mistakes:
# - Using shutil.copy instead of copy2 when metadata matters.
# - Forgetting to create parent directories first.

# Interview Questions:
# - What is the difference between copy and copy2?
# - Why are backup copies important in automation?

# Challenge Exercise:
# - Add a function to remove older processed files while keeping the newest copy.
