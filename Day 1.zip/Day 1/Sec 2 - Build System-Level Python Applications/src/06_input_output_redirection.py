"""Module Name: Input and Output Redirection
Topic: Redirecting stdin, stdout, and stderr in Python
Problem Statement: Automation pipelines often redirect streams to files or other processes.
Enterprise Scenario: A data pipeline wants to capture a command's output into a report file while preserving diagnostic messages.
Learning Objectives:
- Redirect stdout and stderr using context managers
- Read from a file-like object as stdin
- Capture stream behavior for enterprise workflows
Prerequisites: Basic file handling and context managers
Expected Output: A redirected report saved to disk.
Concepts Covered: redirect_stdout, redirect_stderr, contextlib, file-like objects
"""

from __future__ import annotations

import contextlib
import io
import sys
from pathlib import Path


MODULE_NAME = "06_input_output_redirection"
REPORT_PATH = Path("assets/reports/redirected_report.txt")


def build_message() -> str:
    """Create a message that will be captured to a file."""
    return "Pipeline report generated successfully.\nStatus: healthy"


def redirect_output() -> None:
    """Redirect stdout into a report file and print a warning to stderr."""
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with REPORT_PATH.open("w", encoding="utf-8") as handle:
        with contextlib.redirect_stdout(handle):
            print(build_message())
        sys.stderr.write("[WARN] Diagnostics preserved separately\n")


def read_from_buffer() -> None:
    """Demonstrate consumption of text from a file-like object."""
    buffer = io.StringIO("alpha\nbeta\ngamma")
    lines = buffer.read().splitlines()
    print(f"[INFO] Captured {len(lines)} lines from an in-memory stream")


def main() -> None:
    """Execute the redirection example."""
    redirect_output()
    read_from_buffer()
    print(f"[INFO] Report written to {REPORT_PATH}")


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Captured 3 lines from an in-memory stream
# [INFO] Report written to assets/reports/redirected_report.txt

# Best Practices:
# - Use redirection when you need to capture or archive output.
# - Keep diagnostics separate from primary results.

# Common Mistakes:
# - Mixing redirected output with interactive console logs.
# - Forgetting to close file handles.

# Interview Questions:
# - How does redirect_stdout differ from printing to a file directly?
# - When would you want to redirect stderr separately?

# Challenge Exercise:
# - Redirect both stdout and stderr into separate files using context managers.
