"""Module Name: Standard Error
Topic: Sending diagnostics and errors to stderr
Problem Statement: Enterprise scripts should separate normal output from warnings and failures.
Enterprise Scenario: A batch job needs to log warnings and errors without polluting the primary report stream.
Learning Objectives:
- Write to stderr for diagnostics
- Handle expected failures gracefully
- Keep stdout focused on successful output
Prerequisites: Basic exception handling and stream awareness
Expected Output: A warning report written to stderr and a summary written to stdout.
Concepts Covered: sys.stderr, error handling, logging conventions
"""

from __future__ import annotations

import sys
from pathlib import Path


MODULE_NAME = "05_standard_error"
TARGET_PATH = Path("assets/does_not_exist.txt")


def validate_file(path: Path) -> bool:
    """Check whether a file exists and report the result to stderr on failure."""
    if not path.exists():
        sys.stderr.write(f"[WARN] Missing file: {path}\n")
        return False
    return True


def main() -> None:
    """Show how warnings and errors can be separated from main output."""
    print("[INFO] Starting validation run")
    if validate_file(TARGET_PATH):
        print(f"[INFO] File found: {TARGET_PATH}")
    else:
        print("[INFO] Validation completed with warnings")


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Starting validation run
# [WARN] Missing file: assets/does_not_exist.txt
# [INFO] Validation completed with warnings

# Best Practices:
# - Use stderr for warnings and errors.
# - Keep stdout reserved for meaningful results.

# Common Mistakes:
# - Writing error messages to stdout and losing the distinction.
# - Failing to handle missing files explicitly.

# Interview Questions:
# - Why is stderr useful in automation?
# - How can you redirect stderr separately from stdout?

# Challenge Exercise:
# - Add a retry loop for a missing file and print each attempt to stderr.
