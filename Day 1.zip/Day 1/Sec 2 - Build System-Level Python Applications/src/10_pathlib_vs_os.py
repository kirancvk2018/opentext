"""Module Name: pathlib vs os.path
Topic: Comparing pathlib and os.path for path handling
Problem Statement: Enterprise codebases often need to decide between pathlib and os.path based on readability and compatibility.
Enterprise Scenario: An application team wants a clear, maintainable way to resolve config files and report locations across platforms.
Learning Objectives:
- Use pathlib to build readable path operations
- Compare pathlib with os.path semantics
- Demonstrate common path manipulations
Prerequisites: Basic path handling concepts
Expected Output: A path summary showing the resolved file locations.
Concepts Covered: pathlib, os.path, path resolution
"""

from __future__ import annotations

import os
from pathlib import Path


MODULE_NAME = "10_pathlib_vs_os"
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "assets" / "config.json"
REPORT_PATH = BASE_DIR / "assets" / "reports"


def show_path_examples() -> None:
    """Demonstrate equivalent pathlib and os.path operations."""
    print("[INFO] Path Examples")
    print(f"- pathlib parent: {CONFIG_PATH.parent}")
    print(f"- os.path dirname: {os.path.dirname(str(CONFIG_PATH))}")
    print(f"- pathlib name: {CONFIG_PATH.name}")
    print(f"- os.path basename: {os.path.basename(str(CONFIG_PATH))}")
    print(f"- pathlib exists: {CONFIG_PATH.exists()}")


def create_report_folder(path: Path) -> None:
    """Create a reports directory using pathlib."""
    path.mkdir(parents=True, exist_ok=True)
    print(f"[INFO] Ensured report folder exists: {path}")


def main() -> None:
    """Show both approaches side by side."""
    show_path_examples()
    create_report_folder(REPORT_PATH)


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Path Examples
# - pathlib parent: ...
# - os.path dirname: ...
# - pathlib name: config.json
# - os.path basename: config.json
# - pathlib exists: True

# Best Practices:
# - Prefer pathlib for new code due to readability.
# - Use os.path when interacting with legacy modules.

# Common Mistakes:
# - Mixing pathlib and os.path style without converting types.
# - Forgetting that Path objects are not strings.

# Interview Questions:
# - Why is pathlib often preferred in modern Python?
# - When might os.path still be necessary?

# Challenge Exercise:
# - Add a function that joins a base directory and a relative filename using both implementations.
