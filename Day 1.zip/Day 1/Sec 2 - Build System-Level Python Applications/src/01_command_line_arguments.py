"""Module Name: Command Line Arguments
Topic: Command-line argument parsing in Python
Problem Statement: Enterprise automation scripts often need to receive runtime options without modifying the source code.
Enterprise Scenario: A DevOps engineer needs a script that can process a log file, target environment, and output directory from the command line.
Learning Objectives:
- Parse command-line arguments using sys.argv
- Validate required inputs
- Build reusable functions for enterprise automation
Prerequisites: Basic Python syntax
Expected Output: A console report showing the accepted configuration values.
Concepts Covered: sys.argv, validation, error handling, enterprise automation
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import List


MODULE_NAME = "01_command_line_arguments"
DEFAULT_OUTPUT_DIR = "reports"


def parse_arguments(arguments: List[str]) -> dict[str, str]:
    """Parse a simple set of command-line arguments for an automation workflow."""
    if not arguments:
        raise ValueError("No arguments provided.")

    if len(arguments) < 3:
        raise ValueError("Usage: python 01_command_line_arguments.py <input_file> <environment> <output_dir>")

    input_file = arguments[0]
    environment = arguments[1]
    output_dir = arguments[2]

    if not input_file.strip():
        raise ValueError("Input file path cannot be empty.")
    if not environment.strip():
        raise ValueError("Environment cannot be empty.")

    return {
        "input_file": input_file,
        "environment": environment,
        "output_dir": output_dir,
    }


def ensure_output_directory(path: str) -> Path:
    """Create the output directory if it does not already exist."""
    output_path = Path(path)
    output_path.mkdir(parents=True, exist_ok=True)
    return output_path


def build_report(config: dict[str, str]) -> str:
    """Create a summary string for the supplied configuration."""
    return (
        "Automation Configuration\n"
        f"- Input File: {config['input_file']}\n"
        f"- Environment: {config['environment']}\n"
        f"- Output Directory: {config['output_dir']}\n"
        f"- Working Directory: {os.getcwd()}"
    )


def main() -> None:
    """Run the example script."""
    try:
        config = parse_arguments(sys.argv[1:])
        output_dir = ensure_output_directory(config["output_dir"])
        report = build_report(config)
        print("[INFO] Command-line arguments accepted successfully.")
        print(report)
        print(f"[INFO] Output directory ready: {output_dir}")
    except ValueError as error:
        print(f"[ERROR] {error}")
        print("Example: python src/01_command_line_arguments.py assets/sample.txt production reports")
        sys.exit(1)
    except OSError as error:
        print(f"[ERROR] Unable to create output directory: {error}")
        sys.exit(1)


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Command-line arguments accepted successfully.
# Automation Configuration
# - Input File: assets/sample.txt
# - Environment: production
# - Output Directory: reports
# - Working Directory: <current directory>
# [INFO] Output directory ready: <path>

# Best Practices:
# - Validate arguments before processing.
# - Use type hints for clarity.
# - Keep scripts reusable and explicit.

# Common Mistakes:
# - Forgetting to check argument count.
# - Assuming the current working directory is the script directory.

# Interview Questions:
# - What is the difference between sys.argv and argparse?
# - How do you validate command-line input in enterprise scripts?

# Challenge Exercise:
# - Extend the script to accept an optional --verbose flag and print additional details.
