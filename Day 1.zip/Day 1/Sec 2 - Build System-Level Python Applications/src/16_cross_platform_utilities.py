"""Module Name: Cross-Platform Utilities
Topic: Writing code that behaves well across platforms
Problem Statement: Enterprise software often needs to run on Windows, Linux, and macOS.
Enterprise Scenario: A platform team needs to create temporary directories and identify the current OS in a portable way.
Learning Objectives:
- Use platform module safely
- Write OS-agnostic file and path logic
- Handle platform-specific behavior with care
Prerequisites: Familiarity with basic Python modules and OS differences
Expected Output: A platform report and a temporary directory created in a portable way.
Concepts Covered: platform, os, tempfile, cross-platform design
"""

from __future__ import annotations

import os
import platform
import tempfile
from pathlib import Path


MODULE_NAME = "16_cross_platform_utilities"


def report_platform() -> None:
    """Print system platform information."""
    print("[INFO] Platform Report")
    print(f"- System: {platform.system()}")
    print(f"- Release: {platform.release()}")
    print(f"- Python version: {platform.python_version()}")


def create_temp_workspace() -> Path:
    """Create a temporary working directory with a standard library helper."""
    temp_dir = Path(tempfile.mkdtemp(prefix="sysprog_", dir=None))
    print(f"[INFO] Temporary workspace created: {temp_dir}")
    return temp_dir


def main() -> None:
    """Demonstrate portable utilities."""
    report_platform()
    workspace = create_temp_workspace()
    print(f"[INFO] Path exists: {workspace.exists()}")
    os.rmdir(workspace)


if __name__ == "__main__":
    main()


# Expected Output:
# [INFO] Platform Report
# - System: Windows/Linux/macOS
# - Release: ...
# - Python version: ...

# Best Practices:
# - Use tempfile instead of hard-coded paths.
# - Test scripts on the target operating systems.

# Common Mistakes:
# - Assuming path separators or shell commands are universal.
# - Leaking temporary directories after use.

# Interview Questions:
# - Why is cross-platform awareness important for system tools?
# - How does tempfile help with portability?

# Challenge Exercise:
# - Add a function to create a nested directory under the temp workspace.
