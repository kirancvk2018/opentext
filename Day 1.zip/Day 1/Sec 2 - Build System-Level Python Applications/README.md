# Section02_System_Level_Python_Programming

A production-style training repository for learning Python system programming through enterprise-focused examples.

## Module Overview

This repository demonstrates how Python can be used to automate operating system tasks, interact with external processes, manage files and directories, handle streams, and build practical command-line utilities.

## Learning Objectives

- Understand Python command-line argument handling.
- Work with standard input, output, and error streams.
- Automate file and directory operations.
- Use environment variables and platform-aware utilities.
- Launch and manage external processes with subprocess.
- Build reusable system administration and backup automation scripts.

## Repository Structure

```text
Section02_System_Level_Python_Programming/
README.md
requirements.txt
LICENSE
.gitignore
.vscode/
    launch.json
    settings.json
assets/
    sample.txt
    sample.csv
    config.json
    logs/
    reports/
src/
    01_command_line_arguments.py
    02_argparse_basics.py
    03_standard_input.py
    04_standard_output.py
    05_standard_error.py
    06_input_output_redirection.py
    07_os_module_basics.py
    08_file_directory_operations.py
    09_environment_variables.py
    10_pathlib_vs_os.py
    11_subprocess_run.py
    12_subprocess_popen.py
    13_process_communication.py
    14_exec_functions.py
    15_process_management.py
    16_cross_platform_utilities.py
    17_system_administration_tool.py
    18_enterprise_backup_utility.py
```

## VS Code Setup

1. Open the repository folder in VS Code.
2. Select a Python 3.12+ interpreter.
3. Use the included debug configuration in .vscode/launch.json.

## Running the Examples

From the repository root, run:

```bash
python src/01_command_line_arguments.py
```

## Suggested Learning Order

1. 01_command_line_arguments.py
2. 02_argparse_basics.py
3. 03_standard_input.py
4. 04_standard_output.py
5. 05_standard_error.py
6. 06_input_output_redirection.py
7. 07_os_module_basics.py
8. 08_file_directory_operations.py
9. 09_environment_variables.py
10. 10_pathlib_vs_os.py
11. 11_subprocess_run.py
12. 12_subprocess_popen.py
13. 13_process_communication.py
14. 14_exec_functions.py
15. 15_process_management.py
16. 16_cross_platform_utilities.py
17. 17_system_administration_tool.py
18. 18_enterprise_backup_utility.py

## Best Practices

- Use type hints and docstrings.
- Handle errors gracefully.
- Prefer standard library modules.
- Keep scripts reusable and modular.
- Use clear logging and console output.

## References

- Python Standard Library Documentation
- Python subprocess module documentation
- Python pathlib module documentation
