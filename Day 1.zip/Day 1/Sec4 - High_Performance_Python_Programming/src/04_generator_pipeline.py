"""
Module: 04_generator_pipeline.py
Topic: Building Composable Data Processing Pipelines with Generators
Problem Statement: Data processing involves multiple transformation steps (filter, map, aggregate).
    Naive approaches create intermediate lists at each step, consuming massive memory.
    Generator pipelines perform transformations in-memory with constant space complexity.
Enterprise Scenario: A financial institution processes millions of transaction records daily.
    Pipeline-based processing reduces memory footprint from 80GB to 500MB while improving throughput.
Learning Objectives:
    - Design composable generator pipelines
    - Chain transformations efficiently
    - Minimize intermediate data structures
    - Build reusable pipeline components
Prerequisites:
    - Understanding of generators and lazy evaluation
    - Function composition concepts
Expected Output:
    - Working pipeline implementations
    - Performance comparisons
    - Memory usage analysis
Concepts Covered:
    - Pipeline architecture patterns
    - Composable transformations
    - Generator composition
    - Pipeline optimization
    - Real-world data processing
"""

import sys
import time
from typing import Iterator, Callable, Any, TypeVar, List
from dataclasses import dataclass
from datetime import datetime
import json

T = TypeVar('T')


@dataclass
class Transaction:
    """Represents a financial transaction."""
    id: str
    amount: float
    timestamp: str
    customer_id: str
    category: str
    status: str

    def to_dict(self):
        return {
            'id': self.id,
            'amount': self.amount,
            'timestamp': self.timestamp,
            'customer_id': self.customer_id,
            'category': self.category,
            'status': self.status
        }


def demonstrate_naive_approach() -> None:
    """Show the problem: naive multi-step processing with intermediate lists."""
    print("\n" + "=" * 80)
    print("SECTION 1: NAIVE APPROACH (ANTI-PATTERN)")
    print("=" * 80)

    def generate_transactions(n: int) -> List[Transaction]:
        """Generate sample transactions."""
        return [
            Transaction(
                id=f"txn_{i}",
                amount=100 + (i % 1000),
                timestamp=f"2024-01-{(i % 28) + 1:02d}",
                customer_id=f"cust_{i % 100}",
                category=['food', 'gas', 'shopping', 'entertainment'][i % 4],
                status=['completed', 'pending', 'failed'][i % 3]
            )
            for i in range(n)
        ]

    n = 100_000
    print(f"Processing {n:,} transactions (naive approach):")

    start = time.perf_counter()

    step1 = generate_transactions(n)
    print(f"  Step 1 (generate): {sys.getsizeof(step1) / 1024:.2f} KB")

    step2 = [t for t in step1 if t.status == 'completed']
    print(f"  Step 2 (filter): {sys.getsizeof(step2) / 1024:.2f} KB ({len(step2):,} items)")

    step3 = [{'id': t.id, 'amount': t.amount} for t in step2]
    print(f"  Step 3 (map): {sys.getsizeof(step3) / 1024:.2f} KB")

    step4 = [t for t in step3 if t['amount'] > 500]
    print(f"  Step 4 (filter): {sys.getsizeof(step4) / 1024:.2f} KB ({len(step4):,} items)")

    result = sum(t['amount'] for t in step4)
    elapsed = time.perf_counter() - start

    print(f"  Total: {len(step4):,} items, sum: {result:.2f}, time: {elapsed*1000:.2f}ms")
    print("Problem: 4 intermediate lists stored in memory!")


def demonstrate_pipeline_approach() -> None:
    """Show the solution: generator-based pipeline."""
    print("\n" + "=" * 80)
    print("SECTION 2: PIPELINE APPROACH (EFFICIENT)")
    print("=" * 80)

    def generate_transactions(n: int) -> Iterator[Transaction]:
        """Generate transactions lazily."""
        for i in range(n):
            yield Transaction(
                id=f"txn_{i}",
                amount=100 + (i % 1000),
                timestamp=f"2024-01-{(i % 28) + 1:02d}",
                customer_id=f"cust_{i % 100}",
                category=['food', 'gas', 'shopping', 'entertainment'][i % 4],
                status=['completed', 'pending', 'failed'][i % 3]
            )

    def filter_by_status(txns: Iterator[Transaction], status: str) -> Iterator[Transaction]:
        """Filter transactions by status."""
        for t in txns:
            if t.status == status:
                yield t

    def extract_fields(txns: Iterator[Transaction]) -> Iterator[dict]:
        """Extract specific fields."""
        for t in txns:
            yield {'id': t.id, 'amount': t.amount}

    def filter_by_amount(txns: Iterator[dict], threshold: float) -> Iterator[dict]:
        """Filter by amount threshold."""
        for t in txns:
            if t['amount'] > threshold:
                yield t

    n = 100_000
    print(f"Processing {n:,} transactions (pipeline approach):")

    start = time.perf_counter()

    pipeline = filter_by_amount(
        extract_fields(
            filter_by_status(
                generate_transactions(n),
                'completed'
            )
        ),
        500
    )

    result = sum(t['amount'] for t in pipeline)
    elapsed = time.perf_counter() - start

    print(f"  Result: sum = {result:.2f}, time: {elapsed*1000:.2f}ms")
    print("  Benefit: No intermediate lists, constant memory footprint!")


def demonstrate_pipeline_builder() -> None:
    """Build reusable pipeline with fluent interface."""
    print("\n" + "=" * 80)
    print("SECTION 3: PIPELINE BUILDER (FLUENT INTERFACE)")
    print("=" * 80)

    class Pipeline:
        """Fluent interface for building data processing pipelines."""

        def __init__(self, data: Iterator[Any]):
            self.data = data

        def filter(self, predicate: Callable[[Any], bool]) -> 'Pipeline':
            """Filter items matching predicate."""
            def filtered():
                for item in self.data:
                    if predicate(item):
                        yield item
            return Pipeline(filtered())

        def map(self, func: Callable[[Any], Any]) -> 'Pipeline':
            """Transform items."""
            def mapped():
                for item in self.data:
                    yield func(item)
            return Pipeline(mapped())

        def take(self, n: int) -> List[Any]:
            """Take first n items."""
            result = []
            for i, item in enumerate(self.data):
                if i >= n:
                    break
                result.append(item)
            return result

        def collect(self) -> List[Any]:
            """Collect all items into list."""
            return list(self.data)

        def sum(self, key: Callable[[Any], float] = lambda x: x) -> float:
            """Sum items."""
            total = 0
            for item in self.data:
                total += key(item)
            return total

    def generate_numbers(n: int) -> Iterator[int]:
        """Generate numbers."""
        for i in range(n):
            yield i

    result = (Pipeline(generate_numbers(100))
              .filter(lambda x: x % 2 == 0)
              .map(lambda x: x ** 2)
              .take(5))

    print(f"Pipeline: filter evens, square, take 5: {result}")

    total = (Pipeline(generate_numbers(100))
             .filter(lambda x: x % 2 == 0)
             .sum(lambda x: x ** 2))

    print(f"Pipeline: filter evens, square, sum: {total}")


def demonstrate_stateful_pipeline() -> None:
    """Pipeline with stateful transformations."""
    print("\n" + "=" * 80)
    print("SECTION 4: STATEFUL PIPELINE TRANSFORMATIONS")
    print("=" * 80)

    def running_sum(numbers: Iterator[int]) -> Iterator[int]:
        """Yield cumulative sum."""
        total = 0
        for num in numbers:
            total += num
            yield total

    def running_average(numbers: Iterator[float]) -> Iterator[float]:
        """Yield running average."""
        total = 0
        count = 0
        for num in numbers:
            total += num
            count += 1
            yield total / count

    def window(data: Iterator[Any], size: int) -> Iterator[List[Any]]:
        """Yield sliding windows of data."""
        buffer = []
        for item in data:
            buffer.append(item)
            if len(buffer) == size:
                yield list(buffer)
                buffer.pop(0)

    def deduplicate(data: Iterator[Any]) -> Iterator[Any]:
        """Remove consecutive duplicates."""
        last = None
        for item in data:
            if item != last:
                yield item
                last = item

    numbers = [1, 2, 3, 4, 5]
    print(f"Running sum of {numbers}: {list(running_sum(iter(numbers)))}")

    averages = [10.0, 20.0, 30.0, 40.0, 50.0]
    print(f"Running average: {[f'{x:.1f}' for x in running_average(iter(averages))]}")

    data = [1, 1, 2, 2, 3, 3, 3, 4, 4]
    print(f"Deduplicate {data}: {list(deduplicate(iter(data)))}")

    windows = list(window(iter(range(10)), 3))
    print(f"Windows (size=3) of 0-9: {windows[:3]}...")


def demonstrate_pipeline_with_logging() -> None:
    """Pipeline with debugging and monitoring."""
    print("\n" + "=" * 80)
    print("SECTION 5: PIPELINE WITH LOGGING/DEBUGGING")
    print("=" * 80)

    def debug(name: str):
        """Decorator to log pipeline steps."""
        def decorator(gen):
            for i, item in enumerate(gen):
                if i < 3 or i % 100 == 0:
                    print(f"  [{name}] Item {i}: {item}")
                yield item
        return decorator

    def numbers(n: int) -> Iterator[int]:
        for i in range(n):
            yield i

    def filter_even(nums: Iterator[int]) -> Iterator[int]:
        for num in nums:
            if num % 2 == 0:
                yield num

    def square(nums: Iterator[int]) -> Iterator[int]:
        for num in nums:
            yield num ** 2

    n = 1000
    print(f"Processing {n:,} numbers with pipeline logging:")

    pipeline = square(debug("square")(
        filter_even(debug("filter_even")(
            numbers(n)
        ))
    ))

    result = sum(1 for _ in pipeline)
    print(f"  Total items: {result}")


def demonstrate_real_world_etl() -> None:
    """Real-world ETL (Extract-Transform-Load) pipeline."""
    print("\n" + "=" * 80)
    print("SECTION 6: REAL-WORLD ETL PIPELINE")
    print("=" * 80)

    def extract_json_lines(filename: str) -> Iterator[dict]:
        """Extract from JSONL file."""
        try:
            with open(filename, 'w') as f:
                for i in range(1000):
                    record = {
                        'id': i,
                        'amount': 100 + (i % 500),
                        'category': ['A', 'B', 'C'][i % 3],
                        'country': ['US', 'UK', 'DE'][i % 3]
                    }
                    f.write(json.dumps(record) + '\n')
        except:
            pass

        with open(filename, 'r') as f:
            for line in f:
                yield json.loads(line)

    def transform_amount(records: Iterator[dict]) -> Iterator[dict]:
        """Apply currency conversion."""
        for record in records:
            record['amount_usd'] = record['amount'] * 1.1
            yield record

    def filter_threshold(records: Iterator[dict], min_amount: float) -> Iterator[dict]:
        """Filter by amount."""
        for record in records:
            if record['amount_usd'] >= min_amount:
                yield record

    def aggregate_by_category(records: Iterator[dict]) -> dict:
        """Load: aggregate results."""
        result = {}
        for record in records:
            cat = record['category']
            if cat not in result:
                result[cat] = {'count': 0, 'total': 0}
            result[cat]['count'] += 1
            result[cat]['total'] += record['amount_usd']
        return result

    filename = "sample_etl.jsonl"
    extract_json_lines(filename)

    print("ETL Pipeline:")
    print("  Extract: Read JSONL file")
    print("  Transform: Convert currency")
    print("  Filter: Only items > 200 USD")
    print("  Load: Aggregate by category")

    pipeline = aggregate_by_category(
        filter_threshold(
            transform_amount(
                extract_json_lines(filename)
            ),
            200
        )
    )

    print(f"Results: {pipeline}")


def demonstrate_pipeline_composition() -> None:
    """Compose multiple pipelines."""
    print("\n" + "=" * 80)
    print("SECTION 7: PIPELINE COMPOSITION")
    print("=" * 80)

    def make_range_pipeline(start: int, end: int) -> Iterator[int]:
        """Simple pipeline returning range."""
        for i in range(start, end):
            yield i

    def make_transform_pipeline(gen: Iterator[int], func: Callable) -> Iterator[int]:
        """Transform pipeline."""
        for item in gen:
            yield func(item)

    def make_filter_pipeline(gen: Iterator[int], pred: Callable) -> Iterator[int]:
        """Filter pipeline."""
        for item in gen:
            if pred(item):
                yield item

    p1 = make_range_pipeline(0, 20)
    p2 = make_transform_pipeline(p1, lambda x: x ** 2)
    p3 = make_filter_pipeline(p2, lambda x: x % 2 == 0)

    print(f"Composed pipeline (0-19 -> square -> filter even): {list(p3)}")


def demonstrate_error_handling_in_pipeline() -> None:
    """Handle errors gracefully in pipelines."""
    print("\n" + "=" * 80)
    print("SECTION 8: ERROR HANDLING IN PIPELINES")
    print("=" * 80)

    def safe_divide(numbers: Iterator[int]) -> Iterator[float]:
        """Safely divide by number position."""
        for i, num in enumerate(numbers, 1):
            try:
                yield num / i
            except ZeroDivisionError:
                yield 0.0

    def skip_errors(gen: Iterator[Any]) -> Iterator[Any]:
        """Skip items that cause errors."""
        for item in gen:
            try:
                yield item
            except Exception as e:
                print(f"  Skipped item due to: {type(e).__name__}")

    numbers = list(safe_divide(iter([10, 20, 30, 40])))
    print(f"Safe divide: {[f'{x:.1f}' for x in numbers]}")


def demonstrate_infinite_pipeline() -> None:
    """Pipeline with infinite sequences."""
    print("\n" + "=" * 80)
    print("SECTION 9: INFINITE PIPELINES")
    print("=" * 80)

    def infinite_counter() -> Iterator[int]:
        """Generate infinite sequence."""
        i = 0
        while True:
            yield i
            i += 1

    def take_first_n(gen: Iterator[Any], n: int) -> List[Any]:
        """Take first N items."""
        result = []
        for i, item in enumerate(gen):
            if i >= n:
                break
            result.append(item)
        return result

    def fibonacci() -> Iterator[int]:
        """Generate Fibonacci sequence."""
        a, b = 0, 1
        while True:
            yield a
            a, b = b, a + b

    print("Infinite counter (first 5):", take_first_n(infinite_counter(), 5))
    print("Fibonacci sequence (first 10):", take_first_n(fibonacci(), 10))


def demonstrate_performance_metrics() -> None:
    """Compare pipeline performance."""
    print("\n" + "=" * 80)
    print("SECTION 10: PERFORMANCE METRICS")
    print("=" * 80)

    n = 1_000_000

    def eager_processing():
        data = list(range(n))
        filtered = [x for x in data if x % 2 == 0]
        squared = [x ** 2 for x in filtered]
        return sum(squared)

    def lazy_processing():
        def nums():
            for i in range(n):
                yield i

        def filter_even(data):
            for x in data:
                if x % 2 == 0:
                    yield x

        def sq(data):
            for x in data:
                yield x ** 2

        return sum(sq(filter_even(nums())))

    start = time.perf_counter()
    result1 = eager_processing()
    eager_time = time.perf_counter() - start

    start = time.perf_counter()
    result2 = lazy_processing()
    lazy_time = time.perf_counter() - start

    print(f"Processing {n:,} items:")
    print(f"  Eager: {eager_time*1000:.2f}ms (result: {result1})")
    print(f"  Lazy: {lazy_time*1000:.2f}ms (result: {result2})")
    print(f"  Results match: {result1 == result2}")


def best_practices() -> None:
    """Best practices for pipeline design."""
    print("\n" + "=" * 80)
    print("SECTION 11: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Design pipelines as iterators (generators)",
        "2. Each stage should be a pure function",
        "3. Keep stages small and focused (single responsibility)",
        "4. Use type hints for clarity",
        "5. Compose small functions into larger pipelines",
        "6. Add logging/debugging helpers for production",
        "7. Handle errors gracefully (skip or log)",
        "8. Profile pipelines to find bottlenecks",
        "9. Consider memory limits when designing stages",
        "10. Document data flow and transformations",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("GENERATOR PIPELINES - COMPOSABLE DATA PROCESSING")
    print("=" * 80)

    demonstrate_naive_approach()
    demonstrate_pipeline_approach()
    demonstrate_pipeline_builder()
    demonstrate_stateful_pipeline()
    demonstrate_pipeline_with_logging()
    demonstrate_real_world_etl()
    demonstrate_pipeline_composition()
    demonstrate_error_handling_in_pipeline()
    demonstrate_infinite_pipeline()
    demonstrate_performance_metrics()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
Pipeline Architecture Benefits:
    1. Memory efficiency (constant space complexity)
    2. Composability (reuse and combine stages)
    3. Laziness (compute only what's needed)
    4. Modularity (each stage is independent)
    5. Testability (pure functions are easy to test)
    6. Scalability (process unlimited data)

Common Pipeline Stages:
    - Extract: Read from file/API/database
    - Transform: Map, filter, aggregate
    - Load: Write to file/database/API
    - Validate: Check data quality
    - Deduplicate: Remove duplicates
    - Enrich: Add computed fields
    - Sample: Take subset for testing

Pipeline Design Patterns:
    - Fan-in: Multiple inputs to one stage
    - Fan-out: One input to multiple consumers
    - Branching: Multiple parallel processing paths
    - Merging: Combine multiple sources
    - Windowing: Process data in batches
    - Stateful operations: Maintain state across items
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Memory: O(1) constant (streaming) vs O(n) for intermediate lists
# CPU: Slight overhead from generator protocol vs raw loops
# Throughput: Can process terabytes with MB of RAM
# Latency: First result available faster (lazy evaluation)
# Scalability: Unlimited data size bounded only by available memory

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Creating intermediate lists at each pipeline stage
# 2. Not understanding pipeline is lazy (doesn't run until consumed)
# 3. Trying to reuse a consumed generator
# 4. Ignoring error handling in pipelines
# 5. Debugging complex nested pipelines without logging

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Design a pipeline to process 100GB log file
# Q2: How would you compose multiple data sources in a pipeline?
# Q3: Explain the difference between pull-based and push-based pipelines
# Q4: How do you handle errors in a generator pipeline?
# Q5: Design an ETL pipeline for e-commerce transactions
# Q6: What are the benefits of functional pipeline design?
# Q7: How would you implement window operations in a pipeline?
# Q8: Explain stateful transformations in pipelines

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build a real-time analytics pipeline
# Requirements:
#   - Stream data from multiple sources
#   - Apply transformations (filter, map, aggregate)
#   - Output results to file
#   - Track performance metrics
#   - Handle errors gracefully
# Implementation: Use generator pipeline pattern
