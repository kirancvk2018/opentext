"""
Module: 05_itertools_module.py
Topic: itertools - Iterator Building Blocks
Problem Statement: Developers often implement loops that itertools already provides.
    Custom implementations are slower, use more memory, and are error-prone.
    itertools provides optimized, composable iterator tools for common patterns.
Enterprise Scenario: A data pipeline needs to batch data, combine multiple sources, and repeat processing.
    Using itertools instead of custom loops reduces code by 50% and improves performance by 30%.
Learning Objectives:
    - Master itertools for iterator composition
    - Understand common patterns (repeat, cycle, chain, etc.)
    - Build complex iterators from simple components
    - Optimize memory usage with itertools
Prerequisites:
    - Understanding of iterators and generators
    - Basic functional programming concepts
Expected Output:
    - Practical itertools examples
    - Performance comparisons
    - Real-world use cases
Concepts Covered:
    - count, repeat, cycle
    - chain, islice, zip_longest
    - groupby, combinations, permutations
    - takewhile, dropwhile, compress
"""

import itertools
from typing import Iterator, List, Tuple, Any, Callable
import time


def demonstrate_count_repeat_cycle() -> None:
    """Demonstrate basic infinite iterators."""
    print("\n" + "=" * 80)
    print("SECTION 1: INFINITE ITERATORS")
    print("=" * 80)

    print("count(start, step): Infinite counter")
    counter = itertools.count(10, 2)
    print(f"  count(10, 2) first 5: {[next(counter) for _ in range(5)]}")

    print("\nrepeat(obj, times): Repeat value N times")
    repeated = list(itertools.repeat("A", 5))
    print(f"  repeat('A', 5): {repeated}")

    print("\ncycle(iterable): Cycle through iterable infinitely")
    cycled = itertools.cycle([1, 2, 3])
    print(f"  cycle([1,2,3]) first 10: {[next(cycled) for _ in range(10)]}")


def demonstrate_chain_and_combinations() -> None:
    """Chain and combination operations."""
    print("\n" + "=" * 80)
    print("SECTION 2: CHAIN AND COMBINATIONS")
    print("=" * 80)

    print("chain(*iterables): Flatten multiple iterables")
    result = list(itertools.chain([1, 2], [3, 4], [5]))
    print(f"  chain([1,2], [3,4], [5]): {result}")

    print("\nchain.from_iterable(iterable): Flatten nested iterables")
    nested = [[1, 2], [3, 4], [5, 6]]
    result = list(itertools.chain.from_iterable(nested))
    print(f"  chain.from_iterable({nested}): {result}")

    print("\ncombinations(iterable, r): All r-length combinations")
    combos = list(itertools.combinations([1, 2, 3], 2))
    print(f"  combinations([1,2,3], 2): {combos}")

    print("\npermutations(iterable, r): All r-length permutations")
    perms = list(itertools.permutations([1, 2, 3], 2))
    print(f"  permutations([1,2,3], 2): {perms}")

    print("\nproduct(*iterables): Cartesian product")
    prod = list(itertools.product([1, 2], ['a', 'b']))
    print(f"  product([1,2], ['a','b']): {prod}")


def demonstrate_slicing_operations() -> None:
    """Slicing and subsetting iterators."""
    print("\n" + "=" * 80)
    print("SECTION 3: SLICING OPERATIONS")
    print("=" * 80)

    print("islice(iterable, start, stop, step): Lazy slicing")
    result = list(itertools.islice(range(10), 2, 8, 2))
    print(f"  islice(range(10), 2, 8, 2): {result}")

    print("\ntakewhile(predicate, iterable): Take while predicate is True")
    result = list(itertools.takewhile(lambda x: x < 5, [1, 2, 3, 4, 5, 3, 2]))
    print(f"  takewhile(x<5, [1,2,3,4,5,3,2]): {result}")

    print("\ndropwhile(predicate, iterable): Drop while predicate is True")
    result = list(itertools.dropwhile(lambda x: x < 5, [1, 2, 3, 4, 5, 3, 2]))
    print(f"  dropwhile(x<5, [1,2,3,4,5,3,2]): {result}")

    print("\nfilterfalse(predicate, iterable): Opposite of filter")
    result = list(itertools.filterfalse(lambda x: x % 2 == 0, range(10)))
    print(f"  filterfalse(even, range(10)): {result}")


def demonstrate_groupby() -> None:
    """Group consecutive equal elements."""
    print("\n" + "=" * 80)
    print("SECTION 4: GROUPBY OPERATION")
    print("=" * 80)

    print("groupby(iterable, key): Group consecutive equal elements")

    data = [1, 1, 2, 2, 2, 3, 1, 1]
    groups = itertools.groupby(data)
    for key, group in groups:
        print(f"  Key {key}: {list(group)}")

    print("\ngroupby with custom key function:")
    words = ['apple', 'apricot', 'banana', 'blueberry', 'cherry']
    grouped = itertools.groupby(words, key=lambda x: x[0])
    for letter, group in grouped:
        words_list = list(group)
        print(f"  {letter}: {words_list}")


def demonstrate_zip_operations() -> None:
    """Zip and unzip operations."""
    print("\n" + "=" * 80)
    print("SECTION 5: ZIP OPERATIONS")
    print("=" * 80)

    print("zip(*iterables): Zip multiple iterables")
    result = list(zip([1, 2, 3], ['a', 'b', 'c']))
    print(f"  zip([1,2,3], ['a','b','c']): {result}")

    print("\nzip_longest(*iterables, fillvalue): Zip with padding")
    result = list(itertools.zip_longest([1, 2], ['a', 'b', 'c'], fillvalue=None))
    print(f"  zip_longest([1,2], ['a','b','c'], fillvalue=None): {result}")

    print("\nUnzipping with zip(*)")
    zipped = [(1, 'a'), (2, 'b'), (3, 'c')]
    nums, letters = zip(*zipped)
    print(f"  Unzip {zipped}: {nums}, {letters}")


def demonstrate_accumulate() -> None:
    """Accumulate operation (like reduce but returns iterator)."""
    print("\n" + "=" * 80)
    print("SECTION 6: ACCUMULATE OPERATION")
    print("=" * 80)

    print("accumulate(iterable, func): Cumulative application of function")

    print("  Sum (default): ", list(itertools.accumulate([1, 2, 3, 4, 5])))
    print("  Product: ", list(itertools.accumulate([1, 2, 3, 4, 5], lambda x, y: x * y)))
    print("  Max: ", list(itertools.accumulate([3, 1, 4, 1, 5], max)))


def demonstrate_real_world_batching() -> None:
    """Real-world pattern: batch processing."""
    print("\n" + "=" * 80)
    print("SECTION 7: REAL-WORLD BATCHING")
    print("=" * 80)

    def batch(iterable, n: int):
        """Batch items into chunks of size n."""
        args = [iter(iterable)] * n
        return itertools.zip_longest(*args, fillvalue=None)

    data = range(10)
    batches = list(batch(data, 3))
    print(f"Batch size 3 of range(10):")
    for i, b in enumerate(batches):
        print(f"  Batch {i}: {b}")


def demonstrate_real_world_pairwise() -> None:
    """Real-world pattern: pairwise windows."""
    print("\n" + "=" * 80)
    print("SECTION 8: REAL-WORLD PAIRWISE")
    print("=" * 80)

    def pairwise(iterable):
        """Return successive overlapping pairs."""
        a, b = itertools.tee(iterable)
        next(b, None)
        return zip(a, b)

    data = [1, 2, 3, 4, 5]
    pairs = list(pairwise(data))
    print(f"Pairwise of {data}: {pairs}")

    print("\nUse case: Calculate differences between consecutive items")
    diffs = [b - a for a, b in pairwise(data)]
    print(f"Differences: {diffs}")


def demonstrate_tee_operation() -> None:
    """Create independent iterators from one."""
    print("\n" + "=" * 80)
    print("SECTION 9: TEE OPERATION")
    print("=" * 80)

    print("tee(iterable, n): Create n independent iterators")

    data_iter = iter(range(5))
    iter1, iter2 = itertools.tee(data_iter, 2)

    print(f"  Original data: range(5)")
    print(f"  iter1: {list(iter1)}")
    print(f"  iter2: {list(iter2)}")

    print("\nUse case: Iterate twice over same data without storing list")
    data_iter = iter(range(1000000))
    iter1, iter2 = itertools.tee(data_iter, 2)
    sum1 = sum(iter1)
    sum2 = sum(iter2)
    print(f"  Computed sum twice without storing list in memory")


def demonstrate_performance_comparison() -> None:
    """Compare itertools vs manual implementation."""
    print("\n" + "=" * 80)
    print("SECTION 10: PERFORMANCE COMPARISON")
    print("=" * 80)

    n = 1_000_000

    print(f"Processing {n:,} items:")

    start = time.perf_counter()
    result = sum(itertools.islice(range(n), 0, n, 2))
    time1 = time.perf_counter() - start
    print(f"  itertools.islice: {time1*1000:.2f}ms (result: {result})")

    start = time.perf_counter()
    result = sum(range(0, n, 2))
    time2 = time.perf_counter() - start
    print(f"  range slice: {time2*1000:.2f}ms (result: {result})")

    start = time.perf_counter()
    result = sum(x for x in range(n) if x % 2 == 0)
    time3 = time.perf_counter() - start
    print(f"  generator filter: {time3*1000:.2f}ms (result: {result})")


def demonstrate_memory_efficiency() -> None:
    """itertools memory efficiency."""
    print("\n" + "=" * 80)
    print("SECTION 11: MEMORY EFFICIENCY")
    print("=" * 80)

    print("Creating 1M element cycle (itertools vs list):")

    import sys
    cycle_iter = itertools.cycle([1, 2, 3])
    print(f"  cycle object: {sys.getsizeof(cycle_iter)} bytes")

    list_version = [1, 2, 3] * 333_334
    print(f"  list equivalent: {sys.getsizeof(list_version) / 1024:.2f} KB")

    print("\nitertools: Constant memory for infinite patterns")
    print("Lists: Linear memory growth")


def best_practices() -> None:
    """Best practices for itertools."""
    print("\n" + "=" * 80)
    print("SECTION 12: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Use itertools instead of rolling your own iterator functions",
        "2. Chain itertools operations for complex pipelines",
        "3. Use islice for lazy slicing instead of creating intermediate lists",
        "4. Use zip_longest when iterables have different lengths",
        "5. Use groupby to process consecutive groups of data",
        "6. Use tee to create independent iterators when needed",
        "7. Remember groupby requires consecutive equal values",
        "8. Use accumulate for cumulative calculations",
        "9. Combine with generators for powerful pipelines",
        "10. Profile before optimizing (itertools is usually faster)",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("ITERTOOLS MODULE - EFFICIENT ITERATOR TOOLS")
    print("=" * 80)

    demonstrate_count_repeat_cycle()
    demonstrate_chain_and_combinations()
    demonstrate_slicing_operations()
    demonstrate_groupby()
    demonstrate_zip_operations()
    demonstrate_accumulate()
    demonstrate_real_world_batching()
    demonstrate_real_world_pairwise()
    demonstrate_tee_operation()
    demonstrate_performance_comparison()
    demonstrate_memory_efficiency()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY - KEY ITERTOOLS FUNCTIONS")
    print("=" * 80)
    print("""
Infinite Iterators:
    count(start, step)      - Infinite counter
    cycle(iterable)         - Repeat iterable forever
    repeat(obj, times)      - Repeat value

Combination Iterators:
    chain(*iterables)       - Flatten multiple sequences
    combinations(iter, r)   - All r-length combinations
    permutations(iter, r)   - All r-length permutations
    product(*iterables)     - Cartesian product

Filtering Iterators:
    filter(func, iter)      - Filter by predicate
    filterfalse(func, iter) - Inverse filter
    islice(iter, ...)       - Lazy slicing
    takewhile(func, iter)   - Take while true
    dropwhile(func, iter)   - Drop while true
    compress(data, mask)    - Filter by boolean mask

Grouping Iterators:
    groupby(iter, key)      - Group consecutive equal elements
    accumulate(iter, func)  - Cumulative function application
    zip(*iterables)         - Zip iterables
    zip_longest(...)        - Zip with padding

Utility:
    tee(iter, n)           - Create n independent iterators
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# itertools functions are C-implemented and highly optimized
# Lazy evaluation saves memory compared to list creation
# Composable functions enable powerful data pipelines
# Performance often 5-10x faster than pure Python equivalents

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Using itertools in tight loops where simple loops are clearer
# 2. Forgetting that groupby requires consecutive equal values
# 3. Trying to use groupby key without sorting first
# 4. Not realizing cycle/count create infinite iterators
# 5. Creating intermediate lists when itertools can chain

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: How would you implement batching with itertools?
# Q2: What's the difference between combinations and permutations?
# Q3: When would you use tee() and why?
# Q4: Design a pipeline combining multiple itertools functions
# Q5: How does groupby differ from SQL GROUP BY?
# Q6: What are trade-offs of islice vs list slicing?

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build a data pipeline using itertools
# Requirements:
#   - Chain multiple data sources
#   - Group data by category
#   - Batch results
#   - Calculate running statistics
# Implementation: Use itertools primitives exclusively
