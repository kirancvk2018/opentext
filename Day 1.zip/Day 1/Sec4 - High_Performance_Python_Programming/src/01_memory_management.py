"""
Module: 01_memory_management.py
Topic: Python Memory Management and Object Model
Problem Statement: Understand how Python manages memory and optimize memory usage in applications.
Enterprise Scenario: A large financial institution processes millions of account records.
    Memory-inefficient code causes the application to consume 50GB+ RAM, triggering OOM errors.
    Understanding Python's memory model prevents production incidents and reduces infrastructure costs.
Learning Objectives:
    - Understand Python's object model and memory layout
    - Learn reference counting and garbage collection
    - Optimize object creation and memory pooling
    - Identify memory leaks and inefficient patterns
Prerequisites:
    - Basic Python knowledge
    - Understanding of variables and objects
Expected Output:
    - Memory usage comparison across different approaches
    - Object reference demonstration
    - Garbage collection impact visualization
Concepts Covered:
    - Python object model (everything is an object)
    - Reference counting mechanism
    - Memory allocation and deallocation
    - Garbage collection algorithm
    - Memory profiling techniques
    - Object identity vs equality
    - Interning and string pooling
    - Circular references and cleanup
"""

import sys
import gc
from typing import Any, List
from collections import Counter
import weakref


class MemoryMonitor:
    """Utility to track and display memory information."""

    @staticmethod
    def get_size_bytes(obj: Any) -> int:
        """Get size of a single object in bytes."""
        return sys.getsizeof(obj)

    @staticmethod
    def get_size_mb(obj: Any) -> float:
        """Get size of a single object in megabytes."""
        return sys.getsizeof(obj) / (1024 * 1024)

    @staticmethod
    def get_reference_count(obj: Any) -> int:
        """Get reference count for an object."""
        return sys.getrefcount(obj)

    @staticmethod
    def get_object_id(obj: Any) -> int:
        """Get memory address/identity of an object."""
        return id(obj)


def demonstrate_reference_counting() -> None:
    """
    Demonstrate Python's reference counting mechanism.
    Every object has a reference count that tracks how many names reference it.
    When refcount reaches 0, the object is freed.
    """
    print("\n" + "=" * 80)
    print("SECTION 1: REFERENCE COUNTING")
    print("=" * 80)

    a = [1, 2, 3]
    print(f"Created list: {a}")
    print(f"Reference count for 'a': {MemoryMonitor.get_reference_count(a) - 1}")

    b = a
    print(f"After b = a:")
    print(f"Reference count for 'a': {MemoryMonitor.get_reference_count(a) - 1}")
    print(f"a is b: {a is b} (same object in memory)")
    print(f"id(a): {MemoryMonitor.get_object_id(a)}")
    print(f"id(b): {MemoryMonitor.get_object_id(b)}")

    c = [1, 2, 3]
    print(f"\nCreated list c = [1, 2, 3]:")
    print(f"a == c: {a == c} (same value)")
    print(f"a is c: {a is c} (different objects)")
    print(f"id(c): {MemoryMonitor.get_object_id(c)}")

    del b
    print(f"\nAfter del b:")
    print(f"Reference count for 'a': {MemoryMonitor.get_reference_count(a) - 1}")


def demonstrate_memory_sizes() -> None:
    """Show memory footprint of common Python objects."""
    print("\n" + "=" * 80)
    print("SECTION 2: OBJECT MEMORY SIZES")
    print("=" * 80)

    objects = {
        "None": None,
        "True": True,
        "Small int (1)": 1,
        "Large int (10^18)": 10**18,
        "Empty string": "",
        "Short string": "Hello",
        "Empty list": [],
        "List [1,2,3]": [1, 2, 3],
        "Empty dict": {},
        "Dict with data": {"a": 1, "b": 2},
        "Empty tuple": (),
        "Tuple (1,2,3)": (1, 2, 3),
        "Empty set": set(),
        "Set {1,2,3}": {1, 2, 3},
    }

    print(f"{'Object Type':<30} {'Size (bytes)':<15} {'Size (KB)':<10}")
    print("-" * 55)

    for name, obj in objects.items():
        size_bytes = MemoryMonitor.get_size_bytes(obj)
        size_kb = size_bytes / 1024
        print(f"{name:<30} {size_bytes:<15} {size_kb:<10.2f}")


def demonstrate_integer_interning() -> None:
    """
    Demonstrate integer interning: Python caches small integers for performance.
    Small integers (-5 to 256) are pre-allocated and reused.
    """
    print("\n" + "=" * 80)
    print("SECTION 3: INTEGER INTERNING")
    print("=" * 80)

    a = 256
    b = 256
    print(f"a = 256, b = 256:")
    print(f"a is b: {a is b} (same object, interned)")
    print(f"id(a): {MemoryMonitor.get_object_id(a)}")
    print(f"id(b): {MemoryMonitor.get_object_id(b)}")

    c = 257
    d = 257
    print(f"\nc = 257, d = 257:")
    print(f"c is d: {c is d} (different objects, not interned)")
    print(f"id(c): {MemoryMonitor.get_object_id(c)}")
    print(f"id(d): {MemoryMonitor.get_object_id(d)}")

    print("\nLesson: Don't rely on identity (is) for equality checks on large integers.")
    print("Always use == for value comparison.")


def demonstrate_string_interning() -> None:
    """
    Demonstrate string interning: Python caches string literals and valid identifiers.
    """
    print("\n" + "=" * 80)
    print("SECTION 4: STRING INTERNING")
    print("=" * 80)

    a = "hello"
    b = "hello"
    print(f"a = 'hello', b = 'hello':")
    print(f"a is b: {a is b} (same object, interned)")
    print(f"id(a): {MemoryMonitor.get_object_id(a)}")
    print(f"id(b): {MemoryMonitor.get_object_id(b)}")

    c = "hello" + " world"
    d = "hello world"
    print(f"\nc = 'hello' + ' world', d = 'hello world':")
    print(f"c == d: {c == d} (same value)")
    print(f"c is d: {c is d} (may be different objects due to concatenation)")

    s1 = "".join(["hello"])
    s2 = "hello"
    print(f"\ns1 = ''.join(['hello']), s2 = 'hello':")
    print(f"s1 == s2: {s1 == s2}")
    print(f"s1 is s2: {s1 is s2} (different, dynamically created)")


def demonstrate_garbage_collection() -> None:
    """
    Demonstrate garbage collection for circular references.
    Reference counting alone cannot handle circular references.
    The garbage collector detects and cleans them up.
    """
    print("\n" + "=" * 80)
    print("SECTION 5: GARBAGE COLLECTION")
    print("=" * 80)

    gc.collect()
    initial_objects = len(gc.get_objects())
    print(f"Initial object count: {initial_objects}")

    class Node:
        def __init__(self, name: str):
            self.name = name
            self.next = None

        def __repr__(self) -> str:
            return f"Node({self.name})"

    a = Node("A")
    b = Node("B")
    a.next = b
    b.next = a

    print(f"Created circular reference: A -> B -> A")
    print(f"Reference count for 'a': {MemoryMonitor.get_reference_count(a) - 1}")

    del a, b
    print("Deleted both references (del a, b)")
    print("Reference count alone cannot free circular references.")

    collected = gc.collect()
    print(f"gc.collect() freed {collected} objects (including circular structures)")

    final_objects = len(gc.get_objects())
    print(f"Final object count: {final_objects}")


def demonstrate_object_pooling() -> None:
    """
    Demonstrate object pooling pattern to reduce memory allocation overhead.
    Reusing objects is faster than creating and destroying them repeatedly.
    """
    print("\n" + "=" * 80)
    print("SECTION 6: OBJECT POOLING PATTERN")
    print("=" * 80)

    class ConnectionPool:
        """Simple connection pool to reuse expensive objects."""

        def __init__(self, size: int = 5):
            self.available = [{"id": i, "active": False} for i in range(size)]
            self.in_use = []

        def acquire(self) -> dict:
            if self.available:
                conn = self.available.pop()
                conn["active"] = True
                self.in_use.append(conn)
                return conn
            raise RuntimeError("No available connections")

        def release(self, conn: dict) -> None:
            if conn in self.in_use:
                conn["active"] = False
                self.in_use.remove(conn)
                self.available.append(conn)

        def __repr__(self) -> str:
            return f"Pool(available={len(self.available)}, in_use={len(self.in_use)})"

    pool = ConnectionPool(size=3)
    print(f"Created connection pool: {pool}")

    conns = []
    for i in range(3):
        conn = pool.acquire()
        conns.append(conn)
        print(f"Acquired connection: {conn}")

    print(f"Pool state: {pool}")

    for conn in conns:
        pool.release(conn)

    print(f"Released all connections: {pool}")
    print("\nBenefit: Reused objects, no allocation overhead for frequent operations.")


def demonstrate_weak_references() -> None:
    """
    Demonstrate weak references: references that don't prevent garbage collection.
    Useful for caches and parent-child relationships.
    """
    print("\n" + "=" * 80)
    print("SECTION 7: WEAK REFERENCES")
    print("=" * 80)

    class Data:
        def __init__(self, value: str):
            self.value = value

        def __repr__(self) -> str:
            return f"Data({self.value})"

    obj = Data("Important")
    print(f"Created object: {obj}")
    print(f"Reference count: {MemoryMonitor.get_reference_count(obj) - 1}")

    weak_ref = weakref.ref(obj)
    print(f"Created weak reference: {weak_ref()}")
    print(f"Reference count (unchanged): {MemoryMonitor.get_reference_count(obj) - 1}")

    del obj
    print("Deleted original reference (del obj)")
    print(f"Weak reference now returns: {weak_ref()} (object was freed)")


def compare_list_vs_generator() -> None:
    """
    Compare memory usage: list (stores all items) vs generator (creates on demand).
    """
    print("\n" + "=" * 80)
    print("SECTION 8: MEMORY COMPARISON - LIST VS GENERATOR")
    print("=" * 80)

    list_comprehension = [i * 2 for i in range(100000)]
    print(f"List of 100,000 items: {MemoryMonitor.get_size_mb(list_comprehension):.2f} MB")

    def number_generator():
        for i in range(100000):
            yield i * 2

    gen = number_generator()
    print(f"Generator object: {MemoryMonitor.get_size_mb(gen):.2f} MB")
    print("Generator creates items on-the-fly, consuming minimal memory.")


def memory_optimization_tips() -> None:
    """Display best practices for memory optimization."""
    print("\n" + "=" * 80)
    print("SECTION 9: MEMORY OPTIMIZATION BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Use generators for large datasets instead of lists",
        "2. Use __slots__ in classes to reduce per-instance memory",
        "3. Close files and connections explicitly (context managers)",
        "4. Delete large objects when no longer needed",
        "5. Use weak references for caches and circular structures",
        "6. Monitor garbage collection frequency in long-running processes",
        "7. Profile memory usage with memory_profiler",
        "8. Prefer tuples over lists for immutable sequences",
        "9. Use object pooling for frequently created/destroyed objects",
        "10. Avoid circular references or break them explicitly",
    ]

    for tip in tips:
        print(f"  {tip}")


class OptimizedClass:
    """Class using __slots__ for memory efficiency."""
    __slots__ = ['name', 'value']

    def __init__(self, name: str, value: int):
        self.name = name
        self.value = value


class NormalClass:
    """Standard class with dynamic __dict__."""

    def __init__(self, name: str, value: int):
        self.name = name
        self.value = value


def compare_slots_vs_dict() -> None:
    """Compare memory usage: __slots__ vs dynamic __dict__."""
    print("\n" + "=" * 80)
    print("SECTION 10: SLOTS VS DYNAMIC DICTIONARY")
    print("=" * 80)

    normal = NormalClass("test", 42)
    optimized = OptimizedClass("test", 42)

    normal_size = MemoryMonitor.get_size_bytes(normal)
    optimized_size = MemoryMonitor.get_size_bytes(optimized)

    print(f"NormalClass instance size: {normal_size} bytes")
    print(f"OptimizedClass (__slots__) size: {optimized_size} bytes")
    print(f"Memory saved: {normal_size - optimized_size} bytes per instance")

    num_instances = 1_000_000
    print(f"\nFor {num_instances:,} instances:")
    print(f"Normal classes: {(normal_size * num_instances) / (1024**2):.2f} MB")
    print(f"With __slots__: {(optimized_size * num_instances) / (1024**2):.2f} MB")
    print(f"Total savings: {((normal_size - optimized_size) * num_instances) / (1024**2):.2f} MB")


def demonstrate_memory_leak() -> None:
    """Demonstrate a common memory leak pattern and how to fix it."""
    print("\n" + "=" * 80)
    print("SECTION 11: MEMORY LEAK DEMONSTRATION")
    print("=" * 80)

    cache = {}

    def get_data_with_leak(key: str) -> List[int]:
        """Intentional memory leak: cache grows unbounded."""
        if key not in cache:
            cache[key] = list(range(1_000_000))
        return cache[key]

    print("Simulating unbounded cache (memory leak):")
    for i in range(5):
        get_data_with_leak(f"key_{i}")
    print(f"Cache size: {len(cache)} entries")
    print(f"Cache memory: {sum(MemoryMonitor.get_size_bytes(v) for v in cache.values()) / (1024**2):.2f} MB")

    from functools import lru_cache

    @lru_cache(maxsize=3)
    def get_data_safe(key: str) -> List[int]:
        """Fixed: lru_cache with bounded size prevents unbounded growth."""
        return list(range(1_000_000))

    print("\nUsing lru_cache(maxsize=3) to prevent unbounded growth:")
    for i in range(5):
        get_data_safe(f"key_{i}")
    print(f"Cache info: {get_data_safe.cache_info()}")
    print("Cache is bounded to 3 most recent items.")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("PYTHON MEMORY MANAGEMENT - COMPLETE GUIDE")
    print("=" * 80)

    demonstrate_reference_counting()
    demonstrate_memory_sizes()
    demonstrate_integer_interning()
    demonstrate_string_interning()
    demonstrate_garbage_collection()
    demonstrate_object_pooling()
    demonstrate_weak_references()
    compare_list_vs_generator()
    compare_slots_vs_dict()
    demonstrate_memory_leak()
    memory_optimization_tips()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
Key Takeaways:
    1. Python uses reference counting + garbage collection for memory management
    2. Use generators for large datasets (lazy evaluation)
    3. Use __slots__ in classes to reduce memory overhead
    4. Avoid circular references or use weak references
    5. Profile memory with sys.getsizeof() and memory_profiler
    6. Implement object pooling for frequently created objects
    7. Use context managers to ensure resource cleanup
    8. Cache bounded with lru_cache to prevent memory leaks

Best Practices:
    - Measure before optimizing (profile first)
    - Understand Python's object model
    - Use appropriate data structures
    - Clean up resources explicitly
    - Monitor production systems for memory leaks
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Reference Counting: Efficient for most cases, constant-time cleanup
# Garbage Collection: Handles circular references but has overhead
# Generators: 1/1000th memory compared to lists for large sequences
# __slots__: 30-50% memory reduction per instance for tight classes
# Object Pooling: Reduces allocation overhead, improves cache locality
# Weak References: Enable cache patterns without memory leaks

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Using 'is' for value comparison instead of '=='
# 2. Creating unbounded caches without eviction policy
# 3. Not closing file handles and database connections
# 4. Holding circular references without cleanup
# 5. Creating large intermediate lists in tight loops
# 6. Not understanding the cost of object creation
# 7. Forgetting that __dict__ uses memory overhead

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Explain Python's memory management model
# Q2: What's the difference between 'is' and '=='?
# Q3: When is garbage collection triggered?
# Q4: How do you prevent memory leaks in Python?
# Q5: What are the benefits of generators?
# Q6: Explain weak references and their use cases
# Q7: How does integer interning work?
# Q8: What's the memory overhead of __dict__?

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Create a bounded LRU cache that tracks hit/miss statistics
# Requirements:
#   - Max 1000 entries
#   - Track cache hits and misses
#   - Display eviction policy behavior
#   - Measure memory usage
# Hint: Use collections.OrderedDict and track access order
