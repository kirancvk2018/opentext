"""
Module: 07_custom_context_managers.py
Topic: Custom Context Managers - Advanced Patterns
Problem Statement: Complex resource management requires sophisticated patterns.
    Manual implementation is error-prone; proper patterns solve common problems.
Enterprise Scenario: A microservice needs to manage API rate limiting, retries, and circuit breaking.
    Custom context managers encapsulate these patterns cleanly.
Learning Objectives:
    - Implement custom context managers for specific use cases
    - Handle advanced cleanup scenarios
    - Manage state transitions
    - Combine context managers for complex workflows
Prerequisites:
    - Understanding of context manager protocol
    - Exception handling knowledge
Expected Output:
    - Production-grade context managers
    - Real-world use cases
    - Advanced patterns
Concepts Covered:
    - State management patterns
    - Error handling in context managers
    - Composable context managers
    - Async context managers basics
"""

from typing import Any, Optional, Callable, List
import time
import logging
from contextlib import contextmanager, ExitStack
from functools import wraps


logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


def demonstrate_retry_context_manager() -> None:
    """Context manager for retry logic."""
    print("\n" + "=" * 80)
    print("SECTION 1: RETRY CONTEXT MANAGER")
    print("=" * 80)

    class RetryContext:
        """Retry operations on failure."""

        def __init__(self, max_retries: int = 3, delay: float = 0.5):
            self.max_retries = max_retries
            self.delay = delay
            self.attempt = 0
            self.last_exception = None

        def __enter__(self):
            self.attempt += 1
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type is None:
                logger.info(f"Success on attempt {self.attempt}")
                return True

            self.last_exception = exc_val
            if self.attempt >= self.max_retries:
                logger.info(f"Max retries reached. Raising {exc_type.__name__}")
                return False

            logger.info(f"Attempt {self.attempt} failed, retrying...")
            time.sleep(self.delay)
            return True

    def retry_operation(max_retries: int = 3):
        """Execute with retries."""
        for attempt in range(max_retries):
            try:
                with RetryContext(max_retries) as ctx:
                    yield ctx
                    break
            except RetryContext as e:
                if attempt >= max_retries - 1:
                    raise

    counter = {"attempts": 0}

    def failing_operation():
        counter["attempts"] += 1
        if counter["attempts"] < 2:
            raise ValueError("Simulated failure")
        return "Success"

    counter["attempts"] = 0
    for attempt in range(3):
        try:
            with RetryContext(3):
                if counter["attempts"] < 2:
                    counter["attempts"] += 1
                    raise ValueError("Failed")
                break
        except ValueError:
            if attempt >= 2:
                raise

    logger.info(f"Operation succeeded after {counter['attempts']} attempts")


def demonstrate_timeout_context_manager() -> None:
    """Context manager for timeout operations."""
    print("\n" + "=" * 80)
    print("SECTION 2: TIMEOUT CONTEXT MANAGER")
    print("=" * 80)

    import signal

    class TimeoutContext:
        """Timeout operations."""

        def __init__(self, seconds: float):
            self.seconds = seconds
            self.old_handler = None

        def _timeout_handler(self, signum, frame):
            raise TimeoutError(f"Operation exceeded {self.seconds} seconds")

        def __enter__(self):
            if hasattr(signal, 'SIGALRM'):
                self.old_handler = signal.signal(signal.SIGALRM, self._timeout_handler)
                signal.alarm(int(self.seconds))
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if hasattr(signal, 'SIGALRM'):
                signal.alarm(0)
                if self.old_handler:
                    signal.signal(signal.SIGALRM, self.old_handler)
            return False

    logger.info("Timeout context manager configured (demo only)")


def demonstrate_logging_context_manager() -> None:
    """Context manager for structured logging."""
    print("\n" + "=" * 80)
    print("SECTION 3: LOGGING CONTEXT MANAGER")
    print("=" * 80)

    @contextmanager
    def log_execution(operation_name: str):
        """Log operation execution."""
        logger.info(f"[START] {operation_name}")
        start_time = time.perf_counter()
        try:
            yield
        except Exception as e:
            logger.error(f"[ERROR] {operation_name} failed: {e}")
            raise
        else:
            elapsed = time.perf_counter() - start_time
            logger.info(f"[SUCCESS] {operation_name} completed in {elapsed:.3f}s")

    with log_execution("Database Query"):
        time.sleep(0.1)

    try:
        with log_execution("File Processing"):
            raise IOError("File not found")
    except IOError:
        pass


def demonstrate_state_context_manager() -> None:
    """Context manager for state changes."""
    print("\n" + "=" * 80)
    print("SECTION 4: STATE MANAGEMENT CONTEXT MANAGER")
    print("=" * 80)

    class Application:
        def __init__(self):
            self.state = "stopped"

        def with_state(self, new_state: str):
            """Context manager for temporary state change."""
            @contextmanager
            def _context():
                old_state = self.state
                self.state = new_state
                logger.info(f"State: {old_state} -> {new_state}")
                try:
                    yield
                finally:
                    self.state = old_state
                    logger.info(f"State restored: {self.state}")
            return _context()

    app = Application()

    with app.with_state("running"):
        logger.info(f"  Current state: {app.state}")

    logger.info(f"Final state: {app.state}")


def demonstrate_exit_stack() -> None:
    """ExitStack for managing multiple context managers."""
    print("\n" + "=" * 80)
    print("SECTION 5: EXITSTACK FOR DYNAMIC CONTEXT MANAGEMENT")
    print("=" * 80)

    @contextmanager
    def resource(name: str):
        logger.info(f"Acquiring {name}")
        try:
            yield f"resource_{name}"
        finally:
            logger.info(f"Releasing {name}")

    resources_to_manage = ['db', 'cache', 'session']

    logger.info("Using ExitStack for dynamic resource management:")
    with ExitStack() as stack:
        resources = [stack.enter_context(resource(name)) for name in resources_to_manage]
        logger.info(f"  All resources acquired: {resources}")


def demonstrate_circuit_breaker() -> None:
    """Context manager: circuit breaker pattern."""
    print("\n" + "=" * 80)
    print("SECTION 6: CIRCUIT BREAKER PATTERN")
    print("=" * 80)

    class CircuitBreaker:
        """Prevents cascading failures."""

        def __init__(self, failure_threshold: int = 3, timeout: float = 5):
            self.failure_threshold = failure_threshold
            self.timeout = timeout
            self.failure_count = 0
            self.last_failure_time = None
            self.state = "closed"

        def __enter__(self):
            if self.state == "open":
                if time.time() - self.last_failure_time > self.timeout:
                    self.state = "half-open"
                    logger.info("Circuit breaker: half-open (trying recovery)")
                else:
                    raise RuntimeError("Circuit breaker is open")
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type is None:
                self.failure_count = 0
                if self.state == "half-open":
                    self.state = "closed"
                    logger.info("Circuit breaker: closed (recovered)")
            else:
                self.failure_count += 1
                self.last_failure_time = time.time()
                if self.failure_count >= self.failure_threshold:
                    self.state = "open"
                    logger.info("Circuit breaker: open (too many failures)")
            return False

    cb = CircuitBreaker(failure_threshold=2, timeout=1)

    for i in range(3):
        try:
            with cb:
                if i < 2:
                    raise ValueError(f"Request {i} failed")
                logger.info(f"Request {i} succeeded")
        except RuntimeError as e:
            logger.info(f"Request {i} blocked: {e}")


def demonstrate_rate_limiter() -> None:
    """Context manager: rate limiting."""
    print("\n" + "=" * 80)
    print("SECTION 7: RATE LIMITER CONTEXT MANAGER")
    print("=" * 80)

    class RateLimiter:
        """Rate limit operations."""

        def __init__(self, max_per_second: int):
            self.max_per_second = max_per_second
            self.min_interval = 1.0 / max_per_second
            self.last_call = 0

        def __enter__(self):
            elapsed = time.time() - self.last_call
            if elapsed < self.min_interval:
                time.sleep(self.min_interval - elapsed)
            return self

        def __exit__(self, *args):
            self.last_call = time.time()

    limiter = RateLimiter(max_per_second=3)

    logger.info("Rate limiting 5 operations (max 3/sec):")
    start = time.time()
    for i in range(5):
        with limiter:
            elapsed = time.time() - start
            logger.info(f"  Operation {i} at {elapsed:.2f}s")


def demonstrate_resource_tracking() -> None:
    """Context manager: track resource usage."""
    print("\n" + "=" * 80)
    print("SECTION 8: RESOURCE TRACKING")
    print("=" * 80)

    import sys

    class ResourceTracker:
        """Track resource usage."""

        def __init__(self, name: str):
            self.name = name
            self.start_memory = 0

        def __enter__(self):
            self.start_memory = sys.getsizeof(self)
            logger.info(f"[{self.name}] Started")
            return self

        def __exit__(self, *args):
            logger.info(f"[{self.name}] Completed")

    with ResourceTracker("Data Processing"):
        data = list(range(10000))
        logger.info(f"  Created data with {len(data)} items")


def demonstrate_debug_context_manager() -> None:
    """Context manager for debugging."""
    print("\n" + "=" * 80)
    print("SECTION 9: DEBUG CONTEXT MANAGER")
    print("=" * 80)

    @contextmanager
    def debug_scope(section: str, verbose: bool = True):
        """Debug context with detailed logging."""
        if verbose:
            logger.info(f">>> Entering {section}")
        try:
            yield
        finally:
            if verbose:
                logger.info(f"<<< Exiting {section}")

    with debug_scope("Database Operations"):
        logger.info("  Running query")

    with debug_scope("Cache Lookup"):
        logger.info("  Checking cache")


def demonstrate_transaction_context_manager() -> None:
    """Context manager for transactions."""
    print("\n" + "=" * 80)
    print("SECTION 10: ADVANCED TRANSACTION CONTEXT MANAGER")
    print("=" * 80)

    class TransactionManager:
        """Transaction with savepoint support."""

        def __init__(self):
            self.transaction_stack = []

        @contextmanager
        def transaction(self, name: str = "default"):
            """Nested transaction with savepoint."""
            logger.info(f"BEGIN TRANSACTION: {name}")
            self.transaction_stack.append(name)
            try:
                yield
                logger.info(f"COMMIT: {name}")
            except Exception as e:
                logger.error(f"ROLLBACK: {name} ({type(e).__name__})")
                self.transaction_stack.pop()
                raise
            self.transaction_stack.pop()

    tm = TransactionManager()

    with tm.transaction("outer"):
        logger.info("  Outer transaction work")
        try:
            with tm.transaction("inner"):
                logger.info("  Inner transaction work")
                raise ValueError("Inner error")
        except ValueError:
            pass


def best_practices() -> None:
    """Best practices."""
    print("\n" + "=" * 80)
    print("SECTION 11: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Use @contextmanager for simple, single-purpose context managers",
        "2. Implement __enter__ and __exit__ for complex scenarios",
        "3. Use ExitStack for managing multiple dynamic contexts",
        "4. Always clean up resources in __exit__",
        "5. Use circuit breaker pattern to prevent cascading failures",
        "6. Implement rate limiting for API/resource access",
        "7. Log entry/exit points for debugging",
        "8. Support nested contexts where appropriate",
        "9. Handle both success and failure cases",
        "10. Test error paths thoroughly",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("CUSTOM CONTEXT MANAGERS - ADVANCED PATTERNS")
    print("=" * 80)

    demonstrate_retry_context_manager()
    demonstrate_timeout_context_manager()
    demonstrate_logging_context_manager()
    demonstrate_state_context_manager()
    demonstrate_exit_stack()
    demonstrate_circuit_breaker()
    demonstrate_rate_limiter()
    demonstrate_resource_tracking()
    demonstrate_debug_context_manager()
    demonstrate_transaction_context_manager()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY - CUSTOM CONTEXT MANAGER PATTERNS")
    print("=" * 80)
    print("""
Common Patterns:
    1. Retry Logic - Automatic retries with exponential backoff
    2. Timeout - Limit operation execution time
    3. Circuit Breaker - Prevent cascading failures
    4. Rate Limiting - Control operation frequency
    5. Resource Tracking - Monitor resource usage
    6. State Management - Temporary state changes
    7. Logging - Structured operation logging
    8. Transactions - Database transaction handling
    9. Resource Pooling - Acquire/release from pool
    10. Debugging - Enhanced logging and inspection

Implementation Approaches:
    - @contextmanager decorator (simple)
    - Class with __enter__/__exit__ (complex)
    - ExitStack (dynamic/multiple contexts)
    - Nested contexts (layered management)

Production Considerations:
    - Error handling and propagation
    - Resource cleanup even on failure
    - Performance (minimal overhead)
    - Monitoring and observability
    - Thread safety where needed
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Custom context managers add negligible overhead
# Enable proper resource management (prevents leaks)
# Circuit breaker pattern prevents cascading failures
# Rate limiting protects against overload
# Logging context helps with debugging and monitoring

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Not cleaning up all resources in __exit__
# 2. Not handling exceptions in __exit__
# 3. Suppressing exceptions without good reason
# 4. Not testing error paths
# 5. Overhead of context manager protocol in tight loops

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Design a context manager for database connection pooling
# Q2: Implement circuit breaker pattern as context manager
# Q3: How would you create nested transaction contexts?
# Q4: Design rate limiting context manager
# Q5: Implement automatic retry context manager

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build a comprehensive request context manager
# Requirements:
#   - Rate limiting
#   - Timeout handling
#   - Retry on failure (with backoff)
#   - Circuit breaker
#   - Request logging
# Implementation: Combine multiple patterns
