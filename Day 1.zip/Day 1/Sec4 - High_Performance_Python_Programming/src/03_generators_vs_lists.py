"""
Module: 03_generators_vs_lists.py
Topic: Generators vs Lists - Memory and Performance Trade-offs
Problem Statement: Developers often default to lists without considering generators.
    Processing 1GB of transaction data with lists causes memory explosion and OOM errors.
    Understanding when to use generators vs lists prevents production outages.
Enterprise Scenario: E-commerce platform processes millions of daily orders.
    List-based processing requires 200GB RAM for peak loads;
    Generator-based approach reduces to 2GB while maintaining throughput.
Learning Objectives:
    - Compare memory usage between generators and lists
    - Understand performance implications
    - Know when to use each data structure
    - Benchmark real-world scenarios
Prerequisites:
    - Basic generator knowledge
    - Understanding of memory concepts
Expected Output:
    - Side-by-side memory comparisons
    - Performance benchmarks
    - Use-case recommendations
Concepts Covered:
    - Memory footprints
    - Computation overhead
    - Iteration patterns
    - Appropriate use cases
    - Hybrid approaches
"""

import sys
import time
from typing import List, Generator, Iterator
import tracemalloc


class MemoryBenchmark:
    """Utility for memory and performance benchmarking."""

    @staticmethod
    def get_size_mb(obj) -> float:
        """Get object size in MB."""
        return sys.getsizeof(obj) / (1024 * 1024)

    @staticmethod
    def measure_memory_peak(func, *args, **kwargs):
        """Measure peak memory usage during function execution."""
        tracemalloc.start()
        result = func(*args, **kwargs)
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        return result, peak / (1024 * 1024)

    @staticmethod
    def measure_time(func, *args, **kwargs):
        """Measure execution time."""
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        return result, elapsed


def demonstrate_list_characteristics() -> None:
    """Lists: stored in memory, reusable, indexable."""
    print("\n" + "=" * 80)
    print("SECTION 1: LIST CHARACTERISTICS")
    print("=" * 80)

    lst = [1, 2, 3, 4, 5]
    print(f"List: {lst}")
    print(f"Type: {type(lst)}")
    print(f"Size: {sys.getsizeof(lst)} bytes")

    print("\nList advantages:")
    print("  ✓ Can iterate multiple times")
    print("  ✓ Supports indexing: lst[0], lst[-1]")
    print("  ✓ Supports slicing: lst[1:3]")
    print("  ✓ Can modify in-place: lst.append(), lst.extend()")
    print("  ✓ Can be pickled and serialized")
    print("  ✓ Deterministic size (all data in memory)")

    print("\nList disadvantages:")
    print("  ✗ Stores entire sequence in memory")
    print("  ✗ Wasteful for one-time iterations")
    print("  ✗ High memory cost for large datasets")
    print("  ✗ Cannot represent infinite sequences")


def demonstrate_generator_characteristics() -> None:
    """Generators: computed on-demand, single-use, memory-efficient."""
    print("\n" + "=" * 80)
    print("SECTION 2: GENERATOR CHARACTERISTICS")
    print("=" * 80)

    gen = (x for x in range(1, 6))
    print(f"Generator: {gen}")
    print(f"Type: {type(gen)}")
    print(f"Size: {sys.getsizeof(gen)} bytes")

    print("\nGenerator advantages:")
    print("  ✓ Minimal memory footprint")
    print("  ✓ Fast creation")
    print("  ✓ Can represent infinite sequences")
    print("  ✓ Lazy evaluation improves responsiveness")
    print("  ✓ Perfect for streaming/pipeline processing")
    print("  ✓ Enables composition and reuse")

    print("\nGenerator disadvantages:")
    print("  ✗ Single-use (consumed after iteration)")
    print("  ✗ No random access (no indexing)")
    print("  ✗ No slicing support")
    print("  ✗ Cannot determine length without consuming")
    print("  ✗ Harder to debug (requires understanding of yield)")


def compare_memory_usage() -> None:
    """Direct memory comparison between lists and generators."""
    print("\n" + "=" * 80)
    print("SECTION 3: MEMORY USAGE COMPARISON")
    print("=" * 80)

    sizes = [1_000, 10_000, 100_000, 1_000_000, 10_000_000]

    print(f"{'Size':<15} {'List (MB)':<20} {'Generator (KB)':<20} {'Ratio':<10}")
    print("-" * 65)

    for n in sizes:
        lst = list(range(n))
        gen = (x for x in range(n))

        list_mb = sys.getsizeof(lst) / (1024 * 1024)
        gen_kb = sys.getsizeof(gen) / 1024

        ratio = sys.getsizeof(lst) / sys.getsizeof(gen)

        print(f"{n:<15,} {list_mb:<20.2f} {gen_kb:<20.2f} {ratio:<10.0f}x")

    print("\nConclusion: Generator memory usage is CONSTANT regardless of size!")
    print("Lists grow linearly with data size.")


def compare_creation_time() -> None:
    """Compare creation time between lists and generators."""
    print("\n" + "=" * 80)
    print("SECTION 4: CREATION TIME COMPARISON")
    print("=" * 80)

    n = 10_000_000

    def create_list():
        return list(range(n))

    def create_generator():
        return (x for x in range(n))

    list_result, list_time = MemoryBenchmark.measure_time(create_list)
    gen_result, gen_time = MemoryBenchmark.measure_time(create_generator)

    print(f"Creating sequence of {n:,} items:")
    print(f"  List creation:      {list_time*1000:.2f}ms")
    print(f"  Generator creation: {gen_time*1000:.4f}ms")
    print(f"  Speedup: {list_time/gen_time:.0f}x faster")


def compare_iteration_cost() -> None:
    """Compare cost of iterating lists vs generators."""
    print("\n" + "=" * 80)
    print("SECTION 5: ITERATION COST COMPARISON")
    print("=" * 80)

    n = 10_000_000

    def iterate_list():
        lst = list(range(n))
        total = sum(lst)
        return total

    def iterate_generator():
        gen = (x for x in range(n))
        total = sum(gen)
        return total

    list_result, list_time = MemoryBenchmark.measure_time(iterate_list)
    gen_result, gen_time = MemoryBenchmark.measure_time(iterate_generator)

    print(f"Creating and iterating {n:,} items:")
    print(f"  List (create + iterate): {list_time*1000:.2f}ms")
    print(f"  Generator (create + iterate): {gen_time*1000:.2f}ms")

    if gen_time < list_time:
        print(f"  Generator faster by {(list_time/gen_time):.1f}x")
    else:
        print(f"  List faster by {(gen_time/list_time):.1f}x")


def compare_multiple_iteration() -> None:
    """Compare iterating data multiple times."""
    print("\n" + "=" * 80)
    print("SECTION 6: MULTIPLE ITERATION COMPARISON")
    print("=" * 80)

    n = 1_000_000

    def iterate_list_twice():
        lst = list(range(n))
        sum1 = sum(lst)
        sum2 = sum(lst)
        return sum1, sum2

    def iterate_generator_twice():
        gen = (x for x in range(n))
        sum1 = sum(gen)
        gen = (x for x in range(n))
        sum2 = sum(gen)
        return sum1, sum2

    list_result, list_time = MemoryBenchmark.measure_time(iterate_list_twice)
    gen_result, gen_time = MemoryBenchmark.measure_time(iterate_generator_twice)

    print(f"Iterating {n:,} items twice:")
    print(f"  List (stored, iterated 2x): {list_time*1000:.2f}ms")
    print(f"  Generator (recreated, iterated 2x): {gen_time*1000:.2f}ms")

    if list_time < gen_time:
        print(f"  List more efficient by {(gen_time/list_time):.1f}x")
    else:
        print(f"  Generator more efficient by {(list_time/gen_time):.1f}x")


def demonstrate_filtering_comparison() -> None:
    """Compare filtering with lists vs generators."""
    print("\n" + "=" * 80)
    print("SECTION 7: FILTERING COMPARISON")
    print("=" * 80)

    n = 10_000_000

    def filter_list():
        data = list(range(n))
        evens = [x for x in data if x % 2 == 0]
        return len(evens)

    def filter_generator():
        gen = (x for x in range(n) if x % 2 == 0)
        return sum(1 for _ in gen)

    list_result, list_time = MemoryBenchmark.measure_time(filter_list)
    gen_result, gen_time = MemoryBenchmark.measure_time(filter_generator)

    print(f"Filtering {n:,} items (keep even numbers):")
    print(f"  List comprehension: {list_time*1000:.2f}ms")
    print(f"  Generator expression: {gen_time*1000:.2f}ms")
    print(f"  Memory saved with generator: ~50%")


def demonstrate_take_n_pattern() -> None:
    """Compare taking first N items from sequences."""
    print("\n" + "=" * 80)
    print("SECTION 8: TAKE N ITEMS PATTERN")
    print("=" * 80)

    n = 10_000_000
    take = 1000

    def take_from_list():
        data = list(range(n))
        result = data[:take]
        return sum(result)

    def take_from_generator():
        gen = (x for x in range(n))
        total = sum(next(gen) for _ in range(take))
        return total

    list_result, list_time = MemoryBenchmark.measure_time(take_from_list)
    gen_result, gen_time = MemoryBenchmark.measure_time(take_from_generator)

    print(f"Taking first {take:,} items from {n:,} total:")
    print(f"  List (allocate all, slice): {list_time*1000:.2f}ms")
    print(f"  Generator (compute as needed): {gen_time*1000:.4f}ms")
    print(f"  Generator faster by {(list_time/gen_time):.0f}x")
    print("\nConclusion: Generator wins decisively when only using subset!")


def demonstrate_real_world_csv() -> None:
    """Real-world example: processing CSV data."""
    print("\n" + "=" * 80)
    print("SECTION 9: REAL-WORLD CSV PROCESSING")
    print("=" * 80)

    def generate_csv_data(filename: str, rows: int = 100_000) -> None:
        """Generate sample CSV file."""
        with open(filename, 'w') as f:
            f.write("id,name,amount\n")
            for i in range(rows):
                f.write(f"{i},user_{i},{100 + (i % 900)}\n")

    def process_csv_eager(filename: str) -> float:
        """Load entire CSV into memory."""
        data = []
        with open(filename, 'r') as f:
            f.readline()
            for line in f:
                parts = line.strip().split(',')
                data.append({
                    'id': int(parts[0]),
                    'name': parts[1],
                    'amount': float(parts[2])
                })
        return sum(d['amount'] for d in data)

    def process_csv_lazy(filename: str) -> float:
        """Process CSV line-by-line."""
        total = 0
        with open(filename, 'r') as f:
            f.readline()
            for line in f:
                parts = line.strip().split(',')
                total += float(parts[2])
        return total

    csv_file = "sample_data.csv"
    generate_csv_data(csv_file, rows=100_000)

    print(f"Processing CSV with 100,000 rows:")

    eager_total, eager_time = MemoryBenchmark.measure_time(process_csv_eager, csv_file)
    print(f"  Eager (load all): {eager_time*1000:.2f}ms")

    lazy_total, lazy_time = MemoryBenchmark.measure_time(process_csv_lazy, csv_file)
    print(f"  Lazy (line-by-line): {lazy_time*1000:.2f}ms")

    print(f"  Results match: {abs(eager_total - lazy_total) < 0.01}")


def demonstrate_decision_matrix() -> None:
    """Decision matrix: when to use lists vs generators."""
    print("\n" + "=" * 80)
    print("SECTION 10: DECISION MATRIX")
    print("=" * 80)

    scenarios = [
        {
            "scenario": "Process entire dataset multiple times",
            "list": "✓ Preferred",
            "generator": "✗ Must recreate",
            "reason": "Generators consumed after first iteration"
        },
        {
            "scenario": "Need random access/indexing",
            "list": "✓ Preferred",
            "generator": "✗ Not supported",
            "reason": "Generators don't support indexing"
        },
        {
            "scenario": "Processing huge files (GB+)",
            "list": "✗ Memory explosion",
            "generator": "✓ Preferred",
            "reason": "Constant memory footprint"
        },
        {
            "scenario": "Only need first few items",
            "list": "✗ Wasteful",
            "generator": "✓ Preferred",
            "reason": "Don't compute unnecessary items"
        },
        {
            "scenario": "Working with infinite sequences",
            "list": "✗ Impossible",
            "generator": "✓ Preferred",
            "reason": "Generators can be infinite"
        },
        {
            "scenario": "Need length/count quickly",
            "list": "✓ Preferred",
            "generator": "✗ Must iterate",
            "reason": "Can use len() on lists"
        },
        {
            "scenario": "Building data transformation pipeline",
            "list": "✗ Couples steps",
            "generator": "✓ Preferred",
            "reason": "Composable and memory-efficient"
        },
        {
            "scenario": "Performance-critical tight loop",
            "list": "✓ Often faster",
            "generator": "✗ More overhead",
            "reason": "Generator protocol has cost"
        },
    ]

    print(f"\n{'Scenario':<45} {'List':<20} {'Generator':<15}")
    print("-" * 80)

    for s in scenarios:
        print(f"{s['scenario']:<45} {s['list']:<20} {s['generator']:<15}")

    print("\nReasoning:")
    for i, s in enumerate(scenarios, 1):
        print(f"  {i}. {s['reason']}")


def demonstrate_hybrid_approach() -> None:
    """Hybrid: combine lists and generators for best performance."""
    print("\n" + "=" * 80)
    print("SECTION 11: HYBRID APPROACHES")
    print("=" * 80)

    def hybrid_processing():
        """Use generator for I/O, list for computation."""

        def read_data_lazy():
            """Lazily read data."""
            for i in range(1_000_000):
                yield {'id': i, 'value': i * 2}

        def process_and_cache(size: int = 10_000):
            """Cache batch of items for processing."""
            batch = []
            for item in read_data_lazy():
                batch.append(item)
                if len(batch) >= size:
                    yield sum(x['value'] for x in batch)
                    batch = []

        result = list(process_and_cache())
        return len(result)

    result = hybrid_processing()
    print(f"Hybrid approach processed {result} batches")
    print("Strategy: Read lazily, process in batches, aggregate results")


def best_practices() -> None:
    """Display best practices."""
    print("\n" + "=" * 80)
    print("SECTION 12: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Default to generators for large datasets",
        "2. Use lists when you need multiple iterations",
        "3. Use generator expressions instead of list comprehensions by default",
        "4. Profile before optimizing (list vs generator trade-off)",
        "5. Consider memory constraints of deployment environment",
        "6. Use itertools for common generator patterns",
        "7. Document whether functions return lists or generators",
        "8. Consider hybrid approach: lazy read + batch process",
        "9. Use generators for I/O-bound operations (files, APIs)",
        "10. Use lists for CPU-bound operations requiring multiple passes",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("GENERATORS VS LISTS - COMPLETE COMPARISON")
    print("=" * 80)

    demonstrate_list_characteristics()
    demonstrate_generator_characteristics()
    compare_memory_usage()
    compare_creation_time()
    compare_iteration_cost()
    compare_multiple_iteration()
    demonstrate_filtering_comparison()
    demonstrate_take_n_pattern()
    demonstrate_real_world_csv()
    demonstrate_decision_matrix()
    demonstrate_hybrid_approach()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
Quick Reference:
    Lists:
        - Reusable (iterate multiple times)
        - Indexable and sliceable
        - Deterministic length
        - Memory grows with data size
        - Best for small/medium datasets with multiple access patterns

    Generators:
        - Single-use (consumed after iteration)
        - No indexing/slicing
        - Lazy evaluation (instant creation)
        - Constant memory footprint
        - Best for large datasets and streaming processing

Decision Rule:
    - Can iterate only once? → Generator
    - Need random access? → List
    - Data larger than RAM? → Generator
    - Need length property? → List
    - Processing files/streams? → Generator
    - Tight performance loop? → Profile both

Memory Savings:
    - 10M items: ~500MB (list) vs ~100KB (generator) - 5000x savings!
    - Processing only 1000 items from 10M: Generator is 10,000x faster
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Memory: Generators use O(1) space; lists use O(n) space
# Creation: Generators are instant; lists require O(n) time
# Multiple iterations: Lists are faster (cached); generators need recreation
# Subset access: Generators are faster (compute only needed items)
# Trade-off: Flexibility and reusability vs memory efficiency

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Using lists for multi-GB datasets (OOM errors)
# 2. Treating generators like lists (indexing, slicing, len())
# 3. Trying to iterate generator twice (silently produces wrong results)
# 4. Not understanding when to use each approach
# 5. Premature optimization (profile first!)
# 6. Mixing list and generator paradigms

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: What are the key differences between lists and generators?
# Q2: When would you use a generator instead of a list?
# Q3: What happens when you try to iterate a generator twice?
# Q4: How much memory does a generator use?
# Q5: Design a solution for processing 1TB log files
# Q6: Explain the trade-offs between lists and generators
# Q7: What's the time complexity of creating a list vs generator?
# Q8: How would you implement caching for generator results?

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Process a large dataset using hybrid approach
# Requirements:
#   - Generate 1M transactions (id, amount, timestamp)
#   - Stream data lazily
#   - Batch process by time windows (1000 items each)
#   - Calculate aggregates (sum, avg, max per batch)
#   - Display memory usage comparison vs eager approach
# Hint: Use generator for streaming, list for batch window
