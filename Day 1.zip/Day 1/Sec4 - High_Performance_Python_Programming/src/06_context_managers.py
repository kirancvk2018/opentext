"""
Module: 06_context_managers.py
Topic: Context Managers - Resource Management Patterns
Problem Statement: Programs leak database connections, file handles, and memory.
    Developers forget cleanup code or exceptions bypass it.
    Context managers (with statement) guarantee cleanup even during errors.
Enterprise Scenario: A server crashes under load because connection leaks exhaust the pool.
    Adding context managers fixes the issue: resources are always freed properly.
Learning Objectives:
    - Understand context manager protocol
    - Use with statement for safe resource management
    - Implement custom context managers
    - Handle resource cleanup and error handling
Prerequisites:
    - Understanding of __enter__ and __exit__ methods
    - Exception handling fundamentals
Expected Output:
    - Safe resource management patterns
    - Custom context managers
    - Error handling demonstrations
Concepts Covered:
    - Context manager protocol
    - with statement semantics
    - Resource cleanup guarantees
    - Exception handling in context managers
    - Nested context managers
"""

from typing import Any, Generator, Optional
import time
import tempfile
import os


def demonstrate_file_handling() -> None:
    """Safe file handling with context managers."""
    print("\n" + "=" * 80)
    print("SECTION 1: FILE HANDLING WITH CONTEXT MANAGERS")
    print("=" * 80)

    print("WITHOUT context manager (UNSAFE):")
    print("""
    f = open('file.txt', 'r')
    content = f.read()
    f.close()  # May not execute if exception occurs!
    """)

    print("WITH context manager (SAFE):")
    print("""
    with open('file.txt', 'r') as f:
        content = f.read()
    # File automatically closed, even if exception occurs
    """)

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        f.write("Hello, World!")

    try:
        with open(temp_file, 'r') as f:
            content = f.read()
        print(f"Successfully read file: {content}")
    finally:
        os.unlink(temp_file)


def demonstrate_database_connection() -> None:
    """Simulate database connection management."""
    print("\n" + "=" * 80)
    print("SECTION 2: DATABASE CONNECTION MANAGEMENT")
    print("=" * 80)

    class DatabaseConnection:
        """Simulated database connection."""

        def __init__(self, name: str):
            self.name = name
            self.is_open = False

        def __enter__(self):
            print(f"  [DB] Opening connection: {self.name}")
            self.is_open = True
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            print(f"  [DB] Closing connection: {self.name}")
            self.is_open = False
            if exc_type:
                print(f"  [DB] Exception occurred: {exc_type.__name__}")
            return False

        def query(self, sql: str):
            if not self.is_open:
                raise RuntimeError("Connection not open")
            print(f"  [DB] Executing: {sql}")
            return f"Result of {sql}"

    print("Safe database usage:")
    with DatabaseConnection("mydb") as db:
        result = db.query("SELECT * FROM users")
        print(f"  Got: {result}")

    print("\nException handling (connection still closes):")
    try:
        with DatabaseConnection("mydb") as db:
            result = db.query("SELECT * FROM users")
            raise ValueError("Simulated error")
    except ValueError as e:
        print(f"  Caught exception: {e}")

    print("Connection was properly closed despite exception")


def demonstrate_lock_management() -> None:
    """Thread locks using context managers."""
    print("\n" + "=" * 80)
    print("SECTION 3: LOCK MANAGEMENT")
    print("=" * 80)

    import threading

    class Counter:
        def __init__(self):
            self.value = 0
            self.lock = threading.Lock()

        def increment_unsafe(self):
            temp = self.value
            temp += 1
            self.value = temp

        def increment_safe(self):
            with self.lock:
                temp = self.value
                temp += 1
                self.value = temp

    counter = Counter()

    print("With lock context manager:")
    for _ in range(5):
        counter.increment_safe()
    print(f"  Counter value: {counter.value} (correct)")

    print("\nWithout lock (can cause race conditions):")
    counter.value = 0
    for _ in range(5):
        counter.increment_unsafe()
    print(f"  Counter value: {counter.value} (may be wrong under concurrent access)")


def demonstrate_timer_context_manager() -> None:
    """Custom context manager: timer."""
    print("\n" + "=" * 80)
    print("SECTION 4: CUSTOM TIMER CONTEXT MANAGER")
    print("=" * 80)

    class Timer:
        """Context manager for timing code blocks."""

        def __init__(self, name: str = "Operation"):
            self.name = name
            self.start_time = None

        def __enter__(self):
            self.start_time = time.perf_counter()
            print(f"  {self.name} started")
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            elapsed = time.perf_counter() - self.start_time
            print(f"  {self.name} completed in {elapsed*1000:.2f}ms")
            return False

    with Timer("Sleeping for 100ms"):
        time.sleep(0.1)

    with Timer("Loop iteration"):
        sum([i**2 for i in range(1_000_000)])


def demonstrate_transactional_context_manager() -> None:
    """Context manager: transaction rollback on error."""
    print("\n" + "=" * 80)
    print("SECTION 5: TRANSACTIONAL CONTEXT MANAGER")
    print("=" * 80)

    class Transaction:
        """Simulated database transaction."""

        def __init__(self):
            self.changes = []
            self.committed = False

        def __enter__(self):
            print("  [Transaction] BEGIN")
            self.changes = []
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type:
                print(f"  [Transaction] ROLLBACK (exception: {exc_type.__name__})")
                self.changes = []
                return False
            else:
                print("  [Transaction] COMMIT")
                self.committed = True
                return False

        def insert(self, data: str):
            self.changes.append(data)
            print(f"  [Transaction] Inserted: {data}")

    print("Successful transaction:")
    with Transaction() as txn:
        txn.insert("User 1")
        txn.insert("User 2")
    print(f"  Committed: {txn.committed}\n")

    print("Transaction with rollback:")
    with Transaction() as txn:
        txn.insert("User 1")
        raise RuntimeError("Error during insert")
    print(f"  Committed: {txn.committed}")


def demonstrate_resource_pool() -> None:
    """Context manager: resource pool checkout/checkin."""
    print("\n" + "=" * 80)
    print("SECTION 6: RESOURCE POOL")
    print("=" * 80)

    class ResourcePool:
        """Manages a pool of resources."""

        def __init__(self, size: int):
            self.pool = [{"id": i, "in_use": False} for i in range(size)]
            self.total_checkouts = 0

        def __enter__(self):
            for resource in self.pool:
                if not resource["in_use"]:
                    resource["in_use"] = True
                    self.total_checkouts += 1
                    print(f"  Checked out resource {resource['id']}")
                    return resource
            raise RuntimeError("No available resources")

        def __exit__(self, exc_type, exc_val, exc_tb):
            for resource in self.pool:
                if resource["in_use"]:
                    resource["in_use"] = False
                    print(f"  Returned resource {resource['id']}")
                    break
            return False

    pool = ResourcePool(3)

    print("Checkout and use resources:")
    with pool as resource:
        print(f"  Using resource: {resource['id']}")

    print(f"Total checkouts: {pool.total_checkouts}")


def demonstrate_suppressing_exceptions() -> None:
    """Using contextlib.suppress for exception handling."""
    print("\n" + "=" * 80)
    print("SECTION 7: SUPPRESSING EXCEPTIONS")
    print("=" * 80)

    from contextlib import suppress

    print("Without suppress:")
    try:
        int("not a number")
    except ValueError:
        print("  Caught ValueError")

    print("\nWith suppress:")
    with suppress(ValueError):
        int("not a number")
    print("  ValueError was suppressed silently")


def demonstrate_nested_context_managers() -> None:
    """Nested context managers."""
    print("\n" + "=" * 80)
    print("SECTION 8: NESTED CONTEXT MANAGERS")
    print("=" * 80)

    class Resource:
        def __init__(self, name: str):
            self.name = name

        def __enter__(self):
            print(f"  Opening {self.name}")
            return self

        def __exit__(self, *args):
            print(f"  Closing {self.name}")

    print("Multiple context managers (nested):")
    with Resource("File 1") as f1:
        with Resource("File 2") as f2:
            with Resource("Lock") as lock:
                print("    All resources acquired")

    print("\nMultiple context managers (simultaneous):")
    with Resource("File 1") as f1, Resource("File 2") as f2:
        print("    Both resources acquired")


def demonstrate_error_propagation() -> None:
    """Error propagation in context managers."""
    print("\n" + "=" * 80)
    print("SECTION 9: ERROR PROPAGATION")
    print("=" * 80)

    class StrictContext:
        """Propagates exceptions (returns False)."""
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type:
                print(f"  Exception detected: {exc_type.__name__}")
            return False  # Propagate exception

    class SuppressingContext:
        """Suppresses exceptions (returns True)."""
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type:
                print(f"  Exception suppressed: {exc_type.__name__}")
            return True  # Suppress exception

    print("Propagating exceptions:")
    try:
        with StrictContext():
            raise ValueError("Test error")
    except ValueError as e:
        print(f"  Outer handler caught: {e}\n")

    print("Suppressing exceptions:")
    try:
        with SuppressingContext():
            raise ValueError("Test error")
    except ValueError as e:
        print(f"  This should not print")
    print("  Exception was suppressed by context manager")


def demonstrate_generator_context_manager() -> None:
    """Context managers using generators."""
    print("\n" + "=" * 80)
    print("SECTION 10: GENERATOR CONTEXT MANAGERS")
    print("=" * 80)

    from contextlib import contextmanager

    @contextmanager
    def managed_resource(name: str):
        """Context manager from generator."""
        print(f"  Acquiring {name}")
        try:
            yield f"resource_{name}"
        finally:
            print(f"  Releasing {name}")

    print("Using generator-based context manager:")
    with managed_resource("database") as res:
        print(f"    Using {res}")

    print("\nWith exception:")
    try:
        with managed_resource("file") as res:
            print(f"    Using {res}")
            raise RuntimeError("Error!")
    except RuntimeError:
        print("  Exception was raised but resource was cleaned up")


def demonstrate_multiple_exit_handlers() -> None:
    """Multiple exit handlers (cleanup order)."""
    print("\n" + "=" * 80)
    print("SECTION 11: CLEANUP ORDER")
    print("=" * 80)

    class OrderedResource:
        def __init__(self, name: str):
            self.name = name

        def __enter__(self):
            print(f"  Entering {self.name}")
            return self

        def __exit__(self, *args):
            print(f"  Exiting {self.name}")

    print("Resources are cleaned up in reverse order of acquisition:")
    with OrderedResource("1") as r1:
        with OrderedResource("2") as r2:
            with OrderedResource("3") as r3:
                print("    All resources acquired")


def best_practices() -> None:
    """Best practices for context managers."""
    print("\n" + "=" * 80)
    print("SECTION 12: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Always use context managers for resource management",
        "2. Prefer 'with' statement to manual try/finally",
        "3. Resources are cleaned up in reverse order of acquisition",
        "4. Use @contextmanager decorator for simple cases",
        "5. Implement __enter__ and __exit__ for complex cases",
        "6. __exit__ always runs, even if exception occurs",
        "7. Return False from __exit__ to propagate exceptions",
        "8. Return True from __exit__ to suppress exceptions",
        "9. Nest context managers for multiple resource management",
        "10. Use contextlib utilities (suppress, ExitStack, etc.)",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("CONTEXT MANAGERS - RESOURCE MANAGEMENT")
    print("=" * 80)

    demonstrate_file_handling()
    demonstrate_database_connection()
    demonstrate_lock_management()
    demonstrate_timer_context_manager()
    demonstrate_transactional_context_manager()
    demonstrate_resource_pool()
    demonstrate_suppressing_exceptions()
    demonstrate_nested_context_managers()
    demonstrate_error_propagation()
    demonstrate_generator_context_manager()
    demonstrate_multiple_exit_handlers()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
Context Manager Protocol:
    __enter__()  - Called when entering 'with' block
    __exit__(...)- Called when exiting 'with' block (always!)

with Statement Guarantees:
    - Setup code in __enter__ runs
    - Code block runs
    - Cleanup code in __exit__ runs (even if exception)
    - Exceptions are properly handled

Common Use Cases:
    - File I/O (open/close)
    - Database connections (connect/disconnect)
    - Locks (acquire/release)
    - Transactions (begin/commit/rollback)
    - Resource pools (checkout/checkin)
    - Timing measurements
    - Temporary state changes
    - API rate limiting

Generator-based Context Managers:
    @contextmanager decorator
    Yield value to be used in 'as' clause
    Code after yield is cleanup

Best Practice:
    Use context managers for ANY resource that needs cleanup
    This prevents leaks and ensures correct error handling
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Context managers add minimal overhead
# Guarantee cleanup prevents resource exhaustion
# __exit__ always runs, even on exceptions
# Cleanup order: reverse of acquisition order
# Performance cost negligible compared to resource leak cost

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Forgetting to use 'with' statement
# 2. Manual try/finally instead of context managers
# 3. Not understanding __exit__ returns False
# 4. Returning True in __exit__ when should propagate
# 5. Acquiring resources outside 'with' block

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Explain the context manager protocol
# Q2: What happens if __exit__ raises an exception?
# Q3: Design a context manager for database transactions
# Q4: How do you use @contextmanager decorator?
# Q5: What's the cleanup order for nested context managers?
# Q6: How would you implement a connection pool context manager?
# Q7: Explain the difference between return False/True in __exit__

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build a context manager for application configuration
# Requirements:
#   - Load configuration on __enter__
#   - Restore previous config on __exit__
#   - Handle missing config files gracefully
#   - Support nested configuration contexts
# Hint: Save/restore configuration state
