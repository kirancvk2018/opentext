"""
Module: 11_file_stream_processing.py
Topic: Efficient File and Stream Processing
Problem Statement: Loading entire files into memory causes OOM errors.
    Streaming processing handles multi-GB files with constant memory.
Enterprise Scenario: Log file analysis must process terabytes of archived logs.
    Streaming approach enables analysis on modest hardware.
Learning Objectives:
    - Process files line-by-line (streaming)
    - Handle different encodings
    - Implement efficient text processing
    - Design scalable file pipelines
Prerequisites:
    - Understanding of generators and iterators
    - Basic file I/O knowledge
Expected Output:
    - Streaming file processing examples
    - Memory-efficient patterns
    - Real-world use cases
Concepts Covered:
    - Line-by-line processing
    - Chunked reading
    - Encoding handling
    - Binary vs text processing
    - Pipeline composition
"""

import sys
from typing import Iterator, Generator, IO
import tempfile
import os
import time


def demonstrate_eager_vs_lazy_file_processing() -> None:
    """Compare eager and lazy file reading."""
    print("\n" + "=" * 80)
    print("SECTION 1: EAGER VS LAZY FILE READING")
    print("=" * 80)

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        for i in range(1000):
            f.write(f"Line {i}: This is sample data\n")

    try:
        print("ANTI-PATTERN: Load entire file (memory inefficient)")
        print("  with open(file) as f:")
        print("      lines = f.readlines()  # All in memory!")

        print("\nBETTER: Iterate line-by-line (streaming)")
        print("  with open(file) as f:")
        print("      for line in f:  # One line at a time")
        print("          process(line)")

        print("\nDemonstration:")
        with open(temp_file, 'r') as f:
            for i, line in enumerate(f):
                if i < 3:
                    print(f"  Line {i}: {line.rstrip()}")
                if i == 2:
                    print("  ...")
                    break
    finally:
        os.unlink(temp_file)


def demonstrate_line_by_line_processing() -> None:
    """Process files line-by-line."""
    print("\n" + "=" * 80)
    print("SECTION 2: LINE-BY-LINE PROCESSING")
    print("=" * 80)

    def process_file(filename: str) -> Generator[str, None, None]:
        """Yield processed lines."""
        with open(filename, 'r') as f:
            for line in f:
                yield line.rstrip().upper()

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        f.write("line 1\nline 2\nline 3\n")

    try:
        print("Processing lines on-demand:")
        for line in process_file(temp_file):
            print(f"  {line}")
    finally:
        os.unlink(temp_file)


def demonstrate_chunked_reading() -> None:
    """Read files in chunks."""
    print("\n" + "=" * 80)
    print("SECTION 3: CHUNKED READING")
    print("=" * 80)

    def read_chunks(filename: str, chunk_size: int = 8192) -> Generator[str, None, None]:
        """Read file in chunks."""
        with open(filename, 'rb') as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                yield chunk.decode('utf-8', errors='ignore')

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        f.write("x" * 100000)

    try:
        total_bytes = 0
        chunk_count = 0
        for chunk in read_chunks(temp_file, chunk_size=8192):
            total_bytes += len(chunk)
            chunk_count += 1

        print(f"Read {chunk_count} chunks, {total_bytes} total bytes")
        print(f"Memory used: ~8KB per chunk (constant)")
    finally:
        os.unlink(temp_file)


def demonstrate_filtering_pipeline() -> None:
    """Pipeline for filtering large files."""
    print("\n" + "=" * 80)
    print("SECTION 4: FILTERING PIPELINE")
    print("=" * 80)

    def generate_logs(n: int) -> Generator[str, None, None]:
        """Generate log lines."""
        for i in range(n):
            level = ['INFO', 'WARNING', 'ERROR'][i % 3]
            yield f"[{level}] Message {i}\n"

    def filter_errors(lines: Iterator[str]) -> Generator[str, None, None]:
        """Filter to error lines only."""
        for line in lines:
            if '[ERROR]' in line:
                yield line

    def extract_messages(lines: Iterator[str]) -> Generator[str, None, None]:
        """Extract message part."""
        for line in lines:
            parts = line.split('] ')
            if len(parts) > 1:
                yield parts[1].strip()

    print("Log filtering pipeline:")
    pipeline = extract_messages(filter_errors(generate_logs(20)))

    for i, msg in enumerate(pipeline):
        if i < 5:
            print(f"  {msg}")
        if i == 4:
            print("  ...")
            break


def demonstrate_encoding_handling() -> None:
    """Handle various file encodings."""
    print("\n" + "=" * 80)
    print("SECTION 5: ENCODING HANDLING")
    print("=" * 80)

    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', delete=False, suffix='.txt') as f:
        temp_file = f.name
        f.write("Hello,世界\n")
        f.write("Bonjour,Français\n")

    try:
        print("UTF-8 encoding:")
        with open(temp_file, 'r', encoding='utf-8') as f:
            for line in f:
                print(f"  {line.rstrip()}")

        print("\nIgnoring errors:")
        with open(temp_file, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                print(f"  {line.rstrip()}")

        print("\nReplacing invalid characters:")
        with open(temp_file, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                print(f"  {line.rstrip()}")
    finally:
        os.unlink(temp_file)


def demonstrate_binary_processing() -> None:
    """Binary file processing."""
    print("\n" + "=" * 80)
    print("SECTION 6: BINARY FILE PROCESSING")
    print("=" * 80)

    with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.bin') as f:
        temp_file = f.name
        f.write(b'\x00\x01\x02\x03\x04\x05')

    try:
        print("Reading binary file:")
        with open(temp_file, 'rb') as f:
            data = f.read()
            print(f"  Bytes: {data.hex()}")
            print(f"  As list: {list(data)}")

        print("\nProcessing in chunks:")
        with open(temp_file, 'rb') as f:
            chunk_num = 0
            while True:
                chunk = f.read(2)
                if not chunk:
                    break
                print(f"  Chunk {chunk_num}: {chunk.hex()}")
                chunk_num += 1
    finally:
        os.unlink(temp_file)


def demonstrate_line_counting() -> None:
    """Count lines without loading entire file."""
    print("\n" + "=" * 80)
    print("SECTION 7: LINE COUNTING")
    print("=" * 80)

    def count_lines(filename: str) -> int:
        """Count lines efficiently."""
        with open(filename, 'rb') as f:
            return sum(chunk.count(b'\n') for chunk in iter(lambda: f.read(1024*1024), b''))

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        for i in range(10000):
            f.write(f"Line {i}\n")

    try:
        line_count = count_lines(temp_file)
        print(f"File contains {line_count} lines")
        print("Counted without loading entire file into memory")
    finally:
        os.unlink(temp_file)


def demonstrate_grep_pattern() -> None:
    """Search through large files efficiently."""
    print("\n" + "=" * 80)
    print("SECTION 8: GREP-LIKE SEARCHING")
    print("=" * 80)

    def grep(filename: str, pattern: str) -> Generator[tuple[int, str], None, None]:
        """Find lines matching pattern."""
        with open(filename, 'r') as f:
            for line_num, line in enumerate(f, 1):
                if pattern.lower() in line.lower():
                    yield line_num, line.rstrip()

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        for i in range(100):
            f.write(f"Line {i}: ERROR data\n" if i % 10 == 0 else f"Line {i}: normal\n")

    try:
        print('Searching for "ERROR":')
        for line_num, line in grep(temp_file, "ERROR"):
            if line_num <= 30:
                print(f"  {line_num}: {line}")
    finally:
        os.unlink(temp_file)


def demonstrate_memory_mapping() -> None:
    """Memory-mapped file processing."""
    print("\n" + "=" * 80)
    print("SECTION 9: MEMORY-MAPPED FILES")
    print("=" * 80)

    import mmap

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        for i in range(1000):
            f.write(f"Line {i}\n")

    try:
        print("Memory-mapped file access:")
        with open(temp_file, 'r+b') as f:
            with mmap.mmap(f.fileno(), 0) as mmapped:
                print(f"  File size: {len(mmapped)} bytes")
                print(f"  First 50 chars: {mmapped[:50]}")
                print("  (File acts like string, but uses OS virtual memory)")
    finally:
        os.unlink(temp_file)


def demonstrate_streaming_json_processing() -> None:
    """Stream JSON lines (JSONL) processing."""
    print("\n" + "=" * 80)
    print("SECTION 10: STREAMING JSON PROCESSING")
    print("=" * 80)

    import json

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.jsonl') as f:
        temp_file = f.name
        for i in range(10):
            record = {'id': i, 'name': f'user_{i}', 'score': 100 + i}
            f.write(json.dumps(record) + '\n')

    try:
        def process_jsonl(filename: str):
            """Process JSONL line-by-line."""
            with open(filename, 'r') as f:
                for line_num, line in enumerate(f, 1):
                    try:
                        record = json.loads(line)
                        yield record
                    except json.JSONDecodeError:
                        print(f"  Skipped invalid JSON at line {line_num}")

        print("Processing JSONL:")
        for record in process_jsonl(temp_file):
            print(f"  {record}")
    finally:
        os.unlink(temp_file)


def demonstrate_performance_patterns() -> None:
    """Performance patterns for file processing."""
    print("\n" + "=" * 80)
    print("SECTION 11: PERFORMANCE PATTERNS")
    print("=" * 80)

    print("Pattern 1: Buffered reading (for text processing)")
    print("  Read in chunks (e.g., 8KB)")
    print("  Process per line")
    print("  Memory: O(1) regardless of file size")

    print("\nPattern 2: Line buffering")
    print("  Suitable for line-oriented data (logs, CSV)")
    print("  Process per line, minimal state")

    print("\nPattern 3: Block processing")
    print("  Suitable for fixed-width records (binary)")
    print("  Process N bytes at a time")

    print("\nPattern 4: Windowing")
    print("  Process overlapping regions")
    print("  Example: Moving average over data")


def best_practices() -> None:
    """Best practices."""
    print("\n" + "=" * 80)
    print("SECTION 12: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Never load entire file into memory",
        "2. Use generators for file processing",
        "3. Process line-by-line when possible",
        "4. Handle encoding errors gracefully",
        "5. Use context managers (with statement)",
        "6. Consider chunked reading for binary data",
        "7. Close files explicitly (or use context manager)",
        "8. Use mmap for random access to large files",
        "9. Profile I/O performance",
        "10. Use appropriate buffer sizes (typically 4-8KB chunks)",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("FILE STREAM PROCESSING - HANDLING LARGE FILES")
    print("=" * 80)

    demonstrate_eager_vs_lazy_file_processing()
    demonstrate_line_by_line_processing()
    demonstrate_chunked_reading()
    demonstrate_filtering_pipeline()
    demonstrate_encoding_handling()
    demonstrate_binary_processing()
    demonstrate_line_counting()
    demonstrate_grep_pattern()
    demonstrate_memory_mapping()
    demonstrate_streaming_json_processing()
    demonstrate_performance_patterns()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
Streaming File Processing Benefits:
    - Constant memory usage (O(1)) regardless of file size
    - Process multi-GB files on modest hardware
    - Can start processing before file is complete
    - Enables real-time processing
    - Better latency (first results available immediately)

Reading Strategies:
    - Line-by-line: for text files, logs, CSV
    - Chunk-based: for binary data, streaming
    - Memory-mapped: for random access to large files
    - Block-wise: for fixed-size records

Common Patterns:
    1. Filter: Select matching lines
    2. Transform: Modify each line
    3. Aggregate: Accumulate results
    4. Window: Process overlapping regions
    5. Combine: Merge multiple files
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Memory: O(1) for streaming vs O(n) for eager loading
# Processing starts faster with streaming
# Throughput similar, but latency much better
# Encoding handling minimal overhead

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Loading entire file with readlines()
# 2. Not using context managers
# 3. Ignoring encoding issues
# 4. Not handling incomplete lines
# 5. Assuming all records are complete

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Process 100GB log file, find error patterns
# Q2: Design streaming CSV processor
# Q3: Implement line-by-line grep search
# Q4: Handle multi-byte encoding in streaming mode
# Q5: Design windowing operation for streaming data

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build streaming log analyzer
# Requirements:
#   - Process large log files
#   - Extract metrics per line
#   - Aggregate statistics
#   - Output summary report
# Implementation: Use generators and streaming
