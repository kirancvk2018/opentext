"""
Module: 09_exception_handling_best_practices.py
Topic: Exception Handling - Production-Grade Patterns
Problem Statement: Poor exception handling causes silent failures, data corruption, and hard-to-debug issues.
    Production code requires structured error handling, proper logging, and graceful degradation.
Enterprise Scenario: A payment system swallows exceptions in a silent try/except.
    Transactions fail silently, customers don't get refunds, and nobody knows about it.
    Proper exception handling with logging prevents disasters.
Learning Objectives:
    - Implement robust exception handling
    - Design custom exception hierarchies
    - Use exception context and chaining
    - Handle errors without hiding them
Prerequisites:
    - Basic exception handling knowledge
    - Understanding of try/except/finally
Expected Output:
    - Production exception patterns
    - Error tracking strategies
    - Logging best practices
Concepts Covered:
    - Exception hierarchy design
    - Exception context and chaining
    - Custom exceptions
    - Structured error logging
    - Error recovery patterns
"""

import sys
import logging
from typing import Optional, Callable, Any, Type
from functools import wraps
import traceback

logging.basicConfig(level=logging.INFO, format='%(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def demonstrate_basic_exception_handling() -> None:
    """Basic exception handling patterns."""
    print("\n" + "=" * 80)
    print("SECTION 1: BASIC EXCEPTION HANDLING")
    print("=" * 80)

    print("ANTI-PATTERN: Bare except (NEVER DO THIS)")
    print("""
    try:
        dangerous_operation()
    except:  # Catches EVERYTHING, hides bugs!
        pass
    """)

    print("BETTER: Catch specific exceptions")

    def safe_int_conversion(value: str) -> int:
        """Convert string to int with proper error handling."""
        try:
            return int(value)
        except ValueError as e:
            logger.error(f"Invalid integer: {value}")
            raise
        except TypeError as e:
            logger.error(f"Type error: {value} is not a string")
            raise

    try:
        safe_int_conversion("42")
        logger.info("Conversion succeeded")
    except ValueError:
        logger.info("Caught ValueError as expected")


def demonstrate_exception_hierarchy() -> None:
    """Design custom exception hierarchies."""
    print("\n" + "=" * 80)
    print("SECTION 2: CUSTOM EXCEPTION HIERARCHY")
    print("=" * 80)

    class ApplicationError(Exception):
        """Base exception for application."""
        pass

    class ValidationError(ApplicationError):
        """Data validation failed."""
        pass

    class DatabaseError(ApplicationError):
        """Database operation failed."""
        pass

    class ConnectionError(DatabaseError):
        """Network connection failed."""
        pass

    print("Exception hierarchy:")
    print("  ApplicationError")
    print("    ├── ValidationError")
    print("    └── DatabaseError")
    print("        └── ConnectionError")

    try:
        raise ValidationError("Email format invalid")
    except ValidationError as e:
        logger.error(f"Caught specific error: {e}")

    print("\nCatching by parent class:")
    try:
        raise ConnectionError("Lost database connection")
    except DatabaseError as e:
        logger.error(f"Caught as DatabaseError: {e}")


def demonstrate_exception_context() -> None:
    """Exception context and chaining."""
    print("\n" + "=" * 80)
    print("SECTION 3: EXCEPTION CONTEXT AND CHAINING")
    print("=" * 80)

    logger.info("Exception chaining (implicit):")

    try:
        try:
            int("invalid")
        except ValueError as e:
            raise RuntimeError("Conversion failed") from e
    except RuntimeError as e:
        logger.error(f"Caught: {e}")
        logger.error(f"Caused by: {e.__cause__}")

    logger.info("\nException context (implicit via raise):")

    try:
        try:
            int("invalid")
        except ValueError as e:
            logger.error(f"ValueError: {e}")
            raise RuntimeError("Processing failed")
    except RuntimeError as e:
        logger.error(f"RuntimeError raised, __context__: {e.__context__}")


def demonstrate_exception_with_context_manager() -> None:
    """Exceptions with context managers."""
    print("\n" + "=" * 80)
    print("SECTION 4: EXCEPTIONS WITH CONTEXT MANAGERS")
    print("=" * 80)

    class SafeResource:
        """Resource that safely handles exceptions."""

        def __enter__(self):
            logger.info("  Acquiring resource")
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type:
                logger.error(f"  Exception in context: {exc_type.__name__}")
            logger.info("  Releasing resource")
            return False

    logger.info("Normal exit:")
    with SafeResource() as res:
        logger.info("    Using resource")

    logger.info("\nWith exception:")
    try:
        with SafeResource() as res:
            logger.info("    Using resource")
            raise ValueError("Error during use")
    except ValueError:
        logger.info("    Exception was propagated")


def demonstrate_exception_logging() -> None:
    """Proper exception logging."""
    print("\n" + "=" * 80)
    print("SECTION 5: EXCEPTION LOGGING")
    print("=" * 80)

    logger.info("ANTI-PATTERN: Swallowing exceptions silently")
    print("""
    try:
        operation()
    except:
        pass  # BUG: Error is hidden!
    """)

    logger.info("\nBETTER: Log exceptions with context")

    try:
        1 / 0
    except ZeroDivisionError:
        logger.exception("Division by zero occurred")

    logger.info("\nUsing exc_info for manual logging:")

    try:
        int("invalid")
    except ValueError:
        logger.error("Conversion failed", exc_info=True)


def demonstrate_retry_pattern() -> None:
    """Retry pattern for transient failures."""
    print("\n" + "=" * 80)
    print("SECTION 6: RETRY PATTERN")
    print("=" * 80)

    def retry(max_attempts: int = 3, delay: float = 0.1):
        """Decorator to retry failed operations."""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                last_exception = None
                for attempt in range(1, max_attempts + 1):
                    try:
                        return func(*args, **kwargs)
                    except Exception as e:
                        last_exception = e
                        if attempt < max_attempts:
                            logger.warning(f"Attempt {attempt} failed: {e}, retrying...")
                            import time
                            time.sleep(delay)
                        else:
                            logger.error(f"All {max_attempts} attempts failed")
                raise last_exception
            return wrapper
        return decorator

    attempt_count = {"count": 0}

    @retry(max_attempts=3, delay=0.01)
    def flaky_operation():
        """Operation that fails first 2 times."""
        attempt_count["count"] += 1
        if attempt_count["count"] < 3:
            raise ConnectionError("Network timeout")
        return "Success!"

    result = flaky_operation()
    logger.info(f"Result: {result}")


def demonstrate_fallback_pattern() -> None:
    """Fallback/default pattern."""
    print("\n" + "=" * 80)
    print("SECTION 7: FALLBACK PATTERN")
    print("=" * 80)

    def get_user_preference(user_id: int, preference: str, default: Any = None) -> Any:
        """Get preference with fallback to default."""
        try:
            # Simulate database call
            if user_id < 0:
                raise ValueError("Invalid user ID")
            return {"theme": "dark", "lang": "en"}.get(preference)
        except (ValueError, KeyError) as e:
            logger.warning(f"Failed to get preference: {e}, using default")
            return default

    result = get_user_preference(1, "theme", default="light")
    logger.info(f"Theme: {result}")

    result = get_user_preference(-1, "theme", default="light")
    logger.info(f"Theme (with fallback): {result}")


def demonstrate_resource_cleanup() -> None:
    """Resource cleanup in exception scenarios."""
    print("\n" + "=" * 80)
    print("SECTION 8: RESOURCE CLEANUP")
    print("=" * 80)

    import tempfile
    import os

    def process_file_unsafe(filename: str):
        """ANTI-PATTERN: May leak file handle."""
        f = open(filename, 'r')
        content = f.read()
        f.close()
        return content

    def process_file_safe(filename: str):
        """BETTER: Guarantees cleanup."""
        try:
            with open(filename, 'r') as f:
                return f.read()
        except FileNotFoundError:
            logger.error(f"File not found: {filename}")
            return ""

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        temp_file = f.name
        f.write("Content")

    try:
        result = process_file_safe(temp_file)
        logger.info(f"Read: {result}")
    finally:
        os.unlink(temp_file)


def demonstrate_custom_exception() -> None:
    """Design useful custom exceptions."""
    print("\n" + "=" * 80)
    print("SECTION 9: CUSTOM EXCEPTIONS")
    print("=" * 80)

    class ConfigurationError(Exception):
        """Configuration is invalid."""

        def __init__(self, key: str, reason: str):
            self.key = key
            self.reason = reason
            super().__init__(f"Config key '{key}': {reason}")

    def load_config(config_dict: dict, required_key: str):
        """Load config with validation."""
        if required_key not in config_dict:
            raise ConfigurationError(
                required_key,
                "required but missing"
            )
        return config_dict[required_key]

    try:
        config = {"database": "localhost"}
        load_config(config, "api_key")
    except ConfigurationError as e:
        logger.error(f"Configuration error: {e.key} - {e.reason}")


def demonstrate_error_recovery() -> None:
    """Error recovery strategies."""
    print("\n" + "=" * 80)
    print("SECTION 10: ERROR RECOVERY")
    print("=" * 80)

    class DataProcessor:
        """Process data with error recovery."""

        def __init__(self):
            self.processed = 0
            self.errors = 0

        def process_batch(self, items: list):
            """Process items, recovering from individual errors."""
            for i, item in enumerate(items):
                try:
                    result = self.process_item(item)
                    self.processed += 1
                except Exception as e:
                    self.errors += 1
                    logger.error(f"Failed to process item {i}: {e}")
                    continue

            logger.info(f"Processed: {self.processed}, Errors: {self.errors}")

        def process_item(self, item: str) -> str:
            """Process single item."""
            if item < "0":
                raise ValueError(f"Invalid item: {item}")
            return item.upper()

    processor = DataProcessor()
    items = ["a", "b", "error", "c"]

    try:
        processor.process_batch(items)
    except Exception as e:
        logger.error(f"Batch processing failed: {e}")


def demonstrate_structured_error_info() -> None:
    """Structured error information."""
    print("\n" + "=" * 80)
    print("SECTION 11: STRUCTURED ERROR INFORMATION")
    print("=" * 80)

    class ErrorContext:
        """Structured error information."""

        def __init__(self, operation: str, resource: str, attempt: int = 1):
            self.operation = operation
            self.resource = resource
            self.attempt = attempt

        def log_error(self, exception: Exception):
            """Log error with context."""
            logger.error(
                f"Operation: {self.operation}, "
                f"Resource: {self.resource}, "
                f"Attempt: {self.attempt}, "
                f"Error: {exception}"
            )

    context = ErrorContext("database_query", "users_table", attempt=1)

    try:
        raise ConnectionError("Connection timeout")
    except ConnectionError as e:
        context.log_error(e)


def best_practices() -> None:
    """Best practices."""
    print("\n" + "=" * 80)
    print("SECTION 12: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Never use bare except clause",
        "2. Catch specific exceptions, not generic Exception",
        "3. Always log exceptions with context",
        "4. Use exception chaining (from e) to preserve stack traces",
        "5. Clean up resources in finally or use context managers",
        "6. Design custom exception hierarchies",
        "7. Implement retry logic for transient failures",
        "8. Provide sensible defaults/fallbacks",
        "9. Return structured error information",
        "10. Test error paths thoroughly",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("EXCEPTION HANDLING - PRODUCTION PATTERNS")
    print("=" * 80)

    demonstrate_basic_exception_handling()
    demonstrate_exception_hierarchy()
    demonstrate_exception_context()
    demonstrate_exception_with_context_manager()
    demonstrate_exception_logging()
    demonstrate_retry_pattern()
    demonstrate_fallback_pattern()
    demonstrate_resource_cleanup()
    demonstrate_custom_exception()
    demonstrate_error_recovery()
    demonstrate_structured_error_info()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY - EXCEPTION HANDLING PATTERNS")
    print("=" * 80)
    print("""
Core Principles:
    1. Be specific about what exceptions you catch
    2. Always log exceptions with full context
    3. Clean up resources (use context managers)
    4. Preserve exception chains for debugging
    5. Implement recovery strategies

Common Patterns:
    - Retry with exponential backoff (transient failures)
    - Fallback/default values (graceful degradation)
    - Circuit breaker (prevent cascading failures)
    - Error recovery per-item (batch processing)
    - Structured error logging (observability)

Exception Design:
    - Inherit from standard exceptions
    - Provide meaningful error messages
    - Include relevant context
    - Use exception hierarchy for granular handling

Production Checklist:
    ✓ All exceptions are logged
    ✓ No silent failures (no bare except)
    ✓ Resources are cleaned up
    ✓ Exceptions are handled at appropriate level
    ✓ Retry logic for transient failures
    ✓ Fallback strategies for non-critical operations
    ✓ Error information is structured
    ✓ Stack traces are preserved
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Exception handling has minimal overhead in non-error case
# Creating exceptions is faster than string concatenation in catch blocks
# Logging exceptions has more overhead (use logging.exception() for best performance)
# Retry loops add latency but prevent cascading failures

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Bare except clause (catches everything, including bugs)
# 2. Catching Exception instead of specific types
# 3. Swallowing exceptions silently
# 4. Not logging exception context
# 5. Not cleaning up resources
# 6. Losing exception chain information

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Design exception hierarchy for e-commerce system
# Q2: Implement retry logic with exponential backoff
# Q3: Design circuit breaker pattern using exceptions
# Q4: How would you handle cascading failures?
# Q5: Design structured error logging for microservices
# Q6: Implement error recovery for batch processing
# Q7: How do you preserve stack traces in exception chains?

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build production-grade error handling system
# Requirements:
#   - Custom exception hierarchy
#   - Structured error logging
#   - Retry with exponential backoff
#   - Circuit breaker pattern
#   - Error recovery for batch operations
#   - Fallback strategies
# Implementation: Combine multiple patterns
