"""
Module: 02_lazy_evaluation.py
Topic: Lazy Evaluation and On-Demand Computation
Problem Statement: Applications waste resources computing values that are never used.
    A data pipeline calculates features for millions of records but only accesses a small fraction.
    Lazy evaluation defers computation until actually needed, reducing memory and CPU overhead.
Enterprise Scenario: Financial analytics platform processes daily market data.
    Processing all data upfront takes 2 hours; lazy evaluation reduces it to 30 seconds for typical queries.
Learning Objectives:
    - Understand lazy evaluation principles
    - Implement generators for deferred computation
    - Build lazy evaluation chains
    - Optimize performance with on-demand processing
Prerequisites:
    - Basic generator knowledge
    - Understanding of iterables
Expected Output:
    - Performance comparisons between eager and lazy evaluation
    - Lazy evaluation chains
    - Resource usage visualization
Concepts Covered:
    - Lazy vs eager evaluation
    - Generator functions
    - Lazy chains and pipelines
    - Short-circuit evaluation
    - Performance implications
"""

import sys
import time
from typing import Iterator, List, Any, Generator
from functools import wraps


def measure_time(func):
    """Decorator to measure execution time."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        print(f"  ⏱️ {func.__name__} took {elapsed*1000:.2f}ms")
        return result
    return wrapper


def demonstrate_eager_evaluation() -> None:
    """Eager evaluation computes all values immediately."""
    print("\n" + "=" * 80)
    print("SECTION 1: EAGER EVALUATION")
    print("=" * 80)

    @measure_time
    def eager_squares(n: int) -> List[int]:
        """Eagerly compute all squares immediately."""
        result = []
        for i in range(n):
            result.append(i ** 2)
        return result

    squares = eager_squares(1_000_000)
    print(f"Computed {len(squares)} squares eagerly")
    print(f"Memory used: {sys.getsizeof(squares) / 1024:.2f} KB")
    print("All values computed upfront, even if only first 10 are used.")


def demonstrate_lazy_evaluation() -> None:
    """Lazy evaluation defers computation until needed."""
    print("\n" + "=" * 80)
    print("SECTION 2: LAZY EVALUATION")
    print("=" * 80)

    @measure_time
    def lazy_squares(n: int) -> Generator[int, None, None]:
        """Lazily compute squares on-demand."""
        for i in range(n):
            yield i ** 2

    @measure_time
    def get_first_ten():
        """Only consume first 10 values."""
        gen = lazy_squares(1_000_000)
        return list(next(gen) for _ in range(10))

    result = get_first_ten()
    print(f"Consumed only 10 squares: {result}")
    print("Generator creation is instant; computation happens only on access.")


def demonstrate_lazy_chain() -> None:
    """Build computation chains with lazy evaluation."""
    print("\n" + "=" * 80)
    print("SECTION 3: LAZY COMPUTATION CHAINS")
    print("=" * 80)

    def numbers(n: int) -> Generator[int, None, None]:
        """Generate numbers 0 to n-1."""
        print(f"  [Generator] Creating {n} numbers")
        for i in range(n):
            yield i

    def squares(nums: Iterator[int]) -> Generator[int, None, None]:
        """Square each number."""
        for num in nums:
            print(f"    [Square] Computing {num}^2")
            yield num ** 2

    def evens(nums: Iterator[int]) -> Generator[int, None, None]:
        """Filter to even numbers."""
        for num in nums:
            if num % 2 == 0:
                print(f"      [Filter] {num} is even")
                yield num

    print("\nBuilding lazy chain: numbers -> squares -> evens")
    chain = evens(squares(numbers(100)))

    print("\nConsuming first 5 results:")
    results = []
    for i, val in enumerate(chain):
        results.append(val)
        if i >= 4:
            break

    print(f"Results: {results}")
    print("Only computed what was needed to get 5 results.")


def compare_eager_vs_lazy_performance() -> None:
    """Performance comparison between eager and lazy evaluation."""
    print("\n" + "=" * 80)
    print("SECTION 4: PERFORMANCE COMPARISON")
    print("=" * 80)

    n = 10_000_000

    @measure_time
    def eager_pipeline(n: int) -> List[int]:
        """Eager: compute all steps for all data."""
        numbers = list(range(n))
        squared = [x ** 2 for x in numbers]
        evens = [x for x in squared if x % 2 == 0]
        return evens[:10]

    @measure_time
    def lazy_pipeline(n: int) -> List[int]:
        """Lazy: compute only what's needed."""
        def nums():
            for i in range(n):
                yield i

        def sq(nums):
            for x in nums:
                yield x ** 2

        def even(nums):
            for x in nums:
                if x % 2 == 0:
                    yield x

        result = even(sq(nums()))
        return [next(result) for _ in range(10)]

    print(f"Processing {n:,} items:")
    eager_result = eager_pipeline(n)
    lazy_result = lazy_pipeline(n)
    print(f"Eager result: {eager_result[:5]}...")
    print(f"Lazy result: {lazy_result}")


def demonstrate_short_circuit_evaluation() -> None:
    """Short-circuit: stop evaluation when condition is met."""
    print("\n" + "=" * 80)
    print("SECTION 5: SHORT-CIRCUIT EVALUATION")
    print("=" * 80)

    def find_value_eager(target: int, n: int = 10_000_000) -> int:
        """Eager search: check all values."""
        start = time.perf_counter()
        for i in range(n):
            if i == target:
                elapsed = time.perf_counter() - start
                print(f"  Found {target} in {elapsed*1000:.2f}ms (checked {i+1} items)")
                return i
        elapsed = time.perf_counter() - start
        print(f"  Not found in {elapsed*1000:.2f}ms (checked all {n:,} items)")

    def find_value_lazy(target: int, n: int = 10_000_000) -> int:
        """Lazy search: stop when found."""
        def nums():
            for i in range(n):
                yield i

        start = time.perf_counter()
        for val in nums():
            if val == target:
                elapsed = time.perf_counter() - start
                print(f"  Found {target} in {elapsed*1000:.2f}ms (checked {val+1} items)")
                return val
        elapsed = time.perf_counter() - start
        print(f"  Not found in {elapsed*1000:.2f}ms")

    print("Finding value at position 100 out of 10 million:")
    print("Eager approach:")
    find_value_eager(100)
    print("\nLazy approach:")
    find_value_lazy(100)


def demonstrate_generator_expressions() -> None:
    """Generator expressions: compact lazy syntax."""
    print("\n" + "=" * 80)
    print("SECTION 6: GENERATOR EXPRESSIONS")
    print("=" * 80)

    print("\nList comprehension (eager - creates list):")
    squares_list = [x ** 2 for x in range(10)]
    print(f"  Type: {type(squares_list)}")
    print(f"  Result: {squares_list}")

    print("\nGenerator expression (lazy - creates generator):")
    squares_gen = (x ** 2 for x in range(10))
    print(f"  Type: {type(squares_gen)}")
    print(f"  First 5: {[next(squares_gen) for _ in range(5)]}")

    print("\nMemory comparison for 1M items:")
    list_comp = [x for x in range(1_000_000)]
    print(f"  List comprehension: {sys.getsizeof(list_comp) / (1024*1024):.2f} MB")

    gen_exp = (x for x in range(1_000_000))
    print(f"  Generator expression: {sys.getsizeof(gen_exp) / 1024:.2f} KB")


def demonstrate_lazy_file_processing() -> None:
    """Lazy evaluation for file processing."""
    print("\n" + "=" * 80)
    print("SECTION 7: LAZY FILE PROCESSING")
    print("=" * 80)

    def read_large_file_eager(filename: str) -> List[str]:
        """Eager: load entire file into memory."""
        with open(filename, 'r') as f:
            return f.readlines()

    def read_large_file_lazy(filename: str) -> Generator[str, None, None]:
        """Lazy: yield lines one at a time."""
        with open(filename, 'r') as f:
            for line in f:
                yield line.rstrip('\n')

    def process_lines_eager(lines: List[str]) -> List[str]:
        """Process all lines eagerly."""
        return [line.upper() for line in lines if len(line) > 5]

    def process_lines_lazy(lines: Iterator[str]) -> Generator[str, None, None]:
        """Process lines lazily."""
        for line in lines:
            if len(line) > 5:
                yield line.upper()

    print("File processing patterns:")
    print("  Eager: read_large_file_eager() -> process all -> store all")
    print("  Lazy: read_large_file_lazy() -> process line-by-line -> yield results")
    print("\nLazy evaluation allows processing files larger than available RAM.")


def demonstrate_lazy_with_state() -> None:
    """Lazy evaluation with stateful generators."""
    print("\n" + "=" * 80)
    print("SECTION 8: LAZY EVALUATION WITH STATE")
    print("=" * 80)

    def cumulative_sum(numbers: Iterator[int]) -> Generator[int, None, None]:
        """Yield cumulative sum lazily."""
        total = 0
        for num in numbers:
            total += num
            yield total

    numbers = range(1, 11)
    result = list(cumulative_sum(numbers))
    print(f"Cumulative sum of 1-10: {result}")

    def running_average(numbers: Iterator[float]) -> Generator[float, None, None]:
        """Yield running average lazily."""
        total = 0
        count = 0
        for num in numbers:
            total += num
            count += 1
            yield total / count

    data = [10, 20, 30, 40, 50]
    result = list(running_average(data))
    print(f"Running average: {[f'{x:.1f}' for x in result]}")


def demonstrate_lazy_filtering() -> None:
    """Lazy filtering patterns."""
    print("\n" + "=" * 80)
    print("SECTION 9: LAZY FILTERING")
    print("=" * 80)

    def lazy_filter_primes() -> Generator[int, None, None]:
        """Generate prime numbers lazily (naive algorithm)."""
        def is_prime(n: int) -> bool:
            if n < 2:
                return False
            for i in range(2, int(n ** 0.5) + 1):
                if n % i == 0:
                    return False
            return True

        n = 2
        while True:
            if is_prime(n):
                yield n
            n += 1

    print("Generating first 10 primes lazily:")
    primes = lazy_filter_primes()
    result = [next(primes) for _ in range(10)]
    print(f"Primes: {result}")


def demonstrate_lazy_transformation() -> None:
    """Lazy transformation pipelines."""
    print("\n" + "=" * 80)
    print("SECTION 10: LAZY TRANSFORMATION PIPELINES")
    print("=" * 80)

    class LazyPipeline:
        """Lazy transformation pipeline."""

        def __init__(self, iterable):
            self.iterable = iter(iterable)

        def map(self, func):
            """Apply function lazily."""
            self.iterable = (func(x) for x in self.iterable)
            return self

        def filter(self, predicate):
            """Filter lazily."""
            self.iterable = (x for x in self.iterable if predicate(x))
            return self

        def take(self, n):
            """Take first n items."""
            for i, item in enumerate(self.iterable):
                if i >= n:
                    break
                yield item

    result = list(
        LazyPipeline(range(100))
        .map(lambda x: x ** 2)
        .filter(lambda x: x % 2 == 0)
        .take(5)
    )
    print(f"Pipeline result: {result}")


def lazy_best_practices() -> None:
    """Display best practices for lazy evaluation."""
    print("\n" + "=" * 80)
    print("SECTION 11: LAZY EVALUATION BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Use generators for infinite sequences (primes, Fibonacci, etc.)",
        "2. Use lazy evaluation for large datasets",
        "3. Combine generators in pipelines for composable code",
        "4. Use generator expressions instead of list comprehensions when possible",
        "5. Remember generators are consumed once (can't iterate twice)",
        "6. Use itertools for common lazy operations",
        "7. Document when code performs lazy vs eager evaluation",
        "8. Measure performance before and after lazy optimization",
        "9. Be careful with generator scope and variable capture",
        "10. Use try/except to handle StopIteration gracefully",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("LAZY EVALUATION - COMPLETE GUIDE")
    print("=" * 80)

    demonstrate_eager_evaluation()
    demonstrate_lazy_evaluation()
    demonstrate_lazy_chain()
    compare_eager_vs_lazy_performance()
    demonstrate_short_circuit_evaluation()
    demonstrate_generator_expressions()
    demonstrate_lazy_file_processing()
    demonstrate_lazy_with_state()
    demonstrate_lazy_filtering()
    demonstrate_lazy_transformation()
    lazy_best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
Key Takeaways:
    1. Lazy evaluation defers computation until values are needed
    2. Generators enable lazy evaluation with minimal memory overhead
    3. Lazy chains are composable and reusable
    4. Short-circuit evaluation stops when condition is met
    5. Generator expressions are more memory-efficient than list comprehensions
    6. Lazy evaluation enables processing of infinite sequences
    7. Perfect for large datasets and I/O-bound operations
    8. Trade-off: slight CPU overhead for massive memory savings

When to Use Lazy Evaluation:
    - Processing large files or datasets
    - Working with infinite sequences
    - Need only a subset of computed values
    - Building transformation pipelines
    - Memory-constrained environments

When to Use Eager Evaluation:
    - Need to iterate multiple times over same data
    - Working with small datasets (fit in memory)
    - Performance-critical tight loops
    - Easier debugging and testing
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Lazy evaluation: O(1) space for infinite sequences vs O(n) for eager lists
# Generator expressions: 1000x+ memory savings vs list comprehensions
# Short-circuit: Find in O(1) when value is early vs O(n) for full scan
# Pipeline composition: Readable, composable, and memory-efficient
# Trade-off: Slight CPU overhead from generator protocol vs massive memory savings

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Trying to iterate a generator twice (consumed after first iteration)
# 2. Storing generator expressions in variables expecting list operations
# 3. Not understanding when evaluation actually occurs
# 4. Mixing eager and lazy operations causing unexpected behavior
# 5. Creating large intermediate lists in generators
# 6. Forgetting that generators are stateful

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Explain the difference between lazy and eager evaluation
# Q2: What is a generator expression and how does it differ from a list comprehension?
# Q3: Why is lazy evaluation important for big data processing?
# Q4: How does short-circuit evaluation improve performance?
# Q5: Can you iterate a generator twice? Why or why not?
# Q6: Design a lazy pipeline that processes log files
# Q7: What's the memory overhead of a generator vs a list?
# Q8: How would you implement infinite sequence generation?

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build a lazy Fibonacci sequence generator
# Requirements:
#   - Generate unlimited Fibonacci numbers
#   - Track computation count
#   - Implement early-exit for values > 10^6
#   - Display memory usage
# Hint: Use yield and maintain internal state
