"""
Module: 10_logging_framework.py
Topic: Logging Framework - Structured Production Logging
Problem Statement: Debug prints and print statements pollute code and don't work in production.
    Proper logging enables observability, debugging, and monitoring in deployed systems.
Enterprise Scenario: A service has intermittent failures but nobody can debug them.
    Structured logging with correlation IDs and context enables root cause analysis.
Learning Objectives:
    - Design logging strategy for production
    - Use Python logging module effectively
    - Implement structured logging
    - Integrate logging with monitoring
Prerequisites:
    - Basic Python logging knowledge
    - Understanding of log levels
Expected Output:
    - Production logging configurations
    - Structured log examples
    - Best practices and patterns
Concepts Covered:
    - Logging levels and handlers
    - Formatters and filters
    - Contextual logging
    - Performance considerations
    - Integration with monitoring
"""

import logging
import logging.handlers
import sys
import io
from typing import Optional, Any, Dict
import json
import time
from functools import wraps
from contextlib import contextmanager
import tempfile
import os


def demonstrate_logging_levels() -> None:
    """Demonstrate logging levels."""
    print("\n" + "=" * 80)
    print("SECTION 1: LOGGING LEVELS")
    print("=" * 80)

    logger = logging.getLogger("demo")
    logger.setLevel(logging.DEBUG)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('%(levelname)-8s %(message)s'))
    logger.addHandler(handler)

    logger.debug("Debug message - detailed diagnostic info")
    logger.info("Info message - general operational info")
    logger.warning("Warning message - something unexpected happened")
    logger.error("Error message - something failed")
    logger.critical("Critical message - system in critical state")

    print("\nLogging levels hierarchy:")
    print("  DEBUG (10) - Most verbose")
    print("  INFO (20)")
    print("  WARNING (30) - Default level")
    print("  ERROR (40)")
    print("  CRITICAL (50) - Most severe")


def demonstrate_basic_configuration() -> None:
    """Basic logging configuration."""
    print("\n" + "=" * 80)
    print("SECTION 2: BASIC CONFIGURATION")
    print("=" * 80)

    logger = logging.getLogger("app")

    print("Method 1: basicConfig (simple applications)")
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    logger.info("Application started")
    logger.info("This uses basicConfig")


def demonstrate_handlers_formatters() -> None:
    """Handlers and formatters."""
    print("\n" + "=" * 80)
    print("SECTION 3: HANDLERS AND FORMATTERS")
    print("=" * 80)

    logger = logging.getLogger("multi_handler")
    logger.setLevel(logging.DEBUG)

    print("Console handler (INFO and above):")
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter('%(levelname)-8s | %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    print("\nFile handler (DEBUG and above):")
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.log') as f:
        log_file = f.name

    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter('%(asctime)s | %(levelname)-8s | %(funcName)s | %(message)s')
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    logger.debug("Debug message (file only)")
    logger.info("Info message (console + file)")
    logger.error("Error message (console + file)")

    print(f"\nLog file contents ({log_file}):")
    with open(log_file, 'r') as f:
        for line in f:
            print(f"  {line.rstrip()}")

    os.unlink(log_file)


def demonstrate_structured_logging() -> None:
    """Structured logging with JSON output."""
    print("\n" + "=" * 80)
    print("SECTION 4: STRUCTURED LOGGING")
    print("=" * 80)

    class JsonFormatter(logging.Formatter):
        """Format logs as JSON for machine parsing."""

        def format(self, record: logging.LogRecord) -> str:
            log_data = {
                'timestamp': self.formatTime(record, '%Y-%m-%dT%H:%M:%S'),
                'level': record.levelname,
                'logger': record.name,
                'message': record.getMessage(),
                'module': record.module,
                'function': record.funcName,
                'line': record.lineno,
            }
            if record.exc_info:
                log_data['exception'] = self.formatException(record.exc_info)
            return json.dumps(log_data)

    logger = logging.getLogger("json_logs")
    logger.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    logger.addHandler(handler)

    logger.info("Application started")
    logger.warning("Configuration missing, using defaults")

    try:
        1 / 0
    except ZeroDivisionError:
        logger.error("Division by zero", exc_info=True)


def demonstrate_contextual_logging() -> None:
    """Add context to logs."""
    print("\n" + "=" * 80)
    print("SECTION 5: CONTEXTUAL LOGGING")
    print("=" * 80)

    logger = logging.getLogger("context")
    logger.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s [%(request_id)s] %(message)s',
                                 defaults={'request_id': 'N/A'})
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    print("Adding context via LoggerAdapter:")

    class RequestContext:
        """Inject request context into logs."""

        def __init__(self, request_id: str):
            self.request_id = request_id

        def log_with_context(self, msg: str, level=logging.INFO):
            adapter = logging.LoggerAdapter(
                logger,
                {'request_id': self.request_id}
            )
            adapter.log(level, msg)

    context = RequestContext("req-12345")
    context.log_with_context("Processing request")
    context.log_with_context("Request completed")


def demonstrate_rotating_file_handler() -> None:
    """Rotating file handler for log management."""
    print("\n" + "=" * 80)
    print("SECTION 6: ROTATING FILE HANDLER")
    print("=" * 80)

    logger = logging.getLogger("rotating")
    logger.setLevel(logging.DEBUG)

    with tempfile.TemporaryDirectory() as tmpdir:
        log_file = os.path.join(tmpdir, "app.log")

        print("RotatingFileHandler: Rotate by size")
        handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=1024,
            backupCount=3
        )
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

        for i in range(10):
            logger.info(f"Message {i}: " + "x" * 100)

        print(f"Created logs in {tmpdir}:")
        for file in os.listdir(tmpdir):
            print(f"  {file}")


def demonstrate_timing_decorator() -> None:
    """Decorator to log execution time."""
    print("\n" + "=" * 80)
    print("SECTION 7: TIMING DECORATOR")
    print("=" * 80)

    logger = logging.getLogger("timing")
    logger.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)

    def log_execution_time(func):
        """Log function execution time."""
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                elapsed = time.perf_counter() - start
                logger.info(f"{func.__name__} completed in {elapsed*1000:.2f}ms")
        return wrapper

    @log_execution_time
    def slow_operation():
        time.sleep(0.1)
        return "result"

    logger.info("Executing slow_operation:")
    slow_operation()


def demonstrate_context_manager_logging() -> None:
    """Context manager for operation logging."""
    print("\n" + "=" * 80)
    print("SECTION 8: CONTEXT MANAGER LOGGING")
    print("=" * 80)

    logger = logging.getLogger("context_ops")
    logger.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)

    @contextmanager
    def log_operation(operation_name: str):
        """Context manager that logs operation."""
        logger.info(f"[START] {operation_name}")
        start = time.perf_counter()
        try:
            yield
        except Exception as e:
            elapsed = time.perf_counter() - start
            logger.error(f"[FAILED] {operation_name} after {elapsed*1000:.2f}ms: {e}")
            raise
        else:
            elapsed = time.perf_counter() - start
            logger.info(f"[SUCCESS] {operation_name} completed in {elapsed*1000:.2f}ms")

    with log_operation("Database Query"):
        time.sleep(0.05)

    try:
        with log_operation("File Processing"):
            raise IOError("File not found")
    except IOError:
        pass


def demonstrate_log_filtering() -> None:
    """Custom log filtering."""
    print("\n" + "=" * 80)
    print("SECTION 9: LOG FILTERING")
    print("=" * 80)

    logger = logging.getLogger("filtering")
    logger.setLevel(logging.DEBUG)

    class ProductionFilter(logging.Filter):
        """Only show logs from production."""

        def filter(self, record: logging.LogRecord) -> bool:
            if hasattr(record, 'env'):
                return record.env == "production"
            return True

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('%(env)s - %(message)s',
                                          defaults={'env': 'unknown'}))
    handler.addFilter(ProductionFilter())
    logger.addHandler(handler)

    logger.info("Default message (no env)")

    record = logging.LogRecord(
        name="filtering", level=logging.INFO, pathname="", lineno=0,
        msg="Production message", args=(), exc_info=None
    )
    record.env = "production"
    logger.handle(record)


def demonstrate_performance_logging() -> None:
    """Performance-conscious logging."""
    print("\n" + "=" * 80)
    print("SECTION 10: PERFORMANCE LOGGING")
    print("=" * 80)

    logger = logging.getLogger("perf")
    logger.setLevel(logging.DEBUG)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)

    print("ANTI-PATTERN: String concatenation at every log level")
    print("""
    logger.debug("Processing " + str(data))  # Always evaluated!
    """)

    print("\nBETTER: Use string formatting (lazy evaluation)")
    logger.debug("Processing %s", "data")

    print("\nBEST: Use % formatting for numeric operations")
    for i in range(3):
        logger.info("Iteration %d completed", i)

    print("\nLogging only when needed:")

    if logger.isEnabledFor(logging.DEBUG):
        expensive_data = "Expensive computation"
        logger.debug("Debug info: %s", expensive_data)


def demonstrate_production_logging_setup() -> None:
    """Complete production logging setup."""
    print("\n" + "=" * 80)
    print("SECTION 11: PRODUCTION LOGGING SETUP")
    print("=" * 80)

    def setup_production_logging(app_name: str) -> logging.Logger:
        """Setup logging for production."""

        logger = logging.getLogger(app_name)
        logger.setLevel(logging.INFO)

        formatter = logging.Formatter(
            '%(asctime)s [%(process)d] %(levelname)-8s %(name)s: %(message)s'
        )

        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(formatter)
        logger.addHandler(handler)

        return logger

    logger = setup_production_logging("myapp")
    logger.info("Application initialized")
    logger.warning("This is a warning")
    logger.error("This is an error")


def best_practices() -> None:
    """Best practices."""
    print("\n" + "=" * 80)
    print("SECTION 12: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Never use print() in production code",
        "2. Use appropriate log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
        "3. Include context (user_id, request_id, correlation_id)",
        "4. Use structured logging (JSON) for machine parsing",
        "5. Use lazy evaluation ('%s' formatting, not concatenation)",
        "6. Log exceptions with exc_info=True",
        "7. Use rotating file handlers for long-running services",
        "8. Avoid logging sensitive data (passwords, tokens)",
        "9. Measure performance of logging (it can be bottleneck)",
        "10. Centralize logs for analysis (ELK, Splunk, etc.)",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("LOGGING FRAMEWORK - PRODUCTION OBSERVABILITY")
    print("=" * 80)

    demonstrate_logging_levels()
    demonstrate_basic_configuration()
    demonstrate_handlers_formatters()
    demonstrate_structured_logging()
    demonstrate_contextual_logging()
    demonstrate_rotating_file_handler()
    demonstrate_timing_decorator()
    demonstrate_context_manager_logging()
    demonstrate_log_filtering()
    demonstrate_performance_logging()
    demonstrate_production_logging_setup()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY - LOGGING STRATEGY")
    print("=" * 80)
    print("""
Logging Levels:
    DEBUG   - Detailed diagnostic for developers
    INFO    - General operational messages
    WARNING - Something unexpected (default)
    ERROR   - Something failed but app continues
    CRITICAL - Application in critical state

Components:
    Logger      - Creates log records
    Handler     - Outputs log records (console, file, etc.)
    Formatter   - Formats output
    Filter      - Determines which records to process
    LogRecord   - Individual log message

Common Handlers:
    StreamHandler       - Output to console
    FileHandler         - Output to file
    RotatingFileHandler - Rotate by size
    TimedRotatingFileHandler - Rotate by time
    SysLogHandler       - Send to syslog

Production Setup:
    - Use structured logging (JSON format)
    - Include correlation IDs for tracing
    - Use rotating file handlers
    - Set appropriate log levels
    - Monitor log volume/performance
    - Centralize logs for analysis
    - Never log sensitive data
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Logging has overhead - use lazy evaluation ('%s' not concatenation)
# isEnabledFor() checks avoid expensive computations
# Structured logging enables efficient parsing and filtering
# Performance: ~1-10 microseconds per log line

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Using print() instead of logging
# 2. String concatenation instead of % formatting
# 3. Logging sensitive data (passwords, tokens, PII)
# 4. Not using log levels appropriately
# 5. Not including context (request IDs, correlation IDs)
# 6. Logging exceptions without exc_info=True
# 7. Unbounded log file growth (no rotation)
# 8. Too much logging (performance impact)

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Design logging strategy for microservices
# Q2: Implement structured logging with correlation IDs
# Q3: How would you debug production issues with logs?
# Q4: Design log rotation strategy for long-running services
# Q5: How do you handle sensitive data in logs?
# Q6: Explain trade-offs of different log levels

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build production logging system with observability
# Requirements:
#   - Structured JSON logging
#   - Correlation IDs for request tracing
#   - Performance metrics logging
#   - Rotating file handlers
#   - Contextual logging
# Implementation: Use logging module with custom formatters
