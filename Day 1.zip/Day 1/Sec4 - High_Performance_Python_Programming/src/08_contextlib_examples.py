"""
Module: 08_contextlib_examples.py
Topic: contextlib Utilities - Practical Examples
Problem Statement: Writing context managers from scratch is verbose.
    contextlib provides utilities to simplify common patterns.
Enterprise Scenario: A service needs resource management, error suppression, and cleanup.
    contextlib utilities reduce boilerplate while maintaining safety.
Learning Objectives:
    - Use contextlib utilities for common patterns
    - Apply @contextmanager decorator
    - Use contextlib.suppress for error handling
    - Use ExitStack for complex scenarios
Prerequisites:
    - Understanding of context managers
    - Decorator knowledge
Expected Output:
    - Practical contextlib examples
    - Real-world patterns
    - Clean code patterns
Concepts Covered:
    - contextmanager decorator
    - suppress, redirect_stdout, redirect_stderr
    - ExitStack, AsyncExitStack
    - nullcontext
"""

import sys
from contextlib import contextmanager, suppress, redirect_stdout, redirect_stderr, ExitStack, nullcontext
from typing import Iterator, Optional, Any
from io import StringIO
import tempfile
import os
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


def demonstrate_contextmanager_decorator() -> None:
    """@contextmanager decorator simplifies context manager creation."""
    print("\n" + "=" * 80)
    print("SECTION 1: @contextmanager DECORATOR")
    print("=" * 80)

    @contextmanager
    def managed_resource(name: str) -> Iterator[str]:
        """Simple context manager using decorator."""
        logger.info(f"Acquiring {name}")
        try:
            yield f"resource_{name}"
        finally:
            logger.info(f"Releasing {name}")

    with managed_resource("database") as res:
        logger.info(f"  Using {res}")

    @contextmanager
    def timed_operation(operation_name: str) -> Iterator[None]:
        """Context manager for timing."""
        import time
        start = time.perf_counter()
        logger.info(f"Starting {operation_name}")
        try:
            yield
        finally:
            elapsed = time.perf_counter() - start
            logger.info(f"Completed in {elapsed*1000:.2f}ms")

    with timed_operation("calculation"):
        sum([i**2 for i in range(100000)])


def demonstrate_suppress() -> None:
    """suppress() ignores specified exceptions."""
    print("\n" + "=" * 80)
    print("SECTION 2: suppress() - IGNORE EXCEPTIONS")
    print("=" * 80)

    logger.info("Suppressing FileNotFoundError:")

    with suppress(FileNotFoundError):
        with open("nonexistent_file.txt", "r") as f:
            content = f.read()

    logger.info("  Exception was suppressed, execution continued")

    logger.info("\nSuppressing multiple exception types:")

    with suppress(ValueError, TypeError):
        int("not a number")
        logger.info("  If we get here, ValueError was suppressed")

    logger.info("  Execution continued")


def demonstrate_redirect_stdout_stderr() -> None:
    """Redirect stdout and stderr."""
    print("\n" + "=" * 80)
    print("SECTION 3: REDIRECT OUTPUT")
    print("=" * 80)

    logger.info("Capturing stdout:")
    output = StringIO()
    with redirect_stdout(output):
        print("This goes to StringIO")
        print("Not to console")

    captured = output.getvalue()
    logger.info(f"  Captured: {captured.strip()}")

    logger.info("\nCapturing stderr:")
    errors = StringIO()
    with redirect_stderr(errors):
        print("Warning message", file=sys.stderr)

    logger.info(f"  Captured error: {errors.getvalue().strip()}")

    logger.info("\nCombined stdout and stderr capture:")
    output = StringIO()
    errors = StringIO()
    with redirect_stdout(output), redirect_stderr(errors):
        print("Normal output")
        print("Error output", file=sys.stderr)

    logger.info(f"  stdout: {output.getvalue().strip()}")
    logger.info(f"  stderr: {errors.getvalue().strip()}")


def demonstrate_nullcontext() -> None:
    """nullcontext() for conditional context manager usage."""
    print("\n" + "=" * 80)
    print("SECTION 4: nullcontext() - CONDITIONAL CONTEXT")
    print("=" * 80)

    @contextmanager
    def optional_resource(use_resource: bool) -> Iterator[Optional[str]]:
        """Context manager that's optional."""
        if use_resource:
            logger.info("Using resource context")
            try:
                yield "real_resource"
            finally:
                logger.info("Cleaning up resource")
        else:
            logger.info("No resource context needed")
            with nullcontext("dummy_resource") as ctx:
                yield ctx

    logger.info("With resource=True:")
    with optional_resource(True) as res:
        logger.info(f"  Got resource: {res}")

    logger.info("\nWith resource=False:")
    with optional_resource(False) as res:
        logger.info(f"  Got resource: {res}")


def demonstrate_exitstack() -> None:
    """ExitStack for dynamic context manager management."""
    print("\n" + "=" * 80)
    print("SECTION 5: ExitStack - DYNAMIC CONTEXTS")
    print("=" * 80)

    @contextmanager
    def numbered_resource(n: int) -> Iterator[str]:
        """Resource with number."""
        logger.info(f"  Enter resource {n}")
        try:
            yield f"res_{n}"
        finally:
            logger.info(f"  Exit resource {n}")

    logger.info("Managing variable number of resources:")

    with ExitStack() as stack:
        resources = [stack.enter_context(numbered_resource(i)) for i in range(3)]
        logger.info(f"All resources opened: {resources}")

    logger.info("All resources cleaned up in reverse order")


def demonstrate_exitstack_callback() -> None:
    """ExitStack with callbacks."""
    print("\n" + "=" * 80)
    print("SECTION 6: ExitStack WITH CALLBACKS")
    print("=" * 80)

    with ExitStack() as stack:
        logger.info("Registering cleanup callbacks:")

        stack.callback(logger.info, "  Cleanup 3 (registered last)")
        stack.callback(logger.info, "  Cleanup 2 (registered second)")
        stack.callback(logger.info, "  Cleanup 1 (registered first)")

        logger.info("All callbacks registered, exiting...")

    logger.info("Callbacks executed in reverse order (LIFO)")


def demonstrate_exitstack_error_handling() -> None:
    """ExitStack with error handling."""
    print("\n" + "=" * 80)
    print("SECTION 7: ExitStack ERROR HANDLING")
    print("=" * 80)

    @contextmanager
    def resource(name: str) -> Iterator[str]:
        logger.info(f"Acquiring {name}")
        try:
            yield name
        finally:
            logger.info(f"Releasing {name}")

    logger.info("ExitStack ensures cleanup even on error:")

    with ExitStack() as stack:
        res1 = stack.enter_context(resource("db"))
        res2 = stack.enter_context(resource("cache"))
        logger.info(f"Resources acquired: {res1}, {res2}")

        try:
            raise ValueError("Simulated error")
        except ValueError:
            logger.info("Exception occurred, but cleanup still runs")


def demonstrate_file_management() -> None:
    """ExitStack for multiple file management."""
    print("\n" + "=" * 80)
    print("SECTION 8: MULTIPLE FILE MANAGEMENT")
    print("=" * 80)

    with tempfile.TemporaryDirectory() as tmpdir:
        filenames = [os.path.join(tmpdir, f"file_{i}.txt") for i in range(3)]

        logger.info("Opening multiple files with ExitStack:")

        with ExitStack() as stack:
            files = [stack.enter_context(open(fn, 'w')) for fn in filenames]

            for i, f in enumerate(files):
                f.write(f"Content of file {i}")
                logger.info(f"  Wrote to {os.path.basename(f.name)}")

        logger.info("All files automatically closed")


def demonstrate_context_manager_combination() -> None:
    """Combining multiple context managers."""
    print("\n" + "=" * 80)
    print("SECTION 9: CONTEXT MANAGER COMBINATION")
    print("=" * 80)

    @contextmanager
    def log_section(name: str) -> Iterator[None]:
        logger.info(f">>> {name}")
        try:
            yield
        finally:
            logger.info(f"<<< {name}")

    @contextmanager
    def timed_section(name: str) -> Iterator[None]:
        import time
        start = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - start
            logger.info(f"  Duration: {elapsed*1000:.2f}ms")

    logger.info("Combining contexts (both apply):")

    with log_section("Processing"), timed_section("Processing"):
        logger.info("  Doing work...")
        sum([i**2 for i in range(100000)])


def demonstrate_conditional_exception_suppression() -> None:
    """Suppress exceptions conditionally."""
    print("\n" + "=" * 80)
    print("SECTION 10: CONDITIONAL SUPPRESSION")
    print("=" * 80)

    def parse_config(filename: str, required: bool = False) -> Optional[dict]:
        """Parse config file, optionally suppress missing file error."""

        exception_type = () if required else (FileNotFoundError,)

        with suppress(*exception_type):
            with open(filename, 'r') as f:
                logger.info(f"  Loaded {filename}")
                return {"key": "value"}

        if required:
            logger.error(f"  Required file {filename} not found!")
        else:
            logger.info(f"  Optional file {filename} not found, using defaults")

        return None

    logger.info("Optional config (missing file suppressed):")
    result = parse_config("optional_config.json", required=False)

    logger.info("\nRequired config (error if missing):")
    try:
        result = parse_config("required_config.json", required=True)
    except FileNotFoundError:
        logger.error("Config file was required!")


def demonstrate_contextlib_patterns() -> None:
    """Common contextlib patterns."""
    print("\n" + "=" * 80)
    print("SECTION 11: COMMON PATTERNS")
    print("=" * 80)

    @contextmanager
    def temporary_directory_context() -> Iterator[str]:
        """Context manager wrapping tempfile."""
        with tempfile.TemporaryDirectory() as tmpdir:
            logger.info(f"Created temp directory: {tmpdir}")
            try:
                yield tmpdir
            finally:
                logger.info("Cleaned up temp directory")

    @contextmanager
    def resource_pool_context(pool_size: int) -> Iterator[list]:
        """Context manager for resource pool."""
        pool = list(range(pool_size))
        logger.info(f"Initialized pool: {pool}")
        try:
            yield pool
        finally:
            logger.info("Cleaned up resource pool")

    with temporary_directory_context() as tmpdir:
        logger.info(f"  Using {tmpdir}")

    with resource_pool_context(5) as pool:
        logger.info(f"  Using pool: {pool}")


def best_practices() -> None:
    """Best practices."""
    print("\n" + "=" * 80)
    print("SECTION 12: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Use @contextmanager decorator for simple cases",
        "2. Use suppress() only for truly safe exceptions",
        "3. Use ExitStack for dynamic/variable number of contexts",
        "4. Use redirect_stdout/stderr for testing output",
        "5. Use nullcontext for optional resource management",
        "6. Combine multiple context managers for layered management",
        "7. Keep context managers focused and composable",
        "8. Test error paths thoroughly",
        "9. Document what resources are managed",
        "10. Prefer contextlib utilities over manual implementation",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("CONTEXTLIB - PRACTICAL UTILITIES")
    print("=" * 80)

    demonstrate_contextmanager_decorator()
    demonstrate_suppress()
    demonstrate_redirect_stdout_stderr()
    demonstrate_nullcontext()
    demonstrate_exitstack()
    demonstrate_exitstack_callback()
    demonstrate_exitstack_error_handling()
    demonstrate_file_management()
    demonstrate_context_manager_combination()
    demonstrate_conditional_exception_suppression()
    demonstrate_contextlib_patterns()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY - CONTEXTLIB UTILITIES")
    print("=" * 80)
    print("""
Key Utilities:
    @contextmanager    - Create context manager from generator
    suppress            - Suppress specific exceptions
    redirect_stdout     - Capture stdout
    redirect_stderr     - Capture stderr
    nullcontext         - No-op context manager
    ExitStack           - Manage variable number of contexts
    AsyncExitStack      - Async version of ExitStack

Common Patterns:
    - Resource management (files, connections)
    - Output capturing (testing)
    - Exception suppression (cleanup)
    - Dynamic context management (variable count)
    - Composable contexts (layered management)
    - Cleanup callbacks (registration pattern)

When to Use contextlib:
    - Simple context managers → @contextmanager
    - Dynamic resource count → ExitStack
    - Safe exception suppression → suppress
    - Testing output → redirect_stdout/stderr
    - Optional contexts → nullcontext
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# contextlib utilities are lightweight and zero overhead
# @contextmanager avoids boilerplate while maintaining performance
# ExitStack enables efficient dynamic context management
# redirect_* captures output efficiently

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Using suppress() for exceptions that should propagate
# 2. Not understanding suppress() returns None
# 3. Forgetting cleanup in finally block
# 4. Not testing error paths
# 5. Over-suppressing exceptions (masks bugs)

# ============================================================================
# INTERVIEW QUESTIONS
# ============================================================================
# Q1: Explain @contextmanager decorator
# Q2: When would you use ExitStack instead of multiple with statements?
# Q3: Design exception handling with suppress()
# Q4: How would you capture and test stdout?
# Q5: What's the difference between ExitStack and nested with statements?

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build production logging context manager
# Requirements:
#   - Log operation start/end
#   - Capture and log exceptions
#   - Measure execution time
#   - Support nested operations
# Implementation: Use @contextmanager decorator
