"""
Module: 13_performance_measurement.py
Topic: Performance Measurement - Baselines and Metrics
Problem Statement: "My code is slow" is not actionable. Measurements provide facts.
    Without measurements, optimization efforts are wasted on wrong targets.
Enterprise Scenario: Database operations take 5 seconds but nobody knows why.
    Profiling reveals 4.9 seconds is network latency (not optimizable),
    0.1 seconds is parsing (optimizable). Focus on real bottlenecks.
Learning Objectives:
    - Measure execution time accurately
    - Use sys.getsizeof() for memory
    - Identify performance bottlenecks
    - Set performance baselines
Prerequisites:
    - Basic Python performance concepts
    - Understanding of timers
Expected Output:
    - Performance measurement patterns
    - Profiling techniques
    - Real-world examples
Concepts Covered:
    - time.perf_counter() for accurate timing
    - sys.getsizeof() for memory
    - Profiling patterns
    - Benchmark baselines
"""

import sys
import time
from typing import Callable, Any
from functools import wraps
import statistics


def demonstrate_timer_functions() -> None:
    """Compare different timing functions."""
    print("\n" + "=" * 80)
    print("SECTION 1: TIMER FUNCTIONS")
    print("=" * 80)

    print("time.time() - Wall clock time (can go backwards)")
    print("time.perf_counter() - Performance counter (recommended)")
    print("time.process_time() - CPU time only (not wall time)")

    n = 10_000_000

    start = time.perf_counter()
    result = sum(range(n))
    elapsed = time.perf_counter() - start

    print(f"\nSum of 0 to {n}: {elapsed*1000:.2f}ms")


def demonstrate_measuring_function_execution() -> None:
    """Measure individual function execution."""
    print("\n" + "=" * 80)
    print("SECTION 2: FUNCTION TIMING")
    print("=" * 80)

    def operation1():
        return sum(range(1000000))

    def operation2():
        return [x for x in range(1000000)]

    def operation3():
        return (x for x in range(1000000))

    def measure(func: Callable, name: str, runs: int = 5):
        """Measure function execution time."""
        times = []
        for _ in range(runs):
            start = time.perf_counter()
            func()
            elapsed = time.perf_counter() - start
            times.append(elapsed)

        avg = statistics.mean(times)
        stdev = statistics.stdev(times) if runs > 1 else 0
        print(f"{name:20} {avg*1000:8.2f}ms ±{stdev*1000:6.2f}ms")

    print(f"{'Operation':<20} {'Time (ms)':<15} {'Variation':<10}")
    print("-" * 50)
    measure(operation1, "sum(range())", runs=3)
    measure(operation2, "list comprehension", runs=3)


def demonstrate_memory_measurement() -> None:
    """Measure object memory usage."""
    print("\n" + "=" * 80)
    print("SECTION 3: MEMORY MEASUREMENT")
    print("=" * 80)

    objects = {
        "int": 42,
        "str": "hello",
        "list": [1, 2, 3, 4, 5],
        "dict": {'a': 1, 'b': 2},
        "1M list": list(range(1_000_000)),
    }

    print(f"{'Object':<20} {'Size (bytes)':<15} {'Size (MB)':<10}")
    print("-" * 50)

    for name, obj in objects.items():
        size_bytes = sys.getsizeof(obj)
        size_mb = size_bytes / (1024 * 1024)
        print(f"{name:<20} {size_bytes:<15} {size_mb:<10.4f}")


def demonstrate_profiling_decorator() -> None:
    """Decorator for profiling."""
    print("\n" + "=" * 80)
    print("SECTION 4: PROFILING DECORATOR")
    print("=" * 80)

    def profile(func):
        """Decorator to profile function."""
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            result = func(*args, **kwargs)
            elapsed = time.perf_counter() - start
            print(f"{func.__name__} took {elapsed*1000:.2f}ms")
            return result
        return wrapper

    @profile
    def fibonacci(n):
        if n <= 1:
            return n
        return fibonacci(n-1) + fibonacci(n-2)

    @profile
    def factorial(n):
        if n <= 1:
            return 1
        return n * factorial(n-1)

    fibonacci(10)
    factorial(20)


def demonstrate_repeated_measurements() -> None:
    """Take multiple measurements for stability."""
    print("\n" + "=" * 80)
    print("SECTION 5: REPEATED MEASUREMENTS")
    print("=" * 80)

    def slow_operation():
        time.sleep(0.01)
        return sum(range(100000))

    runs = 5
    times = []

    print(f"Running {runs} times:")
    for run in range(1, runs + 1):
        start = time.perf_counter()
        slow_operation()
        elapsed = time.perf_counter() - start
        times.append(elapsed)
        print(f"  Run {run}: {elapsed*1000:.2f}ms")

    print(f"\nStatistics:")
    print(f"  Min: {min(times)*1000:.2f}ms")
    print(f"  Max: {max(times)*1000:.2f}ms")
    print(f"  Mean: {statistics.mean(times)*1000:.2f}ms")
    print(f"  Stdev: {statistics.stdev(times)*1000:.2f}ms")


def demonstrate_comparative_benchmarking() -> None:
    """Compare two approaches."""
    print("\n" + "=" * 80)
    print("SECTION 6: COMPARATIVE BENCHMARKING")
    print("=" * 80)

    n = 10_000_000

    def approach1():
        """List comprehension."""
        return [x**2 for x in range(n)]

    def approach2():
        """Generator expression."""
        return (x**2 for x in range(n))

    print("Creating 10M squares (list vs generator):")

    start = time.perf_counter()
    result1 = approach1()
    time1 = time.perf_counter() - start
    print(f"  List: {time1*1000:.2f}ms")

    start = time.perf_counter()
    result2 = approach2()
    time2 = time.perf_counter() - start
    print(f"  Generator: {time2*1000:.4f}ms")

    print(f"  Speedup: {time1/time2:.0f}x")


def demonstrate_context_manager_timing() -> None:
    """Context manager for automatic timing."""
    print("\n" + "=" * 80)
    print("SECTION 7: CONTEXT MANAGER TIMING")
    print("=" * 80)

    from contextlib import contextmanager

    @contextmanager
    def timer(name: str):
        """Context manager for timing."""
        start = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - start
            print(f"{name} took {elapsed*1000:.2f}ms")

    print("Measuring operations with context manager:")

    with timer("List creation"):
        data = list(range(1_000_000))

    with timer("Sum calculation"):
        total = sum(range(1_000_000))


def demonstrate_performance_baseline() -> None:
    """Establish performance baselines."""
    print("\n" + "=" * 80)
    print("SECTION 8: PERFORMANCE BASELINES")
    print("=" * 80)

    print("Typical operation costs:")
    print("  Function call: ~100 ns")
    print("  Variable lookup: ~10 ns")
    print("  List append: ~100 ns")
    print("  Dict lookup: ~200 ns")
    print("  File read (1MB): ~1 ms")
    print("  Network call: ~100 ms")
    print("  Disk seek: ~10 ms")

    print("\nIf total = 100ms:")
    print("  - 99ms network: Can't optimize (not our code)")
    print("  - 1ms parsing: Can optimize (10x speedup possible)")
    print("  Focus on the 1ms, not the 99ms!")


def demonstrate_profiling_workflow() -> None:
    """Profiling workflow."""
    print("\n" + "=" * 80)
    print("SECTION 9: PROFILING WORKFLOW")
    print("=" * 80)

    print("Step 1: Measure baseline performance")
    print("  - Run application, record metrics")
    print("  - Memory, CPU, execution time")

    print("\nStep 2: Identify bottlenecks")
    print("  - Use profiler to find slow functions")
    print("  - Focus on biggest time consumers (80/20)")

    print("\nStep 3: Measure current implementation")
    print("  - Profile problematic function")
    print("  - Understand where time is spent")

    print("\nStep 4: Optimize")
    print("  - Change implementation")
    print("  - Measure improvement")

    print("\nStep 5: Validate")
    print("  - Ensure speedup is real")
    print("  - Check no regression in other areas")

    print("\nNever optimize without measuring!")


def best_practices() -> None:
    """Best practices."""
    print("\n" + "=" * 80)
    print("SECTION 10: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Always measure, never guess",
        "2. Use time.perf_counter() for accurate timing",
        "3. Run multiple times for stability",
        "4. Remove outliers (warm up JIT if applicable)",
        "5. Measure on representative data",
        "6. Compare apples to apples (same hardware, etc.)",
        "7. Profile before optimizing",
        "8. Establish baselines first",
        "9. Measure memory with sys.getsizeof()",
        "10. Use profiling tools (cProfile, memory_profiler)",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("PERFORMANCE MEASUREMENT - FOUNDATIONS")
    print("=" * 80)

    demonstrate_timer_functions()
    demonstrate_measuring_function_execution()
    demonstrate_memory_measurement()
    demonstrate_profiling_decorator()
    demonstrate_repeated_measurements()
    demonstrate_comparative_benchmarking()
    demonstrate_context_manager_timing()
    demonstrate_performance_baseline()
    demonstrate_profiling_workflow()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
Key Tools:
    - time.perf_counter(): High-resolution timer
    - sys.getsizeof(): Object size
    - statistics module: Calculate mean/stdev
    - Decorators: Automatic profiling

Measurement Strategy:
    1. Set baseline
    2. Identify bottleneck (80/20 rule)
    3. Measure current implementation
    4. Optimize
    5. Validate improvement

Remember: Premature optimization is evil. Measure first!
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Measurement overhead minimal with perf_counter()
# Statistics stabilize after 5-10 runs
# Outliers should be discarded
# Representative data essential for accurate results

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Establish performance baselines for your application
# Requirements:
#   - Measure key operations
#   - Calculate statistics (mean, stdev)
#   - Identify bottlenecks
#   - Create performance dashboard
