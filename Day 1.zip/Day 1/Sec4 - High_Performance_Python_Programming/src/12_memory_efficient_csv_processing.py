"""
Module: 12_memory_efficient_csv_processing.py
Topic: Memory-Efficient CSV Processing
Problem Statement: CSV files from data sources often have millions of rows.
    Loading into pandas DataFrames or Python lists causes memory exhaustion.
    Streaming CSV processing handles multi-GB files efficiently.
Enterprise Scenario: Financial ETL processes billions of transaction records.
    Streaming CSV approach processes in real-time with minimal memory.
Learning Objectives:
    - Stream CSV files without loading entirely
    - Use csv.reader for efficiency
    - Handle CSV dialects and edge cases
    - Implement CSV filtering and transformation
Prerequisites:
    - Understanding of CSV format
    - Streaming file processing knowledge
Expected Output:
    - CSV streaming examples
    - Memory-efficient patterns
    - Real-world use cases
Concepts Covered:
    - csv.reader and csv.DictReader
    - Streaming CSV processing
    - Delimiter handling
    - Error handling in CSV
"""

import csv
import tempfile
import os
from typing import Iterator, Dict, List, Any
from dataclasses import dataclass
import time


@dataclass
class Transaction:
    """Transaction record."""
    id: str
    amount: float
    category: str
    date: str

    @classmethod
    def from_dict(cls, data: Dict):
        return cls(id=data['id'], amount=float(data['amount']),
                   category=data['category'], date=data['date'])


def demonstrate_csv_reader_vs_list() -> None:
    """Compare csv.reader vs readlines()."""
    print("\n" + "=" * 80)
    print("SECTION 1: CSV READER VS LOADING ENTIRE FILE")
    print("=" * 80)

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name
        writer = csv.writer(f)
        writer.writerow(['id', 'name', 'score'])
        for i in range(1000):
            writer.writerow([i, f'user_{i}', 100 + (i % 50)])

    try:
        print("ANTI-PATTERN: Load entire CSV as list")
        print("  lines = open(file).readlines()  # All in memory")

        print("\nBETTER: Stream with csv.reader")
        print("  reader = csv.reader(open(file))")
        print("  for row in reader:")
        print("      process(row)")

        print("\nDemonstration:")
        with open(csv_file) as f:
            reader = csv.reader(f)
            for i, row in enumerate(reader):
                if i < 3:
                    print(f"  Row {i}: {row}")
                if i == 2:
                    break
    finally:
        os.unlink(csv_file)


def demonstrate_csv_dictreader() -> None:
    """Use DictReader for named column access."""
    print("\n" + "=" * 80)
    print("SECTION 2: CSV DICTREADER")
    print("=" * 80)

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name
        writer = csv.DictWriter(f, fieldnames=['id', 'name', 'email'])
        writer.writeheader()
        for i in range(5):
            writer.writerow({'id': i, 'name': f'user_{i}', 'email': f'user_{i}@example.com'})

    try:
        print("Using DictReader for named access:")
        with open(csv_file) as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                if i < 3:
                    print(f"  {row['name']} ({row['email']})")
    finally:
        os.unlink(csv_file)


def demonstrate_filtering_csv() -> None:
    """Filter CSV rows on-the-fly."""
    print("\n" + "=" * 80)
    print("SECTION 3: FILTERING CSV STREAMS")
    print("=" * 80)

    def generate_transactions_csv(filename: str, count: int):
        with open(filename, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['id', 'amount', 'category', 'date'])
            writer.writeheader()
            for i in range(count):
                writer.writerow({
                    'id': i,
                    'amount': 100 + (i % 1000),
                    'category': ['food', 'gas', 'shopping'][i % 3],
                    'date': '2024-01-01'
                })

    def filter_high_value(csv_file: str, threshold: float) -> Iterator[Dict]:
        with open(csv_file) as f:
            reader = csv.DictReader(f)
            for row in reader:
                if float(row['amount']) > threshold:
                    yield row

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name

    try:
        generate_transactions_csv(csv_file, 100)

        print("Filtering transactions > 900:")
        for row in filter_high_value(csv_file, 900):
            print(f"  {row}")
            break
    finally:
        os.unlink(csv_file)


def demonstrate_transforming_csv() -> None:
    """Transform CSV data on-the-fly."""
    print("\n" + "=" * 80)
    print("SECTION 4: TRANSFORMING CSV STREAMS")
    print("=" * 80)

    def transform_prices(csv_file: str, currency_rate: float = 1.1) -> Iterator[Dict]:
        """Convert price to USD."""
        with open(csv_file) as f:
            reader = csv.DictReader(f)
            for row in reader:
                row['price_usd'] = float(row['price']) * currency_rate
                yield row

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name
        writer = csv.DictWriter(f, fieldnames=['product', 'price'])
        writer.writeheader()
        for i in range(5):
            writer.writerow({'product': f'item_{i}', 'price': 100 + i})

    try:
        print("Currency conversion (USD = original * 1.1):")
        for row in transform_prices(csv_file):
            print(f"  {row['product']}: {row['price']} -> ${row['price_usd']:.2f}")
    finally:
        os.unlink(csv_file)


def demonstrate_csv_aggregation() -> None:
    """Aggregate CSV data while streaming."""
    print("\n" + "=" * 80)
    print("SECTION 5: STREAMING AGGREGATION")
    print("=" * 80)

    def aggregate_by_category(csv_file: str) -> Dict[str, Any]:
        """Aggregate by category while streaming."""
        result = {}
        with open(csv_file) as f:
            reader = csv.DictReader(f)
            for row in reader:
                cat = row['category']
                if cat not in result:
                    result[cat] = {'count': 0, 'total': 0}
                result[cat]['count'] += 1
                result[cat]['total'] += float(row['amount'])
        return result

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name
        writer = csv.DictWriter(f, fieldnames=['id', 'amount', 'category'])
        writer.writeheader()
        for i in range(20):
            writer.writerow({'id': i, 'amount': 100 + i, 'category': ['A', 'B', 'C'][i % 3]})

    try:
        print("Aggregation by category:")
        result = aggregate_by_category(csv_file)
        for cat, stats in sorted(result.items()):
            print(f"  {cat}: count={stats['count']}, total={stats['total']}")
    finally:
        os.unlink(csv_file)


def demonstrate_csv_error_handling() -> None:
    """Handle errors in CSV processing."""
    print("\n" + "=" * 80)
    print("SECTION 6: ERROR HANDLING IN CSV")
    print("=" * 80)

    def safe_process_csv(csv_file: str) -> Iterator[Dict]:
        """Process CSV with error handling."""
        errors = 0
        with open(csv_file) as f:
            reader = csv.DictReader(f)
            for line_num, row in enumerate(reader, start=2):
                try:
                    row['value'] = float(row['value'])
                    yield row
                except (ValueError, KeyError) as e:
                    errors += 1
                    print(f"  Warning: Line {line_num}: {e}")
        if errors > 0:
            print(f"  Skipped {errors} invalid rows")

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name
        f.write('id,value\n')
        f.write('1,100\n')
        f.write('2,invalid\n')
        f.write('3,300\n')

    try:
        print("Processing CSV with invalid values:")
        for row in safe_process_csv(csv_file):
            print(f"  {row}")
    finally:
        os.unlink(csv_file)


def demonstrate_batched_csv_processing() -> None:
    """Process CSV in batches for efficiency."""
    print("\n" + "=" * 80)
    print("SECTION 7: BATCHED CSV PROCESSING")
    print("=" * 80)

    def batch_rows(csv_file: str, batch_size: int) -> Iterator[List[Dict]]:
        """Yield batches of rows."""
        with open(csv_file) as f:
            reader = csv.DictReader(f)
            batch = []
            for row in reader:
                batch.append(row)
                if len(batch) >= batch_size:
                    yield batch
                    batch = []
            if batch:
                yield batch

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name
        writer = csv.DictWriter(f, fieldnames=['id', 'value'])
        writer.writeheader()
        for i in range(15):
            writer.writerow({'id': i, 'value': 100 + i})

    try:
        print("Processing in batches of 5:")
        for batch_num, batch in enumerate(batch_rows(csv_file, 5)):
            print(f"  Batch {batch_num}: {len(batch)} rows")
    finally:
        os.unlink(csv_file)


def demonstrate_csv_performance() -> None:
    """Performance comparison."""
    print("\n" + "=" * 80)
    print("SECTION 8: PERFORMANCE")
    print("=" * 80)

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.csv', newline='') as f:
        csv_file = f.name
        writer = csv.DictWriter(f, fieldnames=['id', 'name', 'value'])
        writer.writeheader()
        for i in range(100000):
            writer.writerow({'id': i, 'name': f'item_{i}', 'value': i*10})

    try:
        start = time.perf_counter()
        with open(csv_file) as f:
            reader = csv.DictReader(f)
            count = sum(1 for _ in reader)
        elapsed = time.perf_counter() - start

        print(f"Processed {count} rows in {elapsed*1000:.2f}ms")
        print(f"Performance: {count/elapsed:,.0f} rows/second")
    finally:
        os.unlink(csv_file)


def best_practices() -> None:
    """Best practices."""
    print("\n" + "=" * 80)
    print("SECTION 9: BEST PRACTICES")
    print("=" * 80)

    tips = [
        "1. Always stream CSV files (never load entirely)",
        "2. Use csv.DictReader for named column access",
        "3. Use csv.reader for positional access (slightly faster)",
        "4. Handle encoding issues (specify encoding='utf-8')",
        "5. Process in batches for efficiency (DB inserts, etc.)",
        "6. Handle errors per-row (don't fail on first error)",
        "7. Use newline='' when opening CSV files",
        "8. Close files with context managers (with statement)",
        "9. Validate data while streaming",
        "10. Use generators for composable CSV pipelines",
    ]

    for tip in tips:
        print(f"  {tip}")


def main() -> None:
    """Run all demonstrations."""
    print("\n" + "=" * 80)
    print("MEMORY-EFFICIENT CSV PROCESSING")
    print("=" * 80)

    demonstrate_csv_reader_vs_list()
    demonstrate_csv_dictreader()
    demonstrate_filtering_csv()
    demonstrate_transforming_csv()
    demonstrate_csv_aggregation()
    demonstrate_csv_error_handling()
    demonstrate_batched_csv_processing()
    demonstrate_csv_performance()
    best_practices()

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print("""
CSV Processing Patterns:
    1. Streaming: Process row-by-row (constant memory)
    2. Filtering: Select matching rows
    3. Transformation: Modify fields
    4. Aggregation: Accumulate statistics
    5. Batching: Group rows for batch operations

csv Module:
    - csv.reader: Positional access (slightly faster)
    - csv.DictReader: Named access (more readable)
    - csv.writer: Write CSV data
    - csv.DictWriter: Write with named fields

Performance Tips:
    - Streaming: O(1) memory regardless of size
    - Batching: Better I/O performance
    - Chunking: Balance memory vs throughput
    - ~1M rows/second typical performance
    """)


if __name__ == "__main__":
    main()

# ============================================================================
# PERFORMANCE DISCUSSION
# ============================================================================
# Memory: O(1) for streaming vs O(n) for eager loading
# Throughput: ~1M rows/second for simple processing
# Batching improves DB insert performance by 10-100x

# ============================================================================
# COMMON MISTAKES
# ============================================================================
# 1. Loading entire CSV with readlines()
# 2. Forgetting newline='' parameter
# 3. Not handling encoding
# 4. Failing on first error instead of continuing
# 5. Not validating data types

# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================
# Task: Build streaming CSV ETL pipeline
# Requirements:
#   - Read from source CSV
#   - Filter by criteria
#   - Transform fields
#   - Validate data
#   - Write to output CSV
# Implementation: Use csv.reader/DictReader
