"""
Demonstrate Standard Streams (stdin, stdout, stderr)
Topic: Input/output redirection for automation
"""

import sys
import json
from datetime import datetime

print("=== Standard Streams Demo ===\n", file=sys.stdout)

# stdout - Standard output (normal program output)
print("This goes to STDOUT (default output)", file=sys.stdout)

# stderr - Standard error (errors and diagnostics)
print("[WARNING] This goes to STDERR (errors/warnings)", file=sys.stderr)
print("[ERROR] Log entry to STDERR", file=sys.stderr)

print()

# Enterprise Logging Example
def log_message(level, message):
    """Log messages to appropriate stream based on level"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if level in ["ERROR", "WARNING"]:
        print(f"[{timestamp}] {level}: {message}", file=sys.stderr)
    else:
        print(f"[{timestamp}] {level}: {message}", file=sys.stdout)

print("=== Enterprise Logging ===\n")
log_message("INFO", "Starting Content Server repository validation")
log_message("INFO", "Connecting to PROD environment...")
log_message("WARNING", "Server response time exceeds threshold")
log_message("ERROR", "Failed to connect to repository database")
log_message("INFO", "Validation completed")

print()

# Read from stdin
print("=== Reading from stdin ===\n")
print("Attempting to read configuration from stdin...")
print("(This would accept piped input: echo 'value' | python 3_standard_streams.py)")

# Try to read one line from stdin if available
if not sys.stdin.isatty():  # Check if stdin is being piped
    try:
        line = sys.stdin.readline().strip()
        if line:
            print(f"Received input from pipe: {line}")
    except:
        pass
else:
    print("(No piped input detected - running interactively)")

print()
print("Stream redirection examples:")
print("  Redirect stdout:     python 3_standard_streams.py > output.txt")
print("  Redirect stderr:     python 3_standard_streams.py 2> errors.txt")
print("  Redirect both:       python 3_standard_streams.py > output.txt 2>&1")
print("  Pipe output:         python 3_standard_streams.py | findstr WARNING")

sys.exit(0)
