# OpenText Command-Line Training Materials

This directory contains Python examples demonstrating command-line argument handling, standard streams, and enterprise automation patterns for OpenText Consultants.

## Files Overview

### 1. **1_sys_argv_basics.py**
**Topic:** Command Line Arguments with sys.argv  
Demonstrates:
- How `sys.argv` receives command-line arguments
- Parsing positional arguments
- Providing usage messages and validation
- Basic exit codes

```bash
# Basic usage
python 1_sys_argv_basics.py PROD CS_Server01 D:\Reports

# Expected output shows parsed environment, server, and report path
```

---

### 2. **2_argparse_production.py**
**Topic:** Production-Grade Argument Parsing  
Demonstrates:
- Using `argparse` for professional utilities
- Named arguments (--env, --server, --reports)
- Required vs. optional arguments
- Argument validation
- Help messages and epilog
- Action flags (store_true, choices)

```bash
# With all options
python 2_argparse_production.py check --env PROD --server CS_Server01 --reports D:\Reports --log-level DEBUG

# With help
python 2_argparse_production.py --help

# Minimal required arguments
python 2_argparse_production.py check --env PROD
```

---

### 3. **3_standard_streams.py**
**Topic:** Standard Streams (stdin, stdout, stderr) and Redirection  
Demonstrates:
- Writing to `sys.stdout` (normal output)
- Writing to `sys.stderr` (errors/warnings)
- Structured logging with appropriate streams
- Reading from stdin (piped input)
- Stream redirection patterns

```bash
# Redirect stdout to file
python 3_standard_streams.py > output.txt

# Redirect stderr to file
python 3_standard_streams.py 2> errors.txt

# Redirect both stdout and stderr
python 3_standard_streams.py > output.txt 2>&1

# Pipe output to another command (Windows)
python 3_standard_streams.py | findstr WARNING

# Pipe input
echo "config_value" | python 3_standard_streams.py
```

---

### 4. **4_displayhook.py**
**Topic:** sys.displayhook - Custom Output Formatting  
Demonstrates:
- When displayhook is applied (interactive shell only)
- How to create custom displayhook functions
- JSON formatting output
- Why displayhook is rarely used in production scripts

```bash
# Run the script to see examples
python 4_displayhook.py

# In interactive Python shell:
# >>> import sys
# >>> from displayhook import json_displayhook
# >>> sys.displayhook = json_displayhook
# >>> {'key': 'value'}  # Will output formatted JSON
```

---

### 5. **5_enterprise_automation.py**
**Topic:** Complete Enterprise Automation Utility  
Demonstrates all concepts combined:
- Full argument parsing with argparse
- Multi-level logging to stdout/stderr
- Exit codes (0=success, 1=check failed, 2=config error)
- Report generation
- Real-world use case: Repository health checks

```bash
# Basic usage
python 5_enterprise_automation.py PROD

# With all options
python 5_enterprise_automation.py PROD --server CS_Server01 --reports D:\Reports --validate-only

# Capture errors separately
python 5_enterprise_automation.py PROD 2> errors.log 1> output.log

# Use in scheduled task or pipeline
python 5_enterprise_automation.py PROD --log-level ERROR > report.txt 2>&1
```

---

## Key Concepts

### Command-Line Arguments (sys.argv)
- `sys.argv[0]` = Script name
- `sys.argv[1+]` = Arguments passed
- **Enterprise use:** DEV/TEST/PROD environments, server names, paths

### Production Argument Parsing (argparse)
- Cleaner than manual sys.argv parsing
- Built-in help (--help, -h)
- Type validation
- Required vs. optional arguments
- Better error messages

### Standard Streams
| Stream | Purpose | File Descriptor |
|--------|---------|-----------------|
| stdout | Normal output | 1 |
| stderr | Errors/warnings | 2 |
| stdin | Input (piped) | 0 |

### Stream Redirection (Windows PowerShell/CMD)
```bash
# stdout to file
python script.py > out.txt

# stderr to file
python script.py 2> err.txt

# Both to file
python script.py > out.txt 2>&1

# Append to file
python script.py >> out.txt

# Pipe to another command
python script.py | findstr ERROR
```

### Exit Codes
- `0` = Success
- `1` = General error
- `2` = Misuse of command (argument errors)
- `3+` = Custom error codes

```python
import sys
sys.exit(0)  # Success
sys.exit(1)  # Failure
sys.exit(2)  # Argument error
```

### sys.displayhook
- **Only works in interactive Python shell** (not when running scripts)
- Default behavior: prints non-None expression results
- **Not used in:** Production automation, scripts run by schedulers
- **Used in:** REPL tools, interactive debuggers, custom shells

---

## Enterprise Execution Contexts

These utilities are commonly executed in:

1. **Windows Task Scheduler**
   ```
   Program: python.exe
   Arguments: C:\scripts\5_enterprise_automation.py PROD
   ```

2. **Azure DevOps Pipeline**
   ```yaml
   - script: python 5_enterprise_automation.py PROD --reports $(Build.ArtifactStagingDirectory)
   ```

3. **Jenkins Job**
   ```groovy
   sh 'python 5_enterprise_automation.py PROD --server $SERVER_NAME'
   ```

---

## Best Practices

✓ **Validate mandatory arguments**
- Check argument count
- Validate choices (DEV/TEST/PROD)
- Verify file paths exist

✓ **Provide clear usage messages**
- Use argparse for auto-generated help
- Include examples in epilog

✓ **Return meaningful exit codes**
- 0 for success
- Non-zero for errors
- Consistent with enterprise tools

✓ **Use named arguments for production**
- `--env PROD` is clearer than `PROD`
- Easier to maintain and debug

✓ **Separate normal output and errors**
- stdout for results
- stderr for warnings/errors

✗ **Never pass passwords on command line**
- Use environment variables
- Use credential vaults
- Use secure config files

---

## Running the Examples

All examples run on Windows 11 with Python 3.x:

```bash
# Navigate to script directory
cd "d:\Kiran\Open text\Day 1\Command line"

# Run basic example
python 1_sys_argv_basics.py PROD

# Run production utility
python 5_enterprise_automation.py PROD --server CS_Server01 --reports .

# Check help
python 2_argparse_production.py --help
```

---

## References

- [Python sys module](https://docs.python.org/3/library/sys.html)
- [Python argparse module](https://docs.python.org/3/library/argparse.html)
- [Shell redirection (Windows)](https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/redirection)
- [Exit codes best practices](https://tldp.gnu.org/LDP/abs/html/exit-status.html)
