"""
Enterprise OpenText Repository Health Check Utility
Demonstrates all concepts: arguments, streams, exit codes, and redirection
"""

import sys
import argparse
import os
from datetime import datetime
from pathlib import Path

class HealthCheckUtility:
    def __init__(self, environment, server, report_path, log_level="INFO", validate_only=False):
        self.environment = environment
        self.server = server
        self.report_path = report_path
        self.log_level = log_level
        self.validate_only = validate_only
        self.checks_passed = 0
        self.checks_failed = 0

    def log(self, level, message):
        """Log to appropriate stream based on level"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {level}: {message}"

        if level in ["ERROR", "CRITICAL", "WARNING"]:
            print(log_entry, file=sys.stderr)
        else:
            print(log_entry, file=sys.stdout)

    def check_connectivity(self):
        """Simulate connectivity check"""
        self.log("INFO", f"Checking connectivity to {self.server}...")
        try:
            self.log("INFO", f"✓ Connected to {self.server} in {self.environment}")
            self.checks_passed += 1
            return True
        except Exception as e:
            self.log("ERROR", f"✗ Failed to connect: {e}")
            self.checks_failed += 1
            return False

    def check_repository(self):
        """Simulate repository validation"""
        self.log("INFO", "Validating repository integrity...")
        try:
            self.log("INFO", "✓ Repository tables intact")
            self.log("INFO", "✓ Indexes optimized")
            self.checks_passed += 2
            return True
        except Exception as e:
            self.log("ERROR", f"✗ Repository validation failed: {e}")
            self.checks_failed += 1
            return False

    def check_disk_space(self):
        """Simulate disk space check"""
        self.log("INFO", "Checking disk space...")
        if not os.path.isdir(self.report_path):
            self.log("ERROR", f"✗ Report directory not found: {self.report_path}")
            self.checks_failed += 1
            return False

        try:
            # Get disk usage
            total, used, free = 0, 0, 0  # Would get real stats in production
            self.log("INFO", f"✓ Disk space available: {free}GB")
            self.checks_passed += 1
            return True
        except Exception as e:
            self.log("ERROR", f"✗ Disk check failed: {e}")
            self.checks_failed += 1
            return False

    def generate_report(self):
        """Generate health check report"""
        report_content = f"""
=== OpenText Content Server Health Check Report ===
Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Environment: {self.environment}
Server: {self.server}
Validate Only: {self.validate_only}

Health Checks Summary:
  ✓ Passed: {self.checks_passed}
  ✗ Failed: {self.checks_failed}

Status: {'HEALTHY' if self.checks_failed == 0 else 'ISSUES DETECTED'}
"""

        try:
            report_file = Path(self.report_path) / f"health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            with open(report_file, 'w') as f:
                f.write(report_content)
            self.log("INFO", f"Report saved to: {report_file}")
            return True
        except Exception as e:
            self.log("ERROR", f"Failed to write report: {e}")
            return False

    def run(self):
        """Execute health check"""
        self.log("INFO", f"Starting health check for {self.environment}")

        # Run checks
        self.check_connectivity()
        self.check_repository()
        self.check_disk_space()

        # Generate report
        self.generate_report()

        # Return appropriate exit code
        if self.checks_failed > 0:
            self.log("ERROR", "Health check completed with issues")
            return 1
        else:
            self.log("INFO", "Health check completed successfully")
            return 0

def main():
    parser = argparse.ArgumentParser(
        description="OpenText Content Server Health Check",
        epilog="Example: python 5_enterprise_automation.py PROD --server CS_Server01 --reports D:\\Reports"
    )

    parser.add_argument("environment", choices=["DEV", "TEST", "PROD"], help="Target environment")
    parser.add_argument("--server", default="DEFAULT_SERVER", help="Server hostname")
    parser.add_argument("--reports", default=".", help="Report output directory")
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], default="INFO")
    parser.add_argument("--validate-only", action="store_true", help="Validate only - no changes")

    args = parser.parse_args()

    # Validate report directory
    if not os.path.isdir(args.reports):
        print(f"Error: Report directory not found: {args.reports}", file=sys.stderr)
        sys.exit(2)

    # Execute health check
    utility = HealthCheckUtility(
        environment=args.environment,
        server=args.server,
        report_path=args.reports,
        log_level=args.log_level,
        validate_only=args.validate_only
    )

    exit_code = utility.run()
    sys.exit(exit_code)

if __name__ == "__main__":
    main()
