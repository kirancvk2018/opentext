"""
Demonstrate argparse - Production-Grade Command Line Utilities
Topic: Named arguments, help messages, and validation
# """
# # # Simplest - required args only
# python 2_argparse_production.py check --env PROD

# # Full example
# python 2_argparse_production.py validate --env TEST --server MyServer --reports C:\Reports --log-level INFO --validate-only

# # See what arguments it needs
# python 2_argparse_production.py --help

import argparse
import sys
import os

def main():
    parser = argparse.ArgumentParser(
        description="OpenText Content Server Health Check Utility",
        epilog="Example: python 2_argparse_production.py --env PROD --server CS_Server01 --reports D:\\Reports"
    )

    # Positional arguments
    parser.add_argument(
        "action",
        choices=["check", "validate", "report"],
        help="Action to perform on the repository"
    )

    # Required named arguments
    parser.add_argument(
        "--env", "--environment",
        required=True,
        choices=["DEV", "TEST", "PROD"],
        help="Target environment"
    )

    # Optional arguments with defaults
    parser.add_argument(
        "--server",
        default="DEFAULT_SERVER",
        help="Content Server hostname (default: DEFAULT_SERVER)"
    )

    parser.add_argument(
        "--reports",
        default=".",
        help="Report output directory (default: current directory)"
    )

    # Verbose/logging level
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level (default: INFO)"
    )

    # Optional flags
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Validation only - do not make changes"
    )

    parser.add_argument(
        "--config",
        type=str,
        help="Path to configuration file"
    )

    # Parse arguments
    args = parser.parse_args()

    # Validation
    if not os.path.isdir(args.reports):
        print(f"Error: Report directory does not exist: {args.reports}", file=sys.stderr)
        sys.exit(2)

    # Display parsed configuration
    print("=== OpenText Health Check Configuration ===\n")
    print(f"Action: {args.action}")
    print(f"Environment: {args.env}")
    print(f"Server: {args.server}")
    print(f"Reports Directory: {args.reports}")
    print(f"Log Level: {args.log_level}")
    print(f"Validate Only: {args.validate_only}")
    if args.config:
        print(f"Config File: {args.config}")
    print()

    # Simulate execution
    print(f"[{args.log_level}] Starting {args.action} on {args.env} environment...")
    print(f"[{args.log_level}] Connecting to {args.server}...")

    if args.validate_only:
        print("[INFO] Running in validation-only mode - no changes will be made")

    print(f"[{args.log_level}] {args.action.capitalize()} completed successfully!")
    print(f"[{args.log_level}] Report saved to: {args.reports}")

    sys.exit(0)

if __name__ == "__main__":
    main()
