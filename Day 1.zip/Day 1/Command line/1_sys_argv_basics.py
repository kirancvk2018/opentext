"""
Demonstrate sys.argv - Command Line Arguments Basics
Topic: Understanding how Python receives runtime parameters
"""

import sys

print("=== Command Line Arguments with sys.argv ===\n")

# sys.argv is a list of command-line arguments
# sys.argv[0] is always the script name
# sys.argv[1], sys.argv[2], etc. are the arguments passed

print(f"Script name: {sys.argv[0]}")
print(f"Total arguments (including script): {len(sys.argv)}")
print(f"All arguments: {sys.argv}\n")

# Example: Repository Health Check
if len(sys.argv) < 2:
    print("Usage: python 1_sys_argv_basics.py <ENVIRONMENT> [SERVER] [REPORT_PATH]")
    print("Example: python 1_sys_argv_basics.py PROD CS_Server01 D:\\Reports")
    sys.exit(1)

environment = sys.argv[1]
server = sys.argv[2] if len(sys.argv) > 2 else "DEFAULT_SERVER"
report_path = sys.argv[3] if len(sys.argv) > 3 else "."

print("Parsed Arguments:")
print(f"  Environment: {environment}")
print(f"  Server: {server}")
print(f"  Report Path: {report_path}")

# Simulate enterprise health check
print(f"\n✓ Connecting to {environment} environment...")
print(f"✓ Validating {server}...")
print(f"✓ Report will be saved to: {report_path}")
print("\nHealth check completed successfully!")

sys.exit(0)  # Return exit code 0 for success
