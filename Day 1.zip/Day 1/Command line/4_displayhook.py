"""
Demonstrate sys.displayhook - Custom Output Formatting
Topic: Where displayhook is applicable and how to use it
"""

import sys
import json
from decimal import Decimal

print("=== sys.displayhook Demonstration ===\n")

# Default behavior (in interactive Python shell)
print("In an interactive Python shell:")
print("  >>> 2 + 2")
print("  4  (this is printed by the default displayhook)\n")

# displayhook is ONLY called in interactive mode, NOT when running a script normally
# It only prints non-None values

# Custom displayhook example - JSON formatter
def json_displayhook(value):
    """Custom displayhook that formats output as JSON"""
    if value is not None:
        # Try to format as JSON
        try:
            if isinstance(value, (dict, list)):
                print(json.dumps(value, indent=2, default=str))
            elif isinstance(value, Decimal):
                print(f"Decimal: {value}")
            else:
                print(repr(value))
        except Exception as e:
            print(f"Error formatting: {e}")

# Note: displayhook only works in interactive shell
# When running as a script, you must call it manually to demonstrate
print("Demonstrating custom displayhook behavior:\n")

# Simulate displayhook calls (normally only in interactive shell)
print("Example 1: Dictionary")
data = {"environment": "PROD", "server": "CS_Server01", "status": "healthy"}
json_displayhook(data)

print("\nExample 2: List")
servers = ["Server1", "Server2", "Server3"]
json_displayhook(servers)

print("\nExample 3: None value (displayhook ignores None)")
json_displayhook(None)

print("\nExample 4: String")
json_displayhook("Repository validation completed")

# To actually use a custom displayhook in an interactive session:
print("\n=== Setting Custom displayhook ===")
print("In an interactive Python shell, you would do:")
print("  >>> import sys")
print("  >>> sys.displayhook = json_displayhook")
print("  >>> {'key': 'value'}")
print("  {")
print('    "key": "value"')
print("  }")

# Restore default
original_displayhook = sys.__displayhook__
print(f"\nDefault displayhook: {original_displayhook}")
print(f"Current displayhook: {sys.displayhook}")

print("\n=== When displayhook is useful ===")
print("• Interactive data analysis scripts")
print("• REPL-like tools and debuggers")
print("• Custom shells and interpreters")
print("• NOT typically used in production automation scripts")
print("  (use print() or logging instead)")

sys.exit(0)
